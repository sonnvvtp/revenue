//package com.viettelpost.platform.bms.revenue.worker.service.kafka.producer.impl;
//
//import com.viettelpost.platform.bms.revenue.worker.service.kafka.consumer.RevenueConsumerService;
//import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
//import io.smallrye.mutiny.Uni;
//import io.smallrye.reactive.messaging.kafka.KafkaRecord;
//import jakarta.enterprise.context.ApplicationScoped;
//import jakarta.inject.Inject;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.eclipse.microprofile.reactive.messaging.Channel;
//import org.eclipse.microprofile.reactive.messaging.Emitter;
//
//@Slf4j
//@ApplicationScoped
//@RequiredArgsConstructor
//public class RevenueProducerImpl implements RevenueConsumerService {
//
//  @Inject
//  @Channel("bms-revenue-bill-out")
//  Emitter<BmsBillRevenueDTO> emitter;
//
//  @Override
//  public Uni<Void> produceBillRevenue(BmsBillRevenueDTO billRevenueDTO) {
////    log.info("produceBillRevenue_before: [{}]", billRevenueDTO.getBill());
//    emitter.send(KafkaRecord.of(billRevenueDTO.getBill(), billRevenueDTO));
////    log.info("produceBillRevenue_after: [{}], sent", billRevenueDTO.getBill());
//    return Uni.createFrom().voidItem();
//  }
//}
