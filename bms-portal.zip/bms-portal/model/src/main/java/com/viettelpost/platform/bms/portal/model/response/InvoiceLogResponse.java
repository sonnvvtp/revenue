package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceLogResponse {
    private List<InvoiceLogItem> data;
    private long totalRecords;
    private int totalPage;
    private int currentPage;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceLogItem {
        private Long id;
        private Long invoiceRecordId;
        private String requestAt;
        private String logRequest;
        private String logResponse;
        private Integer logStatus;
        private Integer errCode;
        private String errMsg;
        private String recordNo;
    }
} 