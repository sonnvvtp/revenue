package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class CreateInvoiceRecordRequest {
  @NotNull(message = "vui lòng điền Ids đơn")
  private List<BigDecimal> listOrderIds;
  @NotNull(message = "Vui lòng chọn doctype")
  private Long doctypeId;
  @NotNull
  private Long groupOrderId;
  @NotEmpty(message = "vui lòng chọn nhóm hóa đơn")
  private String source;
}

