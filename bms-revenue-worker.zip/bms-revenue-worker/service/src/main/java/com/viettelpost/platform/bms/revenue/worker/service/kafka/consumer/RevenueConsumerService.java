//package com.viettelpost.platform.bms.revenue.worker.service.kafka.consumer;
//
//import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
//import io.smallrye.mutiny.Uni;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.eclipse.microprofile.reactive.messaging.Message;
//
//public interface RevenueConsumerService {
//    Uni<Void> produceBillRevenue(BmsBillRevenueDTO billRevenueDTO);
//}
