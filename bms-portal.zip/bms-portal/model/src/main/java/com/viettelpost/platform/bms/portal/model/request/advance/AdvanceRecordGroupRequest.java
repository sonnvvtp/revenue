package com.viettelpost.platform.bms.portal.model.request.advance;

import lombok.Data;

@Data
public class AdvanceRecordGroupRequest {

    private String advancedFilter;

    private String docType;

    private Integer page;

    private Integer size;
}
