package com.viettelpost.platform.bms.portal.model.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BillModel {
    private Long partnerId;
    private String partnerCode;
    private Long orgId;
    private String orgCode;
    private Long postId;
    private String postCode;
    private String postName;
    private String serviceCode;
    private String profitCenter;
    private String costCenter;
    private Long amount;
    private Long recordType;
    private Long periodId;
    private Long type;
    private Long recordId;
    private String recordNo;
    private Date completedDate;
    private Date endDate;
    private Long cusId;
}
