package com.viettelpost.platform.bms.portal.model.response.forControl;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BmsDebtComparisonInternalDTO {
    @JsonAlias("comparisonid")
    public Long comparisonId;

    @JsonAlias("checkamount")
    public BigDecimal checkAmount;

    @JsonAlias("checkstatus")
    public Long checkStatus;

    @JsonAlias("collectamount")
    public BigDecimal collectAmount;

    @JsonAlias("created")
    public String created;

    @JsonAlias("createdby")
    public Long createdBy;

    @JsonAlias("debtamount")
    public BigDecimal debtAmount;

    @JsonAlias("debtdate")
    public String debtDate;

    @JsonAlias("debtstatus")
    public Long debtStatus;

    @JsonAlias("docstatus")
    public Long docStatus;

    @JsonAlias("doctype")
    public Long docType;

    @JsonAlias("ischecked")
    public Long isChecked;

    @JsonAlias("issync")
    public Long isSync;

    @JsonAlias("itemcode")
    public String itemCode;

    @JsonAlias("orgcode")
    public String orgCode;

    @JsonAlias("orgid")
    public Long orgId;

    @JsonAlias("partnerid")
    public Long partnerId;

    @JsonAlias("paycode")
    public String payCode;

    @JsonAlias("paydate")
    public String payDate;

    @JsonAlias("paystatus")
    public Long payStatus;

    @JsonAlias("postcode")
    public String postCode;

    @JsonAlias("postid")
    public Long postId;

    @JsonAlias("reqvtporderid")
    public String reqVtpOrderId;

    @JsonAlias("updateby")
    public Long updateBy;

    @JsonAlias("updated")
    public String updated;

    @JsonAlias("fullname")
    public String fullName;

    @JsonAlias("evtpcode")
    public String evtpCode;

    @JsonAlias("documentno")
    public String documentNo;

    @JsonAlias("seqnum")
    public Long seqNum;

    @JsonAlias("employeeid")
    public Long employeeId;

    @JsonAlias("bankcodepartner")
    public String bankCodePartner;

    @JsonAlias("bankcode")
    public String bankCode;

    @JsonAlias("bankdate")
    public String bankDate;

    @JsonAlias("merchanttype")
    public String merchantType;

    @JsonAlias("servicetype")
    public String serviceType;

    @JsonAlias("partnersource")
    public String partnerSource;

    @JsonAlias("requestid")
    public String requestId;

    final Integer groupType = 2;
}
