package com.viettelpost.platform.bms.portal.model.response.forControl;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SyntheticDataExternal {
    Long countReqDocStatus;
    Long amountReqDocStatus;
    Long countResDocStatus;
    Long amountResDocStatus;
}
