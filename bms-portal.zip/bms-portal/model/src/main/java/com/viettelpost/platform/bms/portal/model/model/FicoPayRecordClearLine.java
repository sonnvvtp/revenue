package com.viettelpost.platform.bms.portal.model.model;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
public class FicoPayRecordClearLine {
    Long payRecordClearLineId;
    BigDecimal payRecordClearId;
    String bill;
    BigDecimal payInId;
    BigDecimal amount;
    BigDecimal amountDeduct;
    BigDecimal payAmount;
    Long personId;
    Long partnerId;
    Long postId;
    Long orgId;
    String serviceCode;
    Long billType;
    Date dateInsert;
    Date dateBill;
    Long createdBy;
    Long updatedBy;
}
