package com.viettelpost.platform.bms.revenue.worker.model.request.general;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateBatchOrderRequest {

  private String domainType;

  @NotEmpty
  private List<GeneralOrderRequest> orders;

  @NotEmpty(message = "vui lòng điền nguồn đẩy đơn")
  private String orderSource;

  @NotNull
  private Integer tenantId;
}

