package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum IsPaidStatusEnum {
    BAO_KIM_PAID(Arrays.asList(51, 52), "Đã thu BK"),
    VCB_PAID(Arrays.asList(61, 62), "Đã thu VCB"),
    VIETTEL_MONEY_PAID(Arrays.asList(41, 42), "Đã thu TKLK"),
    OCB_PAID(Arrays.asList(87, 88), "Đã thu OCB"),
    BIDV_PAID(Arrays.asList(91, 92), "Đã thu BIDV"),
    STB_PAID(Arrays.asList(57, 58), "Đã thu SacomBank"),
    TPB_PAID(Arrays.asList(54, 55), "Đã thu TPBank"),
    HDB_PAID(Arrays.asList(64, 65), "Đã thu HDBank"),
    HPAY_PAID(Arrays.asList(97, 98), "Đã thu HPAY"),
    NA1(Collections.singletonList(3), "Đã thu"),
    NA2(Collections.singletonList(12), "Tiền mặt"),
    STATUS_UNPAID(Arrays.asList(0, 1,10,11,50,60,40,86,90,56,53,63,66,96), "Chưa thu");



    private List<Integer> code;
    private String description;


    public static IsPaidStatusEnum get(Integer code) {
        return Arrays.stream(IsPaidStatusEnum.values())
                .filter(e -> Objects.requireNonNull(e.getCode()).contains(code))
                .findFirst()
                .orElse(STATUS_UNPAID);
    }

    public static List<Integer> getAllCodesExceptUnpaid() {
        return Arrays.stream(IsPaidStatusEnum.values())
                .filter(e -> e != STATUS_UNPAID) // Loại bỏ STATUS_UNPAID
                .flatMap(e -> e.getCode().stream()) // Trích xuất List<Integer>
                .collect(Collectors.toList());
    }
}