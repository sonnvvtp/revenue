package com.viettelpost.platform.bms.revenue.worker.model.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DiscountResultModel {

    private BigDecimal result;

    private String drl;

    private Long discountPackageRuleId;

    private Long discountCalLogId;

    // Mã KH phân bổ kết quả ck theo nấc
    private String evtpCode;

}
