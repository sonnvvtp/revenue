package com.viettelpost.platform.bms.portal.model.response.debttransfer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PrintDebtTransferReportResponse {

    private List<DebtTransferReportResponse> data;

    private BigDecimal totalAmt;

    private BigDecimal totalAmtDeduct;

    private BigDecimal totalAmtDeductOther;

    private BigDecimal totalAmtPay;

    private LocalDate now;

}
