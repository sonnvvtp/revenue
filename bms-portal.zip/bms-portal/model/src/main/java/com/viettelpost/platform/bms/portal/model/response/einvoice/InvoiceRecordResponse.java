package com.viettelpost.platform.bms.portal.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.viettelpost.platform.bms.portal.common.config.CustomLocalDateTimeDeserializer;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceRecordResponse {
    @JsonAlias("id")
    private BigDecimal id;

    @JsonAlias("record_status")
    private Integer recordStatus;

    @JsonAlias("record_no")
    private String recordNo;

    @JsonAlias("unit_level1_id")
    private String unitLevel1Id;

    @JsonAlias("unit_level2_id")
    private String unitLevel2Id;

    @JsonAlias("buyer_id")
    private Long buyerId;

    @JsonAlias("buyer_code")
    private String buyerCode;

    @JsonAlias("payment_method")
    private String paymentMethod;

    @JsonAlias("tax_percent")
    private Integer taxPercent;

    @JsonAlias("email")
    private String email;

    @JsonAlias("phone")
    private String phone;

    @JsonAlias("tax_code")
    private String taxCode;

    @JsonAlias("account_no")
    private String accountNo;

    @JsonAlias("customer_name")
    private String customerName;

    @JsonAlias("address")
    private String address;

    @JsonAlias("invoice_type")
    private String invoiceType;

    @JsonAlias("invoice_number")
    private String invoiceNumber;

    @JsonAlias("invoice_serial")
    private String invoiceSerial;

    @JsonAlias("invoice_form")
    private String invoiceForm;

    @JsonAlias("invoice_ref_id")
    private BigDecimal invoiceRefId;

    @JsonAlias("record_type_id")
    private BigDecimal recordTypeId;

    @JsonAlias("amount_before_tax")
    private BigDecimal amountBeforeTax;

    @JsonAlias("amount_tax")
    private BigDecimal amountTax;

    @JsonAlias("amount_deduct")
    private BigDecimal amountDeduct;

    @JsonAlias("amount_total")
    private BigDecimal amountTotal;

    @JsonAlias("company_code")
    private String companyCode;

    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    @JsonAlias("invoice_export_date")
    private LocalDateTime invoiceExportDate;

    @JsonAlias("invoice_url")
    private String invoiceUrl;

    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    @JsonAlias("created_at")
    private LocalDateTime createdAt;

    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    @JsonAlias("accounting_date")
    private LocalDateTime accountingDate;

    @JsonAlias("unit_name")
    private String unitName;
}
