package com.viettelpost.platform.bms.revenue.worker.service;

import io.smallrye.mutiny.Uni;

public interface GloExpRevenueService {
    Uni<Void> pusAllBillToRevenue();

    Uni<Void> pusRevenueToAccountingSap();

    // Doanh thu chưa hoàn thành
    Uni<Void>  accountingUnfinishedRevenue();
    // Doanh thu chiết khấu chưa hoàn thành
//    Uni<Void> accountingUnfinishedDiscountRevenue();
    // Doanh thu hoàn thành - loại ko có trạng thái cuối
    Uni<Void> accountingCompletedRevenueNoEnding();
    // Doanh thu hoàn thành - có trạng thái cuối
    Uni<Void> accountingCompletedRevenueWithEnding();
//    // Doanh thu nội bộ
//    Uni<Void> accountingInternalRevenue();
    // Doanh thu chiết khấu hoàn thành  - loại ko có trạng thái cuối
//    Uni<Void> accountingCompletedDiscountRevenueNoEnding();
//    // Doanh thu chiết khấu hoàn thành  - có trạng thái cuối
//    Uni<Void> accountingCompletedDiscountRevenueWithEnding();
}
