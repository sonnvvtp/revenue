package com.viettelpost.platform.bms.portal.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.viettelpost.platform.bms.portal.common.config.CustomLocalDateTimeDeserializer;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import jdk.jfr.Description;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FindInvoiceOrderResponse {
    @JsonAlias("id")
    public BigDecimal id;

    @JsonAlias("tenant_id")
    public Integer tenantId;

    @JsonAlias("created_by")
    public Long createdBy;

    @JsonAlias("created_at")
    public LocalDateTime createdAt;

    @JsonAlias("updated_by")
    public Long updatedBy;

    @JsonAlias("updated_at")
    public LocalDateTime updatedAt;

    @JsonAlias("order_id")
    public String orderId;

    @Description("Mã đơn hàng")
    @JsonAlias("order_code")
    public String orderCode;

    @JsonAlias("order_reference")
    public String orderReference;

    @Description("loại thu hộ")
    @JsonAlias("cashflow_type")
    public String cashflowType;

    @Description("mã dịch vụ")
    @JsonAlias("service_code")
    public String serviceCode;

    @Description("Ngày tạo đơn")
    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    @JsonAlias("order_created_at")
    public LocalDateTime orderCreatedAt;

    @Description("Ngày phát thành công")
    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    @JsonAlias("order_delivered_at")
    public LocalDateTime orderDeliveredAt;

    @Description("id bưu tá")
    @JsonAlias("employee_id")
    public Long employeeId;

    @Description("Thông tin bưu tá")
    @JsonAlias("employee_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> employeeInfo;

    @Description("id chi nhánh")
    @JsonAlias("unit_level1_id")
    public Long unitLevel1Id;

    @Description("id bưu cục")
    @JsonAlias("unit_level2_id")
    public Long unitLevel2Id;

    @Description("Thông tin chi nhánh")
    @JsonAlias("unit_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> unitInfo;

    @Description("Mã công ty")
    @Builder.Default
    @JsonAlias("company_code")
    public String companyCode = "4000";

    @Description("cus id - Bắt buộc với đơn chuyển phát")
    @JsonAlias("seller_id")
    public Long sellerId;

    @Description("Mã khách hàng E2 - Bắt buộc với đơn chuyển phát")
    @JsonAlias("seller_code")
    public String sellerCode;

    @Description("thông tin người bán")
    @JsonAlias("seller_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> sellerInfo;

    @JsonAlias("buyer_id")
    public Long buyerId;

    @JsonAlias("buyer_code")
    public String buyerCode;

    @Description("thông tin người mua")
    @JsonAlias("buyer_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> buyerInfo;
/*
    @JsonAlias("consignee_id")
    public Long consigneeId;

    @Description("thông tin người nhận")
    @JsonAlias("consignee")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> consignee;
*/

    @Description("Tổng số sản phẩm của đơn hàng")
    @JsonAlias("order_total_quantity")
    public Long orderTotalQuantity;

    @Description("Thành tiền đơn hàng trước thuế")
    @JsonAlias("order_amount_before_tax")
    public BigDecimal orderAmountBeforeTax;

    @Description("Tiền thuế của đơn hàng")
    @JsonAlias("order_tax_amount")
    public BigDecimal orderTaxAmount;

    @Description("Thành tiền đơn hàng sau thuế")
    @JsonAlias("order_amount_after_tax")
    public BigDecimal orderAmountAfterTax;

    @Description("")
    @JsonAlias("total_amount")
    public BigDecimal totalAmount;

    @Description("Trạng thái thanh toán: 0: chưa thanh toán - 1: đã thanh toán")
    @JsonAlias("payment_status")
    public Integer paymentStatus;

    public String paymentStatusName;

    @Description("Thông tin thanh toán")
    @JsonAlias("payment_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> paymentInfo;

    @Description("Phương thức thanh toán (1:tiền mặt/2:chuyển khoản/3: tiền mặt/ chuyển khoản")
    @JsonAlias("payment_method")
    public Integer paymentMethod;
    public String paymentMethodName;

    @Description("Loại thanh toán(0-người gửi trả cước,1-người nhận trả cước, 2-người gửi trả cước sau)")
    @JsonAlias("payment_term_id")
    public Integer paymentTermId;

    @Description("Trạng thái đồng bộ doanh thu")
    @JsonAlias("revenue_sync_status")
    public Integer revenueSyncStatus;

    @Description("Trạng thái xuất hóa đơn")
    @JsonAlias("invoice_status")
    public Integer invoiceStatus;

    @Description("Đối tác xuất hóa đơn")
    @Builder.Default
    @JsonAlias("invoice_partner")
    public String invoicePartner = "V-invoice";

    @JsonAlias("currency")
    public String currency;

    @JsonAlias("order_source")
    public String orderSource;

    @JsonAlias("invoice_buyer_id")
    public BigDecimal invoiceBuyerId;

    @JsonAlias("buyer_type")
    public String buyerType;

    @Builder.Default
    @JsonAlias("buyer_name")
    public String buyerName = "Người mua không lấy hóa đơn";

    @JsonAlias("partner_name")
    public String partnerName;

    @JsonAlias("buyer_phone")
    public String buyerPhone;

    @JsonAlias("buyer_email")
    public String buyerEmail;

    @JsonAlias("buyer_tax_code")
    public String buyerTaxCode;

    @JsonAlias("buyer_address")
    public String buyerAddress;

    @JsonAlias("buyer_bank_account")
    public String buyerBankAccount;

    @JsonAlias("buyer_bank_name")
    public String buyerBankName;

    public String getPaymentStatusName() {
        if (paymentStatus == null) {
            return paymentStatusName;
        }
        switch (paymentStatus) {
            case 1:
                return "Đã thanh toán";
            case 2:
                return "Chưa thanh toán";
            default:
                return "";
        }
    }

    public String getPaymentMethodName() {
        if (paymentMethod == null) {
            return paymentMethodName;
        }
        switch (paymentMethod) {
            case 1:
                return "TM";
            case 2:
                return "CK";
            default:
                return "TM/CK";
        }
    }
}
