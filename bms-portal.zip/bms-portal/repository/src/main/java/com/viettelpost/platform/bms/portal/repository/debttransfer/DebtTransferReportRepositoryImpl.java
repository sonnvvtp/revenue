package com.viettelpost.platform.bms.portal.repository.debttransfer;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.DebtTransferReportRequest;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.FindListBatchDebtDetailRequest;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.FindListBatchDebtRequest;
import com.viettelpost.platform.bms.portal.model.response.debttransfer.*;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

@ApplicationScoped
@RequiredArgsConstructor
public class DebtTransferReportRepositoryImpl implements DebtTransferReportRepository {

    private final ConnectionPool oracleClient;

    private final AuthenticationContext authCtx;

    @Override
    public Multi<DebtTransferReportResponse> getReportDebtTransfer(DebtTransferReportRequest debtTransferReportRequest) {
        Integer docStatus = debtTransferReportRequest.getDocStatus();
        String sql = """
                SELECT *
                    FROM (
                        SELECT /*+ parallel(16)*/
                            CASE
                                WHEN A.Docstatus IN (22, 10, 11, 12, 1, 2)
                                THEN 'Nhận Nợ Chưa Thu'
                                WHEN A.Docstatus = 3
                                THEN 'Nhận Nợ Đã Thu'
                            END AS DEBT_TYPE_NAME,
                            (SELECT orgName FROM ERP_AC.Hr_organization WHERE Org_ID = A.ORG_ID) ORG_NAME,
                            (SELECT Post_Name FROM ERP_AC.HR_POSTCODE WHERE Post_ID = A.Post_ID) POST_NAME,
                            (SELECT orgName FROM ERP_AC.Hr_organization WHERE Org_ID = A.ORG_TO_ID) ORG_NAME_TO,
                            (SELECT Post_Name FROM ERP_AC.HR_POSTCODE WHERE Post_ID = A.POST_TO_ID) POST_NAME_TO,
                            A.Documentno AS DOCUMENT_NO,
                            NULL AS M_PRODUCT,
                            TO_CHAR (A.Dateacct, 'dd/mm/yyyy') ACCOUNTING_DATE,
                            (SELECT Name FROM ERP_AC.Erp_period WHERE period_id = B.PERIOD_ID) PERIOD_NAME,
                            B.Partner_evtp AS PARTNER_EVTP,
                            (SELECT Name FROM ERP_AC.Erp_partner WHERE VALUE = B.Partner_evtp) PARTNER_NAME,
                            A.Partner_evtp_To AS PARTNER_EVTP_TO,
                            (SELECT Name FROM ERP_AC.Erp_partner WHERE VALUE = A.Partner_evtp_To) PARTNER_NAME_TO,
                            'CPN' AS DESCRIPTION,
                            COALESCE(SUM (B.amt), 0) AMT,
                            COALESCE(SUM (B.amt_deduct), 0) AMT_DEDUCT,
                            COALESCE(SUM (B.amt_deduct_other), 0) AMT_DEDUCT_OTHER,
                            COALESCE(SUM (B.amt_pay), 0) AMT_PAY
                        FROM ERP_AC.ERP_CLEAR A, ERP_AC.ERP_CLEARLINE B
                        WHERE A.CLEAR_ID = B.CLEAR_ID
                        AND A.Docstatus in (:docStatusList)
                        AND A.Doctype_ID = 20
                        %s
                        AND A.Dateacct between :fromDate and :toDate
                        AND B.M_Product NOT IN ('VLC', 'VLF', 'VLK', 'VNB')
                        GROUP BY A.ORG_ID, A.Post_ID, A.ORG_TO_ID, A.POST_TO_ID, A.Documentno, B.PERIOD_ID, B.Partner_evtp, A.Partner_evtp_To, TO_CHAR (A.Dateacct, 'dd/mm/yyyy'), A.Docstatus
                        UNION
                        SELECT /*+ parallel(16)*/
                            CASE
                                WHEN A.Docstatus IN (22, 10, 11, 12, 1, 2)
                                THEN 'Nhận Nợ Chưa Thu'
                                WHEN A.Docstatus = 3
                                THEN 'Nhận Nợ Đã Thu'
                            END AS DEBT_TYPE_NAME,
                            (SELECT orgName FROM ERP_AC.Hr_organization WHERE Org_ID = A.ORG_ID) ORG_NAME,
                            (SELECT Post_Name FROM ERP_AC.HR_POSTCODE WHERE Post_ID = A.Post_ID) POST_NAME,
                            (SELECT orgName FROM ERP_AC.Hr_organization WHERE Org_ID = A.ORG_TO_ID) ORG_NAME_TO,
                            (SELECT Post_Name FROM ERP_AC.HR_POSTCODE WHERE Post_ID = A.POST_TO_ID) POST_NAME_TO,
                            A.Documentno AS DOCUMENT_NO,
                            NULL AS M_PRODUCT,
                            TO_CHAR (A.Dateacct, 'dd/mm/yyyy') ACCOUNTING_DATE,
                            (SELECT Name FROM ERP_AC.Erp_period WHERE period_id = B.PERIOD_ID) PERIOD_NAME,
                            B.PARTNER_EVTP,
                            (SELECT Name FROM ERP_AC.Erp_partner WHERE VALUE = B.Partner_evtp) PARTNER_NAME,
                            A.PARTNER_EVTP_TO,
                            (SELECT Name FROM ERP_AC.Erp_partner WHERE VALUE = A.Partner_evtp_To) PARTNER_NAME_TO,
                            'LOG' AS DESCRIPTION,
                            COALESCE(SUM (B.amt), 0) AMT,
                            COALESCE(SUM (B.amt_deduct), 0) AMT_DEDUCT,
                            COALESCE(SUM (B.amt_deduct_other), 0) AMT_DEDUCT_OTHER,
                            COALESCE(SUM (B.amt_pay), 0) AMT_PAY
                        FROM ERP_AC.ERP_CLEAR A, ERP_AC.ERP_CLEARLINE B
                        WHERE A.CLEAR_ID = B.CLEAR_ID
                        AND A.Docstatus in (:docStatusList)
                        AND A.Doctype_ID = 20
                        %s
                        AND A.Dateacct between :fromDate and :toDate
                        AND B.M_Product IN ('VLC', 'VLF', 'VLK')
                        GROUP BY A.ORG_ID, A.Post_ID, A.ORG_TO_ID, A.POST_TO_ID, A.Documentno, B.PERIOD_ID, B.Partner_evtp, A.Partner_evtp_To, TO_CHAR (A.Dateacct, 'dd/mm/yyyy'), A.Docstatus
                        UNION
                        SELECT /*+ parallel(16)*/
                            CASE
                                WHEN A.Docstatus IN (22, 10, 11, 12, 1, 2)
                                THEN 'Nhận Nợ Chưa Thu'
                                WHEN A.Docstatus = 3
                                THEN 'Nhận Nợ Đã Thu'
                            END AS DEBT_TYPE_NAME,
                            (SELECT orgName FROM ERP_AC.Hr_organization WHERE Org_ID = A.ORG_ID) ORG_NAME,
                            (SELECT Post_Name FROM ERP_AC.HR_POSTCODE WHERE Post_ID = A.Post_ID)  POST_NAME,
                            (SELECT orgName FROM ERP_AC.Hr_organization WHERE Org_ID = A.ORG_TO_ID) ORG_NAME_TO,
                            (SELECT Post_Name FROM ERP_AC.HR_POSTCODE WHERE Post_ID = A.POST_TO_ID) POST_NAME_TO,
                            A.Documentno AS DOCUMENT_NO,
                            NULL AS M_PRODUCT,
                            TO_CHAR (A.Dateacct, 'dd/mm/yyyy') ACCOUNTING_DATE,
                            (SELECT Name FROM ERP_AC.Erp_period WHERE period_id = B.PERIOD_ID) PERIOD_NAME,
                            B.PARTNER_EVTP,
                            (SELECT Name FROM ERP_AC.Erp_partner WHERE VALUE = B.Partner_evtp) PARTNER_NAME,
                            A.PARTNER_EVTP_TO,
                            (SELECT Name FROM ERP_AC.Erp_partner WHERE VALUE = A.Partner_evtp_To) PARTNER_NAME_TO,
                            'NB' AS DESCRIPTION,
                            COALESCE(SUM (B.amt), 0) AMT,
                            COALESCE(SUM (B.amt_deduct), 0) AMT_DEDUCT,
                            COALESCE(SUM (B.amt_deduct_other), 0) AMT_DEDUCT_OTHER,
                            COALESCE(SUM (B.amt_pay), 0) AMT_PAY
                            FROM ERP_AC.ERP_CLEAR A, ERP_AC.ERP_CLEARLINE B
                            WHERE A.CLEAR_ID = B.CLEAR_ID
                            AND A.Docstatus in (:docStatusList)
                            AND A.Doctype_ID = 20
                            %s
                            AND A.Dateacct between :fromDate and :toDate
                            AND B.M_Product IN ('VNB')
                        GROUP BY A.ORG_ID, A.Post_ID, A.ORG_TO_ID, A.POST_TO_ID, A.Documentno, B.PERIOD_ID, B.Partner_evtp, A.Partner_evtp_To, TO_CHAR (A.Dateacct, 'dd/mm/yyyy'), A.Docstatus
                ) ORDER BY POST_NAME, LENGTH (DOCUMENT_NO), DOCUMENT_NO
                """;

        String placeholder = "";

        Map<String, Object> params = new HashMap<>();
        if (Objects.nonNull(debtTransferReportRequest.getPostId())) {
            placeholder = "AND A.Post_ID = :postId ";
            params.put("postId", debtTransferReportRequest.getPostId());
        }

        params.put("fromDate", LocalDateTime.of(debtTransferReportRequest.getFromDate(), LocalTime.MIN));
        params.put("toDate", LocalDateTime.of(debtTransferReportRequest.getToDate(), LocalTime.MAX));

        List<Integer> docStatusList;
        if (Objects.equals(docStatus, 0)) { // Nhận Nợ Chưa Thu
            docStatusList = List.of(22, 10, 11, 12, 1, 2);
        } else if (Objects.equals(docStatus, 1)) { // Nhận Nợ Đã Thu
            docStatusList = List.of(3);
        } else { // Chạy tất
            docStatusList = List.of(22, 10, 11, 12, 1, 2, 3);
        }
        params.put("docStatusList", docStatusList);
        sql = sql.formatted(placeholder, placeholder, placeholder);

        return executeMulti(oracleClient, sql, params, DebtTransferReportResponse.class);
    }

    @Override
    public Uni<Integer> findListBillDebtCount(FindListBatchDebtRequest findListBatchDebtRequest) {

        String sql = """
                SELECT
                    count(1) as count
                FROM ERP_AC.ERP_CLEAR_BATCH A
                where Org_ID in (:orgId)
                AND DOCTYPE_ID = :docTypeId
                %s
                And Datetrx between :fromDate and :toDate
                """;

        String placeholder = "";
        Map<String, Object> params = new HashMap<>();
        if (!StringUtils.isBlank(findListBatchDebtRequest.getBatchNo())) {
            placeholder = " And (:batchNo = 'XXX' or  Documentno = :batchNo) ";
            params.put("batchNo", findListBatchDebtRequest.getBatchNo());
        }

        params.put("orgId", findListBatchDebtRequest.getOrgId());
        params.put("docTypeId", findListBatchDebtRequest.getDocTypeId());
        params.put("fromDate", LocalDateTime.of(findListBatchDebtRequest.getFromDate(), LocalTime.MIN));
        params.put("toDate", LocalDateTime.of(findListBatchDebtRequest.getToDate(), LocalTime.MAX));

        sql = sql.formatted(placeholder);

        return executeAndGetValue(oracleClient, sql, params, "count", Integer.class);
    }

    @Override
    public Multi<FindListBatchDebtResponse> findListBillDebt(FindListBatchDebtRequest findListBatchDebtRequest) {

        String sql = """
                select * from (
                    SELECT
                        ROW_NUMBER() OVER (ORDER BY Docstatus,CLEAR_BATCH_ID DESC ) AS rn,
                        DOCSTATUS as DOCSTATUS_ID,
                        (CASE
                            WHEN DOCSTATUS  = 0 THEN 'Tạo Mới'
                            WHEN DOCSTATUS = 1 THEN 'Chốt thu'
                            WHEN DOCSTATUS = 2 THEN 'Đã Thu'
                            WHEN DOCSTATUS = 12 THEN 'ĐB EVIET'
                        END) AS  DOCSTATUS ,
                        DOCUMENTNO,
                        to_char(DATETRX,'dd/mm/yyyy HH24:mi') as PAYMENT_DATE,
                        to_char(Dateacct,'dd/mm/yyyy') as ACCOUNTING_DATE,
                        DESCRIPTION,
                        PERSON_ID,
                        GET_FULLNAME(A.PERSON_ID)  AS EMPLOYEENAME,
                        GET_FULLNAME(A.ACCOUNTANT_ID)  AS ACCOUNTANT_NAME,
                        TOTALAMT,
                        TOTALAMT_PAY,
                        CLEAR_BATCH_ID
                    FROM ERP_AC.ERP_CLEAR_BATCH A
                    where Org_ID in (:orgId)
                    AND DOCTYPE_ID = :docTypeId
                    %s
                    And Datetrx between :fromDate and :toDate
                ) where rn between :fromIndex and :toIndex
                """;

        String placeholder = "";
        Map<String, Object> params = new HashMap<>();
        if (!StringUtils.isBlank(findListBatchDebtRequest.getBatchNo())) {
            placeholder = " And (:batchNo = 'XXX' or  Documentno = :batchNo) ";
            params.put("batchNo", findListBatchDebtRequest.getBatchNo());
        }

        int page = Objects.nonNull(findListBatchDebtRequest.getPage()) ? findListBatchDebtRequest.getPage() : 1;
        int size = Objects.nonNull(findListBatchDebtRequest.getSize()) ? findListBatchDebtRequest.getSize() : 10;

        int fromIndex = (page - 1) * size + 1;
        int toIndex = fromIndex + size - 1;


        params.put("orgId", findListBatchDebtRequest.getOrgId());
        params.put("docTypeId", findListBatchDebtRequest.getDocTypeId());
        params.put("fromDate", LocalDateTime.of(findListBatchDebtRequest.getFromDate(), LocalTime.MIN));
        params.put("toDate", LocalDateTime.of(findListBatchDebtRequest.getToDate(), LocalTime.MAX));
        params.put("fromIndex", fromIndex);
        params.put("toIndex", toIndex);

        sql = sql.formatted(placeholder);

        return executeMulti(oracleClient, sql, params, FindListBatchDebtResponse.class);
    }

    @Override
    public Uni<Integer> findListBillDebtDetailCount(FindListBatchDebtDetailRequest findListBillDebtRequest) {
        String sql = """
                SELECT
                    count(1) as count
                FROM ERP_AC.ERP_CLEAR_BATCHLINE A, ERP_AC.ERP_CLEAR B
                WHERE A.CLEAR_ID=B.CLEAR_ID AND A.CLEAR_BATCH_ID=:clearBatchId
                %s
                """;

        Map<String, Object> params = new HashMap<>();

        params.put("clearBatchId", findListBillDebtRequest.getClearBatchId());
        String placeholder = "";
        if (!StringUtils.isBlank(findListBillDebtRequest.getAdvancedFilter())) {
            placeholder = " and A.Partner_evtp = :advancedFilter ";
            params.put("advancedFilter", findListBillDebtRequest.getAdvancedFilter());
        }

        sql = sql.formatted(placeholder);

        return executeAndGetValue(oracleClient, sql, params, "count", Integer.class);
    }

    @Override
    public Multi<FindListBatchDebtDetailResponse> findListBillDebtDetail(FindListBatchDebtDetailRequest findListBillDebtRequest) {

        String sql = """
                select * from (
                    SELECT
                        ROW_NUMBER() OVER (ORDER BY CLEAR_BATCHLINE_ID DESC ) AS rn,
                        A.CLEAR_BATCH_ID,
                        A.CLEAR_BATCHLINE_ID,
                        B.DOCUMENTNO,
                        to_char(B.DATETRX,'dd/mm/yyyy HH24:mi') PAYMENT_DATE,
                        B.DATEACCT ACCOUNTING_DATE,
                        B.GRANDAMT,
                        B.GRANDAMT_PAY,
                        A.PARTNER_EVTP,
                        (select Name from erp_partner F where F.Value=A.Partner_evtp) PARTNER_NAME
                    FROM ERP_AC.ERP_CLEAR_BATCHLINE A, ERP_AC.ERP_CLEAR B
                    WHERE A.CLEAR_ID=B.CLEAR_ID AND A.CLEAR_BATCH_ID=:clearBatchId
                    %s
                ) where rn between :fromIndex and :toIndex
                """;

        Map<String, Object> params = new HashMap<>();
        int page = Objects.nonNull(findListBillDebtRequest.getPage()) ? findListBillDebtRequest.getPage() : 1;
        int size = Objects.nonNull(findListBillDebtRequest.getSize()) ? findListBillDebtRequest.getSize() : 10;

        int fromIndex = (page - 1) * size + 1;
        int toIndex = fromIndex + size - 1;
        params.put("fromIndex", fromIndex);
        params.put("toIndex", toIndex);

        params.put("clearBatchId", findListBillDebtRequest.getClearBatchId());
        String placeholder = "";
        if (!StringUtils.isBlank(findListBillDebtRequest.getAdvancedFilter())) {
            placeholder = " and A.Partner_evtp = :advancedFilter ";
            params.put("advancedFilter", findListBillDebtRequest.getAdvancedFilter());
        }

        sql = sql.formatted(placeholder);

        return executeMulti(oracleClient, sql, params, FindListBatchDebtDetailResponse.class);
    }

    @Override
    public Multi<BatchDetailDebtReportResponse> getReportListBatchDetailDebt(FindListBatchDebtDetailRequest findListBillDebtRequest) {

        String sql = """
                select
                    a.*,
                    a.TYPE || '-' || a.PERIOD_NAME as NOTE,
                    (number2wordvn(sum(AMT_PAY)  over())) as TOTAL_AMT_PAY_STRING
                from (
                    select
                        A.DOCUMENTNO,
                        A.DOCTYPE_ID,
                        A.DOCSTATUS,
                        C.DOCUMENTNO BATCH_NO,
                        (select Name from ERP_AC.Erp_period where period_id=D.PERIOD_ID) PERIOD_NAME,
                        D.PARTNER_EVTP,
                        (select Name from ERP_AC.Erp_partner where Value=D.Partner_evtp) PARTNER_NAME,
                        to_char(A.dateacct,'dd/mm/yyyy') ACCOUNTING_DATE,
                        'CPN' TYPE,
                        Sum(D.amt) AMT,
                        Sum(D.amt_deduct) AMT_DEDUCT,
                        Sum(D.amt_deduct_other) AMT_DEDUCT_OTHER,
                        sum(D.amt_pay) AMT_PAY
                    from ERP_AC.erp_clear_batch A, ERP_AC.erp_clear_batchLine B, ERP_AC.erp_clear C, ERP_AC.erp_clearLine D
                    where A.Clear_batch_ID=B.Clear_batch_ID
                    and B.Clear_ID=C.Clear_ID
                    and C.Clear_ID=D.Clear_ID
                    And D.M_Product not in ('VLC','VLF','VLK','VNB')
                    and A.CLEAR_BATCH_ID = :clearBatchId
                    Group by A.ORG_ID,A.DOCUMENTNO,A.DOCTYPE_ID,A.Docstatus,C.DOCUMENTNO,D.PERIOD_ID,D.Partner_evtp,to_char(A.dateacct,'dd/mm/yyyy')
                    Union
                    select
                        A.DOCUMENTNO,
                        A.DOCTYPE_ID,
                        A.DOCSTATUS,
                        C.DOCUMENTNO BATCH_NO,
                        (select Name from ERP_AC.Erp_period where period_id=D.PERIOD_ID) PERIOD_NAME,
                        D.PARTNER_EVTP,
                        (select Name from ERP_AC.Erp_partner where Value=D.Partner_evtp) PARTNER_NAME,
                        to_char(A.dateacct,'dd/mm/yyyy') ACCOUNTING_DATE,
                        'VLOG' TYPE,
                        Sum(D.amt) AMT,
                        Sum(D.amt_deduct) AMT_DEDUCT,
                        Sum(D.amt_deduct_other) AMT_DEDUCT_OTHER,
                        sum(D.amt_pay) AMT_PAY
                    from ERP_AC.erp_clear_batch A, ERP_AC.erp_clear_batchLine B, ERP_AC.erp_clear C, ERP_AC.erp_clearLine D
                    where A.Clear_batch_ID=B.Clear_batch_ID
                    and B.Clear_ID=C.Clear_ID
                    and C.Clear_ID=D.Clear_ID
                    And D.M_Product  in ('VLC','VLF','VLK') --'VNB',
                    and A.CLEAR_BATCH_ID = :clearBatchId
                    Group by A.ORG_ID,A.DOCUMENTNO,A.DOCTYPE_ID,A.Docstatus,C.DOCUMENTNO,D.PERIOD_ID,D.Partner_evtp,to_char(A.dateacct,'dd/mm/yyyy')
                    Union
                    select
                        A.DOCUMENTNO,
                        A.DOCTYPE_ID,
                        A.DOCSTATUS,
                        C.DOCUMENTNO BATCH_NO,
                        (select Name from ERP_AC.Erp_period where period_id=D.PERIOD_ID) PERIOD_NAME,
                        D.PARTNER_EVTP,
                        (select Name from ERP_AC.Erp_partner where Value=D.Partner_evtp) PARTNER_NAME,
                        to_char(A.dateacct,'dd/mm/yyyy') ACCOUNTING_DATE,
                        'VNB' TYPE,
                        Sum(D.amt) AMT,
                        Sum(D.amt_deduct) AMT_DEDUCT,
                        Sum(D.amt_deduct_other) AMT_DEDUCT_OTHER,
                        sum(D.amt_pay) AMT_PAY
                    from ERP_AC.erp_clear_batch A, ERP_AC.erp_clear_batchLine B, ERP_AC.erp_clear C, ERP_AC.erp_clearLine D
                    where A.Clear_batch_ID=B.Clear_batch_ID
                    and B.Clear_ID=C.Clear_ID
                    and C.Clear_ID=D.Clear_ID
                    And D.M_Product  in ('VNB') --'VNB',
                    and A.CLEAR_BATCH_ID = :clearBatchId
                    Group by A.ORG_ID,A.DOCUMENTNO,A.DOCTYPE_ID,A.Docstatus,C.DOCUMENTNO,D.PERIOD_ID,D.Partner_evtp,to_char(A.dateacct,'dd/mm/yyyy')
                ) a
                """;

        Map<String, Object> params = new HashMap<>();
        params.put("clearBatchId", findListBillDebtRequest.getClearBatchId());

        return executeMulti(oracleClient, sql, params, BatchDetailDebtReportResponse.class);
    }

    @Override
    public Multi<DocTypeBatchResponse> findDocTypeBatchList() {
        String sql = """
                select
                    DOCTYPE_ID,
                    NAME
                From ERP_AC.ERP_Doctype where Doctype_ID in (
                    Select Distinct(Doctype_ID) From ERP_AC.ERP_Clear_batch
                )
                """;
        return executeMulti(oracleClient, sql, Collections.emptyList(), DocTypeBatchResponse.class);
    }
}
