package com.viettelpost.platform.bms.portal.model.response.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.viettelpost.platform.bms.portal.common.config.CustomLocalDateTimeDeserializer;
import com.viettelpost.platform.bms.portal.model.dto.advance.AdvanceBusinessDetailAcctDTO;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class AdvanceDetailAcctResponse {

    private String businessName;

    @JsonAlias("ref_doc_no")
    private String refDocNo;

    @JsonAlias("bk_c1")
    private String bkC1;

    @JsonAlias("bk_c2")
    private String bkC2;

    @JsonAlias("bk_c3")
    private String bkC3;

    @JsonAlias("acct_batch_id")
    private Long batchId;

    @JsonAlias("document_no")
    private String documentNo;

    @JsonAlias("acct_time")
    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    private LocalDateTime accountingDate;

    @JsonAlias("status")
    private Integer status;

    private String statusName;

    @JsonAlias("sub_details")
    private List<AdvanceBusinessDetailAcctDTO> subDetails;
}
