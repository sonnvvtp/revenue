package com.viettelpost.platform.bms.revenue.worker.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueRecordStatus;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueStatementStatus;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BillEvtpPayInDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueRecordDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RecordDto;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueRecordEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueServiceGroupEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLevel2Entity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLevel2LineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.request.accounting.RawAcctDetailRequest;
import com.viettelpost.platform.bms.revenue.worker.repository.CalculationRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.repository.GloExpRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.service.RevenueVTPService;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class RevenueVTPServiceImpl implements RevenueVTPService {

    private final CalculationRevenueRepository calculationRevenueRepository;

    private final PgPool pool;

    private final GloExpRevenueRepository gloExpRevenueRepository;

    private final ObjectMapper objectMapper;

    @ConfigProperty(name = "job.calculation.discount.batch.handle.size", defaultValue = "1000000")
    Integer batchBillHandleSize;

    @ConfigProperty(name = "config.revenue.request.type", defaultValue = "1")
    List<Integer> revenueRequestType;

    @ConfigProperty(name = "config.revenue.domain.type", defaultValue = "REVENUE_VTP")
    String revenueDomainType;

    @ConfigProperty(name = "config.revenue.company.code", defaultValue = "1000")
    String companyCode;

    @ConfigProperty(name = "config.revenue.business.id", defaultValue = "19")
    Integer revenueBusinessId;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy");

    @Override
    public Uni<Void> processRevenueEveryMonth() {
        long currentTime = System.currentTimeMillis();
        return gloExpRevenueRepository.findRevenuePeriodControlBy("P")
            .collect().asList()
            .flatMap(periods -> {
              log.info("revenue_periods_size: {}", periods.size());
              if (periods.isEmpty()) {
                log.info("revenue_periods_is_empty");
                return Uni.createFrom().voidItem();
              }
              RevenuePeriodControlEntity revenuePeriod = periods.getFirst();
              LocalDate startOfMonth = getLocalDateBy(revenuePeriod.getStartDate());
              return groupByBillRevenueBy(revenuePeriod.getPeriodId(), revenueDomainType, RevenueType.TEMPORARY_REVENUE, startOfMonth) // ghi nhận doanh thu chưa hoàn thành
                  .flatMap(result1 -> groupByRevenueBillEditBy(revenuePeriod.getPeriodId(), revenueDomainType, RevenueType.TEMPORARY_REVENUE, startOfMonth)) // ghi nhận doanh thu bill sửa
                  .flatMap(result2 -> groupByBillRevenueBy(revenuePeriod.getPeriodId(), revenueDomainType, RevenueType.COMPLETED_REVENUE2, startOfMonth)) // ghi nhận doanh thu hoàn thành
                  .flatMap(result3 -> groupByRevenueBillEditBy(revenuePeriod.getPeriodId(), revenueDomainType, RevenueType.COMPLETED_REVENUE2, startOfMonth)) // ghi nhận doanh thu bill sửa
                  .flatMap(result4 -> groupByBillRevenueBy(revenuePeriod.getPeriodId(), revenueDomainType, RevenueType.COMPLETED_REVENUE3, startOfMonth))  // ghi nhận doanh thu hoàn thành
                  .flatMap(result5 -> groupByRevenueBillEditBy(revenuePeriod.getPeriodId(), revenueDomainType, RevenueType.COMPLETED_REVENUE3, startOfMonth)) // ghi nhận doanh thu bill sửa
                  // Bảng kê cấp 2
                  .flatMap(rs -> gloExpRevenueRepository.findGroupByRevenueStatementCount(revenuePeriod.getPeriodId(), null)
                      .flatMap(statementCount -> {
                          log.info("revenue_statement_count: {}, period: {}", statementCount, revenuePeriod.getPeriodId());
                          if (statementCount == 0) {
                            return Uni.createFrom().voidItem();
                          }
                          return gloExpRevenueRepository.saveRevenueStatementLevel2(toRevenueStatementLevel2Entity(revenuePeriod.getPeriodId(), startOfMonth), null)
                              // sum tong
                              .flatMap(revenueStatementLevel2 -> genRevenueStatementLevel2Line(revenueStatementLevel2, revenuePeriod.getPeriodId())
                                  .flatMap(unused -> {
                                    return gloExpRevenueRepository.findGroupByRevenueStatement(revenuePeriod.getPeriodId(), null)
                                        // Cập nhật lại số tiền
                                        .flatMap(groupDebtItem -> {
                                          return gloExpRevenueRepository.updateRevenueStatementLevel2By(revenueStatementLevel2.getId(), groupDebtItem, null);
                                        })
                                        .flatMap(rsUpd -> {
                                          if (rsUpd) {
                                            log.info("updateRevenueStatementLevel2By_success: {}", revenueStatementLevel2.getId());
                                          }
                                          return Uni.createFrom().voidItem();
                                        });
                                  }));
                      })
                  )
                  .flatMap(unuse -> {  // chot ky doanh thu
                    return gloExpRevenueRepository.updateRevenuePeriodControl(revenuePeriod.getPeriodId(), "P", null, null, null)
                        .flatMap(unused -> {
                          log.info("updateRevenuePeriodControl: {}", unused);
                          return Uni.createFrom().voidItem();
                        })
                        .onFailure()
                        .invoke(throwable -> {
                          log.error("updateRevenuePeriodControl_fail: {}", throwable.getMessage(), throwable);
                        });
                  });
            })
            .onFailure()
            .recoverWithUni(throwable -> {
              log.info("processRevenueEveryMonth_executed: {} ms", System.currentTimeMillis() - currentTime);
              return Uni.createFrom().voidItem();
            });
    }

    public Uni<Void> processCheckSyncBaseRevenue() {
      return gloExpRevenueRepository.findRevenuePeriodControlBy("N")
          .collect().asList()
          .flatMap(periodControls -> {
              log.info("findRevenuePeriodControl_size: {}", periodControls.size());
              if (periodControls.isEmpty()) {
                log.info("revenue_periods_is_empty");
                return Uni.createFrom().voidItem();
              }
              for (RevenuePeriodControlEntity periodControl : periodControls) {
                Uni<Long> countBeforeSyncUni = gloExpRevenueRepository.findAllRevenueVtpRecordCount(periodControl.getPeriodId(), revenueDomainType);
                Uni<Long> countAfterSynUni = gloExpRevenueRepository.findAllRevenueRecordCount(periodControl.getPeriodId(), revenueDomainType);
                Uni<ErpPeriodEntity> periodUni = calculationRevenueRepository.findPeriodBy(periodControl.getPeriodId());
                return Uni.combine().all().unis(countBeforeSyncUni, countAfterSynUni, periodUni)
                    .withUni((countBeforeSync, countAfterSyn, period) -> {
                      log.info("checkSyncBaseRevenue_periodId: {}, domainType: {} countBeforeSync: {}, countAfterSyn: {}",  periodControl.getPeriodId(), revenueDomainType, countBeforeSyncUni, countAfterSynUni);
                      if (period == null) {
                          log.error("period_is_null: {}", periodControl.getPeriodId());
                      }
                      if (Objects.equals(countBeforeSync, countAfterSyn) && countBeforeSync > 0) {
                        return gloExpRevenueRepository.updateRevenuePeriodControl(periodControl.getId(), "P", period.getStartDate(), period.getEndDate(), null)
                            .flatMap(unused -> {
                              log.info("updateRevenuePeriodControl: {}", unused);
                              return Uni.createFrom().voidItem();
                            })
                            .onFailure()
                            .invoke(throwable -> {
                              log.error("updateRevenuePeriodControl_fail: {}", throwable.getMessage(), throwable);
                            });
                      }
                      return Uni.createFrom().voidItem();
                    })
                    .onFailure()
                    .recoverWithUni(throwable -> {
                      log.info("check_sync_fail: {}", throwable.getMessage(), throwable);
                      return Uni.createFrom().voidItem();
                    });
              }
            return Uni.createFrom().voidItem();
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("findRevenuePeriodControl_fail: {}", throwable.getMessage(), throwable);
          });
    }

    private Uni<Void> groupByBillRevenueBy(BigDecimal periodId, String domainType, RevenueType revenueType, LocalDate startOfMonth) {
      long currentTime = System.currentTimeMillis();

      Uni<Integer> countUni = gloExpRevenueRepository.groupByBillRevenueCountV2(periodId,domainType, revenueType);

      return countUni
          .flatMap((totalItems) -> {
            log.info("groupByBillRevenueBy_size: {}, periodId: {}",  totalItems,  domainType);
            int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
            List<Multi<GroupRevenueRecordDTO>> multiList = new ArrayList<>();

            for (int i = 0; i < maxPage; i++) {
              multiList.add(
                  gloExpRevenueRepository.findGroupByRevenueRecordV2(periodId, domainType, revenueType, i, batchBillHandleSize));
            }

            Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

            for (Multi<GroupRevenueRecordDTO> multi : multiList) {
              uniChainProcess = uniChainProcess.chain(() -> multi.collect().asList()
                      .flatMap(listGroup -> processSaveBatchRevenueStatementBy(periodId, listGroup, startOfMonth, revenueType)))
                  .onFailure()
                  .recoverWithUni((throwable) -> {
                    log.error("saveBatchGroupBillRevenue_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().voidItem();
                  });
            }
            return uniChainProcess;
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("groupByBillRevenueBy_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }

    private Uni<Void> groupByRevenueBillEditBy(BigDecimal periodId, String domainType, RevenueType revenueType, LocalDate startOfMonth) {
      long currentTime = System.currentTimeMillis();

      Uni<Integer> countUni = gloExpRevenueRepository.groupByRevenueBillEditCount(periodId,domainType, revenueType);

      return countUni
          .flatMap((totalItems) -> {
            log.info("groupByRevenueBillEditBy_size: {}, periodId: {}",  totalItems,  domainType);
            int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
            List<Multi<GroupRevenueRecordDTO>> multiList = new ArrayList<>();

            for (int i = 0; i < maxPage; i++) {
              multiList.add(
                  gloExpRevenueRepository.findGroupByRevenueBillEdit(periodId, domainType, revenueType, i, batchBillHandleSize));
            }

            Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

            for (Multi<GroupRevenueRecordDTO> multi : multiList) {
              uniChainProcess = uniChainProcess.chain(() -> multi.collect().asList()
                      .flatMap(listGroup -> processSaveBatchRevenueStatementBy(periodId, listGroup, startOfMonth, revenueType)))
                  .onFailure()
                  .recoverWithUni((throwable) -> {
                    log.error("groupByRevenueBillEditBy_save_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().voidItem();
                  });
            }
            return uniChainProcess;
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("groupByRevenueBillEditBy_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }

// tao bảng kê doanh thu
    private Uni<Void> processSaveBatchRevenueStatementBy(BigDecimal periodId, List<GroupRevenueRecordDTO> groupBillRevenueDTOList, LocalDate startOfMonth, RevenueType revenueType) {

      return pool.withTransaction(sqlConnection -> {
            List<RevenueStatementEntity> originEntities = toRevenueStatementEntity(periodId, groupBillRevenueDTOList, startOfMonth, revenueType);
            return gloExpRevenueRepository.saveBatchRevenueStatement(originEntities, sqlConnection)
                .collect().asList()
                .flatMap(destEntities -> {
                  log.info("saveBatchRevenueStatement_success_size: {}, periodId: {}", destEntities.size(), revenueType);
                  return gloExpRevenueRepository.saveBatchRevenueStatementLine(toRevenueStatementLineEntity(originEntities, destEntities), sqlConnection)
                      .collect().asList()
                      .flatMap(destLineEntities -> {
                        log.info("saveBatchRevenueStatementLine_success_size: {}, periodId: {}", destLineEntities.size(), revenueType);
//                        List<BigDecimal> ids = destLineEntities.stream()
//                            .map(RevenueStatementLineEntity::getRecordId)
//                            .filter(Objects::nonNull)
//                            .toList();
                        return gloExpRevenueRepository.updateBatchRevenueRecord(toRevenueRecordEntities(destLineEntities), sqlConnection)
                            .flatMap(unused -> {
                              log.info("updateRevenueRecordBy_success_size: {}", destLineEntities.size());
                              return Uni.createFrom().voidItem();
                            })
                            .onFailure()
                            .invoke(throwable -> {
                              log.error("updateBatchRevenueRecord_fail: {}", throwable.getMessage(), throwable);
                            });
                      })
                      .onFailure()
                      .invoke(throwable -> {
                        log.error("saveBatchRevenueStatementLine_fail: {}", throwable.getMessage(), throwable);
                      });
                })
                .onFailure()
                .invoke(throwable -> {
                  log.error("saveBatchRevenueStatement_fail: {}", throwable.getMessage(), throwable);
                });
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("saveBatchRevenueStatement_fail: {}", throwable.getMessage(), throwable);
          });
    }

    private Uni<Void> genRevenueStatementLevel2Line(RevenueStatementLevel2Entity revenueStatementLevel2, BigDecimal periodId) {
      long currentTime = System.currentTimeMillis();

      Uni<Integer> revenueStatementCountUni = gloExpRevenueRepository.findGroupByRevenueStatementCount(periodId, null);

      return revenueStatementCountUni
          .flatMap((revenueCount) -> {
            log.info("revenueCount_size: {}, periodId: {}",  revenueCount,  periodId);
            int maxPage = (int) Math.ceil((double) revenueCount / batchBillHandleSize);
            List<Multi<RevenueStatementEntity>> multiList = new ArrayList<>();

            for (int i = 0; i < maxPage; i++) {
              multiList.add(
                  gloExpRevenueRepository.findRevenueStatementBy(periodId, i, batchBillHandleSize, null));
            }

            Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

            for (Multi<RevenueStatementEntity> multi : multiList) {
              uniChainProcess = uniChainProcess.chain(() -> multi.collect().asList()
                      .flatMap(listGroup -> processBatchRevenueStatementLevel2By(revenueStatementLevel2, listGroup)))
                  .onFailure()
                  .recoverWithUni((throwable) -> {
                    log.error("genRevenueStatementLevel2_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().voidItem();
                  });
            }
            return uniChainProcess;
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("groupByBillRevenueBy_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }

  private Uni<Void> processBatchRevenueStatementLevel2By(RevenueStatementLevel2Entity revenueStatementLevel2, List<RevenueStatementEntity> revenueStatementEntityList) {

    return pool.withTransaction(sqlConnection -> {
          List<RevenueStatementLevel2LineEntity> statementLevel2LineEntities = toRevenueStatementLevel2LineEntity(revenueStatementLevel2, revenueStatementEntityList);
          return  gloExpRevenueRepository.saveBatchRevenueStatementLevel2Line(statementLevel2LineEntities, sqlConnection)
              .collect().asList()
              .flatMap(entities -> {
                log.info("saveBatchRevenueStatementLevel2Line_success_size: {}, statementLevel2Id: {}", entities.size(), revenueStatementLevel2.getId());
                return Uni.createFrom().voidItem();
              });
        })
        .onFailure()
        .invoke(throwable -> {
          log.error("saveBatchRevenueStatement_fail: {}", throwable.getMessage(), throwable);
        });
  }

    private List<RevenueStatementEntity> toRevenueStatementEntity(BigDecimal periodId, List<GroupRevenueRecordDTO> groupRevenueRecordList, LocalDate startOfMonth, RevenueType revenueType) {
    Integer debtType = revenueType.getValue();

    List<RevenueStatementEntity> entities = new ArrayList<>();
    for (GroupRevenueRecordDTO revenueRecord : groupRevenueRecordList) {
      List<RecordDto> records = new ArrayList<>();
      if (Objects.nonNull(revenueRecord.getRecords())) {
        if (revenueRecord.getRecords().isArray()) {
          records = objectMapper.convertValue(
              revenueRecord.getRecords(),
              objectMapper.getTypeFactory().constructCollectionType(List.class, RecordDto.class)
          );
        }
      }

      entities.add(
           RevenueStatementEntity.builder()
              .tenantId(1)
              .createdBy(-1L)
              .updatedBy(-1L)
//              .statementCode(String.format("DT-%02d%02d-%s-%s-%d-%d", startOfMonth.getYear()%100, startOfMonth.getMonthValue(), revenueRecord.getBuyerCode(), revenueRecord.getServiceCode(), revenueRecord.getUnitLevel2Id(), debtType))
              .statementCode(String.format("DT-%02d%02d-%s-%s||%d-%d", startOfMonth.getYear()%100, startOfMonth.getMonthValue(), revenueRecord.getBuyerCode(), revenueRecord.getServiceCode(), revenueRecord.getUnitLevel2Id(), debtType))
              .description(String.format("Chốt DT-T%s/%s-%s-%s", startOfMonth.getMonthValue(), startOfMonth.getYear(), revenueRecord.getBuyerCode(), revenueRecord.getServiceCode()))
              .serviceCode(revenueRecord.getServiceCode())
              .unitLevel1Id(revenueRecord.getUnitLevel1Id())
              .unitLevel1Code(CollectionUtils.isNotEmpty(records) ? records.getFirst().getPostCode() : "")
              .unitLevel1Name(CollectionUtils.isNotEmpty(records) ? records.getFirst().getPostName() : "")
              .unitLevel2Id(revenueRecord.getUnitLevel2Id())
              .unitLevel2Code(CollectionUtils.isNotEmpty(records) ? records.getFirst().getOrgCode() : "")
              .unitLevel2Name(CollectionUtils.isNotEmpty(records) ? records.getFirst().getOrgName() : "")
              .customerCode(revenueRecord.getBuyerCode())
              .customerName("")
              .statementAmountBeforeTax(revenueRecord.getAmountBeforeTax())
              .statementTaxAmount(revenueRecord.getTaxAmount())
              .statementAmountAfterTax(revenueRecord.getAmountAfterTax())
              .statementAmountDiscount(revenueRecord.getDiscountAmount())
              .totalAmount(revenueRecord.getTotalAmount())
              .revenueSyncStatus(RevenueStatementStatus.CHOT_BANG_KE.getCode())
              .revenueAccountingStatus(0)
              .currency("VND")
              .statementSource(revenueRecord.getRecordSource())
              .recordSize(records.size())
              .recordType(debtType)
              .periodId(periodId)
              .records(records)
              .companyCode(CollectionUtils.isNotEmpty(records) ? records.getFirst().getCompany() : companyCode)
              .statementBusinessId(revenueBusinessId)
              .amountDiscountBeforeTax(revenueRecord.getAmountDiscountBeforeTax())
              .amountDiscountTax(revenueRecord.getAmountDiscountTax())
              .build()
           );
    }
    return entities;
  }

    private List<RevenueStatementLineEntity> toRevenueStatementLineEntity(List<RevenueStatementEntity> statementOrginList, List<RevenueStatementEntity> statementSavedList) {

      if (CollectionUtils.isEmpty(statementSavedList)) {
        return new ArrayList<>();
      }
      List<RevenueStatementLineEntity> entities = new ArrayList<>();
      for (RevenueStatementEntity statementSaved : statementSavedList) {

        // Find the matching GeneralOrderEntity
        statementOrginList.stream()
            .filter(order ->
                    statementSaved.getStatementSource() != null &&
                    statementSaved.getStatementSource().equals(order.getStatementSource()) &&
                    statementSaved.getRecordType() != null &&
                    statementSaved.getRecordType().equals(order.getRecordType()) &&
                    statementSaved.getCustomerCode() != null &&
                    statementSaved.getCustomerCode().equals(order.getCustomerCode()) &&
                    statementSaved.getServiceCode() != null &&
                    statementSaved.getServiceCode().equals(order.getServiceCode()) &&
                    statementSaved.getUnitLevel2Id() != null &&
                    Objects.equals(statementSaved.getUnitLevel2Id(), order.getUnitLevel2Id()))
            .findFirst().ifPresent(matchingOrder -> {
                if (!CollectionUtils.isEmpty(matchingOrder.getRecords())) {
                  for (RecordDto record : matchingOrder.getRecords()) {
                    entities.add(RevenueStatementLineEntity.builder()
                        .tenantId(1)
                        .createdBy(-1L)
                        .updatedBy(-1L)
                        .recordId(record.getId())
                        .recordCode(record.getCode())
                        .statementId(statementSaved.getId())
                        .statementCode(statementSaved.getStatementCode())
                        .totalAmount(statementSaved.getTotalAmount())
                      .build());
                  }
                }
            });
      }
      return entities;
    }

    private RevenueStatementLevel2Entity toRevenueStatementLevel2Entity(BigDecimal periodId, LocalDate startOfMonth) {

      return RevenueStatementLevel2Entity.builder()
          .tenantId(1)
          .createdBy(-1L)
          .updatedBy(-1L)
//          .statementCode(String.format("CHOTKY-T%s/%s", startOfMonth.getMonthValue(), startOfMonth.getYear()))
          .statementCode(String.format("CHOTKY-T%s/%s||%d", startOfMonth.getMonthValue(), startOfMonth.getYear(), (int) (Math.random() * 900) + 100))
          .description(String.format("Chốt doanh thu công nợ cuối kỳ tháng %s/%s",
              startOfMonth.getMonthValue(), startOfMonth.getYear()))
          .unitLevel1Id(null)
          .unitLevel1Code(null)
          .unitLevel1Name(null)
          .unitLevel2Id(null)
          .unitLevel2Code(null)
          .unitLevel2Name(null)
          .companyCode(null)
          .statementAmountBeforeTax(BigDecimal.ZERO)
          .statementTaxAmount(BigDecimal.ZERO)
          .statementAmountDiscount(BigDecimal.ZERO)
          .statementAmountAfterTax(BigDecimal.ZERO)
          .totalAmount(BigDecimal.ZERO)
          .itemQuantity(0)
          .revenueSyncStatus(0)
          .revenueAccountingStatus(0)
          .currency("VND")
          .periodId(periodId)
          .statementSource(null)
          .build();
    }

    private List<RevenueStatementLevel2LineEntity> toRevenueStatementLevel2LineEntity(RevenueStatementLevel2Entity revenueStatementLevel2, List<RevenueStatementEntity> statementSavedList) {

      if (CollectionUtils.isEmpty(statementSavedList)) {
        return new ArrayList<>();
      }
      List<RevenueStatementLevel2LineEntity> entities = new ArrayList<>();
      for (RevenueStatementEntity statementSaved : statementSavedList) {
        entities.add(RevenueStatementLevel2LineEntity.builder()
            .tenantId(1)
            .createdBy(-1L)
            .updatedBy(-1L)
            .statementId(statementSaved.getId())
            .statementCode(statementSaved.getStatementCode())
            .statementLevel2Id(revenueStatementLevel2.getId())
            .statementLevel2Code(revenueStatementLevel2.getStatementCode())
            .totalAmount(statementSaved.getTotalAmount())
            .build());
      }
      return entities;
    }

  private List<RevenueRecordEntity> toRevenueRecordEntities(List<RevenueStatementLineEntity> statementLineEntityList) {

    if (CollectionUtils.isEmpty(statementLineEntityList)) {
      return new ArrayList<>();
    }
    List<RevenueRecordEntity> entities = new ArrayList<>();
    for (RevenueStatementLineEntity statementLine : statementLineEntityList) {
      entities.add(RevenueRecordEntity.builder()
          .revenueSyncStatus(RevenueRecordStatus.DA_GOM_BK.getCode())
          .statementId(statementLine.getStatementId())
          .statementCode(statementLine.getStatementCode())
          .updatedBy(-1L)
          .id(statementLine.getRecordId())
          .build());
    }
    return entities;
  }

  private LocalDate getLocalDateBy(LocalDateTime startOfMonth) {
      if (startOfMonth == null) {
        LocalDate today = LocalDate.now();
        return today.with(TemporalAdjusters.firstDayOfMonth());
      }
      return startOfMonth.toLocalDate();
  }
}
