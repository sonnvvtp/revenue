package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum FuelBillingRecoveryConfigType {
    NGUOI_DUYET(1, "Người duyệt"),
    LOAI_XE_TAO_HOA_DON(2, "Loại xe tạo hóa đơn");

    private final int type;
    private final String description;
}
