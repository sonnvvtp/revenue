package com.viettelpost.platform.bms.portal.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceListRequest {
    private String orderCode; // Mã vận đơn/đơn hàng
    private String fromDate; // Ngày đơn hàng (từ)
    private String toDate; // Ngày đơn hàng (đến)
    private Integer page = 1;
    private Integer size = 10;
} 