package com.viettelpost.platform.bms.portal.model.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FicoPayRecordClear {
    BigDecimal payRecordClearId;
    Long payBatchId;
    String recordNo;
    Date accountingDate;
    Long periodId;
    Long personId;
    Long cusId;
    Long cusPoId;
    String cusPoCode;
    Long cusGroupId;
    Long periodDue;
    BigDecimal amount;
    BigDecimal discount;
    Long orgId;
    Long postId;
    Long recordType;
    Long docType;
    Long createdBy;
    Long updatedBy;
    Long recordStatus;
    BigDecimal payAmount;
}
