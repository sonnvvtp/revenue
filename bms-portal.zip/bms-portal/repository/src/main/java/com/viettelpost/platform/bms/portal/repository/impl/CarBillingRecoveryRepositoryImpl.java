package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.enums.BillingType;
import com.viettelpost.platform.bms.portal.model.response.FuelBillingRecoveryResponse;
import com.viettelpost.platform.bms.portal.repository.CarBillingRecoveryRepository;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Singleton
@Slf4j
public class CarBillingRecoveryRepositoryImpl implements CarBillingRecoveryRepository {

    @Inject
    PgPool client;

    @Override
    public Uni<List<FuelBillingRecoveryResponse>> searchCarBills(
            String carLicensePlate, String synthesisPeriod, String receiptNumberLv3,
            String unit, int pageNo, int pageSize, int type, List<Integer> status) {
        int offset = (pageNo - 1) * pageSize;
        String sqlTemplate = """
        SELECT f1.*, f3.receipt_number_excess as receipt_number_excess_lv3,
                f3.receipt_number_reduction as receipt_number_reduction_lv3,
                cms.recover_id as recover_id
        FROM bms_payment.fuel_billing_recovery f1
        LEFT JOIN bms_payment.car_management_setting cms on cms.car_license_plate = f1.car_license_plate and cms.is_active = true
        LEFT JOIN bms_payment.fuel_billing_recovery_level3 f3 on f3.synthesis_period = f1.synthesis_period and f3.is_active = true
        WHERE f1.is_active = true
        %s %s %s %s %s %s
        ORDER BY f1.created_at DESC
        LIMIT $%d OFFSET $%d
        """;

        List<Object> params = new ArrayList<>();

        String unitCondition = "";
        String carLicenseCondition = "";
        String synthesisPeriodCondition = "";
        String receiptNumberLv3Condition = "";
        String statusCondition = "";
        String budgetCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                " AND f1.total_budget_excess > 0" : " AND f1.budget_reduction > 0";

        if (unit != null && !unit.isEmpty()) {
            unitCondition = " AND f1.unit = $1";
            params.add(unit);
        }

        if (carLicensePlate != null && !carLicensePlate.isEmpty()) {
            carLicenseCondition = " AND f1.car_license_plate = $" + (params.size() + 1);
            params.add(carLicensePlate);
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            synthesisPeriodCondition = " AND f1.synthesis_period = $" + (params.size() + 1);
            params.add(synthesisPeriod);
        }

        if (receiptNumberLv3 != null && !receiptNumberLv3.isEmpty()) {
            receiptNumberLv3Condition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND f3.receipt_number_excess like $" + (params.size() + 1) :
                    " AND f3.receipt_number_reduction like $" + (params.size() + 1) ;
            params.add("%" + receiptNumberLv3.toUpperCase().trim() + "%");
        }

        if (status != null && !status.isEmpty()) {
            statusCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND COALESCE(f1.excess_status, 0) = ANY($" + (params.size() + 1) + ")"
                    : " AND COALESCE(f1.reduction_status, 0) = ANY($" + (params.size() + 1) + ")";
            params.add(status.toArray());
        }

        params.add(pageSize);
        params.add(offset);

        String finalSql = String.format(sqlTemplate, unitCondition, budgetCondition, carLicenseCondition,
                synthesisPeriodCondition, receiptNumberLv3Condition, statusCondition, params.size() - 1, params.size());

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<FuelBillingRecoveryResponse> responses = new ArrayList<>();
                    rows.forEach(row -> responses.add(mapRowsToFuelBillingRecoveryResponse(row, type)));
                    return responses;
                });
    }


    @Override
    public Uni<Long> countCarBills(String carLicensePlate, String synthesisPeriod,
                                   String receiptNumberLv3, String unit, int type, List<Integer> status) {
        String sqlTemplate = """
        SELECT count(f1.*)
        FROM bms_payment.fuel_billing_recovery f1
        LEFT JOIN bms_payment.car_management_setting cms on cms.car_license_plate = f1.car_license_plate and cms.is_active = true
        LEFT JOIN bms_payment.fuel_billing_recovery_level3 f3 on f3.synthesis_period = f1.synthesis_period and f3.is_active = true
        WHERE f1.is_active = true
        %s %s %s %s %s %s
        """;

        List<Object> params = new ArrayList<>();

        String unitCondition = "";
        String carLicenseCondition = "";
        String synthesisPeriodCondition = "";
        String receiptNumberLv3Condition = "";
        String statusCondition = "";
        String budgetCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                " AND f1.total_budget_excess > 0" : " AND f1.budget_reduction > 0";

        if (unit != null && !unit.isEmpty()) {
            unitCondition = " AND f1.unit = $1";
            params.add(unit);
        }

        if (carLicensePlate != null && !carLicensePlate.isEmpty()) {
            carLicenseCondition = " AND f1.car_license_plate = $" + (params.size() + 1);
            params.add(carLicensePlate);
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            synthesisPeriodCondition = " AND f1.synthesis_period = $" + (params.size() + 1);
            params.add(synthesisPeriod);
        }

        if (receiptNumberLv3 != null && !receiptNumberLv3.isEmpty()) {
            receiptNumberLv3Condition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND f3.receipt_number_excess like $" + (params.size() + 1) :
                    " AND f3.receipt_number_reduction like $" + (params.size() + 1) ;
            params.add("%" + receiptNumberLv3.toUpperCase().trim() + "%");
        }

        if (status != null && !status.isEmpty()) {
            statusCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND COALESCE(f1.excess_status, 0) = ANY($" + (params.size() + 1) + ")"
                    : " AND COALESCE(f1.reduction_status, 0) = ANY($" + (params.size() + 1) + ")";
            params.add(status.toArray());
        }

        String finalSql = String.format(sqlTemplate,unitCondition, budgetCondition, carLicenseCondition,
                synthesisPeriodCondition, receiptNumberLv3Condition, statusCondition);

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> rows.iterator().next().getLong(0));
    }

    @Override
    public Uni<List<FuelBillingRecoveryResponse>> getCarBillsOfUnit(String unit,
            String synthesisPeriod, int pageNo, int pageSize) {
        int offset = (pageNo - 1) * pageSize;
        StringBuilder sql = new StringBuilder("SELECT * FROM bms_payment.fuel_billing_recovery WHERE unit = $1");
        List<Object> params = new ArrayList<>();
        params.add(unit);

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            sql.append(" AND synthesis_period = $").append(params.size() + 1);
            params.add(synthesisPeriod);
        }
        sql.append(" ORDER BY created_at DESC ");
        sql.append(" LIMIT $").append(params.size() + 1);
        params.add(pageSize);
        sql.append(" OFFSET $").append(params.size() + 1);
        params.add(offset);
        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<FuelBillingRecoveryResponse> responses = new ArrayList<>();
                    rows.forEach(row -> {
                        FuelBillingRecoveryResponse response = mapRowsToFuelBillingRecoveryResponse(
                                row, 1);
                        responses.add(response);
                    });
                    return responses;
                });
    }

    @Override
    public Uni<String> showNewestMonthFuelQuota() {
        String sql = "SELECT MAX(synthesis_period) FROM bms_payment.fuel_billing_recovery";

        return client.query(sql)
                .execute()
                .onItem().transform(rowSet -> {
                    if (rowSet.size() > 0) {
                        Row row = rowSet.iterator().next();
                        return row.getString("max");
                    } else {
                        return null;
                    }
                });
    }

    @Override
    public Uni<Boolean> updateStatus(String synthesisPeriod, Integer status, int type) {
        String sql = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                "UPDATE bms_payment.fuel_billing_recovery SET excess_status = $1 " +
                        "WHERE synthesis_period = $2 AND is_active = true AND total_budget_excess > 0" :
                "UPDATE bms_payment.fuel_billing_recovery SET reduction_status = $1 " +
                        "WHERE synthesis_period = $2 AND is_active = true AND budget_reduction > 0";

        return client.preparedQuery(sql)
                .execute(Tuple.of(status, synthesisPeriod))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0);
    }

    @Override
    public Uni<Long> countCarBillsOfUnit(String unit, String synthesisPeriod) {
        StringBuilder countSql = new StringBuilder(
                "SELECT COUNT(*) FROM bms_payment.fuel_billing_recovery WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (unit != null && !unit.isEmpty()) {
            countSql.append(" AND unit = $").append(1);
            params.add(unit);
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            countSql.append(" AND synthesis_period = $").append(params.size() + 1);
            params.add(synthesisPeriod);
        }

        return client.preparedQuery(countSql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> rows.iterator().next().getLong(0));
    }

    private FuelBillingRecoveryResponse mapRowsToFuelBillingRecoveryResponse(Row row, int type) {
        return FuelBillingRecoveryResponse.builder()
                .id(row.getLong("id"))
                .receiptNumber(
                        (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                                row.getString("receipt_number_excess") :
                                row.getString("receipt_number_reduction")
                )
                .synthesisPeriod(row.getString("synthesis_period"))
                .carLicensePlate(row.getString("car_license_plate"))
                .unit(row.getString("unit"))
                .budget(row.getBigDecimal("budget"))
                .actualMileage(row.getBigDecimal("actual_mileage"))
                .fuelConsumptionRate(row.getBigDecimal("fuel_consumption_rate"))
                .fuelConsumptionUnit(row.getBigDecimal("fuel_consumption_unit"))
                .budgetExcess(row.getBigDecimal("total_budget_excess")
                        .setScale(0, RoundingMode.HALF_UP))
                .totalExcessAmount(row.getBigDecimal("total_excess_amount"))
                .budgetReduction(row.getBigDecimal("budget_reduction")
                        .setScale(0, RoundingMode.HALF_UP))
                .status(
                        (Objects.equals(type, BillingType.TRUY_THU.getCode()))
                                ? (row.getInteger("excess_status") != null ? row.getInteger("excess_status") : 0)
                                : (row.getInteger("reduction_status") != null ? row.getInteger("reduction_status") : 0)
                )
                .receiptNumberLv3(
                        (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                                row.getString("receipt_number_excess_lv3") :
                                row.getString("receipt_number_reduction_lv3")
                )
                .recoverId(row.getString("recover_id"))
                .messSap(
                        (row.getInteger("reduction_status") == 10 ||
                        row.getInteger("reduction_status") == 12)
                                ? row.getString("mess_sap") : null
                )
                .build();
    }
}
