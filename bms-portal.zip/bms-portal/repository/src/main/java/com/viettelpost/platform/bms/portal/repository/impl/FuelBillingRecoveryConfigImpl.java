package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.model.VehicleTypeGroupKmcpModel;
import com.viettelpost.platform.bms.portal.model.model.VehicleTypeGroupModel;
import com.viettelpost.platform.bms.portal.repository.FuelBillingRecoveryConfig;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.smallrye.mutiny.Multi;
import io.vertx.mutiny.pgclient.PgPool;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class FuelBillingRecoveryConfigImpl implements FuelBillingRecoveryConfig {

    @Inject
    PgPool pgPool;

    @Override
    public Mono<List<VehicleTypeGroupModel>> getAllVehicleTypeGroup() {
        String query = "SELECT id, name, vehicle_types, is_sync_invoice FROM bms_payment.vehicle_type_group_setting";
        return ReactiveConverter.toFlux(pgPool.preparedQuery(query)
                        .mapping(DataMapping.map(VehicleTypeGroupModel.class))
                        .execute()
                        .toMulti()
                        .flatMap(rows -> Multi.createFrom().iterable(rows)))
                .collectList();
    }

    @Override
    public Mono<List<VehicleTypeGroupKmcpModel>> getAllVehicleTypeGroupKmcpConfig() {
        String query = "select id, vehicle_type_group_id, org_type, kmcp_id from bms_payment.vehicle_type_group_kmcp_config";
        return ReactiveConverter.toFlux(pgPool.preparedQuery(query)
                        .mapping(DataMapping.map(VehicleTypeGroupKmcpModel.class))
                        .execute()
                        .toMulti()
                        .flatMap(rows -> Multi.createFrom().iterable(rows)))
                .collectList();
    }
}
