package com.viettelpost.platform.bms.portal.model.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class BaseBmsResponse implements Serializable {
    boolean error;
    String errorCode;
    String message;
    Object data;

    public BaseBmsResponse(boolean error, String errorCode, String message, Object data) {
        this.error = error;
        this.errorCode = errorCode;
        this.message = message;
        this.data = data;
    }

    public static Response successBmsApi(Object data, String message) {
        return Response.status(Response.Status.OK).entity(new BaseBmsResponse(false, "00", message, data)).build();
    }
    public static Response errorApiWithHttpStatusCode(
        Status status, String errorCode, String message) {
        return Response.status(status).entity(new BaseBmsResponse(true, errorCode, message, null)).build();
    }
}
