package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceStatusJourneyEntity {

  @JsonAlias("id")
  private BigDecimal id;

  @JsonAlias("tenant_id")
  private Integer tenantId = 1;

  @JsonAlias("created_by")
  private Long createdBy;

  @JsonAlias("created_at")
  private LocalDateTime createdAt = LocalDateTime.now();

  @JsonAlias("updated_by")
  private Long updatedBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt = LocalDateTime.now();

  @JsonAlias("order_code")
  private String orderCode;

  @JsonAlias("company_code")
  private String companyCode;

  @JsonAlias("invoice_error_code")
  private Integer invoiceErrorCode;

  @JsonAlias("invoice_status")
  private Integer invoiceStatus;

  @JsonAlias("invoice_message")
  private String invoiceMessage;

  @JsonAlias("invoice_code")
  private String invoiceCode;

  @JsonAlias("invoice_number")
  private String invoiceNumber;

  @JsonAlias("invoice_date")
  private LocalDateTime invoiceDate;

  @JsonAlias("pdf_url")
  private String pdfUrl;

  @JsonAlias("xml_url")
  private String xmlUrl;

  @JsonAlias("callback_status")
  private Integer callbackStatus;

  @JsonAlias("callback_count")
  private Integer callbackCount;

  @JsonAlias("order_source")
  private String orderSource;
}
