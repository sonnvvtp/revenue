package com.viettelpost.platform.bms.portal.model.utils;

public class Constants {
    public final static String authenKey = "Authorization";
    public final static int tokenInvalid = 201;
    public final static String daily_amount_limit = "1000000";
    public final static String trans_amount_limit = "1000000";

    public enum STATUS {
        E200(200, "Success"),
        E201(201, "Token invalid"),
        E202(202, "Header invalid"),
        E203(203, "Data invalid(validate input)"),
        E204(204, "Data invalid(db raise, business error)"),
        E205(205, "Application error");
        private int code;
        private String name;

        STATUS(int code, String name) {
            this.code = code;
            this.name = name;
        }

        public int getCode() {
            return code;
        }

        public String getName() {
            return name;
        }
    }
}
