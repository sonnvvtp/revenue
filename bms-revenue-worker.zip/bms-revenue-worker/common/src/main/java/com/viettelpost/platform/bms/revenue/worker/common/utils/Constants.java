package com.viettelpost.platform.bms.revenue.worker.common.utils;

public class Constants {

    public final static String HOAN_UNG = "HOAN_UNG";
    public final static String DON_THUONG = "DON_THUONG";
}
