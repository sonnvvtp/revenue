package com.viettelpost.platform.bms.revenue.worker.model.kafka;

import com.viettelpost.platform.bms.revenue.worker.model.model.DiscountResultModel;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class DiscountReportInfoKafka {

    private List<DiscountResultModel> discountResultModels;

}
