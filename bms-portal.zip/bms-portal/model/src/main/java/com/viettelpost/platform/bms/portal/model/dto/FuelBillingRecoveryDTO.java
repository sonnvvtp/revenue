package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FuelBillingRecoveryDTO {

    Long id;
    @JsonAlias("receipt_number_excess")
    String excessNumber;
    @JsonAlias("receipt_number_reduction")
    String reductionNumber;
    @JsonAlias("synthesis_period")
    String synthesisPeriod;
    @JsonAlias("car_license_plate")
    String carLicensePlate;
    String unit;
    BigDecimal budget;
    @JsonAlias("actual_mileage")
    BigDecimal actualMileage;
    @JsonAlias("fuel_consumption_rate")
    BigDecimal fuelConsumptionRate;
    @JsonAlias("fuel_consumption_unit")
    BigDecimal fuelConsumptionUnit;
    @JsonAlias("total_excess_amount")
    BigDecimal totalExcessAmount;
    @JsonAlias("total_budget_excess")
    BigDecimal totalExcessBudget;
    @JsonAlias("reduction_status")
    Integer reductionStatus;
    @JsonAlias("created_at")
    LocalDateTime createdAt;
    @JsonAlias("car_id")
    Long carId;
    @JsonAlias("budget_reduction")
    BigDecimal budgetReduction;
    @JsonAlias("is_active")
    Boolean isActive;
    @JsonAlias("mess_sap")
    String messSap;
    @JsonAlias("excess_status")
    Integer excessStatus;
    @JsonAlias("doc_number_sap")
    Long docNumberSap;
    Integer statusSap;

}
