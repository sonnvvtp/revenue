package com.viettelpost.platform.bms.portal.common.model;

import com.viettelpost.platform.bms.portal.common.model.enums.RoleType;
import lombok.Data;

@Data
public class RoleDTO {

    RoleType roleType;
    String orgCode;
    String postCode;
}
