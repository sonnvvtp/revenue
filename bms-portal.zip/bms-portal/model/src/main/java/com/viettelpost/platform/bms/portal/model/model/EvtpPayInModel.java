package com.viettelpost.platform.bms.portal.model.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EvtpPayInModel {
    private BigDecimal evtpPayInId;
    private Date dateBill;
    private Date dateInsert;
    private String bill;
    private BigDecimal amount;
    private Long status;
    private Long orgId;
    private Long postId;
    private String partnerEvtp;
    private Long partnerId;
    private String mProduct;
    private Long periodId;
    private Long payTeamId;
}
