package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.BillRevenueDTO;
import com.viettelpost.platform.bms.portal.model.dto.ReportRevenueDTO;
import com.viettelpost.platform.bms.portal.model.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.portal.model.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.portal.model.request.BillRevenueRequest;
import com.viettelpost.platform.bms.portal.model.request.ReportRevenueRequest;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;

public interface BillRevenueRepository extends BaseRepository {

    Uni<Integer> getBillRevenueCount(BillRevenueRequest request);

    Multi<BillRevenueDTO> getBillRevenueList(BillRevenueRequest request);

    Multi<BillRevenueDTO> getBillRevenueStream(BillRevenueRequest request, Long lastId, int batchSize);

    Multi<ErpPeriodEntity> findAllPeriod();

    Multi<ReportRevenueDTO> reportRevenue(ReportRevenueRequest request, Long postId);

    Multi<ReportRevenueDTO> reportRevenueStream(ReportRevenueRequest request, BigDecimal lastId, int batchSize, Long postId);

    Multi<RevenuePeriodControlEntity> findAllPerioControl();

    Uni<RevenuePeriodControlEntity> save(RevenuePeriodControlEntity entity, SqlConnection sqlConnection);
}
