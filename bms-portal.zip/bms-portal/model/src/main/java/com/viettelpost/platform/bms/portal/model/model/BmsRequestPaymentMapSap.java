package com.viettelpost.platform.bms.portal.model.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BmsRequestPaymentMapSap {
    private String transactionCode;
    private String bill;
    private String vendorCode;
    private String partnerEvtp;
    private String dateBill;
    private LocalDateTime accountingDate;
    private BigDecimal amount;
    private Long cusId;
    private Long reqPaymentId;
    private String transactionFt;
}
