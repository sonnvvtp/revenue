package com.viettelpost.platform.bms.portal.repository;
import com.viettelpost.platform.bms.portal.model.dto.EpacketBalancePeriodDTO;
import com.viettelpost.platform.bms.portal.model.dto.EpacketTransactionDTO;
import com.viettelpost.platform.bms.portal.model.dto.PartnerConfigByServiceDTO;
import com.viettelpost.platform.bms.portal.model.entity.EpacketTransactionEntity;
import com.viettelpost.platform.bms.portal.model.entity.EpacketTransactionLineEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.model.EpacketCallbackModel;
import com.viettelpost.platform.bms.portal.model.request.ReconciliationEpacketRequest;
import com.viettelpost.platform.bms.portal.model.request.epacket.*;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import com.viettelpost.platform.bms.portal.model.response.epacket.*;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.List;

public interface EpacketTransactionRepository extends BaseRepository {

    Mono<EpacketTransactionEntity> saveTransaction(EpacketTransactionEntity transaction);

    Mono<EpacketTransactionLineEntity> saveTransactionLine(EpacketTransactionLineEntity transaction);

    Mono<EpacketTransactionEntity> partnerTransactionEpacket(EpacketTransactionEntity transaction) throws ParseException;

    Mono<EpacketReconciTransactionResponse> getListTransactionEpacket(EpacketReconciliationEpacketRequest req);

    Mono<EpacketSearchTransCodeResponse> searchTransactionsEpacket(EpacketSearchTransactionRequest req);

    Mono<EpacketTransactionEntity> findByTransactionCode(String tranCode);

    Mono<Boolean> cancelTransactionByCode(String transactionCode);

    Mono<EpacketCallbackModel> findCallbackPayload(EpacketCallbackRequest request);

    //Mono<EpacketBalancePeriodDTO> collectBalanceTransactions(Integer cusId,String referenceTime) ;

/*    Mono<EpacketTransactionDTO> getListCallbackPayloadEpacket(Integer cusId,
                                                                          String fromDate,
                                                                          String toDate);*/

    /*Mono<EpacketTransactionListResponse> listTransactionEpacket(Integer cusId, String walletType, Integer transactionType, String fromDate, String toDate, String transactionCode, Integer reconStatus, Integer accountingStatus);
*/
    Mono<EpacketTransactionListResponse> listTransactionEpacket(EpacketListTransactionRequest req);

    Mono<EpacketExportListResponse> exportToExcelEpacket(EpacketListTransactionRequest req);

    // Đọc thẳng từ bảng partner mình đổ về bms_transaction_partner
/*
    Mono<EpacketTransactionDTO> getPartnerTransactions(Integer cusId, String fromDate, String toDate);
*/

    Mono<EpacketInsertMissingResponse> insertMissingTransactionsBatch(List<EpacketTransactionEntity> transactions);
}

