package com.viettelpost.platform.bms.portal.repository;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

public interface HrOrganizationDAO extends BaseRepository{

    Uni<Long> getOrgIdByOrgCode(String orgCode);

    Multi<Long> getOrgIdByPostCode(String postCode);
}
