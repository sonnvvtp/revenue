package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FuelBillingRecoveryLevel3DetailResponse {
    @JsonProperty("data")
    private List<FuelBillingRecoveryLevel3DetailResponse.Result> results;

    @JsonProperty("pageNo")
    private Integer pageNo;

    @JsonProperty("pageSize")
    private Integer pageSize;

    @JsonProperty("totalElements")
    private Long totalElements;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @Accessors(chain = true)
    public static class Result {
        @JsonAlias("receipt_number_lv3")
        String receiptNumberLv3;

        @JsonAlias("unit")
        String unit;

        @JsonAlias({"id"})
        Long id;

        @JsonAlias({"receipt_id"})
        Long receiptId;

        @JsonAlias({"user_id"})
        Long userId;

        @JsonAlias({"amount"})
        BigDecimal amount;

        @JsonAlias({"created_at"})
        LocalDateTime createdAt;

        @JsonAlias({"note"})
        String note;

        @JsonAlias({"car_id"})
        Long carId;

        @JsonAlias({"car_license_plate"})
        String carLicensePlate;

        @JsonAlias({"user_code_bp"})
        String userCodeBp;

        @JsonAlias({"status"})
        Integer status;

        @JsonAlias({"synthesisPeriod"})
        String synthesisPeriod;

        @JsonAlias({"messSap"})
        String messSap;
    }
}
