package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.common.utils.ThreadUtils;
import com.viettelpost.platform.bms.portal.model.request.AccountingVipoRequest;
import com.viettelpost.platform.bms.portal.service.handler.AccountingVipoService;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/acc-handmade")
@RequiredArgsConstructor
@ApplicationScoped
public class AccountingVipoController {

    @Inject
    AccountingVipoService accountingVipoService;



    @PUT
    @Path("/acc-vipo")
    @Operation(summary = "accounting cod batch id")
    public Uni<Response> accountingVipo(@RequestBody AccountingVipoRequest request) {
        // Trả response ngay lập tức
        Uni<Response> responseUni = Uni.createFrom().item(
                Response.status(Response.Status.OK)
                        .entity(new BaseResponse(true, "Accounting vipo batch triggered successfully!", null))
                        .build()
        );

        // Xử lý chính chạy nền
        ThreadUtils.runInOtherThread(() -> {
            try {
                accountingVipoService.accountingVipo(request).toUni().await().indefinitely();
            } catch (Exception ex) {
                log.info("ERROR_ACCOUNTING_FLOOR : {}", ex.getMessage());
            }
        });

        return responseUni;
    }


    @PUT
    @Path("/acc-refund")
    @Operation(summary = "accounting refund")
    public Uni<Response> accountingTransactionRefund(@RequestBody AccountingVipoRequest request) {
        // Trả response ngay lập tức
        Uni<Response> responseUni = Uni.createFrom().item(
                Response.status(Response.Status.OK)
                        .entity(new BaseResponse(true, "Accounting refund  triggered successfully!", null))
                        .build()
        );

        // Xử lý chính chạy nền
        ThreadUtils.runInOtherThread(() -> {
            try {
                accountingVipoService.refundQrCode(request).toUni().await().indefinitely();
            } catch (Exception ex) {
                log.info("ERROR_REFUND_QR : {}", ex.getMessage());
            }
        });

        return responseUni;
    }


}
