package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvCustomerEntity {
    private Long id;
    private Short tenantId;
    private Long createdBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime createdAt;
    private Long updatedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime updatedAt;
    private Long customerId;
    private Long cusId;
    private String customerCode;
    private Integer customerType;
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private String customerAddress;
    private String customerTax;
    private String budgetUnitCode;
    private Long unitLevel1Id;
    private String unitLevel1Code;
    private Long unitLevel2Id;
    private String unitLevel2Code;
    private String eContractCode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate eContractSignedDate;
    private Boolean invoiceDetailByBill;
    private Integer status;
    private String partnerSource;
    private List<InvItemInfoEntity> list;

}
