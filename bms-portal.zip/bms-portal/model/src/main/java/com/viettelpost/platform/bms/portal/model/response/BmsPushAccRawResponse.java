package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BmsPushAccRawResponse {
    private Long httpStatusCode;
    private String errorCode;
    private String detail;
    private List<Detail> data;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Detail {
        private String refNumber;
        private String refNumberParent;
        private Long acctSyntheticId;

    }
}
