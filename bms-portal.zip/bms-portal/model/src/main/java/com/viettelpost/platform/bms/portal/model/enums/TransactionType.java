package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum TransactionType {
    BILL_PAYIN(1, "BILL_PAYIN", "Bill Cước"),
    BILL_COD(2, "BILL_COD", "Bill COD"),
    RECORD_CLEAR_BT(3, "RECORD_CLEAR_BT", "BK Cước BT"),
    RECORD_CLEAR_KH(4, "RECORD_CLEAR_KH", "BK Cước KH"),
    RECORD_COD(5, "RECORD_COD", "BK Thu Hộ"),
    BILL_MERCHANDISE(6, "BILL_MERCHANDISE", "Bill Tiền Hàng"),
    BILL_RENT_SMB(7, "BILL_RENT_SMB", "Bill Thuê Tủ "),
    RECORD_CUOC_KH_APP(8, "RECORD_CUOC_KH_APP", "Thu Cước Khách Hàng"),
    RECORD_ADVANCE(9, "RECORD_ADVANCE", "Thu Cước Ứng Tiền"),
    BILL_DEPOSIT(10, "BILL_DEPOSIT", "Bill Thuê Cọc"),
    BILL_OVERDUE(11, "BILL_OVERDUE", "Bill phí quá hạn"),
    BILL_BOOKING(12, "BILL_BOOKING", "Bill thu hộ smart gate"),
    NA(-1, "N/A", "N/A");
    private int id;
    private String code;
    private String name;

    public static TransactionType get(String code) {
        return Arrays.stream(TransactionType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(NA);
    }
}