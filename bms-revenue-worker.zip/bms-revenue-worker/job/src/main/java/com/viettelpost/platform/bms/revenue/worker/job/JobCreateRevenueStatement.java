package com.viettelpost.platform.bms.revenue.worker.job;

import com.viettelpost.platform.bms.revenue.worker.service.RevenueVTPService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.job.JobAbs;
import io.quarkus.scheduler.Scheduled;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Mono;

@ApplicationScoped
@Slf4j
@Named("JobCreateRevenueStatement")
public class JobCreateRevenueStatement extends JobAbs<Void> {

  @ConfigProperty(name = "config.cron.create.revenue_statement", defaultValue = "")
  String cronCalculationBillRevenue;

  @Inject
  RevenueVTPService revenueVTPService;

  @Scheduled(cron = "${config.cron.create.revenue_statement}")
  public Uni<Void> createRevenueStatement() {
    log.info("=====createRevenueStatement=====");
    return ReactiveConverter.toUni(super.executeTask("createRevenueStatement", cronCalculationBillRevenue));
  }

  @Override
  protected Mono<Void> taskAction() {
    log.debug("=====start_JobCreateRevenueStatement======");
    return ReactiveConverter.toMono(revenueVTPService.processRevenueEveryMonth());
  }
}
