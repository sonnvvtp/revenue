package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.repository.HrOrganizationDAO;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@ApplicationScoped
@RequiredArgsConstructor
public class HrOrganizationDAOImpl implements HrOrganizationDAO {

    private final ConnectionPool oraclePool;

    @Override
    public Uni<Long> getOrgIdByOrgCode(String orgCode) {
        String sql = """
                select ORG_ID
                from ERP_AC.HR_ORGANIZATION
                where ORGCODE = :orgCode
                """;
        return executeAndGetValue(oraclePool, sql, Map.of("orgCode", orgCode), "ORG_ID", Long.class);
    }

    @Override
    public Multi<Long> getOrgIdByPostCode(String postCode) {
        String sql = """
                select ORGANIZATION_ID
                from ERP_AC.HR_POSTCODE
                where POSTCODE = :postCode
                UNION
                select ORGANIZATION_ID
                from ERP_AC.HR_POSTCODE_LOG
                where POSTCODE = :postCode
                """;
        return executeMultiAndGetValue(oraclePool, sql, Map.of("postCode", postCode), "ORGANIZATION_ID", Long.class);
    }
}
