package com.viettelpost.platform.bms.portal.model.enums;

import lombok.Getter;

@Getter
public enum ReportDebtType {
    DEBT_CPN(1, "Công nợ chuyển phát nhanh"),
    DEBT_LOG(2, "Công nợ Logistic"),
    DEBT_VNB(3, "Công nợ nội bộ"),
    DEBT_ALL(4, "ALL");

    private final int code;
    private final String name;

    ReportDebtType(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ReportDebtType fromCode(int code) {
        for (ReportDebtType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Loại báo cáo doanh thu không hợp lệ");
    }
}
