package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FicoPayPeriodHisDTO {

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("PARTNER_ID")
    private Long partnerId;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PAY_CATEGORY_CONFIG_ID")
    private Long payCategoryConfigId;


    @JsonAlias("CONFIG_TYPE_OLD")
    private Long configTypeOld;

    @JsonAlias("CONFIG_VALUE_OLD")
    private String configValueOld;

    @JsonAlias("CONFIG_TYPE_NEW")
    private Long configTypeNew;

    @JsonAlias("CONFIG_VALUE_NEW")
    private String configValueNew;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("UPDATED_BY")
    private Long updatedBy;

    @JsonAlias("UPDATE_BY_NAME")
    private String updateByName;

    @JsonAlias("UPDATED_AT")
    private Date updateAt;


    @JsonAlias("UPDATED_TIME")
    private String updateTime;

    @JsonAlias("PAY_TYPE")
    private Integer payType;

    @JsonAlias("BANK_NAME")
    private String bankName;

    @JsonAlias("ACCOUNT_NO")
    private String accountNo;

    @JsonAlias("BENEFICIARY")
    private String beneficiary;


    @JsonAlias("CONFIG_TYPE_NAME_NEW")
    private String configTypeNewName;
}
