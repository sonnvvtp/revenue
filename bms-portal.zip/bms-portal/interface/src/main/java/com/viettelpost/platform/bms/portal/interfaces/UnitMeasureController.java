package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.request.UnitMeasureRequest;
import com.viettelpost.platform.bms.portal.service.handler.UnitMeasureService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/unit-measure")
@Tag(name = "API cấu hình đơn vị tính (xuất hóa đơn)")
@RequiredArgsConstructor
@Slf4j
public class UnitMeasureController {

    private final UnitMeasureService unitMeasureService;

    @POST
    @Path("/create")
    @Operation(summary = "Tạo cấu hình đơn vị tính")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createUnitMeasure(@RequestBody UnitMeasureRequest request) {
        return unitMeasureService.save(request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @PUT
    @Path("/{id}")
    @Operation(summary = "Cập nhật cấu hình đơn vị tính")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateUnitMeasure(@PathParam("id") Long id, @RequestBody UnitMeasureRequest request) {
        return unitMeasureService.update(id, request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Operation(summary = "Lấy cấu hình đơn vị tính theo search ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    @Path("/search")
    public Uni<Response> getUnitMeasureBySearch(
            @QueryParam("q") String keyword,
            @QueryParam("page") @DefaultValue("0") int page,
            @QueryParam("size") @DefaultValue("20") int size
    ) {
        return unitMeasureService.getSearch(keyword, page, size)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Operation(summary = "Lấy cấu hình đơn vị tính")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    @Path("")
    public Uni<Response> getAll(
    ) {
        return unitMeasureService.getAll()
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

}
