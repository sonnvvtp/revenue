package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.request.InvoiceReportRequest;
import com.viettelpost.platform.bms.portal.model.response.InvoiceReportResponse;
import com.viettelpost.platform.bms.portal.model.response.InvoiceReportResponse.InvoiceReportItem;
import com.viettelpost.platform.bms.portal.repository.InvoiceReportRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.RowSet;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import io.smallrye.mutiny.Uni;
import reactor.core.publisher.Mono;

import java.io.ByteArrayOutputStream;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class InvoiceReportRepositoryImpl implements InvoiceReportRepository {

    @Inject
    PgPool client;

    private InvoiceReportItem mapRowToInvoiceReportItem(Row row) {
        Long rowNum = 0L;
        try {
            rowNum = row.getLong("row_num");
        } catch (Exception e) {
            log.warn("Column row_num not found, using default value");
        }

        String invoiceDate = "";
        try {
            if (row.getLocalDateTime("invoice_export_date") != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                invoiceDate = row.getLocalDateTime("invoice_export_date").format(formatter);
            }
        } catch (Exception e) {
            log.warn("Column updated_at not found or invalid format");
        }

        return new InvoiceReportItem()
                .setStt(rowNum)
                .setInvoiceDate(invoiceDate)
                .setInvoiceNo(getStringValue(row, "invoice_number"))
                .setPaymentMethod(getStringValue(row, "payment_method"))
                .setCustomerCode(getStringValue(row, "buyer_code"))
                .setCustomerName(getStringValue(row, "customer_name"))
                .setUnitName(getStringValue(row, "customer_name"))
                .setTaxCode(getStringValue(row, "tax_code"))
                .setProductName(getStringValue(row,"item_name"))
                .setPrice(0.0)
                .setOrderCode(getStringValue(row,"order_code"))
                .setAmount(getDoubleValue(row, "item_amount_after_tax"))
                .setPreTaxAmount(getDoubleValue(row, "item_amount_before_tax"))
                .setTaxAmount(getDoubleValue(row, "item_tax_amount"))
                .setCreatedBy(getStringValue(row, "created_by_name"))
                .setCompanyCode(getStringValue(row,"company_code"))
                .setAddress(getStringValue(row,"address"));
    }

    private String getStringValue(Row row, String columnName) {
        try {
            return row.getString(columnName) != null ? row.getString(columnName) : "";
        } catch (Exception e) {
            log.warn("Column {} not found or invalid format", columnName);
            return "";
        }
    }

    private Double getDoubleValue(Row row, String columnName) {
        try {
            return row.getDouble(columnName);
        } catch (Exception e) {
            log.warn("Column {} not found or invalid format", columnName);
            return 0.0;
        }
    }

    @Override
    public Mono<InvoiceReportResponse> getInvoiceReport(InvoiceReportRequest request) {
        final String sql = buildInvoiceReportSql(request, false);
        final String countSql = buildInvoiceReportSql(request, true);

        // Sử dụng PgPool để truy vấn dữ liệu
        Uni<Long> countUni = client.query(countSql).execute()
                .map(rows -> {
                    if (rows.iterator().hasNext()) {
                        return rows.iterator().next().getLong(0);
                    }
                    return 0L;
                });

        // Chuyển đổi từ Uni sang Mono
        Mono<Long> countMono = Mono.fromFuture(countUni.subscribeAsCompletionStage());

        return countMono.flatMap(totalItems -> {
            // Chỉ query chi tiết nếu có dữ liệu (totalItems > 0)
            if (totalItems > 0) {
                Uni<List<InvoiceReportItem>> dataUni = client.query(sql).execute()
                        .map(rows -> {
                            List<InvoiceReportItem> items = new ArrayList<>();
                            for (Row row : rows) {
                                items.add(mapRowToInvoiceReportItem(row));
                            }
                            return items;
                        });

                Mono<List<InvoiceReportItem>> dataMono = Mono.fromFuture(dataUni.subscribeAsCompletionStage());

                return dataMono.map(data -> {
                    int totalPages = (int) Math.ceil((double) totalItems / request.getSize());

                    return new InvoiceReportResponse()
                            .setData(data)
                            .setTotalRecords(totalItems)
                            .setTotalPage(totalPages)
                            .setCurrentPage(request.getPage());
                });
            } else {
                // Trả về response rỗng nếu không có dữ liệu
                return Mono.just(new InvoiceReportResponse()
                        .setData(new ArrayList<>())
                        .setTotalRecords(0)
                        .setTotalPage(0)
                        .setCurrentPage(request.getPage()));
            }
        });
    }

    @Override
    public Mono<InvoiceReportResponse> getAllInvoiceReport(InvoiceReportRequest request) {
        final String sql = buildAllInvoiceReportSql(request);
        Uni<List<InvoiceReportItem>> dataUni = client.query(sql).execute()
                .map(rows -> {
                    List<InvoiceReportItem> items = new ArrayList<>();
                    for (Row row : rows) {
                        items.add(mapRowToInvoiceReportItem(row));
                    }
                    return items;
                });

        Mono<List<InvoiceReportItem>> dataMono = Mono.fromFuture(dataUni.subscribeAsCompletionStage());

        return dataMono.map(data -> {
            long totalItems = data.size();

            return new InvoiceReportResponse()
                    .setData(data)
                    .setTotalRecords(totalItems)
                    .setTotalPage(1)
                    .setCurrentPage(1);
        });
    }

    private String buildAllInvoiceReportSql(InvoiceReportRequest request) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ROW_NUMBER() OVER (ORDER BY a.id desc");
        sql.append(") AS row_num, ");
        sql.append("a.invoice_export_date,\n" +
                "       a.invoice_serial||''||a.invoice_number as invoice_number,\n" +
                "       a.payment_method,\n" +
                "       a.buyer_code,\n" +
                "       a.customer_name,\n" +
                "       a.customer_name unitName,\n" +
                "       a.tax_code,\n" +
                "       a.address,\n" +
                "       c.item_name,\n" +
                "       c.item_amount_before_tax,\n" +
                "       c.item_tax_amount,\n" +
                "       c.item_amount_after_tax,\n" +
                "       a.created_by,\n" +
                "       a.company_code," +
                "       c.item_tax_percent," +
                "       b.order_code," +
                "(select firstname || ' ' || lastname  from bms_payment.vtp_susers where userid = a.created_by limit 1) created_by_name ");

        sql.append(" FROM bms_payment.invoice_record a, bms_payment.invoice_record_line b,bms_payment.item_order c\n" +
                "where a.id= b.record_id\n" +
                "  and b.order_id= c.general_order_id\n" +
                "and a.record_status = 5 ");

        // Add filter conditions
        if (request.getFromDate() != null && !request.getFromDate().isEmpty()) {
            sql.append("AND CAST(invoice_export_date AS DATE) >= TO_DATE('").append(request.getFromDate()).append("', 'DD/MM/YYYY') ");
        }

        if (request.getToDate() != null && !request.getToDate().isEmpty()) {
            sql.append("AND CAST(invoice_export_date AS DATE) <= TO_DATE('").append(request.getToDate()).append("', 'DD/MM/YYYY') ");
        }

        if (request.getInvoiceNo() != null && !request.getInvoiceNo().isEmpty()) {
            sql.append("AND UPPER(invoice_serial||''||invoice_number) LIKE UPPER('%").append(request.getInvoiceNo()).append("%') ");
        }

        if (request.getTaxCode() != null && !request.getTaxCode().isEmpty()) {
            sql.append("AND UPPER(tax_code) LIKE UPPER('%").append(request.getTaxCode()).append("%') ");
        }
        if (request.getStatus() != null) {
            sql.append("AND record_status = ").append(request.getStatus()).append(" ");
        }

        if (request.getCustomerCode() != null && !request.getCustomerCode().isEmpty()) {
            sql.append("AND UPPER(buyer_code) LIKE UPPER('%").append(request.getCustomerCode()).append("%') ");
        }

        // Add order by
        sql.append("ORDER BY a.updated_at desc ");

        return sql.toString();
    }

    private String buildInvoiceReportSql(InvoiceReportRequest request, boolean isCount) {
        StringBuilder sql = new StringBuilder();
        if (isCount) {
            sql.append("SELECT COUNT(*) FROM ( ");
        }

        sql.append("SELECT ");

        if (!isCount) {
            sql.append("ROW_NUMBER() OVER (ORDER BY a.id desc ");
            sql.append(") AS row_num, ");

            sql.append("a.invoice_export_date,\n" +
                    "       a.invoice_serial||''||a.invoice_number invoice_number,\n" +
                    "       a.payment_method,\n" +
                    "       a.buyer_code,\n" +
                    "       a.customer_name,\n" +
                    "       a.customer_name unitName,\n" +
                    "       a.tax_code,\n" +
                    "       a.address,\n" +
                    "       c.item_name,\n" +
                    "       c.item_amount_before_tax,\n" +
                    "       c.item_tax_amount,\n" +
                    "       c.item_amount_after_tax,\n" +
                    "       a.created_by,\n" +
                    "       a.company_code," +
                    "       c.item_tax_percent," +
                    "       b.order_code, " +
                    "       (select firstname || ' ' || lastname  from bms_payment.vtp_susers where userid = a.created_by limit 1) created_by_name ");
        } else {
            sql.append("1 ");
        }

        sql.append(" FROM bms_payment.invoice_record a, bms_payment.invoice_record_line b,bms_payment.item_order c\n" +
                        "where a.id= b.record_id\n" +
                        "  and b.order_id= c.general_order_id\n" +
                        "and a.record_status = 5 ");
        // Add filter conditions
        if (request.getFromDate() != null && !request.getFromDate().isEmpty()) {
            sql.append("AND CAST(a.invoice_export_date AS DATE) >= TO_DATE('").append(request.getFromDate()).append("', 'DD/MM/YYYY') ");
        }

        if (request.getToDate() != null && !request.getToDate().isEmpty()) {
            sql.append("AND CAST(a.invoice_export_date AS DATE) <= TO_DATE('").append(request.getToDate()).append("', 'DD/MM/YYYY') ");
        }

        if (request.getInvoiceNo() != null && !request.getInvoiceNo().isEmpty()) {
            sql.append("AND UPPER(invoice_serial||''||invoice_number) LIKE UPPER('%").append(request.getInvoiceNo()).append("%') ");
        }

        if (request.getTaxCode() != null && !request.getTaxCode().isEmpty()) {
            sql.append("AND UPPER(tax_code) LIKE UPPER('%").append(request.getTaxCode()).append("%') ");
        }
        if (request.getStatus() != null) {
            sql.append("AND record_status = ").append(request.getStatus()).append(" ");
        }

        if (request.getCustomerCode() != null && !request.getCustomerCode().isEmpty()) {
            sql.append("AND UPPER(buyer_code) LIKE UPPER('%").append(request.getCustomerCode()).append("%') ");
        }

        if (isCount) {
            sql.append(") AS subquery_alias ");
        } else {
            // Add pagination
            sql.append("ORDER BY a.created_at desc ");

            // Adjust for pagination starting from 1 instead of 0
            int offset = (request.getPage() - 1) * request.getSize();
            int limit = request.getSize();

            sql.append(" OFFSET ").append(offset).append(" ROWS FETCH NEXT ").append(limit).append(" ROWS ONLY");
        }
        return sql.toString();
    }
} 