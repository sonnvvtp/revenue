package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.common.utils.DataMappingUtils;
import com.viettelpost.platform.bms.portal.common.exception.BusinessException;
import com.viettelpost.platform.bms.portal.model.dto.advance.*;
import com.viettelpost.platform.bms.portal.model.enums.BusinessAdvanceAcctType;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceAcctRequest;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceRecordByBillRequest;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceRecordGroupDetailRequest;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceRecordGroupRequest;
import com.viettelpost.platform.bms.portal.model.response.advance.AdvanceDetailAcctResponse;
import com.viettelpost.platform.bms.portal.repository.AdvanceAcctRepository;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.ColumnMetadata;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.Statement;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Flux;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@ApplicationScoped
@RequiredArgsConstructor
public class AdvanceAcctRepositoryImpl implements AdvanceAcctRepository {

    private final ConnectionPool oracleClient;

    private final PgPool pgClient;

    @ConfigProperty(name = "advance.payment.acct.businessCode", defaultValue = "UNG_COD")
    String businessCode;

    @ConfigProperty(name = "advance.debt.batchSize", defaultValue = "500")
    Integer batchSize;

    @Override
    public Multi<AdvanceRecordDTO> findListAdvanceRecordAcct(AdvanceAcctRequest request) {

        String sql = """
                SELECT
                	adv.PRE_RECORD_ADVANCE_ID,
                	adv.RECORD_NO,
                	adv.CUS_ID,
                	adv.CREATED_AT,
                	partner.PARTNER_EVTP_CODE as PARTNER_CODE,
                	adv.PAY_AMOUNT,
                	adv.FEE_AMOUNT - adv.PHI_AMOUNT as CLEAR_AMOUNT,
                	(SELECT cc.FIRSTNAME || ' ' || cc.LASTNAME FROM ERP_CUS.CUS_CUSTOMER  cc WHERE cc.CUS_ID = adv.CUS_ID) as CREATED_BY
                FROM ERP_AC.FICO_PRE_RECORD_ADVANCE adv
                join ERP_AC.FICO_PRE_RECORD_ADVANCE_LINE advLine on adv.PRE_RECORD_ADVANCE_ID = advLine.PRE_RECORD_ADVANCE_ID AND advLine.TYPE = 2
                join ERP_AC.FICO_PAY_BATCH batch on batch.PAY_BATCH_ID = advLine.PRE_PAY_RECORD_ID
                join ERP_AC.FICO_PAY_ADVANCE_PARTNER partner on partner.PARTNER_ID = adv.ADVANCE_PARTNER_ID
                join ERP_AC.FICO_BANK_TRANSFER transfer on transfer.PAYMENT_BATCH_ID = batch.PAY_BATCH_ID and transfer.STATUS = 1 and transfer.RES_TRANSACTION_ID is not null
                WHERE adv.RECORD_STATUS = 4
                """;

        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        Map<String, Object> params = new HashMap<>();
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += " and adv.CREATED_AT >= :fromDate and adv.CREATED_AT <= :toDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += " and adv.CREATED_AT >= :fromDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += " and adv.CREATED_AT <= :toDate ";
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += " order by adv.CREATED_AT desc";

        return executeMulti(oracleClient, sql, params, AdvanceRecordDTO.class);
    }

    @Override
    public Multi<AdvanceDetailAcctResponse> findAdvanceDetailAcctByBkC3(List<String> bkC3List, List<BusinessAdvanceAcctType> docTypes) {

        if (CollectionUtils.isEmpty(bkC3List)) {
            return Multi.createFrom().empty();
        }

        String sql = """
                select
                    raw.ref_doc_no,
                	raw.bk_c3,
                	raw.bk_c2,
                	raw.bk_c1,
                	asb.status
                FROM bms_payment.bms_acct_sub_business asb
                join bms_payment.bms_acct_sub_business_detail asbt on asb.acct_sub_business_id = asbt.acct_sub_business_id
                join bms_payment.bms_acct_line al on al.acct_sub_business_detail_id = asbt.acct_sub_business_detail_id
                join bms_payment.accounting_synthetic raw on raw.acct_synthetic_id = al.acct_synthetic_id
                where raw.bk_c3 = any($1) and raw.ref_doc_no = any($2)
                """;


        List<Object> params = new ArrayList<>();
        params.add(bkC3List.toArray());
        params.add(docTypes.stream().map(Enum::name).toArray());

        return executeMulti(pgClient, sql, Tuple.from(params), AdvanceDetailAcctResponse.class);
    }

    @Override
    public Multi<AdvanceBatchDTO> findListAdvanceBatchAcct(AdvanceAcctRequest request) {
        String sql = """
                SELECT
                DISTINCT
                    batch.PAY_BATCH_ID,
                    batch.batch_no,
                    batch.CUS_PO_CODE,
                    batch.CUS_ID ,
                    'DAROGAS' as PARTNER_CODE,
                    batch.PAY_AMOUNT,
                    batch.CREATED_AT,
                    (SELECT FIRSTNAME || ' ' || LASTNAME FROM VTP.SUSERS WHERE USERID = batch.CREATED_BY and ROWNUM = 1) as CREATED_BY
                FROM
                 	ERP_AC.FICO_PAY_BATCH batch
                WHERE
                 	batch.batch_status = 4
                 	AND EXISTS (
                 	SELECT
                 		1
                 	FROM
                 		ERP_AC.FICO_PAY_BATCH_LINE batchLine
                 	JOIN ERP_AC.FICO_PAY_RECORD_CLEAR clear ON
                 		clear.PAY_RECORD_CLEAR_ID = batchLine.PAY_RECORD_ID
                 	JOIN ERP_AC.FICO_PAY_RECORD_CLEAR_LINE clearLine ON
                 		clearLine.PAY_RECORD_CLEAR_ID = clear.PAY_RECORD_CLEAR_ID
                 	WHERE
                 		batchLine.pay_batch_id = batch.PAY_BATCH_ID
                 		AND clearLine.service_Code = 'GPUT'
                 		AND clear.RECORD_STATUS = 4
                )
                """;

        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        Map<String, Object> params = new HashMap<>();
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += " and batch.CREATED_AT >= :fromDate and batch.CREATED_AT <= :toDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += " and batch.CREATED_AT >= :fromDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += " and batch.CREATED_AT <= :toDate ";
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += " order by batch.CREATED_AT desc";

        return executeMulti(oracleClient, sql, params, AdvanceBatchDTO.class);
    }

    @Override
    public Multi<AdvanceQrRecordDTO> findAdvanceQrRecordAcct(AdvanceAcctRequest request) {
        String sql = """
                SELECT
                	DISTINCT clear.PAY_RECORD_CLEAR_ID ,
                	clear.RECORD_NO ,
                	clear.CUS_ID ,
                	clear.CUS_PO_CODE AS PARTNER_EVTP,
                	clear.PAY_AMOUNT,
                	clear.CREATED_AT,
                	(SELECT FIRSTNAME || ' ' || LASTNAME FROM VTP.SUSERS WHERE USERID = clear.CREATED_BY and ROWNUM = 1) as CREATED_BY,
                	partner.PARTNER_EVTP_CODE AS PARTNER_CODE
                FROM ERP_AC.FICO_PAY_RECORD_CLEAR clear
                join ERP_AC.FICO_PAY_RECORD_CLEAR_LINE clearLine on clearLine.PAY_RECORD_CLEAR_ID = clear.PAY_RECORD_CLEAR_ID
                join ERP_AC.EVTP_PAY_IN payin on payin.PAY_IN_ID = clearLine.PAY_IN_ID AND payin.M_PRODUCT = 'GPUT'
                join ERP_AC.FICO_PRE_BILL_COD billCod on CONCAT('UTCOD', billCod.BILL) = payin.BILL and billCod.TYPE = 1 and billCod.STATUS = 2
                join ERP_AC.FICO_PAY_ADVANCE_PARTNER partner on partner.PARTNER_ID = billCod.ADVANCE_PARTNER_ID
                WHERE EXISTS (SELECT
                	1
                	FROM ERP_AC.FICO_REQUEST_PAYMENT_LINE paymentLine
                	JOIN ERP_AC.FICO_REQUEST_PAYMENT payment on paymentLine.REQ_VTP_ORDER_ID = payment.REQ_VTP_ORDER_ID
                	WHERE clear.RECORD_NO = paymentLine.ITEM_CODE AND payment.DOC_STATUS = 1
                	)
                """;

        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        Map<String, Object> params = new HashMap<>();
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += " and clear.CREATED_AT >= :fromDate and clear.CREATED_AT <= :toDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += " and clear.CREATED_AT >= :fromDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += " and clear.CREATED_AT <= :toDate ";
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += " order by clear.CREATED_AT desc";

        return executeMulti(oracleClient, sql, params, AdvanceQrRecordDTO.class);
    }

    @Override
    public Multi<AdvancePTCRecordDTO> findAdvancePTCRecordAcct(AdvanceAcctRequest request) {
        String sql = """
                select
                      ADVANCE_ACCT_ID,
                      ADVANCE_ACCT_NO,
                      CREATED_AT,
                      PARTNER_CODE,
                      PARTNER_EVTP,
                      POST_ID,
                      ORG_ID,
                      CUS_POST_ID,
                      CUS_ORG_ID,
                      AMOUNT,
                      DEBT_DATE,
                      BANK_ACCOUNT_NO,
                      TRANSACTION_ID,
                      (SELECT ccc.CUS_ID FROM ERP_CUS.CUS_CUSTOMER_CODE ccc where faa.PARTNER_EVTP = ccc.EVTPCODE AND rownum = 1) AS CUS_ID,
                      CREATED_BY
                  from ERP_AC.FICO_ADVANCE_ACCT faa
                  WHERE DOCTYPE = :docType
                """;

        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        Map<String, Object> params = new HashMap<>();
        params.put("docType", "U2");
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += " and CREATED_AT >= :fromDate and CREATED_AT <= :toDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += " and CREATED_AT >= :fromDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += " and CREATED_AT <= :toDate ";
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += " order by CREATED_AT desc";

        return executeMulti(oracleClient, sql, params, AdvancePTCRecordDTO.class);
    }

    @Override
    public Multi<AdvanceReturnRecordDTO> findAdvanceReturnRecordAcct(AdvanceAcctRequest request) {
        String sql = """
                select
                      ADVANCE_ACCT_ID,
                      ADVANCE_ACCT_NO,
                      CREATED_AT,
                      PARTNER_CODE,
                      PARTNER_EVTP,
                      POST_ID,
                      ORG_ID,
                      CUS_POST_ID,
                      CUS_ORG_ID,
                      AMOUNT,
                      DEBT_DATE,
                      BANK_ACCOUNT_NO,
                      TRANSACTION_ID,
                      (SELECT ccc.CUS_ID FROM ERP_CUS.CUS_CUSTOMER_CODE ccc where faa.PARTNER_EVTP = ccc.EVTPCODE AND rownum = 1) AS CUS_ID,
                      CREATED_BY
                  from ERP_AC.FICO_ADVANCE_ACCT faa
                  WHERE DOCTYPE = :docType
                """;

        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        Map<String, Object> params = new HashMap<>();
        params.put("docType", "U5");
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += " and CREATED_AT >= :fromDate and CREATED_AT <= :toDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += " and CREATED_AT >= :fromDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += " and CREATED_AT <= :toDate ";
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += " order by CREATED_AT desc";

        return executeMulti(oracleClient, sql, params, AdvanceReturnRecordDTO.class);
    }

    @Override
    public Multi<AdvanceTTDTRecordDTO> findAdvanceTTDTRecordAcct(AdvanceAcctRequest request) {

        String sql = """
                SELECT distinct
                	batch.PAY_BATCH_ID,
                	batch.BATCH_NO,
                	cod.CUS_ID,
                    batch.CREATED_AT,
                    batch.CUS_PO_CODE as PARTNER_EVTP,
                    batch.CUS_PO_CODE PARTNER_CODE,
                    (SELECT FIRSTNAME || ' ' || LASTNAME FROM VTP.SUSERS WHERE USERID = batch.CREATED_BY and ROWNUM = 1) as CREATED_BY,
                    batch.PAY_AMOUNT
                from ERP_AC.FICO_PAY_BATCH batch
                join ERP_AC.FICO_PAY_BATCH_LINE batchLine on batchLine.PAY_BATCH_ID = batch.PAY_BATCH_ID AND batchLine.RECORD_TYPE = 20
                join ERP_AC.FICO_PAY_RECORD_COD cod on cod.PAY_RECORD_COD_ID = batchLine.PAY_RECORD_ID
                join ERP_AC.FICO_BANK_TRANSFER transfer on transfer.PAYMENT_BATCH_ID = batch.PAY_BATCH_ID and transfer.STATUS = 1 and transfer.RES_TRANSACTION_ID is not null
                join ERP_AC.FICO_BANK_ACCOUNT_INFO info on info.BANK_ACCOUNT_INFO_ID = batch.BANK_FROM_ID
                WHERE BATCH_STATUS = 4 AND REQ_TYPE = 6
                """;
        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        Map<String, Object> params = new HashMap<>();
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += " and batch.CREATED_AT >= :fromDate and batch.CREATED_AT <= :toDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += " and batch.CREATED_AT >= :fromDate ";
            params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += " and batch.CREATED_AT <= :toDate ";
            params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += " order by batch.CREATED_AT desc";

        return executeMulti(oracleClient, sql, params, AdvanceTTDTRecordDTO.class);
    }

    @Override
    public Uni<String> getBKC3AdvanceAcctByRecordId(Long preRecordId) {
        String sql = """
                SELECT
                	adv.RECORD_NO
                from ERP_AC.FICO_PRE_RECORD_ADVANCE adv
                where adv.PRE_RECORD_ADVANCE_ID = :preRecordId
                """;

        return executeAndGetValue(oracleClient, sql, Map.of("preRecordId", preRecordId), "RECORD_NO", String.class);
    }

    @Override
    public Multi<AdvanceDetailAcctResponse> findDetailAcctByBkC3AndBusinessType(String bkC3, String businessType) {

        String sql = """
                WITH target_acct_sub_business AS (
                    SELECT asb.acct_sub_business_id,
                           raw.ref_doc_no,
                           raw.bk_c3,
                           raw.bk_c2,
                           raw.bk_c1,
                           asb.status,
                           asb.document_no,
                           asb.acct_batch_id,
                           asb.acct_time
                    FROM bms_payment.accounting_synthetic raw
                    left JOIN bms_payment.bms_acct_line al ON al.acct_synthetic_id = raw.acct_synthetic_id
                    left JOIN bms_payment.bms_acct_sub_business_detail asbt ON asbt.acct_sub_business_detail_id = al.acct_sub_business_detail_id
                    left JOIN bms_payment.bms_acct_sub_business asb ON asb.acct_sub_business_id = asbt.acct_sub_business_id
                    WHERE raw.bk_c3 = $1 and raw.ref_doc_no = $2
                    LIMIT 1
                )
                
                SELECT
                    t.ref_doc_no,
                    t.bk_c3,
                    t.bk_c2,
                    t.bk_c1,
                    t.status,
                    t.document_no,
                    t.acct_batch_id,
                    t.acct_time,
                    array_agg(
                        json_build_object(
                            'drcr', asbt.drcr,
                            'bp_code', asbt.bp_code,
                            'gl_account', asbt.gl_account,
                            'profit_ctr', asbt.profit_ctr,
                            'amount', asbt.amount
                        )
                    ) AS sub_details
                FROM target_acct_sub_business t
                left JOIN bms_payment.bms_acct_sub_business_detail asbt ON asbt.acct_sub_business_id = t.acct_sub_business_id
                GROUP BY
                    t.ref_doc_no,
                    t.bk_c3,
                    t.bk_c2,
                    t.bk_c1,
                    t.status,
                    t.document_no,
                    t.acct_batch_id,
                    t.acct_time
                """;

        return executeMulti(pgClient, sql, Tuple.of(bkC3, businessType), AdvanceDetailAcctResponse.class);
    }

    @Override
    public Uni<String> getBKC3AdvanceQrAcctByPayRecordClearId(Long payRecordClearId) {
        String sql = """
                Select clear.RECORD_NO FROM ERP_AC.FICO_PAY_RECORD_CLEAR clear
                where clear.PAY_RECORD_CLEAR_ID = :payRecordClearId
                """;
        return executeAndGetValue(oracleClient, sql, Map.of("payRecordClearId", payRecordClearId), "RECORD_NO", String.class);
    }

    @Override
    public Uni<String> getBKC3AdvanceBatchAcctByPayBatchId(Long payBatchId) {
        String sql = """
                select batch.BATCH_NO from ERP_AC.FICO_PAY_BATCH batch
                where batch.PAY_BATCH_ID = :payBatchId
                """;
        return executeAndGetValue(oracleClient, sql, Map.of("payBatchId", payBatchId), "BATCH_NO", String.class);
    }

    @Override
    public Uni<String> getBKC3AdvanceAcctAdvanceAcctId(Long advanceAcctId) {
        String sql = """
                select faa.ADVANCE_ACCT_NO from ERP_AC.FICO_ADVANCE_ACCT faa
                where faa.ADVANCE_ACCT_ID = :advanceAcctId
                """;
        return executeAndGetValue(oracleClient, sql, Map.of("advanceAcctId", advanceAcctId), "ADVANCE_ACCT_NO", String.class);
    }

    @Override
    public Uni<Integer> findListAdvanceAcctCount(AdvanceRecordGroupRequest advanceRecordGroupRequest) {
        String sql = """
                select count(1) as total
                from ERP_AC.FICO_ADVANCE_ACCT
                where 1 = 1
                """;

        Map<String, Object> params = new HashMap<>();

        if (StringUtils.isNotBlank(advanceRecordGroupRequest.getAdvancedFilter())) {
            sql += """
                     and (
                        ADVANCE_ACCT_NO like :advancedFilter || '%'
                        or RECORD_NO like :advancedFilter || '%'
                        or ADVANCE_NO like :advancedFilter || '%'
                        or BATCH_NO like :advancedFilter || '%'
                        or TRANSACTION_ID = :advancedFilter
                        or to_char(CUS_ID) = :advancedFilter
                        ) 
                    """;
            params.put("advancedFilter", advanceRecordGroupRequest.getAdvancedFilter());
        }

        if (StringUtils.isNotBlank(advanceRecordGroupRequest.getDocType())) {
            sql += " and DOCTYPE = :docType ";
            params.put("docType", advanceRecordGroupRequest.getDocType());
        }

        return executeAndGetValue(oracleClient, sql, params, "total", Integer.class);
    }

    @Override
    public Multi<AdvanceAcctDTO> findListAdvanceAcct(AdvanceRecordGroupRequest advanceRecordGroupRequest) {

        String sql = """
                select f.*, row_number() over (order BY created_at desc) as row_number
                from ERP_AC.FICO_ADVANCE_ACCT f
                where 1 = 1
                """;

        int page = Objects.isNull(advanceRecordGroupRequest.getPage()) ? 1 : advanceRecordGroupRequest.getPage();
        int size = Objects.isNull(advanceRecordGroupRequest.getSize()) ? 10 : advanceRecordGroupRequest.getSize();

        Map<String, Object> params = new HashMap<>();

        if (StringUtils.isNotBlank(advanceRecordGroupRequest.getAdvancedFilter())) {
            sql += """
                     and (
                        ADVANCE_ACCT_NO like :advancedFilter || '%'
                        or RECORD_NO like :advancedFilter || '%'
                        or ADVANCE_NO like :advancedFilter || '%'
                        or BATCH_NO like :advancedFilter || '%'
                        or TRANSACTION_ID = :advancedFilter
                        or to_char(CUS_ID) = :advancedFilter
                        ) 
                    """;
            params.put("advancedFilter", advanceRecordGroupRequest.getAdvancedFilter());
        }

        if (StringUtils.isNotBlank(advanceRecordGroupRequest.getDocType())) {
            sql += " and DOCTYPE = :docType ";
            params.put("docType", advanceRecordGroupRequest.getDocType());
        }

        String finalSql = """
                select a.* from (%s) a where row_number between :startIndex and :endIndex
                """;

        int startIndex = (page - 1) * size + 1;
        int endIndex = startIndex - 1 + size;

        finalSql = finalSql.formatted(sql);

        params.put("startIndex", startIndex);
        params.put("endIndex", endIndex);

        return executeMulti(oracleClient, finalSql, params, AdvanceAcctDTO.class);
    }

    @Override
    public Uni<Integer> findListAdvanceAcctDetailCount(AdvanceRecordGroupDetailRequest request) {

        String sql = """
                select count(1) as total
                from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                where faad.ADVANCE_ACCT_ID = :advanceAcctId
                """;
        return executeAndGetValue(oracleClient, sql, Map.of("advanceAcctId", request.getAdvanceAcctId()), "total", Integer.class);
    }

    @Override
    public Multi<AdvanceAcctDetailDTO> findListAdvanceAcctDetail(AdvanceRecordGroupDetailRequest request) {
        String sql = """
                select f.DOCTYPE from ERP_AC.FICO_ADVANCE_ACCT f
                where f.ADVANCE_ACCT_ID = :advanceAcctId
                """;

        return executeAndGetValue(oracleClient, sql, Map.of("advanceAcctId", request.getAdvanceAcctId()), "DOCTYPE", String.class)
                .onItem()
                .transformToMulti(doctype -> {
                    BusinessAdvanceAcctType businessAdvanceAcctType = BusinessAdvanceAcctType.getBusinessType(doctype);
                    String selectSql = null;
                    switch (businessAdvanceAcctType) {
                        case U2, U6 -> {
                            selectSql = """
                                    select * from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                                    join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                                    join ERP_AC.EVTP_BILL_TRAN evtp on evtp.EVTP_BILL_TRAN_ID = faad.REF_ID
                                    where faad.ADVANCE_ACCT_ID = :advanceAcctId
                                    """;
                        }
                        case U4, U5, U1, U7, U3 -> {
                            selectSql = """
                                    select * from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                                    join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                                    join ERP_AC.EVTP_PAY_IN payin on payin.PAY_IN_ID = faad.REF_ID
                                    where faad.ADVANCE_ACCT_ID = :advanceAcctId
                                    """;
                        }
                    }

                    if (Objects.isNull(selectSql)) {
                        return Multi.createFrom().empty();
                    }

                    return mappingAdvanceAcctDetail(selectSql, Map.of("advanceAcctId", request.getAdvanceAcctId()));

                });
    }

    @Override
    public Uni<Integer> findListAdvanceAcctByBillCount(AdvanceRecordByBillRequest request) {
        if (StringUtils.isBlank(request.getAdvancedFilter())) {
            return Uni.createFrom().item(0);
        }

        BusinessAdvanceAcctType businessAdvanceAcctType = BusinessAdvanceAcctType.getBusinessType(request.getDocType());
        String selectSql = null;
        switch (businessAdvanceAcctType) {
            case U2, U6 -> {
                selectSql = """
                                    select count(1) as total
                                    from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                                    join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                                    join ERP_AC.EVTP_BILL_TRAN evtp on evtp.EVTP_BILL_TRAN_ID = faad.REF_ID
                                    where evtp.BILL = :advancedFilter
                                    """;
            }
            case U4, U5, U1, U7, U3 -> {
                selectSql = """
                                    select count(1) as total
                                    from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                                    join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                                    join ERP_AC.EVTP_PAY_IN payin on payin.PAY_IN_ID = faad.REF_ID
                                    where payin.BILL = :advancedFilter
                                    """;
            }
            default -> throw new BusinessException("docType không hợp lệ");
        }

        Map<String, Object> params = new HashMap<>();
        params.put("advancedFilter", request.getAdvancedFilter());

        return executeAndGetValue(oracleClient, selectSql, params, "total", Integer.class);

    }

    @Override
    public Multi<AdvanceAcctDTO> findListAdvanceAcctByBill(AdvanceRecordByBillRequest request) {

        if (StringUtils.isBlank(request.getAdvancedFilter())) {
            return Multi.createFrom().empty();
        }

        BusinessAdvanceAcctType businessAdvanceAcctType = BusinessAdvanceAcctType.getBusinessType(request.getDocType());
        String selectSql = null;
        switch (businessAdvanceAcctType) {
            case U2, U6 -> {
                selectSql = """
                                    select faa.*, row_number() over (order BY faa.created_at desc) as row_number
                                    from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                                    join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                                    join ERP_AC.EVTP_BILL_TRAN evtp on evtp.EVTP_BILL_TRAN_ID = faad.REF_ID
                                    where evtp.BILL = :advancedFilter
                                    """;
            }
            case U4, U5, U1, U7, U3 -> {
                selectSql = """
                                    select faa.*, row_number() over (order BY faa.created_at desc) as row_number
                                    from ERP_AC.FICO_ADVANCE_ACCT_DETAIL faad
                                    join ERP_AC.FICO_ADVANCE_ACCT faa on faa.ADVANCE_ACCT_ID = faad.ADVANCE_ACCT_ID
                                    join ERP_AC.EVTP_PAY_IN payin on payin.PAY_IN_ID = faad.REF_ID
                                    where payin.BILL = :advancedFilter
                                    """;
            }
            default -> throw new BusinessException("docType không hợp lệ");
        }

        Map<String, Object> params = new HashMap<>();
        params.put("advancedFilter", request.getAdvancedFilter());

        int page = Objects.isNull(request.getPage()) ? 1 : request.getPage();
        int size = Objects.isNull(request.getSize()) ? 10 : request.getSize();
        int startIndex = (page - 1) * size + 1;
        int endIndex = startIndex - 1 + size;

        String finalSql = """
                select a.* from (%s) a where row_number between :startIndex and :endIndex
                """.formatted(selectSql);

        params.put("startIndex", startIndex);
        params.put("endIndex", endIndex);

        return executeMulti(oracleClient, finalSql, params, AdvanceAcctDTO.class);
    }

    @Override
    public Multi<String> findListRawDataByListRefNumber(List<String> refNumberList, Long businessId) {
        String sql = """
                select ref_number
                from bms_payment.accounting_synthetic
                where ref_number = any($1) and business_id = $2
                """;

        return executeMultiAndGetValue(pgClient, sql, Tuple.of(refNumberList.toArray(), businessId), "ref_number", String.class);
    }

    @Override
    public Uni<Long> findAcctBusinessIdConfig() {
        String sql = """
                select
                    abc.business_id
                from bms_payment.acct_business_config abc
                where abc.business_code = $1
                """;

        return executeAndGetValue(pgClient, sql, Tuple.of(businessCode), "business_id", Long.class);
    }

    @Override
    public Uni<Boolean> deleteAdvanceAcctByListId(List<Long> advanceAcctIdList, Connection connection) {

        String sql = """
                delete from ERP_AC.FICO_ADVANCE_ACCT fa
                where fa.ADVANCE_ACCT_ID in (:advanceAcctIdList)
                """;
        if (Objects.nonNull(connection)) {
            return executeOnly(connection, sql, Map.of("advanceAcctIdList", advanceAcctIdList));
        }

        return executeOnly(oracleClient, sql, Map.of("advanceAcctIdList", advanceAcctIdList));
    }

    @Override
    public Multi<BillReturnAcctDTO> findListBillReturnForAccounting(List<String> billList) {
        String sql = """
                    SELECT partner.PARTNER_EVTP_CODE as PARTNER_CODE, -- Mã đối tác cho ứng tiền.
                        epb.POST_ID as POST_ID, -- ID_BC bưu cục của TTKDCP
                        epb.ORG_ID as ORG_ID, -- ID chi nhánh của TTKDCP
                        payin.POST_ID CUS_POST_ID, -- ID_BC bưu cục của KH
                        payin.ORG_ID CUS_ORG_ID, -- ID chi nhánh của KH
                        payin.PAY_IN_ID,
                        payin.PARTNER_EVTP as PARTNER_EVTP,
                        payin.AMT AS AMOUNT,
                        payin.DATEBILL,
                        to_char(payin.DATEBILL, 'YYYY-MM') AS YEAR_MONTH
                    FROM ERP_AC.EVTP_PAY_IN payin
                    join ERP_AC.FICO_PRE_BILL_COD billCod on CONCAT('UTCOD', billCod.BILL) = payin.BILL and billCod.TYPE = 1
                    join ERP_AC.FICO_PAY_ADVANCE_PARTNER partner on partner.PARTNER_ID = billCod.ADVANCE_PARTNER_ID
                    join ERP_AC.ERP_PARTNER_BANK epb on epb.PARTNER_ID = partner.PARTNER_EVTP_ID
                    WHERE payin.bill LIKE 'UTCOD%'
                    AND payin.bill in (:billList)
                    """;
        Map<String, Object> params = Map.of("billList", billList);
        return executeMulti(oracleClient, sql, params, BillReturnAcctDTO.class);
    }

    @Override
    public Uni<Void> saveBatch(List<AdvanceAcctEntity> advanceDebt, Connection connection) {
        String sql = """
                insert into ERP_AC.FICO_ADVANCE_ACCT (
                    ADVANCE_ACCT_ID,
                    DOCTYPE,
                    ADVANCE_ACCT_NO,
                    RECORD_NO,
                    BATCH_NO,
                    ADVANCE_NO,
                    PARTNER_CODE,
                    PARTNER_EVTP,
                    POST_ID,
                    ORG_ID,
                    CUS_POST_ID,
                    CUS_ORG_ID,
                    AMOUNT,
                    DISCOUNT,
                    FEE_AMOUNT,
                    DEBT_DATE,
                    DOC_DATE,
                    ACCOUNTING_DATE,
                    SERVICE_CODE,
                    BANK_ACCOUNT_NO,
                    TRANSACTION_ID,
                    STATUS,
                    DOC_STATUS,
                    CUS_ID,
                    CREATED_AT,
                    CREATED_BY,
                    UPDATED_AT
                ) values (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    current_timestamp,
                    ?,
                    current_timestamp
                )
                """;
        return executeOnlyInsertOracleBatch(connection, sql, advanceDebt, batchSize,  "createdAt", "updatedAt", "updatedBy")
                .replaceWithVoid();
    }

    @Override
    public Uni<Long> getNextId() {
        String sql = "select ERP_AC.FICO_ADVANCE_ACCT_SEQ.nextval as seq from dual";

        return executeAndGetValue(oracleClient, sql, "seq", Long.class);
    }

    @Override
    public Uni<AcctBusinessConfigDTO> findAcctBusinessConfig() {
        String sql = """
                select
                    abc.acct_business_config_id,
                    abc.business_id,
                    abc.business_code,
                    abc.description,
                    abc.is_active
                from bms_payment.acct_business_config abc
                where abc.business_code = $1
                """;

        return execute(pgClient, sql, Tuple.of(businessCode), AcctBusinessConfigDTO.class);
    }

    @Override
    public Multi<BillReturnAggregateAcctDTO> findListBillReturnAggregateForAccounting(List<Long> idList) {
        String sql = """
                select
                    ADVANCE_ACCT_ID,
                    ADVANCE_ACCT_NO,
                    RECORD_NO,
                    BATCH_NO,
                    DOC_DATE,
                    PARTNER_EVTP,
                    PARTNER_CODE,
                    POST_ID,
                    ORG_ID,
                    CUS_POST_ID,
                    CUS_ORG_ID,
                    DEBT_DATE,
                    AMOUNT,
                    BANK_ACCOUNT_NO,
                    TRANSACTION_ID,
                    CREATED_AT,
                    ACCOUNTING_DATE
                from ERP_AC.FICO_ADVANCE_ACCT
                where DOCTYPE = :docType and ADVANCE_ACCT_ID in (:idList)
                order by DOC_DATE
                """;
        Map<String, Object> params = new HashMap<>();
        params.put("docType", "U5");
        params.put("idList", idList);

        return executeMulti(oracleClient, sql, params, BillReturnAggregateAcctDTO.class);
    }

    private Multi<AdvanceAcctDetailDTO> mappingAdvanceAcctDetail(String sql, Map<String, Object> params) {
        return ReactiveConverter.toMulti(Flux.usingWhen(oracleClient.create(), (connection) -> {
            Map<String, Object> finalParams = new HashMap<>();
            String finalSql = sql;

            for(Map.Entry<String, Object> entry : params.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (value instanceof Collection<?> collectionValue) {
                    String placeholder = IntStream.range(0, collectionValue.size()).mapToObj((ix) -> ":" + ix).collect(Collectors.joining(", "));
                    finalSql = finalSql.replaceAll(":" + key, placeholder);
                    Object[] values = collectionValue.toArray();

                    for(int i = 0; i < values.length; ++i) {
                        finalParams.put("" + i, values[i]);
                    }
                } else {
                    finalParams.put(key, value);
                }
            }

            Statement statement = connection.createStatement(finalSql);

            for(Map.Entry<String, Object> entry : finalParams.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (Objects.isNull(value)) {
                    statement.bindNull(key, String.class);
                } else {
                    statement.bind(key, value);
                }
            }
            return Flux.from(statement.execute()).flatMap((result) -> result.map((row, metadata) -> {
                AdvanceAcctDetailDTO dto = new AdvanceAcctDetailDTO();
                dto.setAdvanceAcctId(row.get("ADVANCE_ACCT_ID", Long.class));
                dto.setAdvanceAcctDetailId(row.get("ADVANCE_ACCT_DETAIL_ID", Long.class));
                dto.setRefId(row.get("REF_ID", Long.class));

                Map<String, Object> rowMap = new HashMap<>();

                for(ColumnMetadata columnName : metadata.getColumnMetadatas()) {
                    rowMap.put(columnName.getName(), row.get(columnName.getName(), Object.class));
                }

                dto.setDetails(rowMap);
                return dto;

            }));
        }, Connection::close));
    }
}
