package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.AddPaymentPeriodCusRequest;
import com.viettelpost.platform.bms.portal.model.request.CusManagementRequest;
import com.viettelpost.platform.bms.portal.model.request.DeclareAddExcelRequest;
import com.viettelpost.platform.bms.portal.service.handler.CustomerManagementService;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;

import static com.viettelpost.platform.bms.common.exception.BaseResponse.errorApiWithHttpStatusCodeVTP;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("management-payment/cus")
@Tag(name = "Customer ManagementController")
@RequiredArgsConstructor
public class CustomerManagementController {

    @Inject
    CustomerManagementService customerManagementService;

    @Inject
    AuthenticationContext authenticationContext;


    @POST
    @Path("/list")
    @Operation(summary = "danh sách khách hàng theo cusId")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListCusManagement(@RequestBody CusManagementRequest request) {
        return customerManagementService.getListCusManagement(request);
    }

    @GET
    @Path("/list/evtp")
    @Operation(summary = "danh sách mã khách hàng theo cusId")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListDetailCusManagementEvtp(@QueryParam(value = "cusId") Long cusId,
                                                        @QueryParam(value = "page") int page,
                                                        @QueryParam(value = "size") int size) {
        return customerManagementService.getListPartnerEvtpByCus(cusId, page, size).map(result -> BaseResponse.successApi(result,"OK"));
    }

    @POST
    @Path("/declare/list")
    @Operation(summary = " danh sach khai báo ki thanh toan khách hàng theo cusId")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> listPaymentPeriodByCus(@RequestBody CusManagementRequest request) {
        return customerManagementService.getListCusManagementDeclare(request);
    }


    @GET
    @Path("/get-info-cus")
    @Operation(summary = "danh sách khách hàng theo cusId")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getInfoPaymentByCus(@QueryParam(value = "cusId") Long cusId) {
        return customerManagementService.getInfoPaymentByCus(cusId);
    }

    @POST
    @Path("/declare/add")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Operation(summary = " tao ki thanh toan khách hàng theo cusId")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> addListPaymentPeriodByCus(@Valid DeclareAddExcelRequest request) {
        try {
            CustomUser customUser = authenticationContext.getCurrentUser();
            String token = authenticationContext.getToken();
            return customerManagementService.importFileExcelAddPaymentPeriodByCus(request, customUser.getUserId(),token);
        }catch (Exception ex){
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, ex.getMessage(), null));
        }

    }

    @POST
    @Path("/import-declare-add")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Operation(summary = "Import file excel partner evtp by cus")
    @APIResponse(responseCode = "200", description = "Returns an Excel partner evtp by cus")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> importExcelDeclareAdd(@Valid DeclareAddExcelRequest request) {
        try {
            CustomUser customUser = authenticationContext.getCurrentUser();
            return customerManagementService.importFileExcelGetInfoByCus(request,customUser.getUserId());
        }catch (Exception ex){
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, ex.getMessage(), null));

        }
    }

    @POST
    @Path("/export-declare-list")
    @Operation(summary = "Import file excel partner evtp by cus")
    @APIResponse(responseCode = "200", description = "Returns an Excel partner evtp by cus")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportDeclareCustomer(@RequestBody CusManagementRequest request) {
        try {
            return customerManagementService.exportExcelListCusDeclare(request).map(bos ->{
                String fileName = "Danh sách KH khai báo thanh toán hàng ngày"  + ".xlsx";
                return Response.ok(bos.toByteArray())
                        .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                        .header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                        .build();
            });
        }catch (Exception ex){
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, ex.getMessage(), null));
        }

    }

    @POST
    @Path("/declare/list/his")
    @Operation(summary = " danh sach lịch sử khai báo ki thanh toan khách hàng theo cusId")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> listPaymentPeriodByCus(@QueryParam(value = "cusId") Long cusId,
                                                @QueryParam(value = "page") int page,
                                                @QueryParam(value = "size") int size) {
        return customerManagementService.getListHisDeclareByCus(cusId, page, size).map(result -> BaseResponse.successApi(result,"OK"));

    }


    @GET
    @Path("/history-file")
    @Operation(summary = " hủy hình thức thanh toán")
    @APIResponse(responseCode = "200", description = "return hủy hình thức thanh toán")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> historyListFileUpload(@QueryParam(value = "page") int page,
                                          @QueryParam(value = "size") int size) {
        return customerManagementService.getListHistoryUploadFileCus(page, size).map(result -> BaseResponse.successApi(result,"OK"));

    }

    @GET
    @Path("/cancel-cus/{cusId}")
    @Operation(summary = " hủy hình thức thanh toán")
    @APIResponse(responseCode = "200", description = "return hủy hình thức thanh toán")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> cancelCusDeclare(@PathParam(value = "cusId")  Long cusId) {
        try {
            CustomUser customUser = authenticationContext.getCurrentUser();
            return customerManagementService.cancelCusIdDeclare(cusId,customUser.getUserId());
        }catch (Exception ex){
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST,ex.getMessage(),null));
        }

    }
}
