package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.advance.AdvanceAcctDetailEntity;
import com.viettelpost.platform.bms.portal.repository.AdvanceAcctDetailRepository;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.List;
import java.util.Map;

@ApplicationScoped
@RequiredArgsConstructor
public class AdvanceAcctDetailRepositoryImpl implements AdvanceAcctDetailRepository {

    @ConfigProperty(name = "advance.debt.batchSize", defaultValue = "500")
    Integer batchSize;

    private final ConnectionPool oracleClient;

    @Override
    public Uni<Void> saveBatch(List<AdvanceAcctDetailEntity> entities, Connection connection) {
        String sql = """
                insert into ERP_AC.FICO_ADVANCE_ACCT_DETAIL (
                    ADVANCE_ACCT_DETAIL_ID,
                    ADVANCE_ACCT_ID,
                    REF_ID
                ) values (
                    ERP_AC.FICO_ADVANCE_ACCT_DETAIL_SEQ.nextval,
                    ?,
                    ?
                )
                """;

        return executeOnlyInsertOracleBatch(connection, sql, entities, batchSize, "advanceAcctDetailId")
                .replaceWithVoid();
    }

    @Override
    public Uni<Boolean> deleteByListAdvAcctId(List<Long> ids, Connection connection) {
        String sql = """
                delete from ERP_AC.FICO_ADVANCE_ACCT_DETAIL
                where ADVANCE_ACCT_ID in (:ids)
                """;
        return executeOnly(connection, sql, Map.of("ids", ids));
    }
}
