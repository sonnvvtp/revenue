package com.viettelpost.platform.bms.portal.repository;

import io.smallrye.mutiny.Uni;

public interface HrPostCodeDAO extends BaseRepository{

    Uni<Long> getPostIdByPostCode(String postCode);
}
