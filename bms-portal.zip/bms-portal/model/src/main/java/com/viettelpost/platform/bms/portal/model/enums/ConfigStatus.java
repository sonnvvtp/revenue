package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ConfigStatus {

    INACTIVE(0,"INACTIVE", "Trạng thái tắt "),
    ACTIVE(1, "ACTIVE", "Trạng thái bật"),
    NA(-1,"N/A","N/A");
    private int id;
    private String code;
    private String name;

    public static ConfigStatus get(Integer id) {
        return Arrays.stream(ConfigStatus.values())
                .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(NA);
    }
}
