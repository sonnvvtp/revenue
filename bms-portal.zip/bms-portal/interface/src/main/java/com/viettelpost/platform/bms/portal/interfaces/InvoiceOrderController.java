package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.RemoveOrderFromInvoiceRequest;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceRecordOrderService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import static com.viettelpost.platform.bms.common.exception.BaseResponse.errorApiWithHttpStatusCodeVTP;

@Slf4j
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice/orders")
@Tag(name = "InvoiceOrderController")
@RequiredArgsConstructor
public class InvoiceOrderController {

    private final InvoiceRecordOrderService invoiceOrderService;
    
    @Inject
    AuthenticationContext context;

//    @POST
//    @Path("/add")
//    @Produces(MediaType.APPLICATION_JSON)
//    @Operation(summary = "API thêm đơn hàng vào bảng kê")
//    @APIResponse(responseCode = "200", description = "Thêm đơn hàng vào bảng kê thành công")
//    @APIResponse(responseCode = "400", description = "Đơn hàng đã tồn tại trong bảng kê hoặc không tìm thấy đơn hàng")
//    @APIResponse(responseCode = "500", description = "Lỗi server")
//    public Uni<Response> addOrderToInvoice(AddOrderToInvoiceRequest request) {
//        log.info("Adding order {} to invoice record {}", request.getOrderCode(), request.getRecordId());
//
//        if (request.getOrderCode() == null || request.getOrderCode().isEmpty()) {
//            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, "Order code is required", null));
//        }
//
//        if (request.getRecordId() == null) {
//            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, "Record ID is required", null));
//        }
//
//        CustomUser user = context.getCurrentUser();
//        return ReactiveConverter.toUni(invoiceOrderService.addOrderToInvoice(user, request));
//    }
    
    @POST
    @Path("/remove")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "API loại đơn hàng ra khỏi bảng kê")
    @APIResponse(responseCode = "200", description = "Loại đơn hàng ra khỏi bảng kê thành công")
    @APIResponse(responseCode = "400", description = "Đơn hàng không tồn tại trong bảng kê hoặc đã bị loại bỏ trước đó")
    @APIResponse(responseCode = "500", description = "Lỗi server")
    public Uni<Response> removeOrderFromInvoice(RemoveOrderFromInvoiceRequest request) {
        log.info("Removing order {} from invoice record {}", request.getOrderCode(), request.getRecordId());
        
        if (request.getOrderCode() == null || request.getOrderCode().isEmpty()) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, "Order ID is required", null));
        }
        
        if (request.getRecordId() == null) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, "Record ID is required", null));
        }
        
        CustomUser user = context.getCurrentUser();
        return ReactiveConverter.toUni(invoiceOrderService.removeOrderFromInvoice(user, request));
    }
} 