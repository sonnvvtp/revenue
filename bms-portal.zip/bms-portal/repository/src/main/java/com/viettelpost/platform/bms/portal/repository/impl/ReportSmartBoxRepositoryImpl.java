package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.common.utils.CommonUtils;
import com.viettelpost.platform.bms.common.utils.DateUtils;
import com.viettelpost.platform.bms.portal.model.dto.ReportRevenueSmbDTO;
import com.viettelpost.platform.bms.portal.model.enums.IsPaidStatusEnum;
import com.viettelpost.platform.bms.portal.model.model.EvtpPayInModel;
import com.viettelpost.platform.bms.portal.model.model.FicoPayRecordClear;
import com.viettelpost.platform.bms.portal.model.model.FicoPayRecordClearLine;
import com.viettelpost.platform.bms.portal.repository.ReportSmartBoxRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.*;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.multi.MultiReactorConverters;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.RowSet;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

@Singleton
@Slf4j
@KeepTracedContext
public class ReportSmartBoxRepositoryImpl implements ReportSmartBoxRepository {
    @Inject
    PgPool client;

    @Inject
    ConnectionPool oraclePool;


    @ConfigProperty(name = "config.mproduct.smartbox",defaultValue = "SBQH,SBTT")
    String mProductSmb;




    public static final BiFunction<Row, RowMetadata, EvtpPayInModel> LIST_BILL_FEE_SMB =
            (row, rowMetaData) -> EvtpPayInModel.builder()
                    .evtpPayInId(row.get("evtpPayInId", BigDecimal.class))
                    .dateBill(row.get("dateBill", Date.class))
                    .dateInsert(row.get("dateInsert", Date.class))
                    .bill(row.get("bill", String.class))
                    .status(row.get("status", Long.class))
                    .orgId(row.get("orgId", Long.class))
                    .postId(row.get("postId", Long.class))
                    .partnerEvtp(row.get("partnerEvtp", String.class))
                    .partnerId(row.get("partnerId", Long.class))
                    .mProduct(row.get("mProduct", String.class))
                    .periodId(row.get("periodId", Long.class))
                    .payTeamId(row.get("payTeamId", Long.class))
                    .amount(row.get("amount", BigDecimal.class))
                    .build();

    @Override
    public Mono<Integer> countReportRevenueSmb(String bill,String fromDate, String toDate, Integer type) {
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        int paramIndex = 3;
        params.add(DateUtils.convertToLocalDateTime(
                DateUtils.convertStringToDate(convertFormatDate(fromDate),
                        DateUtils.LOCALDATE_TO_STRING_FORMAT)));
        params.add(DateUtils.convertToLocalDateTime(
                DateUtils.convertStringToDate(convertFormatDate(toDate),
                        DateUtils.LOCALDATE_TO_STRING_FORMAT)).plusDays(1).minusNanos(1));
        if(!CommonUtils.isNullOrEmpty(bill)){
            moreQuery.append(" and bill = $").append(paramIndex);
            params.add(bill);
            paramIndex++;
        }
        if (type != null) {
            moreQuery.append(" and type = $").append(paramIndex);
            params.add(type);
        }

        String sql = " select count(1) total from bms_payment.bms_report_revenue_smartbox where date_insert between  $1 and $2  " + moreQuery;

        return client.preparedQuery(sql)
                .execute(Tuple.from(params))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getInteger("total") : 0)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Flux<ReportRevenueSmbDTO> getListReportRevenueSmb(String bill,String fromDate, String toDate, Integer type, int page, int size) {
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        int paramIndex = 3;
        params.add(DateUtils.convertToLocalDateTime(
                DateUtils.convertStringToDate(convertFormatDate(fromDate),
                        DateUtils.LOCALDATE_TO_STRING_FORMAT)));
        params.add(DateUtils.convertToLocalDateTime(
                DateUtils.convertStringToDate(convertFormatDate(toDate),
                        DateUtils.LOCALDATE_TO_STRING_FORMAT)).plusDays(1).minusNanos(1));
        if (!CommonUtils.isNullOrEmpty(bill)) {
            moreQuery.append(" and bill = $").append(paramIndex);
            params.add(bill);
            paramIndex++;
        }
        if (type != null) {
            moreQuery.append(" and type = $").append(paramIndex);
            params.add(type);
            paramIndex++;
        }

        moreQuery.append(" order by date_payment desc limit $").append(paramIndex).append(" offset $").append(paramIndex + 1);
        params.add(size);
        params.add((page - 1) * size);

        String sql = " select id,bill,partner_evtp,service_code,\"type\",amount,item_code,partner_id,to_char(date_insert,'dd/MM/yyyy') date_insert,to_char(date_payment,'dd/MM/yyyy HH24:MI:SS') formatted_date_payment,status  from bms_payment.bms_report_revenue_smartbox where date_insert between  $1 and $2  " + moreQuery;
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(ReportRevenueSmbDTO.class))
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Flux<EvtpPayInModel> getListBillFeeSmartBox(String partnerEvtp,String fromDate) {
        return Flux.usingWhen(
                oraclePool.create(),  // Tạo kết nối từ ConnectionPool
                connection -> {
                    String placeholders = IsPaidStatusEnum.getAllCodesExceptUnpaid().stream()
                            .map(d -> "?")
                            .collect(Collectors.joining(", "));

                    List<String> mProductList = Arrays.stream(mProductSmb.split(","))
                            .map(String::trim)
                            .toList();


                    String placeMProduct = mProductList.stream().map(d -> "?").collect(Collectors.joining(", "));


                    String sql = "    select a.PAY_IN_ID evtpPayInId, " +
                                 "       a.DATEBILL dateBill, " +
                                 "       a.DATEINSERT dateInsert, " +
                                 "       a.BILL bill, " +
                                 "       a.IS_PAID status, " +
                                 "       a.ORG_ID orgId, " +
                                 "       a.POST_ID postId, " +
                                 "       a.PARTNER_EVTP partnerEvtp, " +
                                 "       a.PARTNER_ID partnerId, " +
                                 "       a.M_PRODUCT mProduct, " +
                                 "       a.PERIOD_ID periodId, " +
                                 "       a.PAYMENTTEAM_ID payTeamId, " +
                                 "       a.AMT amount " +
                                 "from ERP_AC.EVTP_PAY_IN a " +
                                 "where EMPLOYEE_ID = 5681912 " +
                                 "  and POST_ID = 1272377 " +
                                 "  and ORG_ID = 86142 and PARTNER_EVTP = ? " +
                                 "  and DATEBILL BETWEEN TO_DATE(?, 'yyyy-MM-dd') and TO_DATE(?, 'yyyy-MM-dd') + 1 - 0.00001 " +
                                 "  and IS_PAID IN (" + placeholders + ") and M_PRODUCT IN (" + placeMProduct + ") and NOT EXISTS (select 1 from ERP_AC.FICO_PAY_RECORD_CLEAR_LINE z where z.PAY_IN_ID = a.PAY_IN_ID) ";

                    Statement statement = connection.createStatement(sql)
                            .bind(0, partnerEvtp)
                            .bind(1, fromDate)
                            .bind(2, fromDate);

                    // Bind các giá trị của danh sách IS_PAID
                    List<Integer> isPaidStatusList = IsPaidStatusEnum.getAllCodesExceptUnpaid();
                    for (int i = 0; i < isPaidStatusList.size(); i++) {
                        statement.bind(i + 3, isPaidStatusList.get(i));
                    }
                    for (int i = 0; i < mProductList.size(); i++) {
                        statement.bind(i + 3 + isPaidStatusList.size(), mProductList.get(i));
                    }

                    return Flux.from(statement.execute())
                            .flatMap(result -> result.map(LIST_BILL_FEE_SMB));
                },
                Connection::close
        );
    }

    @Override
    public Mono<BigDecimal> getNewSequenceRecordId(Connection connection, String sequenceName) {
        if (sequenceName == null || sequenceName.isEmpty()) return null;
        String mainQuery = "SELECT " + sequenceName + ".nextval as nextValue FROM DUAL";
        return Mono.from(connection.createStatement(mainQuery)
                        .execute())
                .flatMap(result -> Mono.from(result.map((row, rowMetadata) -> row.get("nextValue", BigDecimal.class))));
    }

    @Override
    public Mono<Integer> getPaymentPeriodId(Connection connection, String partnerEvtp) {
        Date now = new Date();
        int dayNow = now.getDay() + 1;
        String sql = "select PAYMENT_PERIOD_ID  as id from ERP_AC.ERP_PAYMENT_PERIOD where partner_evtp = :partnerEvtp AND VALUE_CONFIG = :valueConfig AND ISACTIVE = 'Y'";
        return Mono.from(connection.createStatement(sql)
                        .bind("partnerEvtp", partnerEvtp)
                        .bind("valueConfig", dayNow)
                        .execute())
                .flatMap(result -> Mono.from(result.map((row, rowMetadata) -> row.get("id", Integer.class))))
                .switchIfEmpty(Mono.just(-1));
    }

    @Override
    public Mono<FicoPayRecordClear> insertRecordClear(Connection connection, FicoPayRecordClear clear) {
        log.info("api_insert_record_smartbox:{}",clear.getRecordNo());
        String sql = " INSERT INTO ERP_AC.FICO_PAY_RECORD_CLEAR (PAY_RECORD_CLEAR_ID, RECORD_NO, RECORD_STATUS " +
                     "    , PERIOD_ID, PERSON_ID, DESCRIPTION, ORG_ID, POST_ID, RECORD_TYPE, " +
                     "                                          CREATED_BY, PERIOD_DUE, CREATED_AT, UPDATED_AT, AMOUNT, DISCOUNT, PAY_AMOUNT,ACCOUNTING_DATE,CUS_PO_CODE,CUS_PO_ID,DOC_TYPE) " +
                     "VALUES (:payRecordClearId, :recordNo, :recordStatus, :periodId, :personId, :description, :orgId, :postId, :recordType, -1, " +
                     "        :periodDue, SYSDATE, SYSDATE, :amount, 0, :amount,:accoungtingDate,:partnerEvtp,:partnerId,:docType) ";
        return Mono.from(connection.createStatement(sql)
                        .bind("payRecordClearId", clear.getPayRecordClearId())
                        .bind("recordNo", clear.getRecordNo())
                        .bind("recordStatus", clear.getRecordStatus())
                        .bind("periodId", clear.getPeriodId())
                        .bind("personId", clear.getPersonId())
                        .bind("description", "Bang ke phi qua han smartbox")
                        .bind("orgId", clear.getOrgId())
                        .bind("postId", clear.getPostId())
                        .bind("recordType", clear.getRecordType())
                        .bind("periodDue", clear.getPeriodDue())
                        .bind("amount", clear.getAmount())
                        .bind("accoungtingDate", Parameters.in(R2dbcType.TIMESTAMP, clear.getAccountingDate()))
                        .bind("partnerEvtp", clear.getCusPoCode())
                        .bind("partnerId", clear.getCusPoId())
                        .bind("docType",clear.getDocType())
                        .execute())
                .flatMap(result -> Mono.from(result.getRowsUpdated()))
                .doOnSuccess(rowsUpdated -> log.info("Api insert successful, rows updated: {}", rowsUpdated))
                .doOnError(error -> log.error("Api error inserting record: {}", error.getMessage(), error))
                .thenReturn(clear);
    }

    @Override
    public Mono<BigDecimal> saveFicoPayRecordClearLine(Connection connection, FicoPayRecordClearLine line) {
        String sqlInsertLine = "INSERT INTO ERP_AC.FICO_PAY_RECORD_CLEAR_LINE (PAY_RECORD_CLEAR_LINE_ID, PAY_RECORD_CLEAR_ID, BILL, PAY_IN_ID, AMOUNT, " +
                               "                                               DEDUCT_AMOUNT, PERSON_ID, PARTNER_ID, POST_ID, ORG_ID " +
                               "    , DATEINSERT, CREATED_AT, CREATED_BY, UPDATED_AT, SERVICE_CODE, PAY_AMOUNT) " +
                               "VALUES (ERP_AC.FICO_PAY_RECORD_CLEAR_LINE_SEQ.nextval, :payRecordClearId, :bill, :payInId, :amount, 0, :partnerId, " +
                               "        :partnerId, :postId, :orgId, :dateInsert, SYSDATE, -1, SYSDATE, :mProduct, :amount) ";
        return Mono.from(connection.createStatement(sqlInsertLine)
                        .bind("payRecordClearId", line.getPayRecordClearId())
                        .bind("bill", line.getBill())
                        .bind("payInId", line.getPayInId())
                        .bind("amount", line.getAmount())
                        .bind("partnerId", line.getPartnerId())
                        .bind("postId", line.getPostId())
                        .bind("orgId", line.getOrgId())
                        .bind("dateInsert", convertToLocalDateTime(line.getDateInsert()))
                        .bind("mProduct", line.getServiceCode())
                        .bind("amount", line.getAmount())
                        .execute())
                .flatMap(result -> Mono.from(result.getRowsUpdated()))
                .doOnSuccess(rowsUpdated -> log.info("Api insert successful saveFicoPayRecordClearLine, rows updated: {}", rowsUpdated))
                .doOnError(error -> log.error("Api error inserting record saveFicoPayRecordClearLine Bill: {},error:{}",line.getBill(),error.getMessage(), error))
                .thenReturn(line.getAmount());
    }

    @Override
    public Mono<String> genBangKeCode(Connection connection) {
        String sql = "select ERP_AC.AC_PROCESS.get_dono_Post(:docType,:orgId,:postId,SYSDATE) docNo  from DUAL";
        return Mono.from(connection.createStatement(sql)
                        .bind("docType", 383116)
                        .bind("orgId", 86142)
                        .bind("postId", 1272377)
                        .execute())
                .flatMap(result -> Mono.from(result.map((row, rowMetadata) -> row.get("docNo", String.class))));
    }

    @Override
    public Mono<Integer> processToSAP(Connection connection, String dateAcc, List<BigDecimal> recordIds, String type) {
        String sql = "INSERT INTO ERP_AC.ERP_RECORD_SAP(RECORD_SAP_ID, CREATED, CREATEDBY, UPDATED, UPDATEDBY, DATEACCT, PERIOD_ID, TYPE_SAP, RECORD_ID, IS_DONE) " +
                     "VALUES (ERP_AC.RECORD_SAP_ID_SEQ.NEXTVAL, SYSDATE, 781308, SYSDATE, 781308, TO_DATE(:dateAcc, 'DD/MM/YYYY'), ERP_AC.GET_PERIOD_ID(TO_DATE(:dateAcc, 'DD/MM/YYYY')), :type, :recordId, -1)";

        return Flux.fromIterable(recordIds)
                .flatMap(recordId ->
                        Mono.from(connection.createStatement(sql)
                                        .bind("recordId", Parameters.in(R2dbcType.BIGINT, recordId))
                                        .bind("type", Parameters.in(R2dbcType.VARCHAR, type))
                                        .bind("dateAcc", Parameters.in(R2dbcType.VARCHAR, dateAcc))
                                        .execute())
                                .flatMap(queryResult -> Mono.from(queryResult.getRowsUpdated()))
                                .doOnSuccess(rowsUpdated -> log.info("processToSAP successful for recordId {}: rows updated: {}", recordId, rowsUpdated))
                                .doOnError(error -> log.error("Api Error in processToSAP for recordId {}: {}", recordId, error.getMessage(), error))
                                .onErrorReturn(0L) // Return 0 in case of error
                )
                .collectList() // Collect results into a List
                .map(results -> {
                    // Check if any result is 0 (indicating a failure)
                    boolean anyFailed = results.stream().anyMatch(result -> result == 0);
                    if (anyFailed) {
                        return 0;
                    } else {
                        return results.size(); // Return the count of successful updates
                    }
                });
    }

    private String convertFormatDate(String inputDate) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        // Định dạng của ngày đầu ra
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Chuyển đổi chuỗi ngày thành LocalDate
        LocalDate date = LocalDate.parse(inputDate, inputFormatter);
        // Chuyển đổi LocalDate thành chuỗi ngày với định dạng mong muốn
        return date.format(outputFormatter);
    }

    private LocalDateTime convertToLocalDateTime(Date date) {
        return date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }


    @Override
    public Mono<Void> updateItemCodeRecord(SqlConnection sqlConnection, String itemCode, List<EvtpPayInModel> list) {
        String sql = " update bms_payment.bms_report_revenue_smartbox set item_code =$1,updated_at  = now() where bill = any ($2) ";
        List<String> billList = list.stream().map(EvtpPayInModel::getBill).toList();
        Tuple params = Tuple.of(itemCode, billList.toArray(new String[0]));
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(params);
        return (sqlConnection == null ? client.withConnection(function) : function.apply(sqlConnection))
                .onItem().transform(result -> result.rowCount() > 0)
                .convert().with(UniReactorConverters.toMono()).then();
    }

    @Override
    public Mono<Void> updateDocumentNoComparison(SqlConnection sqlConnection, String itemCode,List<EvtpPayInModel> list) {
        String sql = " update bms_report.bms_debt_comparison_internal set documentno = $1 where item_code = any ($2) ";
        List<String> billList = list.stream().map(EvtpPayInModel::getBill).toList();
        Tuple params = Tuple.of(itemCode, billList.toArray(new String[0]));
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(params);
        return (sqlConnection == null ? client.withConnection(function) : function.apply(sqlConnection))
                .onItem().transform(result -> result.rowCount() > 0)
                .convert().with(UniReactorConverters.toMono()).then();
    }

    @Override
    public Uni<String> getRecordSmartBoxBKPHI(String bill) {
        String sql = "select a.RECORD_NO recordNo from ERP_AC.FICO_PAY_RECORD_CLEAR a where a.PAY_RECORD_CLEAR_ID = (select z.PAY_RECORD_CLEAR_ID from ERP_AC.FICO_PAY_RECORD_CLEAR_LINE z where z.BILL = :bill )";
        Map<String, Object> params = Map.of("bill", bill);
        return executeAndGetValue(oraclePool,sql,params,"recordNo",String.class);
    }

    @Override
    public Uni<Boolean> updateBmsReportRevenueSmb(String bill, Long userId, String record) {
        String sql = "update bms_payment.bms_report_revenue_smartbox set item_code =$1,updated_by =$2 where bill  = $3 returning id";
        return executeOnly(client,sql,Tuple.of(record, userId,bill));
    }

    @Override
    public Mono<EvtpPayInModel> getListBillEvtp(String bill) {
        return Mono.usingWhen(
                oraclePool.create(),  // Tạo kết nối từ ConnectionPool
                connection -> {

                    String sql = "    select a.PAY_IN_ID evtpPayInId, " +
                                 "       a.DATEINSERT dateInsert, " +
                                 "       a.BILL bill, " +
                                 "       a.IS_PAID status, " +
                                 "       a.PARTNER_EVTP partnerEvtp, " +
                                 "       a.PARTNER_ID partnerId, " +
                                 "       a.M_PRODUCT mProduct, " +
                                 "       a.PERIOD_ID periodId, " +
                                 "       a.PAYMENTTEAM_ID payTeamId, " +
                                 "       a.AMT amount " +
                                 "from ERP_AC.EVTP_PAY_IN a " +
                                 "where EMPLOYEE_ID = 5681912 " +
                                 "  and POST_ID = 1272377 " +
                                 "  and ORG_ID = 86142 and BILL = ? " ;

                    Statement statement = connection.createStatement(sql)
                            .bind(0, bill);

                    return Mono.from(statement.execute())
                            .flatMapMany(result -> result.map((row, rowMetadata) ->
                                    EvtpPayInModel.builder()
                                            .bill(row.get("bill", String.class))
                                            .dateInsert(row.get("dateInsert", Date.class))
                                            .status(row.get("status", Long.class))
                                            .partnerEvtp(row.get("partnerEvtp", String.class))
                                            .partnerId(row.get("partnerId", Long.class))
                                            .mProduct(row.get("mProduct", String.class))
                                            .periodId(row.get("periodId", Long.class))
                                            .payTeamId(row.get("payTeamId", Long.class))
                                            .amount(row.get("amount", BigDecimal.class))
                                            .build()
                            )).collectList().flatMap(list -> {
                                if (list.isEmpty()) {
                                    return Mono.empty();
                                } else {
                                    return Mono.just(list.get(0));
                                }
                            });
                },
                Connection::close
        );
    }

    @Override
    public Mono<Long> insertBmsReportRevenueSmb(
            String bill,
            String partnerEvtp,
            String serviceCode,
            int type,
            BigDecimal amount,
            Date datePayment,
            Date dateInsert,
            int partnerId,
            int status,Long userId) {
        String sql = " insert into bms_payment.bms_report_revenue_smartbox(bill,\n" +
                     "                                                    amount,\n" +
                     "                                                    partner_evtp,\n" +
                     "                                                    service_code,\n" +
                     "                                                    type,\n" +
                     "                                                    date_payment,\n" +
                     "                                                    date_insert,\n" +
                     "                                                    partner_id, status,updated_by,updated_at)\n" +
                     "values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now()) returning id ";

        List<Object> params = Arrays.asList(bill,
                amount,
                partnerEvtp,
                serviceCode,
                type,
                datePayment.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() ,
                dateInsert.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime(),
                partnerId,
                status,
                userId);
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(Tuple.from(params));
        return client.withConnection(function)
                .convert().with(UniReactorConverters.toMono())
                .map(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        return rowSet.iterator().next().getLong("id");
                    } else {
                        return 0L;
                    }
                });


    }

    @Override
    public Uni<Boolean> updateBmsReportComparisonInternal(String transactionCode, String bill,String record) {
        String sql = "update bms_report.bms_debt_comparison_internal set documentno =$1 where req_vtp_order_id =$2 and item_code =$3";
        return executeOnly(client,sql,Tuple.of(record,transactionCode,bill));
    }

    @Override
    public Uni<String> getTransactionCodeByBill(String bill) {
        String sql = "select brp.transaction_code from bms_payment.bms_request_payment brp  where brp.status =1 and brp.req_payment_id in (select brpl.req_payment_id from bms_payment.bms_request_payment_line brpl where brpl.item_code =$1)  limit 1 ";
        return executeAndGetValue(client,sql,Tuple.of(bill),"transaction_code",String.class);
    }

    @Override
    public Uni<Boolean> deleteBillSmartBoxRevenue(Long id) {
        String sql = "delete from bms_payment.bms_report_revenue_smartbox where id =$1";
        return executeOnly(client,sql,Tuple.of(id));
    }

    @Override
    public Multi<EvtpPayInModel> listBillSmartBox(String partnerEvtp,String dateTime) {
        Map<String, Object> map = new HashMap<>();
        map.put("partnerEvtp", partnerEvtp);
        map.put("dateTime", dateTime);

        String inIsPaids = IsPaidStatusEnum.getAllCodesExceptUnpaid().stream()
                .map(String::valueOf)
                .collect(Collectors.joining(",", "(", ")"));

        String inMProducts = Arrays.stream(mProductSmb.split(","))
                .map(String::trim)
                .toList().stream()
                .map(p -> "'" + p + "'")
                .collect(Collectors.joining(",", "(", ")"));
        String sql = """
                select BILL, PARTNER_EVTP, DATEBILL, AMT, ORG_ID, POST_ID, PERIOD_ID,
                       PARTNER_ID, DATEINSERT, M_PRODUCT, PAY_IN_ID, IS_PAID
                from ERP_AC.EVTP_PAY_IN a
                where DATEBILL between to_date(:dateTime,'dd/MM/yyyy')  and to_date(:dateTime,'dd/MM/yyyy') + 1  and IS_PAID in %s
                  and M_PRODUCT not in %s
                  and not exists (
                      select 1 from ERP_AC.FICO_PAY_RECORD_CLEAR_LINE b
                      where a.PAY_IN_ID = b.PAY_IN_ID
                  ) and PARTNER_EVTP = :partnerEvtp and not exists(select 1 from ERP_AC.ERP_CLEARLINE d where d.PAY_IN_ID = a.PAY_IN_ID)
                """.formatted(inIsPaids, inMProducts);

        return executeMulti(oraclePool, sql, map, EvtpPayInModel.class);
    }

    @Override
    public Uni<String> genBangKeCodeUni(Connection connection, Long orgId, Long postId) {
        Map<String, Object> map = new HashMap<>();
        String sql = "select ERP_AC.AC_PROCESS.get_dono_Post(:docType,:orgId,:postId,SYSDATE) docNo  from DUAL";
        map.put("docType", 523116);
        map.put("orgId", orgId);
        map.put("postId", postId);
        return executeAndGetValue(connection, sql, map, "docNo", String.class);
    }

    @Override
    public Uni<Long> getNewSequenceRecordIdUni(Connection connection, String sequenceName) {
        Map<String, Object> map = new HashMap<>();
        if (sequenceName == null || sequenceName.isEmpty()) return null;
        String mainQuery = "SELECT " + sequenceName + ".nextval as nextValue FROM DUAL";
        return executeAndGetValue(connection, mainQuery, map, "nextValue", Long.class);
    }

    @Override
    public Uni<Boolean> insertRecordClearUni(Connection connection, FicoPayRecordClear clear) {
        Map<String, Object> map = new HashMap<>();
        map.put("payRecordClearId", clear.getPayRecordClearId());
        map.put("recordNo", clear.getRecordNo());
        map.put("recordStatus", clear.getRecordStatus());
        map.put("periodId", clear.getPeriodId());
        map.put("personId", clear.getPersonId());
        map.put("description", "Bang ke cuoc smartbox");
        map.put("orgId", clear.getOrgId());
        map.put("postId", clear.getPostId());
        map.put("recordType", clear.getRecordType());
        map.put("periodDue", clear.getPeriodDue());
        map.put("amount", clear.getAmount());
        map.put("accoungtingDate", Parameters.in(R2dbcType.TIMESTAMP, clear.getAccountingDate()));
        map.put("partnerEvtp", clear.getCusPoCode());
        map.put("partnerId", clear.getCusPoId());
        map.put("docType", 523116);
        String sql = " INSERT INTO ERP_AC.FICO_PAY_RECORD_CLEAR (PAY_RECORD_CLEAR_ID, RECORD_NO, RECORD_STATUS " +
                     "    , PERIOD_ID, PERSON_ID, DESCRIPTION, ORG_ID, POST_ID, RECORD_TYPE, " +
                     "                                          CREATED_BY, PERIOD_DUE, CREATED_AT, UPDATED_AT, AMOUNT, DISCOUNT, PAY_AMOUNT,ACCOUNTING_DATE,CUS_PO_CODE,CUS_PO_ID,DOC_TYPE) " +
                     "VALUES (:payRecordClearId, :recordNo, :recordStatus, :periodId, :personId, :description, :orgId, :postId, :recordType, -1, " +
                     "        :periodDue, SYSDATE, SYSDATE, :amount, 0, :amount,:accoungtingDate,:partnerEvtp,:partnerId,:docType) ";
        return executeOnly(connection, sql, map);
    }

    @Override
    public Uni<Integer> getPaymentPeriodIdUni(Connection connection, String partnerEvtp) {
        Map<String, Object> map = new HashMap<>();
        Date now = new Date();
        int dayNow = now.getDay() + 1;
        map.put("partnerEvtp", partnerEvtp);
        map.put("valueConfig", dayNow);
        String sql = "select NVL(PAYMENT_PERIOD_ID,-1)  as id from ERP_AC.ERP_PAYMENT_PERIOD where partner_evtp = :partnerEvtp AND VALUE_CONFIG = :valueConfig AND ISACTIVE = 'Y'";
        return executeAndGetValue(connection, sql, map, "id", Integer.class);
    }

    @Override
    public Uni<Boolean> saveFicoPayRecordClearLine(Connection connection, List<FicoPayRecordClearLine> lines) {
        String sqlInsertLine = "INSERT INTO ERP_AC.FICO_PAY_RECORD_CLEAR_LINE (PAY_RECORD_CLEAR_LINE_ID, PAY_RECORD_CLEAR_ID, BILL, PAY_IN_ID, AMOUNT,\n" +
                               "                                               DEDUCT_AMOUNT, PAY_AMOUNT, PERSON_ID, PARTNER_ID, POST_ID, ORG_ID\n" +
                               "    , DATEINSERT, SERVICE_CODE, CREATED_BY, CREATED_AT, UPDATED_AT)\n" +
                               "VALUES (ERP_AC.FICO_PAY_RECORD_CLEAR_LINE_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?,\n" +
                               "        ?, ?, ?, ?, ?, -1, SYSDATE, SYSDATE) ";
        return executeOnlyInsertOracleBatch(connection, sqlInsertLine, lines, 1000, "payRecordClearLineId", "billType", "dateBill", "createdBy", "updatedBy");
    }

    @Override
    public Uni<Boolean> updateAmountRecordClear(Connection connection, Long payRecordId) {
        Map<String, Object> map = new HashMap<>();
        map.put("recordId", payRecordId);
        String sql = """
                UPDATE ERP_AC.FICO_PAY_RECORD_CLEAR a SET AMOUNT = (select SUM(z.AMOUNT) from ERP_AC.FICO_PAY_RECORD_CLEAR_LINE z where z.PAY_RECORD_CLEAR_ID =:recordId),
                      DISCOUNT = (select NVL(SUM(z.DEDUCT_AMOUNT),0) from ERP_AC.FICO_PAY_RECORD_CLEAR_LINE z where z.PAY_RECORD_CLEAR_ID =:recordId),
                      PAY_AMOUNT = (select NVL(SUM(z.PAY_AMOUNT),0) from ERP_AC.FICO_PAY_RECORD_CLEAR_LINE z where z.PAY_RECORD_CLEAR_ID =:recordId) where a.PAY_RECORD_CLEAR_ID = :recordId
                """;
        return executeOnly(connection, sql, map);
    }

    @Override
    public Uni<Void> updateRecordNoRevenue(List<EvtpPayInModel> list, String recordNo) {
        List<Object> params = new ArrayList<>();
        String sql = " update bms_payment.bms_report_revenue_smartbox set item_code =$1,updated_at  = now() where bill = any ($2) ";
        List<String> billList = list.stream().map(EvtpPayInModel::getBill).toList();
        params.add(recordNo);
        params.add(billList.toArray());
        return executeOnly(client, sql, Tuple.from(params)).replaceWithVoid();
    }

    @Override
    public Uni<Boolean> processToSAP(Connection connection, Long recordId, String type) {
        Map<String, Object> map = new HashMap<>();
        map.put("recordId", recordId);
        map.put("type", type);
        String sql = "INSERT INTO ERP_AC.ERP_RECORD_SAP(RECORD_SAP_ID, CREATED, CREATEDBY, UPDATED, UPDATEDBY, DATEACCT, PERIOD_ID, TYPE_SAP, RECORD_ID, IS_DONE) " +
                     " VALUES (ERP_AC.RECORD_SAP_ID_SEQ.NEXTVAL, SYSDATE, 781308, SYSDATE, 781308, TO_DATE(SYSDATE, 'DD/MM/YYYY'), ERP_AC.GET_PERIOD_ID(TO_DATE(SYSDATE, 'DD/MM/YYYY')), :type, :recordId, -1)";
        return executeOnly(connection, sql, map);
    }


}
