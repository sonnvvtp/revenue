package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeneralOrderEntity {
    @JsonAlias("id")
    public BigDecimal id;

    @JsonAlias("tenant_id")
    public Integer tenantId;

    @JsonAlias("created_by")
    public Long createdBy;

    @JsonAlias("created_at")
    public LocalDateTime createdAt;

    @JsonAlias("updated_by")
    public Long updatedBy;

    @JsonAlias("updated_at")
    public LocalDateTime updatedAt;

    @JsonAlias("order_id")
    public String orderId;

    @JsonAlias("order_code")
    public String orderCode;

    @JsonAlias("order_reference")
    public String orderReference;

    @JsonAlias("cashflow_type")
    public String cashflowType;

    @JsonAlias("service_code")
    public String serviceCode;

    @JsonAlias("order_created_at")
    public LocalDateTime orderCreatedAt;

    @JsonAlias("order_delivered_at")
    public LocalDateTime orderDeliveredAt;

//    @JsonAlias("employee_id")
//    public Long employeeId;
//
//    @JsonAlias("employee_info")
//    @JsonDeserialize(as = LinkedHashMap.class)
//    public Map<String, Object> employeeInfo;

    @JsonAlias("unit_level1_id")
    public Long unitLevel1Id;

    @JsonAlias("unit_level2_id")
    public Long unitLevel2Id;

    @JsonAlias("unit_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> unitInfo;

    @JsonAlias("company_code")
    public String companyCode;

    @JsonAlias("seller_id")
    public Long sellerId;

    @JsonAlias("seller_code")
    public String sellerCode;

    @JsonAlias("seller_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> sellerInfo;

    @JsonAlias("buyer_id")
    public Long buyerId;

    @JsonAlias("buyer_code")
    public String buyerCode;

    @JsonAlias("buyer_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> buyerInfo;

    @JsonAlias("consignee_id")
    public Long consigneeId;

    @JsonAlias("consignee")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> consignee;

    @JsonAlias("order_total_quantity")
    public Long orderTotalQuantity;

    @JsonAlias("order_amount_before_tax")
    public BigDecimal orderAmountBeforeTax;

    @JsonAlias("order_tax_amount")
    public BigDecimal orderTaxAmount;

    @JsonAlias("order_amount_after_tax")
    public BigDecimal orderAmountAfterTax;

    @JsonAlias("total_amount")
    public BigDecimal totalAmount;

    @JsonAlias("payment_status")
    public Integer paymentStatus;

    @JsonAlias("payment_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> paymentInfo;

    @JsonAlias("payment_method")
    public Integer paymentMethod;

    @JsonAlias("payment_term_id")
    public Integer paymentTermId;

    @JsonAlias("revenue_sync_status")
    public Integer revenueSyncStatus;

    @JsonAlias("invoice_status")
    public Integer invoiceStatus;

    @JsonAlias("invoice_partner")
    public String invoicePartner;

    @JsonAlias("currency")
    public String currency;

    @JsonAlias("order_source")
    public String orderSource;

    @JsonAlias("record_type")
    public Integer recordType;

    @JsonAlias("pic_type")
    public Integer picType;

    @JsonAlias("pic_info")
    @JsonDeserialize(as = LinkedHashMap.class)
    public Map<String, Object> picInfo;

    @JsonAlias("pic_id")
    public Long picId;
}
