package com.viettelpost.platform.bms.portal.common.utils;

import com.viettelpost.platform.bms.portal.common.model.HeaderCell;
import com.viettelpost.platform.bms.portal.common.model.TableCell;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellUtil;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;


public class ExcelSheetUtils {
    public static final String DEFAULT_FONT_NAME = "Times New Roman";

    private static final String HEADER_TITLE = "TỔNG CÔNG TY CỔ PHẦN BƯU CHÍNH VIETTEL";

    private static final String HEADER_SUBTITLE = "PHÒNG TÀI CHÍNH";

    private static final String HEADER_NATIONAL = "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM";

    private static final String HEADER_NATIONAL_SUB = "Độc lập - Tự do - Hạnh phúc";

    public static void createTable(Workbook workbook, Sheet sheet, int rowPosition, int cellPosition, TableCell tableCell) {
        Object[][] tableData = tableCell.getData();
        Map<String, CellStyle> styleCache = new HashMap<>();

        Font baseFont = tableCell.getFont();
        if (Objects.isNull(baseFont)) {
            baseFont = workbook.createFont();
            baseFont.setFontHeightInPoints((short) 11);
            baseFont.setFontName(DEFAULT_FONT_NAME);
        }

        Font finalBaseFont = baseFont;

        for (int i = 0; i < tableData.length; i++) {
            Row row = sheet.createRow(i + rowPosition);

            for (int j = 0; j < tableData[0].length; j++) {
                BorderStyle borderStyle = tableCell.getBorderStyle();
                HeaderCell headerCell = tableCell.getHeaderCells().get(j);
                if (borderStyle == null) borderStyle = BorderStyle.THIN;
                BorderStyle finalBorderStyle = borderStyle;

                Cell cell = row.createCell(j + cellPosition);
                if (i == 0) {
                    // Create header style key
                    String key = "header:" + headerCell.isBold() + ":" + headerCell.getHeaderHorizontalAlignment() + ":" + headerCell.getHeaderVerticalAlignment() + ":" + borderStyle + ":" + headerCell.getForegroundHeaderColor();

                    CellStyle headerStyle = styleCache.computeIfAbsent(key, k -> {
                        CellStyle style = workbook.createCellStyle();
                        Font font = workbook.createFont();
                        font.setFontName(finalBaseFont.getFontName());
                        font.setFontHeightInPoints(finalBaseFont.getFontHeightInPoints());
                        font.setBold(headerCell.isBold());
                        style.setFont(font);

                        HorizontalAlignment hAlign = Optional.ofNullable(headerCell.getHeaderHorizontalAlignment()).orElse(HorizontalAlignment.LEFT);
                        VerticalAlignment vAlign = Optional.ofNullable(headerCell.getHeaderVerticalAlignment()).orElse(VerticalAlignment.CENTER);
                        style.setAlignment(hAlign);
                        style.setVerticalAlignment(vAlign);
                        style.setBorderTop(finalBorderStyle);
                        style.setBorderLeft(finalBorderStyle);
                        style.setBorderRight(finalBorderStyle);
                        style.setBorderBottom(finalBorderStyle);

                        if (headerCell.getForegroundHeaderColor() != null) {
                            style.setFillForegroundColor(headerCell.getForegroundHeaderColor().getIndex());
                            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                        }

                        return style;
                    });

                    cell.setCellValue(headerCell.getName());
                    cell.setCellStyle(headerStyle);
                } else {
                    // Create data cell style key
                    String key = "data:" + headerCell.getCellHorizontalAlignment() + ":" + headerCell.getCellVerticalAlignment() + ":" + borderStyle;
                    CellStyle dataStyle = styleCache.computeIfAbsent(key, k -> {
                        CellStyle style = workbook.createCellStyle();
                        Font font = workbook.createFont();
                        font.setFontName(finalBaseFont.getFontName());
                        font.setFontHeightInPoints(finalBaseFont.getFontHeightInPoints());
                        font.setBold(false);
                        style.setFont(font);

                        HorizontalAlignment hAlign = Optional.ofNullable(headerCell.getCellHorizontalAlignment()).orElse(HorizontalAlignment.LEFT);
                        VerticalAlignment vAlign = Optional.ofNullable(headerCell.getCellVerticalAlignment()).orElse(VerticalAlignment.CENTER);
                        style.setAlignment(hAlign);
                        style.setVerticalAlignment(vAlign);
                        style.setBorderTop(finalBorderStyle);
                        style.setBorderLeft(finalBorderStyle);
                        style.setBorderRight(finalBorderStyle);
                        style.setBorderBottom(finalBorderStyle);

                        return style;
                    });

                    Object value = tableData[i][j];
                    if (value instanceof String) {
                        cell.setCellValue((String) value);
                    } else if (value instanceof BigDecimal) {
                        cell.setCellValue(((BigDecimal) value).longValue());

                        // Optionally use a different style for numeric values with format
                        String numberKey = key + ":number";
                        DataFormat format = workbook.createDataFormat();
                        CellStyle numericStyle = styleCache.computeIfAbsent(numberKey, k -> {
                            CellStyle style = workbook.createCellStyle();
                            style.cloneStyleFrom(dataStyle); // base it on the data style
                            style.setDataFormat(format.getFormat("#,##0"));
                            return style;
                        });

                        cell.setCellStyle(numericStyle);
                        continue;
                    } else if (value != null) {
                        cell.setCellValue(value.toString());
                    }

                    cell.setCellStyle(dataStyle);
                }
            }
        }
    }

    public static void createRowTotal(Workbook workbook, Sheet sheet, int rowPosition, int totalCellPosition, int cellPosition, int lastCellPosition, boolean haveTotalWord, Object... values) {
        Row row = sheet.createRow(rowPosition);
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName(DEFAULT_FONT_NAME);
        font.setBold(true);
        DataFormat format = workbook.createDataFormat();
        CellStyle style = workbook.createCellStyle();
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.RIGHT);
        style.setDataFormat(format.getFormat("#,##0"));
        for (int i = 0; i <= lastCellPosition; i++) {
            Cell cell = row.createCell(i);
            cell.setCellStyle(style);
            if (i == totalCellPosition && haveTotalWord) {
                cell.setCellValue("TỔNG CỘNG");
            }
            if (i >= cellPosition && i - cellPosition < values.length) {
                if (values[i - cellPosition] instanceof BigDecimal) {
                    cell.setCellValue(((BigDecimal) values[i - cellPosition]).longValue());
                } else if (values[i - cellPosition] instanceof String) {
                    cell.setCellValue((String) values[i - cellPosition]);
                } else {
                    cell.setCellValue(values[i - cellPosition].toString());
                }
            }
        }
    }

    public static void createHeader(Workbook workbook, Sheet sheet, String title, int firstRow, int lastRow, int firstCol, int lastCol) {

        Font boldFont = workbook.createFont();
        boldFont.setFontName(DEFAULT_FONT_NAME);
        boldFont.setFontHeightInPoints((short) 11);
        boldFont.setBold(true);

        Row headerRow1 = CellUtil.getRow(0, sheet);
        Cell headerCell1 = CellUtil.getCell(headerRow1, 0);
        headerCell1.setCellValue(HEADER_TITLE);
        CellUtil.setFont(headerCell1, boldFont);

        Row headerRow2 = CellUtil.getRow(1, sheet);
        Cell headerCell2 = CellUtil.getCell(headerRow2, 0);
        headerCell2.setCellValue(HEADER_SUBTITLE);
        CellUtil.setFont(headerCell2, boldFont);

        Row headerRow3 = CellUtil.getRow(4, sheet);
        sheet.addMergedRegion(new CellRangeAddress(firstRow, lastRow, firstCol, lastCol));
        Cell headerCell3 = CellUtil.getCell(headerRow3, 0);
        headerCell3.setCellValue(title);
        CellStyle boldAndCenterStyle = workbook.createCellStyle();
        boldAndCenterStyle.setFont(boldFont);
        boldAndCenterStyle.setAlignment(HorizontalAlignment.CENTER);
        headerCell3.setCellStyle(boldAndCenterStyle);
    }

    public static void createHeader(Workbook workbook, Sheet sheet, String title, int firstRow, int lastRow, int firstCol, int lastCol, boolean haveNationalEmblem) {
        if (haveNationalEmblem) {
            Font boldFont = workbook.createFont();
            boldFont.setFontName(DEFAULT_FONT_NAME);
            boldFont.setFontHeightInPoints((short) 11);
            boldFont.setBold(true);
            CellStyle boldAndCenterStyle = workbook.createCellStyle();
            boldAndCenterStyle.setFont(boldFont);
            boldAndCenterStyle.setAlignment(HorizontalAlignment.CENTER);

            Row headerRow1 = CellUtil.getRow(0, sheet);
            Cell headerCell1 = CellUtil.getCell(headerRow1, lastCol - 3);
            headerCell1.setCellValue(HEADER_NATIONAL);
            headerCell1.setCellStyle(boldAndCenterStyle);

            Row headerRow2 = CellUtil.getRow(1, sheet);
            Cell headerCell2 = CellUtil.getCell(headerRow2, lastCol - 3);
            headerCell2.setCellValue(HEADER_NATIONAL_SUB);
            headerCell2.setCellStyle(boldAndCenterStyle);

            addMergeRegionKeepValueAndStyle(sheet, new CellRangeAddress(0, 0, lastCol - 3, lastCol), 0, lastCol - 3);
            addMergeRegionKeepValueAndStyle(sheet, new CellRangeAddress(1, 1, lastCol - 3, lastCol), 1, lastCol - 3);
        }
        createHeader(workbook, sheet, title, firstRow, lastRow, firstCol, lastCol);
    }

    public static void setCellValue(Sheet sheet, int rowPosition, int cellPosition, Object value, Font font, CellStyle style) {

        Row row = sheet.getRow(rowPosition);
        if (Objects.isNull(row)) {
            row = sheet.createRow(rowPosition);
        }

        Cell cell = row.getCell(cellPosition);
        if (Objects.isNull(cell)) {
            cell = row.createCell(cellPosition);
        }

        if (value instanceof String) {
            cell.setCellValue((String) value);
        } else if (value instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal) value).longValue());
        } else if (Objects.nonNull(value)) {
            cell.setCellValue(value.toString());
        }

        if (Objects.isNull(style) && Objects.nonNull(font)) {
            CellUtil.setFont(cell, font);
        }

        if (Objects.nonNull(style)) {
            if (Objects.nonNull(font)) {
                style.setFont(font);
            }
            cell.setCellStyle(style);
        }
    }

    public static void setCellValue(Sheet sheet, int rowPosition, int cellPosition, Object value, Font font, String propName, Object propValue) {

        Row row = sheet.getRow(rowPosition);
        if (Objects.isNull(row)) {
            row = sheet.createRow(rowPosition);
        }

        Cell cell = row.getCell(cellPosition);
        if (Objects.isNull(cell)) {
            cell = row.createCell(cellPosition);
        }

        if (value instanceof String) {
            cell.setCellValue((String) value);
        } else if (value instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal) value).longValue());
        } else if (Objects.nonNull(value)) {
            cell.setCellValue(value.toString());
        }

        if (Objects.nonNull(propName) && Objects.nonNull(propValue)) {
            CellUtil.setCellStyleProperty(cell, propName, propValue);
            if (Objects.nonNull(font)) {
                CellStyle newStyle = cell.getCellStyle();
                if (newStyle == null || newStyle.getIndex() == 0) {
                    newStyle = sheet.getWorkbook().createCellStyle();
                }
                newStyle.setFont(font);
                cell.setCellStyle(newStyle);
            }
        }
    }

    public static void setCellValue(Sheet sheet, int rowPosition, int cellPosition, Object value, Map<String, Object> properties, Font font) {

        Row row = sheet.getRow(rowPosition);
        if (Objects.isNull(row)) {
            row = sheet.createRow(rowPosition);
        }
        Cell cell = row.getCell(cellPosition);
        if (Objects.isNull(cell)) {
            cell = row.createCell(cellPosition);
        }

        if (value instanceof String) {
            cell.setCellValue((String) value);
        } else if (value instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal) value).longValue());
        } else if (Objects.nonNull(value)) {
            cell.setCellValue(value.toString());
        }

        if (Objects.nonNull(properties)) {
            CellUtil.setCellStyleProperties(cell, properties);
            if (Objects.nonNull(font)) {
                CellStyle newStyle = cell.getCellStyle();
                if (newStyle == null || newStyle.getIndex() == 0) {
                    newStyle = sheet.getWorkbook().createCellStyle();
                }
                newStyle.setFont(font);
                cell.setCellStyle(newStyle);
            }
        }
    }

    public static void setBorderRegion(CellRangeAddress region, BorderStyle borderStyle, boolean top, boolean right, boolean bottom, boolean left, Sheet sheet) {
        if (top) {
            setBorderTopRegion(borderStyle, region, sheet);
        }
        if (right) {
            setBorderRightRegion(borderStyle, region, sheet);
        }
        if (bottom) {
            setBorderBottomRegion(borderStyle, region, sheet);
        }
        if (left) {
            setBorderLeftRegion(borderStyle, region, sheet);
        }

    }

    public static void setBorderTopRegion(BorderStyle borderStyle, CellRangeAddress region, Sheet sheet) {
        int colStart = region.getFirstColumn();
        int colEnd = region.getLastColumn();
        int rowIndex = region.getFirstRow();
        Row row = CellUtil.getRow(rowIndex, sheet);
        for (int i = colStart; i <= colEnd; i++) {
            Cell cell = CellUtil.getCell(row, i);
            CellStyle newStyle = cell.getCellStyle();
            if (newStyle == null || newStyle.getIndex() == 0) {
                newStyle = sheet.getWorkbook().createCellStyle();
            }
            newStyle.setBorderTop(borderStyle);
            cell.setCellStyle(newStyle);
        }
    }

    public static void setBorderRightRegion(BorderStyle borderStyle, CellRangeAddress region, Sheet sheet) {
        int rowStart = region.getFirstRow();
        int rowEnd = region.getLastRow();
        int column = region.getLastColumn();

        for (int i = rowStart; i <= rowEnd; i++) {
            Row row = CellUtil.getRow(i, sheet);
            Cell cell = CellUtil.getCell(row, column);
            CellStyle newStyle = cell.getCellStyle();
            if (newStyle == null || newStyle.getIndex() == 0) {
                newStyle = sheet.getWorkbook().createCellStyle();
            }
            newStyle.setBorderRight(borderStyle);
            cell.setCellStyle(newStyle);
        }
    }

    public static void setBorderBottomRegion(BorderStyle borderStyle, CellRangeAddress region, Sheet sheet) {
        int colStart = region.getFirstColumn();
        int colEnd = region.getLastColumn();
        int rowIndex = region.getLastRow();
        Row row = CellUtil.getRow(rowIndex, sheet);
        for (int i = colStart; i <= colEnd; i++) {
            Cell cell = CellUtil.getCell(row, i);
            CellStyle newStyle = cell.getCellStyle();
            if (newStyle == null || newStyle.getIndex() == 0) {
                newStyle = sheet.getWorkbook().createCellStyle();
            }
            newStyle.setBorderBottom(borderStyle);
            cell.setCellStyle(newStyle);
        }
    }

    public static void setBorderLeftRegion(BorderStyle borderStyle, CellRangeAddress region, Sheet sheet) {
        int rowStart = region.getFirstRow();
        int rowEnd = region.getLastRow();
        int column = region.getFirstColumn();

        for (int i = rowStart; i <= rowEnd; i++) {
            Row row = CellUtil.getRow(i, sheet);
            Cell cell = CellUtil.getCell(row, column);
            CellStyle newStyle = cell.getCellStyle();
            if (newStyle == null || newStyle.getIndex() == 0) {
                newStyle = sheet.getWorkbook().createCellStyle();
            }
            newStyle.setBorderLeft(borderStyle);
            cell.setCellStyle(newStyle);
        }
    }

    public static void addMergeRegionKeepValueAndStyle(Sheet sheet, CellRangeAddress region, int rowPositionTracker, int cellPositionTracker) {
        Cell cellTracker = sheet.getRow(rowPositionTracker).getCell(cellPositionTracker);
        CellStyle cellStyle = cellTracker.getCellStyle();
        CellType cellType = cellTracker.getCellType();
        Object value = null;
        switch (cellType) {
            case STRING:
                value = cellTracker.getStringCellValue();
                break;
            case NUMERIC:
                value = cellTracker.getNumericCellValue();
                break;
            case BOOLEAN:
                value = cellTracker.getBooleanCellValue();
                break;
            case FORMULA:
                value = cellTracker.getCellFormula();
                break;
            default: {
                value = null;
            }
        }
        sheet.addMergedRegion(region);
        Row row = CellUtil.getRow(region.getFirstRow(), sheet);
        Cell finalCell = CellUtil.getCell(row, region.getFirstColumn());
        finalCell.setCellStyle(cellStyle);
        if (Objects.nonNull(value)) {
            switch (cellType) {
                case NUMERIC:
                    finalCell.setCellValue(((double) value));
                    break;
                case BOOLEAN:
                    finalCell.setCellValue(((boolean) value));
                default:
                    finalCell.setCellValue(value.toString());
                    break;
            }
        }
    }
}