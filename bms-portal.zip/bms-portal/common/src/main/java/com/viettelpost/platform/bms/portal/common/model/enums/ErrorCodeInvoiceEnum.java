package com.viettelpost.platform.bms.portal.common.model.enums;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodeInvoiceEnum {

    SUCCESS("00", "SUCCESS"),
    UNAUTHORIZED("01", "UNAUTHORIZED"),
    DATA_ERROR("02", "DATA_ERROR"),
    INTERNAL_SERVER_ERROR("99", "INTERNAL_SERVER_ERROR"),
    SQL_TIMEOUT("ERROR_SQL_TIMEOUT", "SQL_TIMEOUT"),
    INVOICE_NOT_FOUND("INVOICE_NOT_FOUND", "Không tìm thấy thông tin hóa đơn: %s"),
    QUANTITY_NOT_MATCH("QUANTITY_NOT_MATCH", "Tổng chi tiết mặt hàng của đơn không khớp Tổng số lượng mặt hàng của đơn hàng"),
    TOTAL_MONEY_NOT_MATCH("TOTAL_MONEY_NOT_MATCH", "Tổng tiền các mặt hàng không khớp Tổng tiền của đơn"),
    INVOICE_ORER_EXISTS("INVOICE_ORDER_EXISTS", "Bill %s đã tồn tại"),
    INVOICE_USER_EXISTS("INVOICE_USER_EXISTS", "User %s đã tồn tại"),
    LIST_ORDER_NOT_VALID("LIST_ORDER_NOT_VALID", "Danh sách đơn xuất hóa đơn không hợp lệ"),
    PARTNER_NOT_FOUND("PARTNER_NOT_FOUND", "Đối tác với mã %s không tồn tại hoặc không hoạt động"),
    LIST_RECORD_NOT_VALID("LIST_RECORD_NOT_VALID", "Danh sách bảng kê không hợp lệ"),
    LIST_RECORD_ITEM_ORDER("LIST_RECORD_ITEM_ORDER", "Danh sách hàng hóa không hợp lệ"),
    RECORD_ITEM_ORDER_INVALID("RECORD_ITEM_ORDER_INVALID", "Hàng hóa bảng kê hóa đơn không hợp lệ"),
    GENERAL_ITEM_ORDER_INVALID("GENERAL_ITEM_ORDER_INVALID", "Hàng hóa không hợp lệ"),
    AMOUNT_DIFFERENCE_MORE_THAN("AMOUNT_DIFFERENCE_MORE_THAN", "Số tiền thuế sửa không chênh lệch quá 5 đồng");

    private final String code;
    private final String message;

    public String format(String ...value) {
        return String.format(this.message, Arrays.stream(value).toArray());
    }
}
