package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VehicleTypeGroupKMCPConfigDTO {
    private Long id;
    @JsonAlias("vehicle_type_group_id")
    private Long vehicleTypeGroupId;
    @JsonAlias("vehicle_type_group_name")
    private String vehicleTypeGroupName;
    @JsonAlias("org_type")
    private Integer orgType;
    @JsonAlias("kmcp_id")
    private String kmcpId;
    private String ci;
}
