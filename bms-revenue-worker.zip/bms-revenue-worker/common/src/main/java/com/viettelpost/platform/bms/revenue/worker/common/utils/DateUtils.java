package com.viettelpost.platform.bms.revenue.worker.common.utils;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;

public class DateUtils {

    public static LocalDateTime getToDateNMinusM(LocalDateTime fromDate, Duration range, Duration m) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nMinus = LocalDateTime.of(now.minus(m).toLocalDate(), LocalTime.MAX);
        LocalDateTime toDate = fromDate.plus(range);
        return nMinus.isAfter(toDate) ? toDate : nMinus;
    }

    public static LocalDate getLocalDateBy(LocalDateTime startOfMonth) {
        if (startOfMonth == null) {
            LocalDate today = LocalDate.now();
            return today.with(TemporalAdjusters.firstDayOfMonth());
        }
        return startOfMonth.toLocalDate();
    }
}
