package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

@Data
public class UpdateStartDateRequest {
    private String companyCode;
    private String startDate; // Format dd/MM/yyyy
}
