package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.BmsRequestPaymentAndLineDTO;
import com.viettelpost.platform.bms.portal.model.dto.CostRefundDataDTO;
import com.viettelpost.platform.bms.portal.model.dto.FicoForControlLineDTO;
import com.viettelpost.platform.bms.portal.model.dto.OrgPostDTO;
import com.viettelpost.platform.bms.portal.model.request.AccountingVipoRequest;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;

import java.util.List;

public interface AccountingVipoRepository extends BaseRepository {
    Multi<BmsRequestPaymentAndLineDTO> getInfoBillByTransactionPaid(AccountingVipoRequest request);

    Uni<Void> updateStatusPushSap(SqlConnection sqlConnection, String transactionCode, String itemCode, Integer status);

    Multi<FicoForControlLineDTO> getTransactionFtByTransactionCode(List<BmsRequestPaymentAndLineDTO> request);

    Uni<OrgPostDTO> getOrgPostRfInternalPostgres(String transactionCode);

    Uni<OrgPostDTO> getOrgPostPostgres(String transactionCode);

    Multi<CostRefundDataDTO> getListCostRefund(AccountingVipoRequest request);

    Multi<String> getCountAccountingCostReFund(List<String> paymentCostId);

    Uni<OrgPostDTO> getOrgPostOracle(String transactionCode);
}
