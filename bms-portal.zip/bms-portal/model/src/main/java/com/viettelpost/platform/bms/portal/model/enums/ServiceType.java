package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ServiceType {
    RECEIVE_INTERNAL_DELIVERY(0, "RECEIVE_INTERNAL_DELIVERY", "Thu Chuyển Phát"),
    RECEIVE_MERCHANDISE(1, "RECEIVE_MERCHANDISE", "Thu Tiền Hàng"),
    RECEIVE_DEPOSIT(2, "RECEIVE_DEPOSIT", "Thu Hộ Cọc "),
    RECEIVE_RENT_SMB(3, "RECEIVE_RENT_SMB", "Thu Thuê Tủ"),
    RECEIVE_BOOKING(4,"RECEIVE_BOOKING","Thu Hộ Smart Gate"),
    RECEIVE_PAYMENT_LGT(5,"RECEIVE_PAYMENT_LGT","đồng bộ nạp tền logistek "),
    NA(-1, "N/A", "N/A");
    private int id;
    private String code;
    private String name;

    public static ServiceType get(String code) {
        return Arrays.stream(ServiceType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(NA);
    }

    public static ServiceType get(int id) {
        return Arrays.stream(ServiceType.values())
                .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(NA);
    }
}
