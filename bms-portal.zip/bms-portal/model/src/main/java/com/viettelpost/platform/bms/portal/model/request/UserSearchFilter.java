package com.viettelpost.platform.bms.portal.model.request;

import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserSearchFilter {
    private String maNhanVien;
    @Builder.Default
    private int page = 1;

    @Builder.Default
    private int limit = 10;

    private String search;

    private List<Long> userIds;
    private String unit;
}
