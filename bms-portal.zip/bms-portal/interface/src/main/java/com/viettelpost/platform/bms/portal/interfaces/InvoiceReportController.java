package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.InvoiceLogRequest;
import com.viettelpost.platform.bms.portal.model.request.InvoiceReportRequest;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceLogService;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceReportService;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import static com.viettelpost.platform.bms.common.exception.BaseResponse.errorApiWithHttpStatusCodeVTP;

@Slf4j
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice/report")
@Tag(name = "InvoiceReportController")
@RequiredArgsConstructor
public class InvoiceReportController {

    private final InvoiceReportService invoiceReportService;
    private final InvoiceLogService invoiceLogService;
    
    @Inject
    AuthenticationContext context;

    @POST
    @Path("/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "API báo cáo hóa đơn")
    @APIResponse(responseCode = "200", description = "Trả về danh sách hóa đơn theo điều kiện lọc")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getInvoiceReport(InvoiceReportRequest request) {
        log.info("Getting invoice report with request: {}", request);
        String err = validateInput(request);
        if (err != null) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, err, null));
        }
        CustomUser user = context.getCurrentUser();
        return ReactiveConverter.toUni(invoiceReportService.getInvoiceReport(user, request));
    }
    
    @POST
    @Path("/excel")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "API báo cáo hóa đơn excel")
    @APIResponse(responseCode = "200", description = "Trả về tất cả hóa đơn theo điều kiện")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getAllInvoiceReport(InvoiceReportRequest request) {
        log.info("Getting all invoice report with request: {}", request);
        String err = validateInput(request);
        if (err != null) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, err, null));
        }
        CustomUser user = context.getCurrentUser();
        return ReactiveConverter.toUni(invoiceReportService.getAllInvoiceReport(user, request));
    }
    
    @GET
    @Path("/log")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "API kiểm tra log xuất hóa đơn")
    @APIResponse(responseCode = "200", description = "Trả về thông tin log xuất hóa đơn theo record_no")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getInvoiceLog(@QueryParam("record_no") String recordNo) {
        log.info("Getting invoice log with record_no: {}", recordNo);
        if (recordNo == null || recordNo.isEmpty()) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, "Record number is required", null));
        }
        CustomUser user = context.getCurrentUser();
        InvoiceLogRequest request = new InvoiceLogRequest().setRecordNo(recordNo);
        return ReactiveConverter.toUni(invoiceLogService.getInvoiceLog(user, request));
    }
    
    private String validateInput(InvoiceReportRequest request) {
        if (request.getFromDate() != null && !request.getFromDate().isEmpty() && 
            request.getToDate() != null && !request.getToDate().isEmpty()) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate fromDate = LocalDate.parse(request.getFromDate(), formatter);
                LocalDate toDate = LocalDate.parse(request.getToDate(), formatter);
                if (fromDate.isAfter(toDate)) {
                    return "fromDate must be before or equal to toDate";
                }
            } catch (DateTimeParseException e) {
                return "Invalid date format. Please use dd/MM/yyyy";
            }
        }
        return null;
    }
} 