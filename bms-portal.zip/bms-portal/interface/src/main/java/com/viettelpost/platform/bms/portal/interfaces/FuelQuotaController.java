package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.response.FuelQuotaResponse;
import com.viettelpost.platform.bms.portal.service.handler.FuelQuotaService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/fuel-quota")
@Tag(name = "Fuel Quota")
@RequiredArgsConstructor
public class FuelQuotaController {

    private final FuelQuotaService fuelQuotaService;

    @GET
    @Operation(summary = "Search Fuel Quotas")
    @APIResponse(responseCode = "200", description = "Returns a list of fuel quotas")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Map<String, Object>> searchFuelQuotas(
            @QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("unit") String unit,
            @QueryParam("pageNo") @DefaultValue("1") int pageNo,
            @QueryParam("pageSize") @DefaultValue("10") int pageSize) {

        return fuelQuotaService.searchFuelQuotas(
                carLicensePlate, synthesisPeriod, unit, pageNo, pageSize);
    }

    @GET
    @Operation(summary = "Fuel Quota Detail")
    @Path("/detail")
    @APIResponse(responseCode = "200", description = "Returns fuel quota detail")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<FuelQuotaResponse> getFuelQuota(
            @QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("synthesisPeriod") String synthesisPeriod) {

        return fuelQuotaService.getFuelQuota(carLicensePlate, synthesisPeriod);
    }

    @GET
    @Operation(summary = "List Months which have data")
    @Path("/list-month")
    @APIResponse(responseCode = "200", description = "Returns a list of month which has data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<List<String>> showListMonth() {
        return fuelQuotaService.showListMonth();
    }

    @GET
    @Path("/export-to-excel")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON})
    @Operation(summary = "Export Fuel Quota to Excel")
    @APIResponse(responseCode = "200", description = "Returns an Excel file containing Fuel Quota")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportToExcel(
            @QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("unit") String unit
    ) {
        return fuelQuotaService.exportToExcel(carLicensePlate, synthesisPeriod, unit)
                .onItem().transform(excelData -> {
                    String fileName = fuelQuotaService.generateFileName(synthesisPeriod);
                    return Response.ok(new ByteArrayInputStream(excelData))
                            .header("Content-Disposition",
                                    "attachment; filename=\"" + fileName + "\"")
                            .build();
                })
                .onFailure().recoverWithItem(throwable ->
                        Response.serverError().entity("Failed to generate Excel file").build()
                );
    }

    @GET
    @Path("/export-to-pdf")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response generateFuelQuotaPdf(@QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("unit") String unit) {
        try {
            byte[] pdfData = fuelQuotaService.fuelQuotaToPDF(carLicensePlate, synthesisPeriod,
                    unit);
            return Response.ok(pdfData)
                    .header("Content-Disposition", "attachment; filename=\"fuel_quota_report.pdf\"")
                    .build();
        } catch (Exception e) {
            log.error("Failed to generate PDF", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to generate PDF: " + e.getMessage())
                    .build();
        }
    }
}
