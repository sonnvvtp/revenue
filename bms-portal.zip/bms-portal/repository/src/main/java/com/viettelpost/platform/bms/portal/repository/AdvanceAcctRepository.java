package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.dto.advance.*;
import com.viettelpost.platform.bms.portal.model.enums.BusinessAdvanceAcctType;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceAcctRequest;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceRecordByBillRequest;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceRecordGroupDetailRequest;
import com.viettelpost.platform.bms.portal.model.request.advance.AdvanceRecordGroupRequest;
import com.viettelpost.platform.bms.portal.model.response.advance.AdvanceDetailAcctResponse;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

import java.util.List;

public interface AdvanceAcctRepository extends BaseRepository {

    Multi<AdvanceRecordDTO> findListAdvanceRecordAcct(AdvanceAcctRequest request);

    Multi<AdvanceDetailAcctResponse> findAdvanceDetailAcctByBkC3(List<String> bkC3List, List<BusinessAdvanceAcctType> docTypes);

    Multi<AdvanceBatchDTO> findListAdvanceBatchAcct(AdvanceAcctRequest request);

    Multi<AdvanceQrRecordDTO> findAdvanceQrRecordAcct(AdvanceAcctRequest request);

    Multi<AdvancePTCRecordDTO> findAdvancePTCRecordAcct(AdvanceAcctRequest request);

    Multi<AdvanceReturnRecordDTO> findAdvanceReturnRecordAcct(AdvanceAcctRequest request);

    Multi<AdvanceTTDTRecordDTO> findAdvanceTTDTRecordAcct(AdvanceAcctRequest request);

    Uni<String> getBKC3AdvanceAcctByRecordId(Long preRecordId);

    Multi<AdvanceDetailAcctResponse> findDetailAcctByBkC3AndBusinessType(String bkC3, String businessType);

    Uni<String> getBKC3AdvanceQrAcctByPayRecordClearId(Long payRecordClearId);

    Uni<String> getBKC3AdvanceBatchAcctByPayBatchId(Long payBatchId);

    Uni<String> getBKC3AdvanceAcctAdvanceAcctId(Long advanceAcctId);

    Uni<Integer> findListAdvanceAcctCount(AdvanceRecordGroupRequest advanceRecordGroupRequest);

    Multi<AdvanceAcctDTO> findListAdvanceAcct(AdvanceRecordGroupRequest advanceRecordGroupRequest);

    Uni<Integer> findListAdvanceAcctDetailCount(AdvanceRecordGroupDetailRequest request);

    Multi<AdvanceAcctDetailDTO> findListAdvanceAcctDetail(AdvanceRecordGroupDetailRequest request);

    Uni<Integer> findListAdvanceAcctByBillCount(AdvanceRecordByBillRequest request);

    Multi<AdvanceAcctDTO> findListAdvanceAcctByBill(AdvanceRecordByBillRequest request);

    Multi<String> findListRawDataByListRefNumber(List<String> refNumberList, Long businessId);

    Uni<Long> findAcctBusinessIdConfig();

    Uni<Boolean> deleteAdvanceAcctByListId(List<Long> advanceAcctIdList, Connection connection);

    Multi<BillReturnAcctDTO> findListBillReturnForAccounting(List<String> billList);

    Uni<Void> saveBatch(List<AdvanceAcctEntity> advanceDebt, Connection connection);

    Uni<Long> getNextId();

    Uni<AcctBusinessConfigDTO> findAcctBusinessConfig();

    Multi<BillReturnAggregateAcctDTO> findListBillReturnAggregateForAccounting(List<Long> idList);
}
