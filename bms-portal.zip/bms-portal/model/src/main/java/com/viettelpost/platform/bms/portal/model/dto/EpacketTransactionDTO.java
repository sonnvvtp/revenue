package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EpacketTransactionDTO {
    private boolean error;

    @JsonAlias({"error_code", "errorCode"})   // map "error_code" -> errorCode
    private String errorCode;

    private String message;

    private long totalRecords;
    private int totalPage;
    private int currentPage;

    @JsonProperty("items")
    private List<EpacketTransactionItem> items; // mảng items như đối tác trả

    // hỗ trợ shape nested { data: { items: [...] } }
    @JsonProperty("data")
    private DataNode data;

    @JsonIgnore
    public List<EpacketTransactionItem> getEffectiveItems() {
        if (items != null) return items;
        if (data != null && data.items != null) return data.items;
        return java.util.Collections.emptyList();
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DataNode {
        @JsonProperty("items")
        private List<EpacketTransactionItem> items;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EpacketTransactionItem {
        private String reqTransactionId;
        private BigDecimal amount;
        private String transactionCode;
        @JsonAlias({"createdDate", "createdTime"})
        private String createdTime;   // đối tác trả "25-09-2025 14:25:15" -> để String cho “đúng như vậy”
        @JsonAlias({"updatedDate", "updatedTime"})
        private String updatedTime;
        private BigDecimal transactionId;
        private Long transactionType;
        private String requestId;
        private Long cusId;
        private String orgCode;
        private Long orgId;
        private String postCode;
        private Long postId;
        private PartnerSource partnerSource;
        private ServiceType serviceType;
        private MerchantType merchantType;

        private BigDecimal partnerInternalId;
        private String timeTransaction;
        private String partnerBankCode;
        private BigDecimal partnerInternalLineId;
        private String reqPaymentCode;
    }
}


