package com.viettelpost.platform.bms.portal.interfaces.einvoice;

import com.cronutils.utils.StringUtils;
import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.common.model.enums.ErrorCodeInvoiceEnum;
import com.viettelpost.platform.bms.portal.model.exception.BaseBmsResponse;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.ConfirmRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.CreateInvoiceRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.DetailRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceOrderRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.UpdateTaxAmountRequest;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceRecordService;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import java.math.BigDecimal;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice-record")
@Tag(name = "API Quản lý bảng kê hóa đơn")
@RequiredArgsConstructor
public class InvoiceRecordController {

    @ConfigProperty(name = "invoice.client.id", defaultValue = "BMS_FMCG")
    String invoiceClientId;

    @ConfigProperty(name = "invoice.client.secret", defaultValue = "Abc123456")
    String invoiceClientSecret;

    private final InvoiceRecordService invoiceOrderService;
    @Inject
    AuthenticationContext authCtx;

    @POST
    @Path("/create")
    @Operation(summary = "API tạo bảng kê hóa đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createInvoiceRecord(@Valid CreateInvoiceRecordRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.createInvoiceRecord(request, infoUser);
    }

    @POST
    @Path("/create-record")
    @Operation(summary = "API tạo bảng kê hóa đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createInvoiceRecordAuto(@HeaderParam("client-id") String clientId, @HeaderParam("secret-key") String secretKey,
                                                 @Valid CreateInvoiceRecordRequest request) {
        if (StringUtils.isEmpty(clientId) || StringUtils.isEmpty(secretKey) || !invoiceClientId.equals(clientId) || !invoiceClientSecret.equals(secretKey)) {
            return Uni.createFrom().item(
                    BaseBmsResponse.errorApiWithHttpStatusCode(Response.Status.UNAUTHORIZED, ErrorCodeInvoiceEnum.UNAUTHORIZED.getCode(), ErrorCodeInvoiceEnum.UNAUTHORIZED.getMessage())
            );
        }
        CustomUser infoUser = new CustomUser();
        return invoiceOrderService.createInvoiceRecord(request, infoUser);
    }

    @POST
    @Path("/find-list")
    @Operation(summary = "Danh sach quan ly đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findInvoiceRecord(@Valid FindInvoiceRecordRequest findInvoiceRecordRequest) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.findInvoiceRecord(findInvoiceRecordRequest, infoUser)
            .map(querySearchResult -> BaseResponse.successApi(querySearchResult, "OK"));
    }

    @GET
    @Path("/detail")
    @Operation(summary = "Chi tiết bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> detailRecord(@Valid @QueryParam("recordId") BigDecimal recordId) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.detailRecordBy(recordId, infoUser)
            .map(response ->  BaseResponse.successApi(response, "OK"));
    }


    @POST
    @Path("/{recordId}/list-order")
    @Operation(summary = "Chi tiết đơn hàng trong bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> listOrderRecord(@Valid @PathParam("recordId") BigDecimal recordId, @Valid @RequestBody DetailRecordRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.orderRecordBy(recordId, request, infoUser)
            .map(response ->  BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Path("/{recordId}/list-item")
    @Operation(summary = "Chi tiết mặt hàng từng đơn bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> listItemRecord(@Valid @PathParam("recordId") BigDecimal recordId, @Valid @QueryParam("isDetailBill") Boolean isDetailBill) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.itemRecordBy(recordId, isDetailBill, infoUser)
            .map(response ->  BaseResponse.successApi(response, "OK"));
    }

    @POST
    @Path("/confirm")
    @Operation(summary = "Chốt bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> confirmInvoiceRecord(@Valid @RequestBody ConfirmRecordRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.confirmInvoiceRecord(request, infoUser);
    }

    @POST
    @Path("/{recordId}/find-order-in")
    @Operation(summary = "Danh sach đơn trong bản ghi")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findOrderInRecord(@Valid @PathParam("recordId") BigDecimal recordId, @Valid FindInvoiceOrderRequest findInvoiceOrderRequest) {
        return invoiceOrderService.findOrderInRecord(recordId, findInvoiceOrderRequest)
            .map(querySearchResult -> BaseResponse.successApi(querySearchResult, "OK"));
    }

    @POST
    @Path("/{recordId}/try-print")
    @Operation(summary = " In thử")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> tryPrint(@Valid @PathParam("recordId") BigDecimal recordId) {
        return invoiceOrderService.tryPrint(recordId)
            .map(querySearchResult -> BaseResponse.successApi(querySearchResult, "OK"));
    }

    @POST
    @Path("/{recordId}/record-item-order/update-tax-amount")
    @Operation(summary = " In thử")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateTaxAmount(@Valid @PathParam("recordId") BigDecimal recordId, @Valid @RequestBody UpdateTaxAmountRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.updateTaxAmount(recordId, request, infoUser);
    }
}
