package com.viettelpost.platform.bms.portal.model.request.advance;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AdvanceRecordGroupDetailRequest {

    private String advancedFilter;

    @NotNull
    private Long advanceAcctId;

    private Integer page;

    private Integer size;
}
