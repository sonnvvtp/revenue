package com.viettelpost.platform.bms.revenue.worker.job;

import com.viettelpost.platform.bms.revenue.worker.service.RevenueVTPService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.job.JobAbs;
import io.quarkus.scheduler.Scheduled;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Mono;

@ApplicationScoped
@Slf4j
@Named("JobCheckSyncBaseRevenue")
public class JobCheckSyncBaseRevenue extends JobAbs<Void> {

  @ConfigProperty(name = "config.cron.check.sync.revenue", defaultValue = "")
  String cronCalculationBillRevenue;

  @Inject
  RevenueVTPService revenueVTPService;

  @Scheduled(cron = "${config.cron.check.sync.revenue}")
  public Uni<Void> checkSyncBaseRevenue() {
    log.info("=====checkSyncBaseRevenue=====");
    return ReactiveConverter.toUni(super.executeTask("checkSyncBaseRevenue", cronCalculationBillRevenue));
  }

  @Override
  protected Mono<Void> taskAction() {
    log.debug("=====start_JobCheckSyncBaseRevenue======");
    return ReactiveConverter.toMono(revenueVTPService.processCheckSyncBaseRevenue());
  }
}
