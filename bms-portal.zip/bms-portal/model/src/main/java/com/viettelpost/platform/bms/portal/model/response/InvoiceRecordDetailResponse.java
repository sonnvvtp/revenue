package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceRecordDetailResponse {
    public String orderId;
    public String orderCode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    public LocalDateTime orderCreatedAt;
    private String buyerCode;
    public String itemCode;
    public String itemName;
    public String itemUnit;
    public Integer itemQuantity;
    public BigDecimal itemPrice;
    public BigDecimal itemAmountBeforeTax;
    public Integer itemTaxPercent;
    public BigDecimal itemTaxAmount;
    private BigDecimal itemAmountAfterTax;
    public Integer itemSelection;
}
