package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import lombok.Data;

@Data
public class ReSyncBillOnPetrol {

    private long id;
    private int successBill;
    private int errorBill;
    private List<BillPetroFailDataResponse> failDataResponses;
    private List<BillPetroSuccessDataResponse> successDataResponses;
    @JsonIgnore
    private int executeNum;
}
