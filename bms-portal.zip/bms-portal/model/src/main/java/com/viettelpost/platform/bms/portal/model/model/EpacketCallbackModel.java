package com.viettelpost.platform.bms.portal.model.model;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketCallbackModel {

    private String transactionCode;
    private BigDecimal partnerInternalId;
    private Long cusId;
    private String timeTransaction;
    private String partnerBankCode;
    private BigDecimal amount;
    private BigDecimal partnerInternalLineId;

    private String reqPaymentCode;
    private BigDecimal orgId;
    private String orgCode;
    private BigDecimal postId;
    private String postCode;

}
