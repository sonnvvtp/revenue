package com.viettelpost.platform.bms.portal.model.response.debttransfer;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class FindListBatchDebtDetailResponse {

    @JsonAlias("CLEAR_BATCH_ID")
    private Long clearBatchId;

    @JsonAlias("CLEAR_BATCHLINE_ID")
    private Long clearBatchLineId;

    @JsonAlias("DOCUMENTNO")
    private String batchNo;

    @JsonAlias("PAYMENT_DATE")
    private String paymentDate;

    @JsonAlias("ACCOUNTING_DATE")
    private LocalDateTime accountingDate;

    @JsonAlias("GRANDAMT")
    private BigDecimal grandAmt;

    @JsonAlias("GRANDAMT_PAY")
    private BigDecimal grandAmtPay;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_NAME")
    private String partnerName;
}
