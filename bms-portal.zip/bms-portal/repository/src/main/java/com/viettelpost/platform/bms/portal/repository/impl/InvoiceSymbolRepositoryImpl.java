package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.dto.InvoiceSymbolDTO;
import com.viettelpost.platform.bms.portal.repository.InvoiceConfigRepository;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@ApplicationScoped
public class InvoiceSymbolRepositoryImpl implements InvoiceConfigRepository {
    @Inject
    PgPool client;

    @Override
    public Flux<InvoiceSymbolDTO> listAll() {
        String sql = "SELECT A.*, (SELECT doctype_name FROM bms_payment.erp_doctype where doctype_id =A.invoice_type) doctype_name FROM bms_payment.invoice_symbol A ORDER BY symbol_id DESC";
        return Flux.create(sink -> {
            client.query(sql)
                    .execute()
                    .subscribe().with(rows -> {
                        for (Row row : rows) {
                            sink.next(mapRowToDTO(row));
                        }
                        sink.complete();
                    }, sink::error);
        });
    }

    @Override
    public Mono<InvoiceSymbolDTO> insert(CustomUser user, InvoiceSymbolDTO dto) {
        String checkSql = "SELECT 1 FROM bms_payment.invoice_symbol WHERE company_code = $1 AND invoice_type = $2 and is_active=true LIMIT 1";
        Tuple checkParams = Tuple.tuple()
                .addValue(dto.getCompanyCode())
                .addValue(dto.getInvoiceType());
        return Mono.fromCompletionStage(
                client.preparedQuery(checkSql)
                        .execute(checkParams)
                        .subscribeAsCompletionStage()
        ).flatMap(rows -> {
            if (rows.iterator().hasNext()) {
                String errorJson = "{\"error\": true, \"message\": \"Loại bảng kê đã được khai báo cho mã công ty này\", \"data\": null}";
                return Mono.error(new CustomFormatException(errorJson));
            }
            String sql = "INSERT INTO bms_payment.invoice_symbol " +
                    "(symbol_code, invoice_type, current_number, max_threshold, is_active, company_code, issue_date_type, created_by, update_by) " +
                    "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *";
            Tuple params = Tuple.tuple()
                    .addValue(dto.getSymbolCode())
                    .addValue(dto.getInvoiceType())
                    .addValue(dto.getCurrentNumber())
                    .addValue(dto.getMaxThreshold())
                    .addValue(dto.getIsActive())
                    .addValue(dto.getCompanyCode())
                    .addValue(dto.getIssueDateType())
                    .addValue(user.getName())
                    .addValue(user.getName());
            return Mono.fromCompletionStage(
                    client.preparedQuery(sql)
                            .execute(params)
                            .subscribeAsCompletionStage()
            ).map(insertRows -> {
                Row row = insertRows.iterator().hasNext() ? insertRows.iterator().next() : null;
                if (row == null) return null;
                return mapRowToDTO(row);
            });
        });
    }

    @Override
    public Mono<InvoiceSymbolDTO> update(CustomUser user, InvoiceSymbolDTO dto) {
        String checkSql = "SELECT 1 FROM bms_payment.invoice_symbol WHERE company_code = $1 AND invoice_type = $2 and is_active=true AND symbol_id <> $3 LIMIT 1";
        Tuple checkParams = Tuple.tuple()
                .addValue(dto.getCompanyCode())
                .addValue(dto.getInvoiceType())
                .addValue(dto.getSymbolId());
        return Mono.fromCompletionStage(
                client.preparedQuery(checkSql)
                        .execute(checkParams)
                        .subscribeAsCompletionStage()
        ).flatMap(rows -> {
            if (rows.iterator().hasNext()) {
                String errorJson = "{\"error\": true, \"message\": \"Loại bảng kê đã được khai báo cho mã công ty này\", \"data\": null}";
                return Mono.error(new CustomFormatException(errorJson));
            }
            // If not exists, proceed to update
            String sql = "UPDATE bms_payment.invoice_symbol SET " +
                    "symbol_code=$1, invoice_type=$2, max_threshold=$3, is_active=$4, company_code=$5, issue_date_type=$6, update_by=$7, update_at=now() " +
                    "WHERE symbol_id=$8 RETURNING *";
            Tuple params = Tuple.tuple()
                    .addValue(dto.getSymbolCode())
                    .addValue(dto.getInvoiceType())
                    .addValue(dto.getMaxThreshold())
                    .addValue(dto.getIsActive())
                    .addValue(dto.getCompanyCode())
                    .addValue(dto.getIssueDateType())
                    .addValue(user.getName())
                    .addValue(dto.getSymbolId());
            return Mono.fromCompletionStage(
                    client.preparedQuery(sql)
                            .execute(params)
                            .subscribeAsCompletionStage()
            ).map(updateRows -> {
                Row row = updateRows.iterator().hasNext() ? updateRows.iterator().next() : null;
                if (row == null) return null;
                return mapRowToDTO(row);
            });
        });
    }

    private InvoiceSymbolDTO mapRowToDTO(Row row) {
        InvoiceSymbolDTO dto = new InvoiceSymbolDTO();
        dto.setSymbolId(row.getLong("symbol_id"));
        dto.setSymbolCode(row.getString("symbol_code"));
        dto.setInvoiceType(row.getInteger("invoice_type"));
        dto.setCurrentNumber(row.getInteger("current_number"));
        dto.setMaxThreshold(row.getLong("max_threshold"));
        dto.setIsActive(row.getBoolean("is_active"));
        dto.setCompanyCode(row.getString("company_code"));
        dto.setIssueDateType(row.getString("issue_date_type"));
        dto.setCreatedAt(row.getLocalDateTime("created_at"));
        dto.setCreatedBy(row.getString("created_by"));
        dto.setUpdateAt(row.getLocalDateTime("update_at"));
        dto.setUpdateBy(row.getString("update_by"));
        try {
            dto.setInvoiceTypeName(row.getString("doctype_name"));
        } catch (Exception e) {
            dto.setInvoiceTypeName("");
        }
        return dto;
    }

    // Custom exception để trả về lỗi đúng format JSON
    public static class CustomFormatException extends RuntimeException {
        public CustomFormatException(String message) {
            super(message);
        }
    }
} 