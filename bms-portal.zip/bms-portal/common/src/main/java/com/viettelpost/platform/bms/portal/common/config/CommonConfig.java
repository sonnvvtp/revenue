package com.viettelpost.platform.bms.portal.common.config;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@ApplicationScoped
public class CommonConfig {
    @Inject
    @ConfigProperty(name = "common.config.thread")
    Integer configThreads;

    @Produces
    @ApplicationScoped
    @Named("SupportingExecutorService")
    public ExecutorService getExecutorService() {
        return Executors.newFixedThreadPool(configThreads);
    }
}
