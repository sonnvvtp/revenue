package com.viettelpost.platform.bms.portal.model.dto;// FILE: EpacketBalancePeriodDTO.java
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EpacketBalancePeriodDTO {

    private boolean error;

    @JsonAlias({"error_code","errorCode"})
    private String errorCode;

    private String message;

    // Giữ field này để tương thích nếu từng có ở root (nhưng hiện tại balance nằm trong data)
    @JsonIgnore
    private BigDecimal partnerBalance;

    /** Số dư tính ở hệ thống mình (tổng cộng -/+) */
    private BigDecimal vtpMoney;

    /** vtpMoney - partnerBalance */
    private BigDecimal diff;

    /** true nếu vtpMoney == partnerBalance */
    private boolean matched;

    /** Thông tin filter/doisoat ở phía bạn */
    private Integer cusId;
    private String fromDate;
    private String toDate;
    private String referenceTime;

    /** Payload dạng mới từ đối tác */
    private DataNode data;

    /** Danh sách giao dịch đã tính ở phía bạn (tuỳ chọn) */
    private List<BalanceTxnItem> items;

    // ====== Fallback getters cho shape mới ======

    /** Lấy partnerBalance: ưu tiên field root, nếu null thì lấy từ data.balance */
    @JsonIgnore
    public BigDecimal getPartnerBalance() {
        if (partnerBalance != null) return partnerBalance;
        if (data != null && data.getBalance() != null) return data.getBalance();
        return null;
    }

    /** Cho phép set thủ công nếu bạn muốn ghi đè sau khi deserialize */
    public EpacketBalancePeriodDTO setPartnerBalance(BigDecimal v) {
        this.partnerBalance = v;
        return this;
    }

    /** cusId: ưu tiên root (do bạn set), nếu null thì lấy từ data */
    @JsonIgnore
    public Integer getCusIdEffective() {
        if (cusId != null) return cusId;
        return (data != null ? data.getCusId() : null);
    }

    @JsonIgnore
    public Long getOrgIdEffective() {
        return (data != null ? data.getOrgId() : null);
    }

    @JsonIgnore
    public Long getPostIdEffective() {
        return (data != null ? data.getPostId() : null);
    }

    // ====== Nested types ======

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DataNode {
        private Integer cusId;
        private Long orgId;
        private Long postId;
        private String fullName;
        private String email;
        private String phoneNumber;

        /** Đối tác trả "balance" trong data → map trực tiếp BigDecimal */
        private BigDecimal balance;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class BalanceTxnItem {
        private String transactionType;
        private String transactionCode;
        private String createdDate;
        private BigDecimal amountSigned; // giữ nguyên âm/dương
    }
}