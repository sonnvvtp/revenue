package com.viettelpost.platform.bms.portal.model.response;

import lombok.Data;

import java.util.List;

@Data
public class InvoiceCustomerDetailResponse {
    private String budgetUnitCode;
    private Boolean invoiceDetailByBill;

    private List<InvoiceItemInfoDTO> items;

    @Data
    public static class InvoiceItemInfoDTO {
        private String customerItemName;
        private String customerItemPhone;
        private String customerItemAddress;
        private String customerItemTax;
        private String customerItemEmail;
        private Integer customerItemType;
        private String invoiceConditionLv1;
        private String invoiceConditionLv2;
        private Integer fromDate;
        private Integer toDate;
        private Boolean autoMergeBill;
    }
}
