package com.viettelpost.platform.bms.portal.common.utils;

import io.vertx.mutiny.sqlclient.Tuple;
import java.util.ArrayList;
import java.util.List;

/**
 * SQL Query Builder với tự động quản lý parameters
 */
public class SqlQueryBuilder {
    private final StringBuilder sql;
    private final List<Object> params;
    private int paramIndex;

    public SqlQueryBuilder() {
        this.sql = new StringBuilder();
        this.params = new ArrayList<>();
        this.paramIndex = 1;
    }

    /**
     * Append SQL string không có parameter
     */
    public SqlQueryBuilder append(String sqlFragment) {
        sql.append(sqlFragment);
        return this;
    }

    /**
     * Append SQL với một parameter
     * @param sqlFragment SQL string có placeholder {}
     * @param param giá trị parameter
     */
    public SqlQueryBuilder append(String sqlFragment, Object param) {
        String processedSql = sqlFragment.replace("{}", "$" + paramIndex);
        sql.append(processedSql);
        params.add(param);
        paramIndex++;
        return this;
    }

    /**
     * Append SQL với nhiều parameters
     * @param sqlFragment SQL string có nhiều placeholder {}
     * @param params các giá trị parameters
     */
    public SqlQueryBuilder append(String sqlFragment, Object... params) {
        String processedSql = sqlFragment;
        for (Object param : params) {
            processedSql = processedSql.replaceFirst("\\{\\}", "\\$" + paramIndex);
            this.params.add(param);
            paramIndex++;
        }
        sql.append(processedSql);
        return this;
    }

    /**
     * Append WHERE condition với parameter
     */
    public SqlQueryBuilder where(String condition, Object param) {
        sql.append(" WHERE ").append(condition.replace("{}", "$" + paramIndex));
        params.add(param);
        paramIndex++;
        return this;
    }

    /**
     * Append AND condition với parameter
     */
    public SqlQueryBuilder and(String condition, Object param) {
        sql.append(" AND ").append(condition.replace("{}", "$" + paramIndex));
        params.add(param);
        paramIndex++;
        return this;
    }

    /**
     * Append AND condition với nhiều parameters
     */
    public SqlQueryBuilder and(String condition, Object... params) {
        String processedCondition = condition;
        for (Object param : params) {
            processedCondition = processedCondition.replaceFirst("\\{\\}", "\\$" + paramIndex);
            this.params.add(param);
            paramIndex++;
        }
        sql.append(" AND ").append(processedCondition);
        return this;
    }

    /**
     * Append OR condition với parameter
     */
    public SqlQueryBuilder or(String condition, Object param) {
        sql.append(" OR ").append(condition.replace("{}", "$" + paramIndex));
        params.add(param);
        paramIndex++;
        return this;
    }

    /**
     * Append AND condition nếu điều kiện đúng
     */
    public SqlQueryBuilder andIf(boolean condition, String sql, Object param) {
        if (condition) {
            and(sql, param);
        }
        return this;
    }

    /**
     * Append AND condition với nhiều params nếu điều kiện đúng
     */
    public SqlQueryBuilder andIf(boolean condition, String sql, Object... params) {
        if (condition) {
            and(sql, params);
        }
        return this;
    }

    /**
     * Append SQL nếu điều kiện đúng
     */
    public SqlQueryBuilder appendIf(boolean condition, String sqlFragment) {
        if (condition) {
            sql.append(sqlFragment);
        }
        return this;
    }

    /**
     * Append SQL với param nếu điều kiện đúng
     */
    public SqlQueryBuilder appendIf(boolean condition, String sqlFragment, Object param) {
        if (condition) {
            append(sqlFragment, param);
        }
        return this;
    }

    /**
     * Append IN clause với list parameters
     */
    public SqlQueryBuilder in(String sqlFragment, List<?> values) {
        if (values == null || values.isEmpty()) {
            return this;
        }

        sql.append(sqlFragment).append(" IN (");
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) {
                sql.append(", ");
            }
            sql.append("$").append(paramIndex);
            params.add(values.get(i));
            paramIndex++;
        }
        sql.append(")");
        return this;
    }

    /**
     * Lấy SQL string cuối cùng
     */
    public String getSql() {
        return sql.toString();
    }

    /**
     * Lấy Tuple parameters cho Vert.x
     */
    public Tuple getTuple() {
        return Tuple.wrap(params);
    }

    /**
     * Lấy List parameters
     */
    public List<Object> getParams() {
        return new ArrayList<>(params);
    }

    /**
     * Reset builder để tái sử dụng
     */
    public SqlQueryBuilder reset() {
        sql.setLength(0);
        params.clear();
        paramIndex = 1;
        return this;
    }

    @Override
    public String toString() {
        return "SQL: " + sql.toString() + "\nParams: " + params.toString();
    }
}