package com.viettelpost.platform.bms.portal.model.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StatementPayStatus {
    private Long statementCreate;
    private Long billCreate;
    private Long statementClear;
    private Long statementCod;
    private Long billPay;
    private Long billTran;
    private Integer type;
    private String partnerCode;
    private String sapCodeClear;
    private String sapCodeClear_APPWEB;
    private String sapCodeCod;

}