package com.viettelpost.platform.bms.portal.model.request;

import com.viettelpost.platform.bms.portal.model.model.KMCPModel;
import com.viettelpost.platform.bms.portal.model.response.sap.MSTSapResponse;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
public class InvInfo {

    private String fKey;
    private String invNo;
    private String mstNgBan;
    private String carUnit;
    private MSTSapResponse.BP_LISTS debtInfo;
    private MSTSapResponse.BP_LISTS mstInfo;
    private KMCPModel kmcp;
    private String carLicensePlate;
}
