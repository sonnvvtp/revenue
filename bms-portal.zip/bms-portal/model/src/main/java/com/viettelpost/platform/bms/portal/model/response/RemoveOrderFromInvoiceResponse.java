package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class RemoveOrderFromInvoiceResponse {
    private String orderId; // ID của đơn hàng
    private Long recordId; // ID của bảng kê
    private Integer deletedLineCount; // Số lượng bản ghi đã xóa từ bảng invoice_record_line
    private Integer deletedItemCount; // Số lượng bản ghi đã xóa từ bảng invoice_record_item
    private Boolean orderStatusUpdated; // Trạng thái cập nhật đơn hàng
    private Boolean success; // Trạng thái thành công hay thất bại
    private String message; // Thông báo kết quả
} 