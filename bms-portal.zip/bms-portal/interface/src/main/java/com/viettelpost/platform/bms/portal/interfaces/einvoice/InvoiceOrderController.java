package com.viettelpost.platform.bms.portal.interfaces.einvoice;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceOrderRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.GeneralOrderRequest;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceOrderService;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice-order")
@Tag(name = "API đẩy đơn xuất hóa đơn")
@RequiredArgsConstructor
public class InvoiceOrderController {

    private final InvoiceOrderService invoiceOrderService;

    @Inject
    AuthenticationContext authCtx;

    @POST
    @Path("/create")
    @Operation(summary = "API gửi thông tin đơn hàng")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createInvoiceOrder(@HeaderParam("client-id") String clientId, @HeaderParam("secret-key") String secretKey,
                                            @Valid GeneralOrderRequest generalOrderRequest) {
        return invoiceOrderService.createInvoiceOrder(clientId, secretKey, generalOrderRequest);
    }

    @GET
    @Path("/query")
    @Operation(summary = "API tra cứu thông tin hoá đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> queryInvoiceOrder(@HeaderParam("client-id") String clientId, @HeaderParam("secret-key") String secretKey,
                                            @QueryParam("orderCode") @NotBlank String orderCode, @QueryParam("companyCode") @NotBlank String companyCode, @QueryParam("source") @NotBlank String source) {
        return invoiceOrderService.queryInvoiceOrder(clientId, secretKey, orderCode, companyCode, source);
    }

    @POST
    @Path("/find-list")
    @Operation(summary = "Danh sach quan ly đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findInvoiceOrder(@Valid FindInvoiceOrderRequest findInvoiceOrderRequest) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceOrderService.findInvoiceOrder(findInvoiceOrderRequest, infoUser)
            .map(querySearchResult -> BaseResponse.successApi(querySearchResult, "OK"));
    }
}
