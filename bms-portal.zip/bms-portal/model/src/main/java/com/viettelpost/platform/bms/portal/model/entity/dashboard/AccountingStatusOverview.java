package com.viettelpost.platform.bms.portal.model.entity.dashboard;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

@Data
public class AccountingStatusOverview {
    @JsonAlias("status")
    private Integer status;

    private String statusName;

    @JsonAlias("business_id")
    private Integer business_id;

    @JsonAlias("sum")
    private Long totalRecord;

    public String getStatusName() {
        return switch (this.status) {
            case -4 -> "Tạo mới";
            case -5 -> "Dữ liệu tạo mới không hợp lệ";
            case -3 -> "Tạo dữ liệu kiểm tra thất bại";
            case -2 -> "Kiểm tra dữ liệu";
            case -10 -> "Kiểm tra, tạo dữ liệu bên SAP thất bại";
            case 0 -> "Sẵn sàng gom";
            case -1 -> "Đang gom";
            case 1 -> "Đã gom xong";
            default -> "Không xác định";
        };
    }
}
