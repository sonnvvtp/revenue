package com.viettelpost.platform.bms.portal.model.request.forControl;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SyntheticDataReq {
    String merchantType; // merchant
    String serviceType; // nguồn dữ liệu
    String partnerSource; // list partner source
    Long reqRequestType; // Loại dịch vụ

    Integer page;
    Integer size;
    String fromDate;
    String toDate;
    Long partnerId;
    String postCode;
    String orgCode;
    String reqVtpOderId;
    Long checkedStatus;
}
