package com.viettelpost.platform.bms.portal.model.response.advance;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AdvanceAcctDocTypeResponse {

    private Integer docType;

    private String docTypeName;
}
