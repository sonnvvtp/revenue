package com.viettelpost.platform.bms.portal.repository.impl;


import com.viettelpost.platform.bms.portal.common.exception.BusinessException;
import com.viettelpost.platform.bms.portal.model.dto.EpacketBalancePeriodDTO;
import com.viettelpost.platform.bms.portal.model.dto.EpacketTransactionDTO;
import com.viettelpost.platform.bms.portal.model.dto.EpacketUserDTO;
import com.viettelpost.platform.bms.portal.model.entity.EpacketTransactionEntity;
import com.viettelpost.platform.bms.portal.model.entity.EpacketTransactionLineEntity;
import com.viettelpost.platform.bms.portal.model.enums.EpacketTransactionType;
import com.viettelpost.platform.bms.portal.model.model.EpacketCallbackModel;
import com.viettelpost.platform.bms.portal.model.request.epacket.*;
import com.viettelpost.platform.bms.portal.model.response.InvoiceReportResponse;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import com.viettelpost.platform.bms.portal.model.response.PartnerInternalConfigResponse;
import com.viettelpost.platform.bms.portal.model.response.RemoveOrderFromInvoiceResponse;
import com.viettelpost.platform.bms.portal.model.response.epacket.*;
import com.viettelpost.platform.bms.portal.repository.EpacketTransactionRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.multi.MultiReactorConverters;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@KeepTracedContext
@ApplicationScoped
@RequiredArgsConstructor
public class EpacketTransactionRepositoryImpl implements EpacketTransactionRepository {

    final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final PgPool client;

    private final ConnectionPool oracleClient;

    public Mono<EpacketTransactionEntity> saveTransaction(EpacketTransactionEntity transaction)  {
        // 1) Kiểm tra tồn tại transaction_code
        String existsSql = "select 1 from bms_payment.bms_transaction_epacket where transaction_code = $1 limit 1";
        Tuple existsTuple = Tuple.of(transaction.getTransactionCode());

        return client.preparedQuery(existsSql)
                .execute(existsTuple)
                .onItem().transform(rs -> rs != null && rs.iterator().hasNext())
                .convert().with(UniReactorConverters.toMono())
                .flatMap(exists -> {
                    if (exists) {
                        return Mono.error(new BusinessException("Đã tồn tại"));
                    }

                    // 2) INSERT (loại bỏ cột id tự sinh nếu có), nhớ khớp thứ tự params
                    String insertSql =
                            "insert into bms_payment.bms_transaction_epacket (" +
                                    "  cust_id, created_date, is_checked, org_code, org_id, partner_internal_id, " +
                                    "  post_code, post_id, req_acc_name, req_acc_no, req_collect_amount, req_expire_date, " +
                                    "  req_memo, req_operation, req_partner_code, req_partner_id, req_payment_code, req_payment_time, " +
                                    "  req_request_type, res_qr_path, res_qr_string, status, transaction_type, transaction_code, " +
                                    "  updated_by, updated_date, request_id, partner_internal_line_id" +
                                    ") values (" +
                                    "  $1,$2,$3,$4,$5,$6," +
                                    "  $7,$8,$9,$10,$11,$12," +
                                    "  $13,$14,$15,$16,$17,$18," +
                                    "  $19,$20,$21,$22,$23,$24," +
                                    "  $25,$26,$27,$28" +
                                    ") returning req_transaction_id";

                    List<Object> params = new ArrayList<>();
                    params.add(transaction.getCustId());                    // $1
                    params.add(transaction.getCreatedDate());               // $2
                    params.add(transaction.getIsChecked());                 // $3
                    params.add(transaction.getOrgCode());                   // $4
                    params.add(transaction.getOrgId());                     // $5
                    params.add(transaction.getPartnerInternalId());         // $6
                    params.add(transaction.getPostCode());                  // $7
                    params.add(transaction.getPostId());                    // $8
                    params.add(transaction.getReqAccName());                // $9
                    params.add(transaction.getReqAccNo());                  // $10
                    params.add(transaction.getReqCollectAmount());          // $11 (BigDecimal)
                    params.add(transaction.getReqExpireDate());             // $12
                    params.add(transaction.getReqMemo());                   // $13
                    params.add(transaction.getReqOperation());              // $14
                    params.add(transaction.getReqPartnerCode());            // $15
                    params.add(transaction.getReqPartnerId());              // $16
                    params.add(transaction.getReqPaymentCode());            // $17
                    params.add(transaction.getReqPaymentTime());            // $18
                    params.add(transaction.getReqRequestType());            // $19
                    params.add(transaction.getResQrPath());                 // $20
                    params.add(transaction.getResQrString());               // $21
                    params.add(transaction.getStatus());                    // $22
                    params.add(transaction.getTransactionType());           // $23
                    params.add(transaction.getTransactionCode());           // $24
                    params.add(transaction.getUpdatedBy());                 // $25
                    params.add(transaction.getUpdatedDate());               // $26
                    params.add(transaction.getRequestId());                 // $27
                    params.add(transaction.getPartnerInternalLineId());     // $28 (BigDecimal)

                    Tuple insertTuple = Tuple.from(params);

                    return client.preparedQuery(insertSql)
                            .execute(insertTuple)
                            .onItem().transform(rs -> {
                                var it = rs.iterator();
                                if (it.hasNext()) {
                                    var row = it.next();
                                    Long id = row.getLong("req_transaction_id");
                                    transaction.setReqTransactionId(id);
                                }
                                return transaction;
                            })
                            .convert().with(UniReactorConverters.toMono());
                });
    }
    public Mono<EpacketTransactionLineEntity> saveTransactionLine(EpacketTransactionLineEntity line)
    {
        // Validate tối thiểu
        if (line.getReqTransactionId() == null ||
                line.getTransactionCode() == null || line.getTransactionCode().isBlank()) {
            return Mono.error(new BusinessException("Thiếu khóa giao dịch để lưu line"));
        }

        final String sql =
                "insert into bms_payment.bms_transaction_epacket_line (" +
                        "  amount, item_code, req_transaction_id, transaction_code, transaction_type, partner_evtp, vendor_code, date_bill_record" +
                        ") values (" +
                        "  $1,     $2,       $3,                $4,              $5,              $6,          $7,         $8" +
                        ") returning req_transaction_line_id";

        // date_bill_record: dùng LocalDateTime nếu bạn có, hoặc null
        List<Object> params = Arrays.asList(line.getAmount(),line.getItemCode(),line.getReqTransactionId(),line.getTransactionCode(),line.getTransactionType(),line.getPartnerEvtp(),line.getVendorCode(),line.getDateBillRecord());

        Tuple tuple = Tuple.from(params);

        return client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transform(rs -> {
                    var it = rs.iterator();
                    if (it.hasNext()) {
                        var row = it.next();
                        Long id = row.getLong("req_transaction_line_id");
                        line.setReqTransactionLineId(id);
                    }
                    return line;
                })
                .convert().with(UniReactorConverters.toMono());
    }


    public Flux<PartnerInternalConfigResponse> getListPartnerConfigsInternal() {
        String sql = "select bpi.partner_internal_id,bpil.partner_internal_line_id ,bpi.active,bpi.endpoint,bpi.partner_source,bpil.prefix,bpi.service_type,bpil.merchant_type,bpil.transaction_type_id,bpil.transaction_type_code,bpi.statement_token_partner from bms_payment.bms_partner_internal bpi,bms_payment.bms_partner_internal_line bpil where bpi.partner_internal_id = bpil.partner_internal_id order by bpil.created_date desc   ";
        List<Object> params = new ArrayList<>();
        Tuple tuple = Tuple.from(params);
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(PartnerInternalConfigResponse.class))
                .execute(tuple)
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    private Mono<String> getPartnerInternalConfig(EpacketTransactionRequest req) {
        String sql = "select bpil.prefix from \n" +
                "    bms_payment.bms_partner_internal bpi\n" +
                "INNER JOIN\n" +
                "    bms_payment.bms_partner_internal_line bpil ON bpi.partner_internal_id = bpil.partner_internal_id " +
                "where bpi.partner_source  = $1 and bpi.service_type  = $2 and bpil.merchant_type = $3 limit 1";
        List<Object> params = Arrays.asList(req.getPartnerSource().getCode(), req.getServiceType().getCode(), req.getMerchantType().getCode());

        Tuple tuple = Tuple.from(params);

        return Mono.from(client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transformToMulti(rowSet ->
                        Multi.createFrom().iterable(rowSet)
                                .map(row -> row.getString("prefix"))
                )
                .convert().with(MultiReactorConverters.toFlux())
                .doOnError(error -> {
                    log.error("Lỗi lấy cấu hình đối tác getPartnerInternalConfig : {}", error.getMessage());
                }));

    }

    public Mono<EpacketTransactionEntity> partnerTransactionEpacket(EpacketTransactionEntity transaction) throws ParseException {
        // 1) Kiểm tra tồn tại transaction_code
        String existsSql = "select 1 from bms_payment.bms_transaction_epacket where transaction_code = $1 limit 1";
        Tuple existsTuple = Tuple.of(transaction.getTransactionCode());

        return client.preparedQuery(existsSql)
                .execute(existsTuple)
                .onItem().transform(rs -> rs != null && rs.iterator().hasNext())
                .convert().with(UniReactorConverters.toMono())
                .flatMap(exists -> {
                    if (exists) {
                        return Mono.error(new BusinessException("Đã tồn tại"));
                    }

                    // 2) INSERT (loại bỏ cột id tự sinh nếu có), nhớ khớp thứ tự params
                    String insertSql =
                            "insert into bms_payment.bms_transaction_epacket (" +
                                    "  cust_id, created_date, is_checked, org_code, org_id, partner_internal_id, " +
                                    "  post_code, post_id, req_acc_name, req_acc_no, req_collect_amount, req_expire_date, " +
                                    "  req_memo, req_operation, req_partner_code, req_partner_id, req_payment_code, req_payment_time, " +
                                    "  req_request_type, res_qr_path, res_qr_string, status, transaction_type, transaction_code, " +
                                    "  updated_by, updated_date, request_id, partner_internal_line_id" +
                                    ") values (" +
                                    "  $1,$2,$3,$4,$5,$6," +
                                    "  $7,$8,$9,$10,$11,$12," +
                                    "  $13,$14,$15,$16,$17,$18," +
                                    "  $19,$20,$21,$22,$23,$24," +
                                    "  $25,$26,$27,$28" +
                                    ") returning req_transaction_id";

                    List<Object> params = new ArrayList<>();
                    params.add(transaction.getCustId());                    // $1
                    params.add(transaction.getCreatedDate());               // $2
                    params.add(transaction.getIsChecked());                 // $3
                    params.add(transaction.getOrgCode());                   // $4
                    params.add(transaction.getOrgId());                     // $5
                    params.add(transaction.getPartnerInternalId());         // $6
                    params.add(transaction.getPostCode());                  // $7
                    params.add(transaction.getPostId());                    // $8
                    params.add(transaction.getReqAccName());                // $9
                    params.add(transaction.getReqAccNo());                  // $10
                    params.add(transaction.getReqCollectAmount());          // $11 (BigDecimal)
                    params.add(transaction.getReqExpireDate());             // $12
                    params.add(transaction.getReqMemo());                   // $13
                    params.add(transaction.getReqOperation());              // $14
                    params.add(transaction.getReqPartnerCode());            // $15
                    params.add(transaction.getReqPartnerId());              // $16
                    params.add(transaction.getReqPaymentCode());            // $17
                    params.add(transaction.getReqPaymentTime());            // $18
                    params.add(transaction.getReqRequestType());            // $19
                    params.add(transaction.getResQrPath());                 // $20
                    params.add(transaction.getResQrString());               // $21
                    params.add(transaction.getStatus());                    // $22
                    params.add(transaction.getTransactionType());           // $23
                    params.add(transaction.getTransactionCode());           // $24
                    params.add(transaction.getUpdatedBy());                 // $25
                    params.add(transaction.getUpdatedDate());               // $26
                    params.add(transaction.getRequestId());                 // $27
                    params.add(transaction.getPartnerInternalLineId());     // $28 (BigDecimal)

                    Tuple insertTuple = Tuple.from(params);

                    return client.preparedQuery(insertSql)
                            .execute(insertTuple)
                            .onItem().transform(rs -> {
                                var it = rs.iterator();
                                if (it.hasNext()) {
                                    var row = it.next();
                                    Long id = row.getLong("req_transaction_id");
                                    transaction.setReqTransactionId(id);
                                }
                                return transaction;
                            })
                            .convert().with(UniReactorConverters.toMono());
                });
    }

    @Override
    public Mono<EpacketReconciTransactionResponse> getListTransactionEpacket(EpacketReconciliationEpacketRequest req) {

        Integer cusId = req.getCusId();
        String fromDate = normalizeDate(req.getFromDate());
        String toDate = normalizeDate(req.getToDate());
        Integer page = req.getPage();
        Integer size = req.getSize();
        Integer reconStatus = req.getReconStatus();

        log.info("[epacket_getListTransactionEpacket] Start query with request: {}", req);

        // ===== Chuẩn hóa khoảng thời gian =====
        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDate firstDay = LocalDate.now().withDayOfMonth(1);

        LocalDateTime fromTs;
        LocalDateTime toTs;

        try {
            fromTs = (fromDate != null && !fromDate.isBlank())
                    ? LocalDateTime.parse(fromDate.trim(), inputFmt)
                    : firstDay.atStartOfDay();
        } catch (Exception e) {
            fromTs = firstDay.atStartOfDay();
        }

        try {
            toTs = (toDate != null && !toDate.isBlank())
                    ? LocalDateTime.parse(toDate.trim(), inputFmt)
                    : LocalDateTime.now();
        } catch (Exception e) {
            toTs = LocalDateTime.now();
        }

        Long cusIdL = (cusId == null) ? null : cusId.longValue();

        // ===== Phân trang =====
        int safePage = (page == null || page < 1) ? 1 : page;
        int safeSize = (size == null || size < 1) ? 10 : size;
        int offset = (safePage - 1) * safeSize;

        // ===== SQL cơ bản =====
        StringBuilder countSql = new StringBuilder("SELECT COUNT(*) AS total FROM bms_payment.bms_transaction_epacket te WHERE te.status = 1 AND te.created_date BETWEEN $1 AND $2");
        StringBuilder dataSql = new StringBuilder("""
        SELECT 
            te.req_transaction_id AS req_transaction_id,
            te.transaction_code   AS transaction_code,
            te.req_payment_code   AS req_payment_code,
            te.req_collect_amount AS req_collect_amount,
            te.req_partner_amount AS req_partner_amount,
            te.created_date       AS created_date,
            te.updated_date       AS updated_date,
            te.org_id             AS org_id,
            te.org_code           AS org_code,
            te.post_id            AS post_id,
            te.post_code          AS post_code,
            te.cust_id            AS cust_id,
            te.transaction_type   AS transaction_type,
            te.request_id         AS request_id,
            te.transaction_source AS transaction_source,
            te.partner_internal_id AS partner_internal_id,
            te.recon_status         AS recon_status,
            te.req_partner_code   AS req_partner_code,
            te.partner_internal_line_id AS partner_internal_line_id,
            te.req_payment_time   AS req_payment_time
        FROM bms_payment.bms_transaction_epacket te
        WHERE te.status = 1 AND te.created_date BETWEEN $1 AND $2
    """);

        List<Object> params = new ArrayList<>();
        params.add(fromTs);
        params.add(toTs);

        // ===== Thêm filter optional cusId =====
        if (cusIdL != null) {
            countSql.append(" AND te.cust_id = $").append(params.size() + 1);
            dataSql.append(" AND te.cust_id = $").append(params.size() + 1);
            params.add(cusIdL);
        }

        // ===== Thêm filter optional reconStatus =====
        if (reconStatus != null) {
            if (reconStatus != 0) {
                countSql.append(" AND te.recon_status <> 0");
                dataSql.append(" AND te.recon_status <> 0");
            }
            else
            {
                countSql.append(" AND te.recon_status = $").append(params.size() + 1);
                dataSql.append(" AND te.recon_status = $").append(params.size() + 1);
            }
            params.add(reconStatus);
        }

        // ===== Phân trang cho data =====
        dataSql.append(" ORDER BY te.created_date DESC OFFSET $").append(params.size() + 1)
                .append(" LIMIT $").append(params.size() + 2);
        params.add(offset);
        params.add(safeSize);

        Tuple tupleCount = Tuple.from(params.subList(0, params.size() - 2)); // Count chỉ dùng các filter trước OFFSET/LIMIT
        Tuple tupleData  = Tuple.from(params);

        DateTimeFormatter outFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        Uni<Long> totalUni = client.preparedQuery(countSql.toString())
                .execute(tupleCount)
                .onItem().transform(rows -> {
                    Row row = rows.iterator().next();
                    return row.getLong("total");
                });

        Uni<List<EpacketReconciTransactionResponse.ITEMS>> dataUni = client.preparedQuery(dataSql.toString())
                .execute(tupleData)
                .onItem().transformToMulti(rows -> Multi.createFrom().iterable(rows))
                .onItem().transform(row -> {
                    EpacketReconciTransactionResponse.ITEMS item = new EpacketReconciTransactionResponse.ITEMS();
                    item.setTransactionId(row.getBigDecimal("req_transaction_id"));
                    item.setTransactionCode(row.getString("transaction_code"));
                    item.setReqPaymentCode(row.getString("req_payment_code"));
                    item.setTransactionType(row.getLong("transaction_type"));
                    item.setCusId(row.getLong("cust_id"));
                    item.setOrgCode(row.getString("org_code"));
                    item.setOrgId(row.getLong("org_id"));
                    item.setPostCode(row.getString("post_code"));
                    item.setPostId(row.getLong("post_id"));
                    item.setTransactionSource(row.getInteger("transaction_source"));
                    item.setPartnerBankCode(row.getString("req_partner_code"));
                    BigDecimal amtVTP = row.getBigDecimal("req_collect_amount");
                    BigDecimal amtPartner = row.getBigDecimal("req_partner_amount");
                    if (amtVTP == null) amtVTP = BigDecimal.ZERO;
                    if (amtPartner == null) amtPartner = BigDecimal.ZERO;
                    item.setAmountVTP(amtVTP);
                    item.setAmountPartner(amtPartner);
                    item.setAmountDiff(amtPartner.subtract(amtVTP));

                    LocalDateTime c = row.getLocalDateTime("created_date");
                    LocalDateTime t = row.getLocalDateTime("req_payment_time");
                    item.setCreatedTime(c != null ? c.format(outFmt) : null);
                    item.setCreatedTimePartner(t != null ? t.format(outFmt) : null);

                    item.setPartnerInternalId(row.getBigDecimal("partner_internal_id"));
                    item.setPartnerInternalLineId(row.getBigDecimal("partner_internal_line_id"));

                    Integer rStatus = row.getInteger("recon_status");
                    item.setReconStatus(rStatus);

                    String message;
                    switch (rStatus != null ? rStatus : -1) {
                        case 0 -> message = "Cân khớp";
                        case 1 -> message = "Chênh lệch";
                        case 2 -> message = "VTP có, đối tác không có";
                        case 3 -> message = "Đối tác có, VTP không có";
                        default -> message = "Chưa đối soát";
                    }
                    item.setMessage(message);
                    item.setIsMatching(rStatus != null && rStatus == 0);

                    return item;
                })
                .collect().asList();

        return Uni.combine().all().unis(totalUni, dataUni)
                .asTuple()
                .map(tuple -> {
                    long totalRecords = tuple.getItem1();
                    List<EpacketReconciTransactionResponse.ITEMS> items = tuple.getItem2();
                    int totalPage = (int) Math.ceil((double) totalRecords / safeSize);

                    EpacketReconciTransactionResponse resp = new EpacketReconciTransactionResponse();
                    resp.setError(false);
                    resp.setErrorCode(null);
                    resp.setItems(items);
                    resp.setTotalRecords(totalRecords);
                    resp.setTotalPage(totalPage);
                    resp.setCurrentPage(safePage);
                    return resp;
                })
                .onFailure().recoverWithItem(e -> {
                    log.error("[getListTransactionEpacket] Error: {}", e.getMessage(), e);
                    EpacketReconciTransactionResponse resp = new EpacketReconciTransactionResponse();
                    resp.setError(true);
                    resp.setErrorCode("DB_QUERY_ERROR");
                    resp.setItems(Collections.emptyList());
                    resp.setTotalRecords(0);
                    resp.setTotalPage(0);
                    resp.setCurrentPage(safePage);
                    return resp;
                })
                .convert().with(UniReactorConverters.toMono());
    }


    /*public Mono<EpacketTransactionDTO> getPartnerTransactions(
            Integer cusId, String fromDate, String toDate) {

        log.info("[getPartnerTransactions]  Start - cusId={}, from={}, to={}", cusId, fromDate, toDate);

        LocalDate firstDay = LocalDateTime.now().withDayOfMonth(1).toLocalDate();
        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime fromTs;
        LocalDateTime toTs;

        try {
            fromTs = (fromDate != null && !fromDate.isBlank())
                    ? LocalDateTime.parse(fromDate.trim(), inputFmt)
                    : firstDay.atStartOfDay();
        } catch (Exception e) {
            log.info("[getPartnerTransactions] Parse fromDate failed ({}), fallback to first day of month", fromDate);
            fromTs = firstDay.atStartOfDay();
        }

        try {
            toTs = (toDate != null && !toDate.isBlank())
                    ? LocalDateTime.parse(toDate.trim(), inputFmt)
                    : LocalDateTime.now();
        } catch (Exception e) {
            log.info("[getPartnerTransactions]  Parse toDate failed ({}), fallback to now", toDate);
            toTs = LocalDateTime.now();
        }

        Long cusIdL = (cusId == null) ? null : cusId.longValue();

        // ===== 2. SQL chỉ đọc bảng bms_transaction_partner =====
        String sql = """
        SELECT 
            req_transaction_id AS req_transaction_id,
            transaction_code   AS transaction_code,
            req_collect_amount AS req_collect_amount,
            created_date       AS created_date,
            updated_date       AS updated_date,
            org_id             AS org_id,
            org_code           AS org_code,
            post_id            AS post_id,
            post_code          AS post_code,
            cust_id            AS cust_id,
            transaction_type   AS transaction_type,
            request_id         AS request_id
        FROM bms_payment.bms_transaction_partner
        WHERE ($1::bigint IS NULL OR cust_id = $1)
          AND status = 1
          AND created_date >= $2 AND created_date <= $3
        ORDER BY created_date DESC
    """;

        Tuple tuple = Tuple.of(cusIdL, fromTs, toTs);
        DateTimeFormatter outFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        return client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    EpacketTransactionDTO.EpacketTransactionItem item = new EpacketTransactionDTO.EpacketTransactionItem();

                    item.setTransactionId(row.getBigDecimal("req_transaction_id"));
                    item.setTransactionCode(row.getString("transaction_code"));
                    item.setRequestId(row.getString("request_id"));
                    item.setTransactionType(row.getLong("transaction_type"));
                    item.setCusId(row.getLong("cust_id"));
                    item.setOrgId(row.getLong("org_id"));
                    item.setOrgCode(row.getString("org_code"));
                    item.setPostId(row.getLong("post_id"));
                    item.setPostCode(row.getString("post_code"));

                    BigDecimal amt = row.getBigDecimal("req_collect_amount");
                    item.setAmount(amt != null ? amt : BigDecimal.ZERO);

                    LocalDateTime c = row.getLocalDateTime("created_date");
                    LocalDateTime u = row.getLocalDateTime("updated_date");
                    item.setCreatedTime(c != null ? c.format(outFmt) : null);
                    item.setUpdatedTime(u != null ? u.format(outFmt) : null);

                    return item;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .collectList()
                .map(list -> {
                    EpacketTransactionDTO wrapper = new EpacketTransactionDTO();
                    wrapper.setError(false);
                    wrapper.setErrorCode(null);
                    wrapper.setMessage("Success");
                    wrapper.setItems(list);
                    log.info("[getPartnerTransactions] Done - fetched {} records", list.size());
                    return wrapper;
                });
    }
*/
    /**
     * Tìm giao dịch theo req (cusId, danh sách transactionCode)
     * Trả về wrapper {error, error_code, message, data: [...]}
     */
    public Mono<EpacketSearchTransCodeResponse> searchTransactionsEpacket(EpacketSearchTransactionRequest req) {
        // === 1. Chuẩn hóa thời gian ===
        String fromDate = normalizeDate(req.getFromDate());
        String toDate   = normalizeDate(req.getToDate());

        // Nếu không truyền ngày → mặc định từ đầu tháng đến hiện tại
        if ((fromDate == null || fromDate.isBlank()) && (toDate == null || toDate.isBlank())) {
            LocalDateTime now = LocalDateTime.now();
            LocalDate firstDay = now.withDayOfMonth(1).toLocalDate();
            fromDate = firstDay.atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            toDate   = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }

        final String TS_FMT = "YYYY-MM-DD HH24:MI:SS";
        List<Object> params = new ArrayList<>();
        int idx = 0;

        // === 2. SQL chỉ đọc bảng bms_transaction_epacket ===
        StringBuilder sql = new StringBuilder("""
        SELECT
            te.transaction_code,
            te.req_collect_amount AS amount,
            te.transaction_type,
            te.request_id,
            te.org_code,
            te.org_id,
            te.post_code,
            te.post_id,
            te.created_date,
            te.updated_date,
            te.status,
            te.partner_internal_id,
            te.req_partner_code,
            te.req_partner_id,
            'TRANSACTION_EPACKET' AS source_table
        FROM bms_payment.bms_transaction_epacket te
        WHERE te.status = 1
    """);

        // === 3. Điều kiện lọc ===
        if (req.getCusId() != null) {
            params.add(req.getCusId());
            sql.append(" AND te.cust_id = $").append(++idx).append(" ");
        }

        // Lọc theo danh sách transaction_code
        List<String> codes = Optional.ofNullable(req.getTransactionsCode())
                .orElseGet(Collections::emptyList)
                .stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();

        if (!codes.isEmpty()) {
            params.add(codes.toArray(new String[0]));
            sql.append(" AND te.transaction_code = ANY($").append(++idx).append(") ");
        }

        // Lọc theo thời gian
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        if (fromDate != null && !fromDate.isBlank()) {
            LocalDateTime fromDt = LocalDateTime.parse(fromDate.trim(), fmt);
            params.add(fromDt);
            sql.append(" AND te.created_date >= $").append(++idx).append("::timestamp ");
        }

        if (toDate != null && !toDate.isBlank()) {
            if (toDate.endsWith("00:00:00")) {
                toDate = toDate.substring(0, 10) + " 23:59:59";
            }
            LocalDateTime toDt = LocalDateTime.parse(toDate.trim(), fmt);
            params.add(toDt);
            sql.append(" AND te.created_date <= $").append(++idx).append("::timestamp ");
        }

        // Sắp xếp
        sql.append(" ORDER BY te.created_date DESC ");

        Tuple tuple = Tuple.from(params);

        // === 4. Mapping dữ liệu ===
        DateTimeFormatter outFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        log.info("Final SQL: {}", sql);
        log.info("Params: {}", params);

        return client.preparedQuery(sql.toString())
                .execute(tuple)
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    EpacketSearchTransCodeResponse.ITEMS dto = new EpacketSearchTransCodeResponse.ITEMS();

                    dto.setTransactionCode(row.getString("transaction_code"));
                    dto.setAmount(row.getBigDecimal("amount"));
                    dto.setTransactionType(row.getInteger("transaction_type"));
                    dto.setRequestId(row.getString("request_id"));
                    dto.setOrgCode(row.getString("org_code"));
                    dto.setOrgId(row.getLong("org_id"));
                    dto.setPostCode(row.getString("post_code"));
                    dto.setPostId(row.getLong("post_id"));
                    dto.setStatus(row.getInteger("status"));

                    LocalDateTime c = row.getLocalDateTime("created_date");
                    LocalDateTime u = row.getLocalDateTime("updated_date");
                    dto.setCreateDate(c != null ? c.format(outFmt) : null);
                    dto.setUpdateDate(u != null ? u.format(outFmt) : null);
                    dto.setPartnerInternalId(row.getLong("partner_internal_id"));
                    dto.setPartnerBankCode(row.getString("req_partner_code"));
                    dto.setReqPartnerId(row.getLong("req_partner_id"));
                    dto.setStatusText("Thành công");
                    return dto;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .collectList()
                .map(list -> {
                    EpacketSearchTransCodeResponse wrapper = new EpacketSearchTransCodeResponse();
                    wrapper.setError(false);
                    wrapper.setErrorCode(null);
                    wrapper.setMessage("Success");
                    wrapper.setItems(list);
                    return wrapper;
                })
                .onErrorResume(e -> {
                    EpacketSearchTransCodeResponse wrapper = new EpacketSearchTransCodeResponse();
                    wrapper.setError(true);
                    wrapper.setErrorCode("SEARCH_ERROR");
                    wrapper.setMessage(e.getMessage());
                    wrapper.setItems(Collections.emptyList());
                    return Mono.just(wrapper);
                });
    }




    @Override
    public Mono<EpacketTransactionEntity> findByTransactionCode(String tranCode) {
        String sql =
                "select req_transaction_id, cust_id, created_date, is_checked, org_code, org_id, " +
                        "       partner_internal_id, post_code, post_id, req_acc_name, req_acc_no, " +
                        "       req_collect_amount, req_expire_date, req_memo, req_operation, req_partner_code, " +
                        "       req_partner_id, req_payment_code, req_payment_time, req_request_type, " +
                        "       res_qr_path, res_qr_string, status, transaction_type, transaction_code, " +
                        "       updated_by, updated_date, request_id, partner_internal_line_id " +
                        "from bms_payment.bms_transaction_epacket " +
                        "where transaction_code = $1 limit 1";

        return client.preparedQuery(sql)
                .execute(Tuple.of(tranCode))
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    EpacketTransactionEntity e = new EpacketTransactionEntity();

                    e.setReqTransactionId(row.getLong("req_transaction_id"));
                    e.setCustId(row.getLong("cust_id"));
                    e.setCreatedDate(row.getLocalDateTime("created_date"));

                    // is_checked (int8?) -> Integer
                    Long isCheckedL = row.getLong("is_checked");
                    e.setIsChecked(isCheckedL != null ? isCheckedL.intValue() : null);

                    e.setOrgCode(row.getString("org_code"));
                    e.setOrgId(row.getLong("org_id"));

                    // partner_internal_id int4 -> Long
                    Long partnerInternalId = null;
                    Integer pii = row.getInteger("partner_internal_id");
                    if (pii != null) partnerInternalId = pii.longValue();
                    else partnerInternalId = row.getLong("partner_internal_id");
                    e.setPartnerInternalId(partnerInternalId);
                    e.setPostCode(row.getString("post_code"));
                    e.setPostId(row.getLong("post_id"));
                    e.setReqAccName(row.getString("req_acc_name"));
                    e.setReqAccNo(row.getString("req_acc_no"));

                    e.setReqCollectAmount(row.getBigDecimal("req_collect_amount"));
                    e.setReqExpireDate(row.getLocalDateTime("req_expire_date"));
                    e.setReqMemo(row.getString("req_memo"));
                    e.setReqOperation(row.getString("req_operation"));
                    e.setReqPartnerCode(row.getString("req_partner_code"));
                    e.setReqPartnerId(row.getLong("req_partner_id"));
                    e.setReqPaymentCode(row.getString("req_payment_code"));
                    e.setReqPaymentTime(row.getLocalDateTime("req_payment_time"));
                    e.setReqRequestType(row.getLong("req_request_type"));
                    e.setResQrPath(row.getString("res_qr_path"));
                    e.setResQrString(row.getString("res_qr_string"));

                    // status smallint -> Integer
                    Short st = row.getShort("status");
                    e.setStatus(st != null ? st.intValue() : null);

                    // transaction_type (int8/int4) -> Integer
                    Integer tti = row.getInteger("transaction_type");
                    if (tti != null) e.setTransactionType(tti);
                    else {
                        Long ttl = row.getLong("transaction_type");
                        e.setTransactionType(ttl != null ? ttl.intValue() : null);
                    }

                    e.setTransactionCode(row.getString("transaction_code"));
                    e.setUpdatedBy(row.getLong("updated_by"));
                    e.setUpdatedDate(row.getLocalDateTime("updated_date"));
                    e.setRequestId(row.getString("request_id"));

                    // partner_internal_line_id numeric(19) -> Long
                    BigDecimal lineId = row.getBigDecimal("partner_internal_line_id");
                    e.setPartnerInternalLineId(lineId != null ? lineId.longValue() : null);

                    return e;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .next(); // Mono<EpacketTransactionEntity>
    }

    @Override
    public Mono<Boolean> cancelTransactionByCode(String transactionCode) {
        // Chỉ hủy khi đang ở trạng thái khởi tạo (-1) → set -10 (đã hủy)
        String sql =
                "update bms_payment.bms_transaction_epacket " +
                        "set status = -10 " +
                        "where transaction_code = $1 and status = -1 " +
                        "returning req_transaction_id";

        return client.preparedQuery(sql)
                .execute(Tuple.of(transactionCode))
                .onItem().transform(rs -> rs != null && rs.iterator().hasNext()) // có row -> update thành công
                .convert().with(UniReactorConverters.toMono());
    }

    public Mono<EpacketCallbackModel> findCallbackPayload(EpacketCallbackRequest request)
    {
        String transactionCode = request.getTransactionCode();
        Long createdBy = request.getCusId();
        final String sql = """
        SELECT
            rp.transaction_code,
            rp.partner_internal_id,
            rp.created_by                                        AS cus_id,
            to_char(COALESCE(cb.trans_time, rp.created_date, NOW()),
                    'YYYY-MM-DD HH24:MI:SS')                     AS time_transaction,
            rp.req_partner_code,
            COALESCE(cb.trans_amount::numeric, rp.req_collect_amount) AS amount,
            rp.partner_internal_line_id,
            rp.req_payment_code,
            rp.org_id,
            rp.org_code,
            rp.post_id,
            rp.post_code
        FROM bms_payment.bms_request_payment rp
        LEFT JOIN bms_payment.bms_callback_payment cb
               ON cb.transaction_code = rp.transaction_code
              AND cb.req_payment_code = rp.req_payment_code
        WHERE rp.transaction_code = $1
          AND rp.created_by = $2
        LIMIT 1
        """;

        return client.preparedQuery(sql)
                .execute(Tuple.of(transactionCode, createdBy))
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    EpacketCallbackModel m = new EpacketCallbackModel();

                    // transactionCode
                    m.setTransactionCode(row.getString("transaction_code"));

                    // partnerInternalId numeric -> BigDecimal
                    m.setPartnerInternalId(row.getBigDecimal("partner_internal_id"));

                    // cusId (created_by) -> Long
                    m.setCusId(row.getLong("cus_id"));

                    // timeTransaction (String đã format dd-MM-yyyy HH:mm:ss)
                    m.setTimeTransaction(row.getString("time_transaction"));

                    // partnerBankCode từ callback
                    m.setPartnerBankCode(row.getString("req_partner_code"));

                    // amount numeric -> BigDecimal (ưu tiên cb.trans_amount, fallback rp.req_collect_amount)
                    m.setAmount(row.getBigDecimal("amount"));

                    // partnerInternalLineId numeric -> BigDecimal
                    m.setPartnerInternalLineId(row.getBigDecimal("partner_internal_line_id"));

                    // reqPaymentCode
                    m.setReqPaymentCode(row.getString("req_payment_code"));

                    // orgId/postId trong model là BigDecimal -> convert từ BIGINT
                    Long orgIdL = row.getLong("org_id");
                    m.setOrgId(orgIdL != null ? BigDecimal.valueOf(orgIdL) : null);

                    m.setOrgCode(row.getString("org_code"));

                    Long postIdL = row.getLong("post_id");
                    m.setPostId(postIdL != null ? BigDecimal.valueOf(postIdL) : null);

                    m.setPostCode(row.getString("post_code"));

                    return m;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .next(); // -> Mono<EpacketCallbackModel>
    }


    /*public Mono<EpacketBalancePeriodDTO> collectBalanceTransactions(Integer cusId, String referenceTime) {
        DateTimeFormatter inFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime refTs;
        try {
            refTs = (referenceTime != null && !referenceTime.isBlank())
                    ? LocalDateTime.parse(referenceTime.trim(), inFmt)
                    : LocalDateTime.now();
        } catch (Exception e) {
            refTs = LocalDateTime.now(); // fallback now nếu format sai
        }

        // ===== SQL chỉ đọc từ bms_transaction_epacket =====
        final String sql = """
        SELECT
          CASE te.transaction_type
               WHEN 1 THEN 'DEPOSIT_MONEY'
               WHEN 2 THEN 'WITHDRAW_MONEY'
               WHEN 3 THEN 'MINUS_MONEY_WALLET'
               WHEN 4 THEN 'PLUS_MONEY_WALLET'
               ELSE 'N/A'
          END AS transaction_type,
          te.transaction_code,
          to_char(te.created_date,'YYYY-MM-DD HH24:MI:SS') AS created_date,
          COALESCE(te.req_collect_amount, 0)::numeric AS amount
        FROM bms_payment.bms_transaction_epacket te
        WHERE te.cust_id = $1
          AND te.created_date <= $2
        ORDER BY te.created_date
    """;

        Tuple tuple = Tuple.of(cusId, refTs);

        return client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    var it = new EpacketBalancePeriodDTO.BalanceTxnItem();
                    it.setTransactionType(row.getString("transaction_type"));
                    it.setTransactionCode(row.getString("transaction_code"));
                    it.setCreatedDate(row.getString("created_date"));
                    it.setAmountSigned(row.getBigDecimal("amount"));
                    return it;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .collectList()
                .map(list -> {
                    // Tính tổng tiền theo chiều âm/dương
                    BigDecimal total = list.stream()
                            .map(i -> i.getAmountSigned() == null ? BigDecimal.ZERO : i.getAmountSigned())
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    return new EpacketBalancePeriodDTO()
                            .setError(false)
                            .setItems(list)
                            .setVtpMoney(total);
                })
                .onErrorResume(e -> {
                    EpacketBalancePeriodDTO fail = new EpacketBalancePeriodDTO();
                    fail.setError(true);
                    fail.setMessage("Collect balance failed: " + e.getMessage());
                    fail.setItems(Collections.emptyList());
                    fail.setVtpMoney(BigDecimal.ZERO);
                    return Mono.just(fail);
                });
    }*/


    /*public Mono<EpacketTransactionDTO> getListCallbackPayloadEpacket(Integer cusId,
                                                                          String fromDate,
                                                                          String toDate) {
        // 1) Điều kiện dùng CHUNG tham số ($1..$3):
        // $1 = cusId, $2 = fromDate (optional), $3 = toDate (optional)
        StringBuilder cond = new StringBuilder(" WHERE rp.created_by = $1 ");
        int idx = 1; // $1
        List<Object> params = new ArrayList<>();
        params.add(cusId);

        // Dùng format input 'YYYY-MM-DD HH24:MI:SS'
        if (fromDate != null && !fromDate.isBlank()) {
            idx++; // $2
            cond.append(" AND rp.created_date >= to_timestamp($").append(idx).append(", 'YYYY-MM-DD HH24:MI:SS') ");
            params.add(fromDate.trim());
        }
        if (toDate != null && !toDate.isBlank()) {
            idx++; // $3
            cond.append(" AND rp.created_date <= to_timestamp($").append(idx).append(", 'YYYY-MM-DD HH24:MI:SS') ");
            params.add(toDate.trim());
        }

        final String sql = """
        SELECT
            rp.transaction_code,
            rp.partner_internal_id,
            rp.created_by                                        AS cus_id,
            to_char(COALESCE(cb.trans_time, rp.created_date, NOW()),
                    'YYYY-MM-DD HH24:MI:SS')                     AS time_transaction,
            COALESCE(cb.partner_bank_code, rp.req_partner_code) AS partner_bank_code,
            COALESCE(cb.trans_amount::numeric, rp.req_collect_amount) AS amount,
            rp.partner_internal_line_id,
            rp.req_payment_code,
            rp.org_id,
            rp.org_code,
            rp.post_id,
            rp.post_code
        FROM bms_payment.bms_request_payment rp
        JOIN bms_payment.bms_callback_payment cb
               ON cb.transaction_code = rp.transaction_code
              AND cb.req_payment_code = rp.req_payment_code
        """ + cond +
                " ORDER BY rp.created_date DESC";

        Tuple tuple = Tuple.tuple();
        params.forEach(tuple::addValue);

        return client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    EpacketTransactionDTO.EpacketTransactionItem m = new EpacketTransactionDTO.EpacketTransactionItem();

                    m.setTransactionCode(row.getString("transaction_code"));
                    m.setPartnerInternalId(row.getBigDecimal("partner_internal_id"));
                    m.setCusId(row.getLong("cus_id"));
                    m.setTimeTransaction(row.getString("time_transaction"));
                    m.setPartnerBankCode(row.getString("partner_bank_code"));
                    m.setAmount(row.getBigDecimal("amount"));
                    m.setPartnerInternalLineId(row.getBigDecimal("partner_internal_line_id"));
                    m.setReqPaymentCode(row.getString("req_payment_code"));
                    m.setOrgId(row.getLong("org_id"));
                    m.setOrgCode(row.getString("org_code"));
                    m.setPostId(row.getLong("post_id"));
                    m.setPostCode(row.getString("post_code"));

                    return m;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .collectList()
                .map(list -> {
                    EpacketTransactionDTO wrapper =
                            new EpacketTransactionDTO();
                    wrapper.setError(false);
                    wrapper.setErrorCode(null);
                    wrapper.setMessage("Success");
                    wrapper.setItems(list);
                    return wrapper;
                });
    }*/

    /*public Mono<EpacketTransactionListResponse> listTransactionEpacket(Integer cusId,
                                                                       String walletType,          // chưa dùng
                                                                       Integer transactionType,    // null -> tất cả
                                                                       String fromDate,
                                                                       String toDate,
                                                                       String transactionCode,
                                                                       Integer reconStatus,
                                                                       Integer accountingStatus) {
        final String TS_FMT = "YYYY-MM-DD HH24:MI:SS"; // input yyyy-MM-dd HH:mm:ss

        // ===== 1) Chuẩn hóa khoảng thời gian =====
        if ((fromDate == null || fromDate.isBlank()) && (toDate == null || toDate.isBlank())) {
            LocalDateTime now = LocalDateTime.now();
            LocalDate firstDay = now.withDayOfMonth(1).toLocalDate();
            fromDate = firstDay.atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            toDate   = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }

        // ===== 2) Build điều kiện và tham số =====
        List<Object> params = new ArrayList<>();
        int idx = 0;

        StringBuilder condEpk = new StringBuilder(" WHERE 1=1 ");

        if (cusId != null && cusId > 0) {
            params.add(cusId);
            condEpk.append(" AND te.cust_id = $").append(++idx).append(' ');
        }

        if (transactionCode != null && !transactionCode.isBlank()) {
            params.add(transactionCode.trim());
            condEpk.append(" AND te.transaction_code = $").append(++idx).append(' ');
        }

        if (reconStatus != null) {
            params.add(reconStatus);
            condEpk.append(" AND te.is_checked = $").append(++idx).append(' ');
        }

        if (fromDate != null && !fromDate.isBlank()) {
            params.add(fromDate.trim());
            condEpk.append(" AND te.created_date >= to_timestamp($").append(++idx)
                    .append(", '").append(TS_FMT).append("') ");
        }
        if (toDate != null && !toDate.isBlank()) {
            params.add(toDate.trim());
            condEpk.append(" AND te.created_date <= to_timestamp($").append(++idx)
                    .append(", '").append(TS_FMT).append("') ");
        }

        if (transactionType != null) {
            params.add(transactionType);
            condEpk.append(" AND te.transaction_type = $").append(++idx).append(' ');
        }

        // ===== 3) SQL chính =====
        final String sql = """
        SELECT
            'TRANSACTION_EPACKET' AS status_text,
            te.transaction_code AS transaction_code,
            NULL::varchar AS req_payment_code,
            te.cust_id AS cus_id,
            NULL::varchar AS cus_name,
            COALESCE(te.req_collect_amount, 0)::numeric AS amount,
            te.is_checked AS recon_status,
            -1 AS accounting_status,
            te.transaction_type AS transaction_type,
            to_char(te.created_date, 'YYYY-MM-DD HH24:MI:SS') AS create_date,
            to_char(te.updated_date, 'YYYY-MM-DD HH24:MI:SS') AS update_date
        FROM bms_payment.bms_transaction_epacket te
    """ + condEpk + " ORDER BY te.created_date DESC";

        // ===== 4) Thực thi query =====
        Tuple tuple = Tuple.tuple();
        params.forEach(tuple::addValue);

        return client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transformToMulti(rs -> Multi.createFrom().iterable(rs))
                .onItem().transform(row -> {
                    EpacketTransactionListResponse.ITEMS it = new EpacketTransactionListResponse.ITEMS();

                    it.setStatusText("TRANSACTION_EPACKET");
                    it.setTransactionCode(row.getString("transaction_code"));
                    it.setReqPaymentCode(row.getString("req_payment_code"));
                    it.setCusId(row.getLong("cus_id"));
                    it.setCusName(row.getString("cus_name"));
                    it.setAmount(row.getBigDecimal("amount"));
                    it.setReconStatus(row.getInteger("recon_status"));
                    it.setAccountingStatus(-1);
                    it.setTransactionType(row.getInteger("transaction_type"));
                    it.setCreateDate(row.getString("create_date"));
                    it.setUpdateDate(row.getString("update_date"));
                    return it;
                })
                .convert().with(MultiReactorConverters.toFlux())
                .collectList()
                .map(list -> {
                    EpacketTransactionListResponse res = new EpacketTransactionListResponse();
                    res.setItems(list);
                    return res;
                })
                .onErrorResume(e -> {
                    e.printStackTrace();
                    EpacketTransactionListResponse fail = new EpacketTransactionListResponse();
                    fail.setItems(new ArrayList<>());
                    return Mono.just(fail);
                });
    }*/


    public Mono<EpacketTransactionListResponse> listTransactionEpacket(EpacketListTransactionRequest req) {
        final String TS_FMT = "YYYY-MM-DD HH24:MI:SS"; // input yyyy-MM-dd HH:mm:ss

        // ===== 0) Chuẩn hoá page/size & time range =====
        int page = (req.getPage() == null || req.getPage() <= 0) ? 1 : req.getPage();
        int size = (req.getSize() == null || req.getSize() <= 0) ? 10 : req.getSize();
        int offset = (page - 1) * size;

        String fromDate = normalizeDate(req.getFromDate());
        String toDate   = normalizeDate(req.getToDate());
        if ((fromDate == null || fromDate.isBlank()) && (toDate == null || toDate.isBlank())) {
            LocalDateTime now = LocalDateTime.now();
            LocalDate firstDay = now.withDayOfMonth(1).toLocalDate();
            fromDate = firstDay.atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            toDate   = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }

        // ===== 1) Build điều kiện + tham số =====
        List<Object> params = new ArrayList<>();
        int idx = 0;

        StringBuilder condEpk = new StringBuilder(" WHERE te.status = 1 ");

        // cusId
        if (req.getCusId() != null && req.getCusId() > 0) {
            params.add(req.getCusId());
            condEpk.append(" AND te.cust_id = $").append(++idx).append(' ');
        }

        // transactionCode
        if (req.getTransactionsCode() != null && !req.getTransactionsCode().isBlank()) {
            params.add(req.getTransactionsCode().trim());
            condEpk.append(" AND te.transaction_code = $").append(++idx).append(' ');
        }

        // reconStatus -> is_checked
        if (req.getReconStatus() != null) {
            params.add(req.getReconStatus());
            condEpk.append(" AND te.recon_status = $").append(++idx).append(' ');
        }

        // fromDate/toDate
        if (fromDate != null && !fromDate.isBlank()) {
            params.add(fromDate.trim());
            condEpk.append(" AND te.created_date >= to_timestamp($")
                    .append(++idx).append(", '").append(TS_FMT).append("') ");
        }
        if (toDate != null && !toDate.isBlank()) {
            params.add(toDate.trim());
            condEpk.append(" AND te.created_date <= to_timestamp($")
                    .append(++idx).append(", '").append(TS_FMT).append("') ");
        }

        // transactionType (nếu có)
        if (req.getTransactionType() != null) {
            params.add(req.getTransactionType());
            condEpk.append(" AND te.transaction_type = $").append(++idx).append(' ');
        }

        // ===== 2) SQL query & count =====
        final String dataSql = """
        SELECT
           'TRANSACTION_EPACKET' AS status_text,
           te.transaction_code AS transaction_code,
           NULL::varchar       AS req_payment_code,
           te.cust_id          AS cus_id,
           NULL::varchar       AS cus_name,
           COALESCE(te.req_collect_amount, 0)::numeric AS amount,
           te.recon_status       AS recon_status,
           -1                  AS accounting_status,
           te.transaction_type AS transaction_type,
           to_char(te.created_date, 'YYYY-MM-DD HH24:MI:SS') AS create_date,
           to_char(te.updated_date, 'YYYY-MM-DD HH24:MI:SS') AS update_date
        FROM bms_payment.bms_transaction_epacket te
    """ + condEpk +
                " ORDER BY te.created_date DESC LIMIT $" + (idx + 1) + " OFFSET $" + (idx + 2);

        final String countSql = "SELECT COUNT(*) FROM bms_payment.bms_transaction_epacket te " + condEpk;

        Tuple dataTuple = Tuple.tuple();
        params.forEach(dataTuple::addValue);
        dataTuple.addInteger(size).addInteger(offset);

        Tuple countTuple = Tuple.tuple();
        params.forEach(countTuple::addValue);

        // ===== 3) COUNT =====
        Uni<Long> countUni = client.preparedQuery(countSql)
                .execute(countTuple)
                .map(rows -> {
                    var it = rows.iterator();
                    return it.hasNext() ? it.next().getLong(0) : 0L;
                });
        Mono<Long> countMono = Mono.fromFuture(countUni.subscribeAsCompletionStage());

        // ===== 4) Chain count -> data -> mapping =====
        return countMono.flatMap(totalItems -> {
            if (totalItems <= 0) {
                EpacketTransactionListResponse empty = new EpacketTransactionListResponse();
                empty.setItems(new ArrayList<>());
                empty.setTotalRecords(0);
                empty.setTotalPage(0);
                empty.setCurrentPage(page);
                return Mono.just(empty);
            }

            return queryDataRows(client, dataSql, dataTuple)
                    .flatMap(items -> {
                        Set<Long> cusIds = items.stream()
                                .map(EpacketTransactionListResponse.ITEMS::getCusId)
                                .filter(Objects::nonNull)
                                .collect(Collectors.toCollection(LinkedHashSet::new));

                        if (cusIds.isEmpty()) {
                            return Mono.just(items);
                        }

                        return Mono.fromFuture(getCusInfoMapFromOracle(cusIds).subscribeAsCompletionStage())
                                .onErrorReturn(Collections.emptyMap())
                                .map(cusInfoMap -> {
                                    for (var it : items) {
                                        Long c = it.getCusId();
                                        if (c == null) continue;
                                        EpacketUserDTO user = cusInfoMap.get(c);
                                        if (user != null) {
                                            if (it.getCusName() == null || it.getCusName().isBlank()) {
                                                it.setCusName(user.getCusName());
                                            }
                                            if (it.getEmail() == null || it.getEmail().isBlank()) {
                                                it.setEmail(user.getEmail());
                                            }
                                            if (it.getPhone() == null || it.getPhone().isBlank()) {
                                                it.setPhone(user.getPhone());
                                            }
                                        }
                                    }
                                    return items;
                                });
                    })
                    .map(items -> {
                        log.info("epacket_listTransactionEpacket_success: {}", totalItems);

                        int totalPages = (int) Math.ceil((double) totalItems / (double) size);
                        EpacketTransactionListResponse res = new EpacketTransactionListResponse();
                        res.setItems(items);
                        res.setTotalRecords(totalItems);
                        res.setTotalPage(totalPages);
                        res.setCurrentPage(page);
                        return res;
                    });
        }).onErrorResume(e -> {
            EpacketTransactionListResponse fail = new EpacketTransactionListResponse();
            fail.setItems(new ArrayList<>());
            fail.setTotalRecords(0);
            fail.setTotalPage(0);
            fail.setCurrentPage(page);
            return Mono.just(fail);
        });
    }



    public Mono<EpacketExportListResponse> exportToExcelEpacket(EpacketListTransactionRequest req) {
        final String TS_FMT = "YYYY-MM-DD HH24:MI:SS"; // input yyyy-MM-dd HH:mm:ss

        // ===== 0) Chuẩn hoá time range =====
        String fromDate = normalizeDate(req.getFromDate());
        String toDate   = normalizeDate(req.getToDate());

        if ((fromDate == null || fromDate.isBlank()) && (toDate == null || toDate.isBlank())) {
            LocalDateTime now = LocalDateTime.now();
            LocalDate firstDay = now.withDayOfMonth(1).toLocalDate();
            fromDate = firstDay.atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            toDate   = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }

        // ===== 1) Build điều kiện & tham số =====
        List<Object> params = new ArrayList<>();
        int idx = 0;
        StringBuilder condEpk = new StringBuilder(" WHERE te.status = 1 ");

        // cusId
        if (req.getCusId() != null && req.getCusId() > 0) {
            params.add(req.getCusId());
            condEpk.append(" AND te.cust_id = $").append(++idx).append(' ');
        }

        // transactionCode
        if (req.getTransactionsCode() != null && !req.getTransactionsCode().isBlank()) {
            params.add(req.getTransactionsCode().trim());
            condEpk.append(" AND te.transaction_code = $").append(++idx).append(' ');
        }

        // reconStatus
        if (req.getReconStatus() != null) {
            params.add(req.getReconStatus());
            condEpk.append(" AND te.recon_status = $").append(++idx).append(' ');
        }

        // fromDate/toDate
        if (fromDate != null && !fromDate.isBlank()) {
            params.add(fromDate.trim());
            condEpk.append(" AND te.created_date >= to_timestamp($")
                    .append(++idx).append(", '").append(TS_FMT).append("') ");
        }
        if (toDate != null && !toDate.isBlank()) {
            params.add(toDate.trim());
            condEpk.append(" AND te.created_date <= to_timestamp($")
                    .append(++idx).append(", '").append(TS_FMT).append("') ");
        }

        // transactionType
        if (req.getTransactionType() != null) {
            params.add(req.getTransactionType());
            condEpk.append(" AND te.transaction_type = $").append(++idx).append(' ');
        }

        // ===== 2) Build SQL chính =====
        final String dataSql = """
        SELECT
           'TRANSACTION_EPACKET' AS status_text,
           te.transaction_code AS transaction_code,
           te.req_payment_code AS req_payment_code,
           te.cust_id          AS cus_id,
           NULL::varchar       AS cus_name,
           COALESCE(te.req_collect_amount, 0)::numeric AS amount,
           te.recon_status       AS recon_status,
           -1                  AS accounting_status,
           te.transaction_type AS transaction_type,
           to_char(te.created_date, 'YYYY-MM-DD HH24:MI:SS') AS create_date,
           to_char(te.updated_date, 'YYYY-MM-DD HH24:MI:SS') AS update_date
        FROM bms_payment.bms_transaction_epacket te
    """ + condEpk + " ORDER BY te.created_date DESC";

        Tuple dataTuple = Tuple.tuple();
        params.forEach(dataTuple::addValue);

        String finalFromDate = fromDate;
        String finalToDate = toDate;

        // ===== 3) Query Data =====
        return queryDataRowsExport(client, dataSql, dataTuple)
                .flatMap(items -> {
                    // Lấy danh sách cusId để fill thêm thông tin
                    Set<Long> cusIds = items.stream()
                            .map(EpacketExportListResponse.ITEMS::getCusId)
                            .filter(Objects::nonNull)
                            .collect(Collectors.toCollection(LinkedHashSet::new));

                    if (cusIds.isEmpty()) return Mono.just(items);

                    return Mono.fromFuture(getCusInfoMapFromOracle(cusIds).subscribeAsCompletionStage())
                            .onErrorReturn(Collections.emptyMap())
                            .map(cusInfoMap -> {
                                for (var it : items) {
                                    Long c = it.getCusId();
                                    if (c == null) continue;
                                    EpacketUserDTO user = cusInfoMap.get(c);
                                    if (user != null) {
                                        if (it.getCusName() == null || it.getCusName().isBlank())
                                            it.setCusName(user.getCusName());
                                        if (it.getEmail() == null || it.getEmail().isBlank())
                                            it.setEmail(user.getEmail());
                                        if (it.getPhone() == null || it.getPhone().isBlank())
                                            it.setPhone(user.getPhone());
                                    }
                                }
                                return items;
                            });
                })
                .map(items -> {
                    // ===== 4) Tính số dư đầu và cuối =====
                    long startingBalance = 100000L; // giả định tạm, có thể thay bằng query thực tế
                    long endingBalance = startingBalance;

                    for (var it : items) {
                        if (it.getAmount() == null || it.getTransactionType() == null) continue;

                        long amt = it.getAmount().longValue();
                        EpacketTransactionType type = Arrays.stream(EpacketTransactionType.values())
                                .filter(e -> e.getId() == it.getTransactionType())
                                .findFirst()
                                .orElse(EpacketTransactionType.NA);

                        switch (type) {
                            case DEPOSIT_MONEY, PLUS_MONEY_WALLET -> endingBalance += amt;
                            case WITHDRAW_MONEY, MINUS_MONEY_WALLET -> endingBalance -= amt;
                            default -> { /* không đổi */ }
                        }
                    }

                    // ===== 5) Build response =====
                    EpacketExportListResponse res = new EpacketExportListResponse();
                    res.setItems(items);
                    res.setCusId(req.getCusId());
                    res.setFromDate(finalFromDate);
                    res.setToDate(finalToDate);
                    res.setStartingBalance(startingBalance);
                    res.setEndingBalance(endingBalance);
                    log.info("epacket_exportToExcelEpacket_Success");

                    return res;
                })
                .onErrorResume(e -> {
                    log.error("epacket_exportToExcelEpacket_Error: {}", e.getMessage(), e);
                    EpacketExportListResponse fail = new EpacketExportListResponse();
                    fail.setItems(new ArrayList<>());
                    fail.setCusId(req.getCusId());
                    fail.setFromDate(finalFromDate);
                    fail.setToDate(finalToDate);
                    fail.setStartingBalance(0L);
                    fail.setEndingBalance(0L);
                    return Mono.just(fail);
                });
    }

    public Mono<EpacketInsertMissingResponse> insertMissingTransactionsBatch(List<EpacketTransactionEntity> transactions) {
        if (transactions == null || transactions.isEmpty()) {
            return Mono.just(new EpacketInsertMissingResponse(false, "Danh sách rỗng",0, 0, Collections.emptyList(), Collections.emptyList()));
        }

        // SQL: thêm 2 cột cuối recon_status, transaction_source
        final String insertSql =
                "insert into bms_payment.bms_transaction_epacket (" +
                        "  cust_id, created_date, is_checked, org_code, org_id, partner_internal_id, " +   // 1..6
                        "  post_code, post_id, req_acc_name, req_acc_no, req_collect_amount, req_expire_date, " + // 7..12
                        "  req_memo, req_operation, req_partner_code, req_partner_id, req_payment_code, req_payment_time, " + // 13..18
                        "  req_request_type, res_qr_path, res_qr_string, status, transaction_type, transaction_code, " + // 19..24
                        "  updated_by, updated_date, request_id, partner_internal_line_id, recon_status, transaction_source, req_partner_amount " + // 25..30
                        ") values (" +
                        "  $1,$2,$3,$4,$5,$6," +
                        "  $7,$8,$9,$10,$11,$12," +
                        "  $13,$14,$15,$16,$17,$18," +
                        "  $19,$20,$21,$22,$23,$24," +
                        "  $25,$26,$27,$28,$29,$30,$31" +
                        ") " +
                        "on conflict (transaction_code) do nothing " +
                        "returning transaction_code";

        // Dựng batch params
        List<Tuple> batch = new ArrayList<>(transactions.size());
        for (EpacketTransactionEntity t : transactions) {
            Tuple tp = Tuple.tuple()
                    .addValue(t.getCustId())                     // $1
                    .addValue(t.getCreatedDate())                // $2
                    .addValue(t.getIsChecked())                  // $3
                    .addValue(t.getOrgCode())                    // $4
                    .addValue(t.getOrgId())                      // $5
                    .addValue(t.getPartnerInternalId())          // $6
                    .addValue(t.getPostCode())                   // $7
                    .addValue(t.getPostId())                     // $8
                    .addValue(t.getReqAccName())                 // $9
                    .addValue(t.getReqAccNo())                   // $10
                    .addValue(t.getReqCollectAmount())           // $11
                    .addValue(t.getReqExpireDate())              // $12
                    .addValue(t.getReqMemo())                    // $13
                    .addValue(t.getReqOperation())               // $14
                    .addValue(t.getReqPartnerCode())             // $15
                    .addValue(t.getReqPartnerId())               // $16
                    .addValue(t.getReqPaymentCode())             // $17
                    .addValue(t.getReqPaymentTime())             // $18
                    .addValue(t.getReqRequestType())             // $19
                    .addValue(t.getResQrPath())                  // $20
                    .addValue(t.getResQrString())                // $21
                    .addValue(t.getStatus())                     // $22
                    .addValue(t.getTransactionType())            // $23
                    .addValue(t.getTransactionCode())            // $24
                    .addValue(t.getUpdatedBy())                  // $25
                    .addValue(t.getUpdatedDate())                // $26
                    .addValue(t.getRequestId())                  // $27
                    .addValue(t.getPartnerInternalLineId())      // $28
                    .addValue(t.getReconStatus() == null ? 3 : t.getReconStatus()) // $29
                    .addValue(t.getTransactionSource() == null ? 1 : t.getTransactionSource()) // $30
                    .addValue(t.getReqCollectAmount());         // $31


            batch.add(tp);
        }

        // Thực thi batch
        return client.preparedQuery(insertSql)
                .executeBatch(batch)
                .onItem().transform(rs -> {
                    // Thu thập các transaction_code được insert (DO NOTHING thì không trả về)
                    List<String> inserted = new ArrayList<>();
                    for (Row row : rs) {
                        inserted.add(row.getString("transaction_code"));
                    }
                    // Xác định các code bị skip (đã tồn tại)
                    Set<String> insertedSet = new HashSet<>(inserted);
                    List<String> requested = transactions.stream().map(EpacketTransactionEntity::getTransactionCode).toList();
                    List<String> skipped = requested.stream().filter(c -> !insertedSet.contains(c)).toList();

                    return new EpacketInsertMissingResponse(false,"insert thành công",requested.size(), inserted.size(), inserted, skipped);
                })
                .convert().with(UniReactorConverters.toMono());
    }

    // Query data từ Postgres và map theo style hiện tại
    private Mono<List<EpacketTransactionListResponse.ITEMS>> queryDataRows(
            PgPool client, String dataSql, Tuple dataTuple) {

        Uni<List<EpacketTransactionListResponse.ITEMS>> dataUni = client.preparedQuery(dataSql)
                .execute(dataTuple)
                .map(rows -> {
                    List<EpacketTransactionListResponse.ITEMS> list = new ArrayList<>();
                    for (Row row : rows) {
                        EpacketTransactionListResponse.ITEMS it = new EpacketTransactionListResponse.ITEMS();
                        it.setStatusText(row.getString("status_text"));
                        it.setTransactionCode(row.getString("transaction_code"));
                        it.setReqPaymentCode(row.getString("req_payment_code"));

                        Long cus = row.getLong("cus_id");
                        it.setCusId(cus);

                        // PG không có tên -> sẽ fill sau từ Oracle
                        it.setCusName(row.getString("cus_name"));

                        it.setAmount(row.getBigDecimal("amount"));

                        Integer recon = row.getInteger("recon_status");
                        if (recon == null) {
                            Long rcl = row.getLong("recon_status");
                            recon = (rcl != null ? rcl.intValue() : null);
                        }
                        it.setReconStatus(recon);
                        it.setAccountingStatus(-1);

                        Integer tt = row.getInteger("transaction_type");
                        if (tt == null) {
                            Long ttl = row.getLong("transaction_type");
                            it.setTransactionType(ttl != null ? ttl.intValue() : null);
                        } else {
                            it.setTransactionType(tt);
                        }

                        it.setCreateDate(row.getString("create_date"));
                        it.setUpdateDate(row.getString("update_date"));

                        list.add(it);
                    }
                    return list;
                });

        return Mono.fromFuture(dataUni.subscribeAsCompletionStage());
    }

    private Mono<List<EpacketExportListResponse.ITEMS>> queryDataRowsExport(
            PgPool client, String dataSql, Tuple dataTuple) {

        Uni<List<EpacketExportListResponse.ITEMS>> dataUni = client.preparedQuery(dataSql)
                .execute(dataTuple)
                .map(rows -> {
                    List<EpacketExportListResponse.ITEMS> list = new ArrayList<>();
                    for (Row row : rows) {
                        EpacketExportListResponse.ITEMS it = new EpacketExportListResponse.ITEMS();
                        it.setStatusText(row.getString("status_text"));
                        it.setTransactionCode(row.getString("transaction_code"));
                        it.setReqPaymentCode(row.getString("req_payment_code"));

                        Long cus = row.getLong("cus_id");
                        it.setCusId(cus);

                        // PG không có tên -> sẽ fill sau từ Oracle
                        it.setCusName(row.getString("cus_name"));

                        it.setAmount(row.getBigDecimal("amount"));

                        Integer recon = row.getInteger("recon_status");
                        if (recon == null) {
                            Long rcl = row.getLong("recon_status");
                            recon = (rcl != null ? rcl.intValue() : null);
                        }
                        it.setReconStatus(recon);
                        it.setAccountingStatus(-1);

                        Integer tt = row.getInteger("transaction_type");
                        if (tt == null) {
                            Long ttl = row.getLong("transaction_type");
                            it.setTransactionType(ttl != null ? ttl.intValue() : null);
                        } else {
                            it.setTransactionType(tt);
                        }

                        it.setCreateDate(row.getString("create_date"));
                        it.setUpdateDate(row.getString("update_date"));

                        list.add(it);
                    }
                    return list;
                });

        return Mono.fromFuture(dataUni.subscribeAsCompletionStage());
    }

    /** Oracle: lấy map tên KH cho nhiều cusId (IN (...)) — 1 roundtrip */
    /** Oracle: lấy thông tin KH cho nhiều cusId (IN (...)) — 1 roundtrip */
    private Uni<Map<Long, EpacketUserDTO>> getCusInfoMapFromOracle(Set<Long> cusIds) {
        if (cusIds == null || cusIds.isEmpty()) {
            return Uni.createFrom().item(Collections.emptyMap());
        }

        // Tạo named placeholders :id0, :id1, ... và map tham số
        List<String> placeholders = new ArrayList<>(cusIds.size());
        Map<String, Object> params = new HashMap<>();
        int i = 0;
        for (Long id : cusIds) {
            String key = "id" + (i++);
            placeholders.add(":" + key);
            params.put(key, id);
        }

        // Alias cột chính xác camelCase để map đúng DTO
        String sql = """
        SELECT 
            cc.CUS_ID AS "cusId",
            (cc.FIRSTNAME || ' ' || cc.LASTNAME) AS "cusName",
            cc.EMAIL AS "email",
            cc.PHONE AS "phone"
        FROM ERP_CUS.CUS_CUSTOMER cc
        WHERE cc.CUS_ID IN (""" + String.join(",", placeholders) + ")";

        // Truy vấn và convert sang map<Long, EpacketUserDTO>
        return executeMulti(oracleClient, sql, params, EpacketUserDTO.class)
                .collect().asList()
                .map(rows -> rows.stream()
                        .filter(Objects::nonNull)
                        .filter(r -> r.getCusId() != null)
                        .collect(Collectors.toMap(
                                EpacketUserDTO::getCusId,
                                dto -> dto,
                                (a, b) -> a,
                                LinkedHashMap::new
                        ))
                );
    }

    private static final List<DateTimeFormatter> SUPPORTED_FORMATS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy")
    );

    private static String normalizeDate(String input) {
        if (input == null || input.isBlank()) return null;

        for (DateTimeFormatter fmt : SUPPORTED_FORMATS) {
            try {
                if (input.contains(":")) {
                    LocalDateTime dt = LocalDateTime.parse(input, fmt);
                    return dt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                } else {
                    LocalDate d = LocalDate.parse(input, fmt);
                    return d.atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                }
            } catch (DateTimeParseException ignored) {}
        }

        throw new IllegalArgumentException("Sai định dạng ngày: " + input +
                " (Hỗ trợ: yyyy-MM-dd, dd/MM/yyyy, dd-MM-yyyy, có hoặc không có giờ)");
    }

}
