package com.viettelpost.platform.bms.portal.model.response.advance;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AdvanceAcctBusinessTypeResponse {

    private String businessType;

    private String businessTypeName;
}
