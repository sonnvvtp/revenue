package com.viettelpost.platform.bms.portal.model.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BusinessException extends RuntimeException{
    private int httpStatusCode;
    private String errorCode;
    private String message;
    private Object data;

    public BusinessException(int httpStatusCode, String errorCode, String message) {
        this.httpStatusCode = httpStatusCode;
        this.errorCode = errorCode;
        this.message = message;
    }

    public BusinessException(int httpStatusCode, String errorCode, String message, Object data) {
        this.httpStatusCode = httpStatusCode;
        this.errorCode = errorCode;
        this.message = message;
        this.data = data;
    }

    public BusinessException(int httpStatusCode, String errorCode, Object data) {
        this.httpStatusCode = httpStatusCode;
        this.errorCode = errorCode;
        this.data = data;
    }

    public BusinessException(String errorCode, String message) {
        this.httpStatusCode = 400;
        this.errorCode = errorCode;
        this.message = message;
    }

    public BusinessException(String errorCode, String message, Object data) {
        this.httpStatusCode = 400;
        this.errorCode = errorCode;
        this.message = message;
        this.data = data;
    }

    public BusinessException(String message) {
        this.httpStatusCode = 400;
        this.message = message;
    }
}