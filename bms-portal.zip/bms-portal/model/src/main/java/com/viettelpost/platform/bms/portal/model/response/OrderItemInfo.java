package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderItemInfo {
    private Long id;
    private String itemCode;
    private String itemName;
    private String warehouseCode;
    private Integer itemSelection;
    private String departureLocation;
    private String arrivalLocation;
    private String vehiclePlatenumber;
    private String itemUnit;
    private Integer itemQuantity;
    private Integer itemWeight;
    private BigDecimal itemPrice;
    private BigDecimal itemAmountBeforeTax;
    private BigDecimal itemTaxPercent;
    private Integer itemTaxType;
    private BigDecimal itemTaxAmount;
    private BigDecimal itemAmountAfterTax;
}
