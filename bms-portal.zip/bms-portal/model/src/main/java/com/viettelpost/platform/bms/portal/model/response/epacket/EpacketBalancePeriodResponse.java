package com.viettelpost.platform.bms.portal.model.response.epacket;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class EpacketBalancePeriodResponse {
    private boolean error;

    @JsonProperty("error_code")
    private String errorCode;

    /** trùng khớp số dư hay không */
    private Boolean isMatching;

    /** mã KH phía bạn truyền vào */
    private Integer cusId;

    private BigDecimal vtpBalance;  // Số dư bên VTP

    /** ======= THÔNG TIN ĐỐI TÁC TRẢ VỀ (đưa ra root cho tiện dùng) ======= */
    private Long orgId;           // từ partner.data.orgId
    private Long postId;          // từ partner.data.postId
    private String fullName;      // partner.data.fullName
    private String email;         // partner.data.email
    private String phoneNumber;   // partner.data.phoneNumber
    private BigDecimal partnerBalance;  // partner.data.balance

    /** danh sách giao dịch local đã tính */
    private List<ITEMS> items;

    @Data
    @Accessors(chain = true)
    public static class ITEMS {
        private String transactionType;   // DEPOSIT_MONEY | WITHDRAW_MONEY | ...
        private String transactionCode;
        private String createdDate;       // dd-MM-yyyy HH:mm:ss
        private BigDecimal amount;        // đã âm/dương đúng như DB
    }
}
