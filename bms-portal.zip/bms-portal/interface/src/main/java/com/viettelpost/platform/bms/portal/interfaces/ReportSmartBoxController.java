package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.UpReportRevenueSmbRequest;
import com.viettelpost.platform.bms.portal.service.handler.ReportSmartBoxService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.text.ParseException;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("smart-box")
@Tag(name = "SmartBox")
@RequiredArgsConstructor
public class ReportSmartBoxController {

    private final ReportSmartBoxService reportSmartBoxService;

    @Inject
    AuthenticationContext authCtx;


    @GET
    @Path("/report-revenue")
    @Operation(summary = "get list danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListReportRevenueSmartBox(@QueryParam(value = "bill") String bill,
                                                      @QueryParam(value = "fromDate") String fromDate,
                                                      @QueryParam(value = "toDate") String toDate,
                                                      @QueryParam(value = "type") Integer type,
                                                      @QueryParam(value = "page") int page,
                                                      @QueryParam(value = "size") int size) throws ParseException {
        return ReactiveConverter.toUni(reportSmartBoxService.getListReportRevenueSmb(bill,fromDate, toDate, type, page, size));
    }

    @GET
    @Path("/create-record")
    @Operation(summary = "tạo bảng kê smartbox")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListReportRevenueSmartBox(@QueryParam(value = "partnerEvtp") String partnerEvtp,
                                                      @QueryParam(value = "fromDate") String fromDate) {
        return ReactiveConverter.toUni(reportSmartBoxService.createRecordFeeSmartBox(partnerEvtp, fromDate));
    }


    @PUT
    @Path("/update-record")
    @Operation(summary = "update record smartbox")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListReportRevenueSmartBox(@RequestBody UpReportRevenueSmbRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return reportSmartBoxService.updateRecordBKPHISmb(request.getBill(), infoUser.getUserId());
    }

    @POST
    @Path("/create-revenue-smb")
    @Operation(summary = "create revenue smartbox")
    @APIResponse(responseCode = "200", description = "return đồng bộ bill doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getCreateRevenueSmb(@RequestBody UpReportRevenueSmbRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return ReactiveConverter.toUni(reportSmartBoxService.createBillRevenue(request.getBill(), infoUser.getUserId()));
    }

    @POST
    @Path("/delete-revenue-smb")
    @Operation(summary = "delete revenue smartbox")
    @APIResponse(responseCode = "200", description = "return đồng bộ bill doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> deleteRevenueSmartBox(@QueryParam(value = "id") Long id) {
        return reportSmartBoxService.deleteRevenueSmartBox(id);
    }

    @GET
    @Path("/create-record-sbqh")
    @Operation(summary = "tạo bảng kê smartbox sbgh")
    @APIResponse(responseCode = "200", description = "return danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListReportRevenueSmartBoxSBGH(@QueryParam(value = "partnerEvtp") String partnerEvtp,
                                                      @QueryParam(value = "fromDate") String fromDate) {
        return reportSmartBoxService.createBkCuocSmartBox(partnerEvtp, fromDate);
    }
}
