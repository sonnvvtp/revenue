package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.viettelpost.platform.bms.portal.model.enums.ScopeQrType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartnerExternalConfigResponse {

    @JsonAlias("partner_external_id")
    private Long configId;

    @JsonAlias("partner_external_code")
    private String configCode;

    @JsonAlias("partner_external_name")
    private String partnerName;

    private String description;

    @JsonAlias("is_active")
    private Integer isActive;

    @JsonAlias("partner_external_logo")
    private String partnerLogo;

    @JsonAlias("partner_external_type")
    private Integer partnerExType;

    @JsonAlias("active_all_area")
    private Integer activeAllArea;

    @JsonAlias("active_from")
    private LocalTime activeFrom;

    @JsonAlias("active_to")
    private LocalTime activeTo;

    private String updateBy;

    private String updatedAt;

    private ScopeQrType scopeQrType;

    public ScopeQrType getScopeQrType() {
        return ScopeQrType.get(activeAllArea);
    }
}
