package com.viettelpost.platform.bms.portal.common.config;

public interface AuthenticationContext {
    CustomUser getCurrentUser();

    String getToken();

}
