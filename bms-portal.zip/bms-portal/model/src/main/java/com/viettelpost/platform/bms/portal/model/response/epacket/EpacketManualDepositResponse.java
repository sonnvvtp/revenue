package com.viettelpost.platform.bms.portal.model.response.epacket;
import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)

public class EpacketManualDepositResponse {
    private BigDecimal amount;
    private String transactionCode;
    private String createdTime;
    private String transactionId;
    private String orgCode;
    private Long orgId;
    private String postCode;
    private Long postId;
}
