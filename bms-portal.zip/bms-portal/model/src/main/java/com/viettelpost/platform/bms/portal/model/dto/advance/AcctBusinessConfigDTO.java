package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

@Data
public class AcctBusinessConfigDTO {

    @JsonAlias("acct_business_config_id")
    private Long acctBusinessConfigId;

    @JsonAlias("business_id")
    private Long businessId;

    @JsonAlias("business_code")
    private String businessCode;

    @JsonAlias("description")
    private String description;

    @JsonAlias("is_active")
    private Boolean isActive;

}
