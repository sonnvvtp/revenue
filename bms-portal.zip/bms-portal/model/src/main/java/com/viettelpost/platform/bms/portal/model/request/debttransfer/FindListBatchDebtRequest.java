package com.viettelpost.platform.bms.portal.model.request.debttransfer;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class FindListBatchDebtRequest {

    @NotNull(message = "Vui lòng cung cấp ID loại bảng kê")
    private Long docTypeId;

    private String batchNo;

    @NotNull(message = "Vui lòng cung cấp ngày bắt đầu")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate fromDate;

    @NotNull(message = "Vui lòng cung cấp ngày kết thúc")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    private Integer page;

    private Integer size;

    private List<Long> orgId;
}
