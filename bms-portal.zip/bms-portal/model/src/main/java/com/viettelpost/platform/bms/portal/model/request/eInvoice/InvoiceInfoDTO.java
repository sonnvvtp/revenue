package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceInfoDTO {
  private BigDecimal generalOrderId;
  private String orderId;
  private Long buyerId;
  private String buyerType;
  private String buyerName;
  private String partnerName;
  private String buyerPhone;
  private String buyerEmail;
  private String buyerTaxCode;
  private String buyerAddress;
  private String buyerBankAccount;
  private String buyerBankName;
}

