package com.viettelpost.platform.bms.portal.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class CarLicensePlateAndCIDTO {

    private String licensePlate;
    private String ci;
}
