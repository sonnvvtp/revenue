package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class GroupRevenueRecordDTO {

    @JsonAlias("unit_level1_id")
    private Long unitLevel1Id;

    @JsonAlias("unit_level2_id")
    private Long unitLevel2Id;

    @JsonAlias("seller_id")
    private Long sellerId;

    @JsonAlias("buyer_code")
    private String buyerCode;

    @JsonAlias("service_code")
    private String serviceCode;

    @JsonAlias("service_category")
    private String serviceCategory;

    @JsonAlias("total_bill")
    private Integer totalBill;

    @JsonAlias("amount_before_tax")
    private BigDecimal amountBeforeTax;

    @JsonAlias("tax_amount")
    private BigDecimal taxAmount;

    @JsonAlias("discount_amount")
    private BigDecimal discountAmount;

    @JsonAlias("amount_after_tax")
    private BigDecimal amountAfterTax;

    @JsonAlias("total_amount")
    private BigDecimal totalAmount;

    @JsonAlias("record_source")
    private String recordSource;

    @JsonAlias("amount_discount_before_tax")
    private BigDecimal amountDiscountBeforeTax;

    @JsonAlias("amount_discount_tax")
    private BigDecimal amountDiscountTax;

    @JsonAlias("amount_discount_after_tax")
    private BigDecimal amountDiscountAfterTax;

    @JsonAlias("records")
    private JsonNode records;
}
