package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.request.AddOrderToInvoiceRequest;
import com.viettelpost.platform.bms.portal.model.request.RemoveOrderFromInvoiceRequest;
import com.viettelpost.platform.bms.portal.model.response.AddOrderToInvoiceResponse;
import com.viettelpost.platform.bms.portal.model.response.RemoveOrderFromInvoiceResponse;
import reactor.core.publisher.Mono;

public interface InvoiceRecordOrderRepository {

    Mono<AddOrderToInvoiceResponse> addOrderToInvoice(AddOrderToInvoiceRequest request);

    Mono<Boolean> isOrderExistsInInvoice(String orderId, Long recordId);

    Mono<RemoveOrderFromInvoiceResponse> removeOrderFromInvoice(RemoveOrderFromInvoiceRequest request);
} 