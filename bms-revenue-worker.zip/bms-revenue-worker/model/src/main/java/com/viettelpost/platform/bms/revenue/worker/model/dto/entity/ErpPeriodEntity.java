package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErpPeriodEntity {
    
    @JsonAlias("PERIOD_ID")
    private BigDecimal periodId;

    @JsonAlias("STARTDATE")
    private LocalDateTime startDate;

    @JsonAlias("ENDDATE")
    private LocalDateTime endDate;
}
