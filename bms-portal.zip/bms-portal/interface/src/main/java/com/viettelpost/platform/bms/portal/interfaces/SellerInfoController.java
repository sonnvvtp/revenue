package com.viettelpost.platform.bms.portal.interfaces;


import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.request.SellerAccountRequest;
import com.viettelpost.platform.bms.portal.model.request.SellerInfoRequest;
import com.viettelpost.platform.bms.portal.service.handler.SellerInfoService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/seller-info")
@Tag(name = "API quản lý thông tin người bán (xuất hóa đơn)")
@RequiredArgsConstructor
@Slf4j
public class SellerInfoController {

    private final SellerInfoService sellerInfoService;

    @POST
    @Path("")
    @Operation(summary = "Tạo cấu hình quản lý thông tin người bán")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createSellerInfo(@RequestBody SellerInfoRequest request) {
        return sellerInfoService.create(request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Path("")
    @Operation(summary = "Lấy cấu hình quản lý thông tin người bán")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getAll(@QueryParam("page") @DefaultValue("1") int page,
                                @QueryParam("size") @DefaultValue("10") int size) {
        return sellerInfoService.getAll(page, size)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @PUT
    @Path("/{id}")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> update(
            @PathParam("id") Long id,
            SellerInfoRequest request) {
        return sellerInfoService.update(id, request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @PUT
    @Path("/{id}/update-account")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateAccountInfo(
            @PathParam("id") Long sellerId,
            SellerAccountRequest request) {
        return sellerInfoService.updateAccountInfo(sellerId, request)
                .map(v -> BaseResponse.successApi(null, "OK"));
    }


}
