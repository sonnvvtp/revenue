package com.viettelpost.platform.bms.portal.repository.impl;


import com.viettelpost.platform.bms.portal.model.dto.CarLicensePlateAndCIDTO;
import com.viettelpost.platform.bms.portal.model.model.CarManagementSettingModel;
import com.viettelpost.platform.bms.portal.repository.CarRepository;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class CarRepositoryImpl implements CarRepository {

    @Inject
    protected PgPool client;

    @Override
    public Mono<List<CarManagementSettingModel>> getAllByCarType(List<String> carTypes) {
        StringBuilder queryBuilder = new StringBuilder(
                "select id,  unit, car_license_plate, recover_id, fuel_consumption_rate, car_label, type, "
                        + "fuel_consumption_unit, type_id, org_type, type_group_id "
                        + "from bms_payment.car_management_setting where type_id in (");
        for (int i = 0; i < carTypes.size(); i++) {
            queryBuilder.append("$").append(i + 1);  // PostgreSQL uses 1-based index for parameters
            if (i < carTypes.size() - 1) {
                queryBuilder.append(", ");
            }
        }
        queryBuilder.append(")");
        String query = queryBuilder.toString();
        Tuple params = Tuple.tuple();
        carTypes.forEach(params::addString);
        return ReactiveConverter.toFlux(client.preparedQuery(query)
                        .mapping(DataMapping.map(CarManagementSettingModel.class))
                        .execute(params)
                        .toMulti()
                        .flatMap(rows -> Multi.createFrom().iterable(rows)))
                .collectList();


    }

    @Override
    public Uni<List<CarManagementSettingModel>> findAll() {

        String query = """
                        SELECT id, unit, car_license_plate,
                               recover_id, fuel_consumption_rate, car_label, type, fuel_consumption_unit, type_id,
                               is_active, update_date, org_type, type_group_id, car_license_plate_key
                        FROM bms_payment.car_management_setting
                        """;
        return client.preparedQuery(query)
                .execute()
                .onItem().transform(rowSet -> {
                    List<CarManagementSettingModel> carManagementSettings = new ArrayList<>();
                    rowSet.forEach(row -> {
                        CarManagementSettingModel dto = mapRowToCarManagementSettingModel(row);
                        carManagementSettings.add(dto);
                    });
                    return carManagementSettings;
                });
    }

    @Override
    public Mono<List<CarManagementSettingModel>> findByLicensePlates(
            List<String> licensePlates) {
        if (licensePlates == null || licensePlates.isEmpty()) {
            log.debug("License plates list is null or empty.");
            return Mono.just(new ArrayList<>());
        }
        List<String> trimmedLicensePlates = licensePlates.stream()
                .map(String::trim)
                .collect(Collectors.toList());

        String query = """
                        SELECT id, unit, car_license_plate,
                               recover_id, fuel_consumption_rate, car_label, type, fuel_consumption_unit, type_id,
                               is_active, update_date, org_type, type_group_id, car_license_plate_key
                        FROM bms_payment.car_management_setting WHERE TRIM(car_license_plate) = ANY($1)
                        """;

        log.debug("Executing query: {} with params: {}", query, trimmedLicensePlates);
        String[] platesArray = trimmedLicensePlates.toArray(new String[0]);

        return client.preparedQuery(query)
                .execute(Tuple.of(platesArray))
                .convert()
                .with(UniReactorConverters.toMono())
                .map(resultSet -> {
                    List<CarManagementSettingModel> carManagementSettings = new ArrayList<>();
                    resultSet.forEach(row -> {
                        CarManagementSettingModel dto = mapRowToCarManagementSettingModel(row);
                        carManagementSettings.add(dto);
                    });
                    return carManagementSettings;
                })
                .doOnSuccess(dtoList -> log.info(
                        "[DB] Successfully retrieved {} car management records.", dtoList.size()))
                .doOnError(ex -> log.error(
                        "[DB] Error retrieving car management information for LICENSE PLATES: {}",
                        licensePlates, ex));
    }

    @Override
    public Mono<List<CarLicensePlateAndCIDTO>> findLicensePlatesWithCI(List<String> licensePlates) {
        if (licensePlates == null || licensePlates.isEmpty()) {
            log.debug("License plates list is null or empty.");
            return Mono.just(Collections.emptyList());
        }

        String query = "SELECT c.car_license_plate, v.ci " +
                "FROM bms_payment.car_management_setting c " +
                "JOIN bms_payment.vehicle_type_group_kmcp_config v " +
                "ON c.org_type = v.org_type " +
                "WHERE c.car_license_plate = ANY($1) and c.type_group_id =v.vehicle_type_group_id group by ( c.car_license_plate, v.ci)";

        log.debug("Executing query: {} with params: {}", query, licensePlates);

        String[] platesArray = licensePlates.toArray(new String[0]);

        return client.preparedQuery(query)
                .execute(Tuple.of((Object) platesArray))
                .onItem()
                .transform(rowSet -> {
                    log.debug("Mapped rowSet to results.");
                    List<CarLicensePlateAndCIDTO> result = new ArrayList<>();
                    rowSet.forEach(row -> {
                        CarLicensePlateAndCIDTO dto = new CarLicensePlateAndCIDTO();
                        dto.setLicensePlate(row.getString("car_license_plate"));
                        dto.setCi(row.getString("ci"));
                        log.debug("Mapped row to DTO: {}", dto);
                        result.add(dto);
                    });
                    return result;
                })
                .convert()
                .with(UniReactorConverters.toMono())
                .doOnError(error -> log.error("Error executing query", error));
    }

    public Uni<Boolean> upsertCar(CarManagementSettingModel car) {
        String query =
                """
                        INSERT INTO bms_payment.car_management_setting (unit, car_license_plate, recover_id,
                                                            fuel_consumption_rate, car_label, type, fuel_consumption_unit,
                                                            type_id, is_active, org_type, type_group_id,
                                                            car_license_plate_key)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                        ON CONFLICT (car_license_plate_key) DO UPDATE SET unit                  = EXCLUDED.unit,
                                                                          recover_id            = EXCLUDED.recover_id,
                                                                          fuel_consumption_rate = EXCLUDED.fuel_consumption_rate,
                                                                          car_label             = EXCLUDED.car_label,
                                                                          type                  = EXCLUDED.type,
                                                                          fuel_consumption_unit = EXCLUDED.fuel_consumption_unit,
                                                                          type_id               = EXCLUDED.type_id,
                                                                          is_active             = EXCLUDED.is_active,
                                                                          org_type              = EXCLUDED.org_type,
                                                                          type_group_id         = EXCLUDED.type_group_id,
                                                                          car_license_plate_key = EXCLUDED.car_license_plate_key
                        """;
        Tuple params = Tuple.tuple()
                .addString(car.getUnit())
                .addString(car.getCarLicensePlate())
                .addString(car.getRecoverId())
                .addDouble(car.getFuelConsumptionRate())
                .addString(car.getCarLabel())
                .addString(car.getType())
                .addDouble(car.getFuelConsumptionUnit())
                .addString(car.getTypeId())
                .addBoolean(car.getActive())
                .addInteger(car.getOrgType())
                .addLong(car.getTypeGroupId())
                .addString(car.getCarLicensePlateKey());

        return client.preparedQuery(query)
                .execute(params)
                .onItem().transform(rowSet -> {
                    int updatedRows = rowSet.rowCount();
                    if (updatedRows == 0) {
                        log.info("Không có bản ghi nào bị thay đổi.");
                    } else {
                        log.info("Đã cập nhật {} bản ghi.", updatedRows);
                    }
                    return true;
                });
    }


    private CarManagementSettingModel mapRowToCarManagementSettingModel(Row row) {
        CarManagementSettingModel model = new CarManagementSettingModel();
        model.setId(row.getLong("id"));                                  // ID (Bigserial)
        model.setUnit(row.getString("unit"));                            // Unit
        model.setCarLicensePlate(row.getString("car_license_plate"));    // Car License Plate
        model.setRecoverId(row.getString("recover_id"));                 // Recover ID
        model.setFuelConsumptionRate(
                row.getDouble("fuel_consumption_rate")); // Fuel Consumption Rate
        model.setCarLabel(row.getString("car_label"));                   // Car Label
        model.setType(row.getString("type"));                            // Type
        model.setFuelConsumptionUnit(
                row.getDouble("fuel_consumption_unit")); // Fuel Consumption Unit
        model.setTypeId(row.getString("type_id"));                       // Type ID
        model.setOrgType(row.getInteger("org_type"));
        model.setCarLicensePlateKey(row.getString("car_license_plate_key"));
        model.setActive(row.getBoolean("is_active"));
        model.setUpdateDate(row.getLocalDateTime("update_date"));
        model.setTypeGroupId(row.getLong("type_group_id"));
        return model;
    }
}
