package com.viettelpost.platform.bms.portal.model.request.forControl;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetDataComparisonInternalForm {
    // advance search

    String merchantType; // merchant
    String serviceType; // nguồn dữ liệu
    String partnerSource; // list partner source
    Long reqRequestType; // Loại dịch thêm


    String partnerId;

    String fromDate;

    String toDate;

    String postCode;

    String orgCode;

    Integer page;

    Integer size;

    String sort;

    String reqVtpOrderId;

    String itemCode;

    String documentno;

    Long checkedStatus;

    List<Long> docTypeIds;
}
