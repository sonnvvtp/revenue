package com.viettelpost.platform.bms.revenue.worker.service;

import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueAccountingType;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RevenueStatementSapDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.accounting.AcctBusinessConfigDTO;
import io.smallrye.mutiny.Uni;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface PushingRevenueSapService {
    Uni<Void> handlePushRawData(List<RevenueStatementSapDTO> rawDTOList, RevenueType revenueType, AcctBusinessConfigDTO acctBusinessConfigDTO, Map<String, String> serviceMap, Map<String, Integer> dichVuMap, LocalDate endOfMonth);
}
