package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceOrdersResponse {
    private Long recordId; // ID của hóa đơn
    private List<InvoiceOrderDetail> orders;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceOrderDetail {
        private String orderCode; // Mã đơn hàng
        private String orderReference; // Mã tham chiếu
        private String serviceCode; // Mã dịch vụ
        private String orderCreatedDate; // Ngày tạo đơn
        private String orderDeliveredDate; // Ngày giao hàng
        private String sellerCode; // Mã người bán
        private String buyerCode; // Mã người mua
        private Integer quantity; // Số lượng
        private Double amountBeforeTax; // Tiền trước thuế
        private Double taxAmount; // Tiền thuế
        private Double amountAfterTax; // Tiền sau thuế
        private Double totalAmount; // Tổng tiền
    }
} 