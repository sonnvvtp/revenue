package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EpacketUserDTO {
    private Long cusId;
    private String cusName;
    private String email;
    private String phone;
}


