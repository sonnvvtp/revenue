package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class chuẩn hóa response API
 * @param <T> kiểu dữ liệu trả về
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseApiResponse<T> {
    private boolean error;
    private String message;
    private T data;

    /**
     * Tạo response thành công
     * @param message thông báo
     * @param data dữ liệu
     * @return BaseApiResponse
     */
    public static <T> BaseApiResponse<T> success(String message, T data) {
        return new BaseApiResponse<>(false, message, data);
    }

    /**
     * Tạo response lỗi
     * @param message thông báo lỗi
     * @return BaseApiResponse
     */
    public static <T> BaseApiResponse<T> error(String message) {
        return new BaseApiResponse<>(true, message, null);
    }
} 