package com.viettelpost.platform.bms.portal.repository;


import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.dto.InvoiceSymbolDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface InvoiceConfigRepository {
    Flux<InvoiceSymbolDTO> listAll();

    Mono<InvoiceSymbolDTO> insert(CustomUser user, InvoiceSymbolDTO dto);

    Mono<InvoiceSymbolDTO> update(CustomUser user, InvoiceSymbolDTO dto);
}
