package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BmsBillRevenueEntity {
    
    @JsonAlias("BILL_REVENUE_ID")
    private Long billRevenueId;

    @JsonAlias("CREATED")
    private LocalDateTime created;

    @JsonAlias("CREATEDBY")
    private Long createdBy;

    @JsonAlias("UPDATED")
    private LocalDateTime updated;

    @JsonAlias("UPDATEDBY")
    private Long updatedBy;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("PAY_IN_ID")
    private Long payInId;

    @JsonAlias("BILL")
    private String bill;

    @JsonAlias("TYPE")
    private Integer type;

    @JsonAlias("BILL_ID")
    private Long billId;

    @JsonAlias("BILL_STATUS")
    private Long billStatus;

    @JsonAlias("DATEBILL")
    private LocalDateTime dateBill;
    
    @JsonAlias("DATEINSERT")
    private LocalDateTime dateInsert;

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("M_PRODUCT")
    private String mProduct;

    @JsonAlias("CITY_FROM")
    private String cityFrom;

    @JsonAlias("CITY_TO")
    private String cityTo;

    @JsonAlias("PAYMENTTEAM_ID")
    private Integer paymentTeamId;

    @JsonAlias("IS_PAID")
    private Integer isPaid;

    @JsonAlias("WEIGHT")
    private Integer weight;

    @JsonAlias("AMT")
    private BigDecimal amt = BigDecimal.ZERO;

    @JsonAlias("AMT_DEDUCT")
    private BigDecimal amtDeduct = BigDecimal.ZERO;

    @JsonAlias("AMT_DEDUCT_OTHER")
    private BigDecimal amtDeductOther = BigDecimal.ZERO;

    @JsonAlias("FEE")
    private BigDecimal fee = BigDecimal.ZERO;

    @JsonAlias("FREIGHT")
    private BigDecimal freight = BigDecimal.ZERO;

    @JsonAlias("FEE_OTHER")
    private BigDecimal feeOther = BigDecimal.ZERO;

    @JsonAlias("AMT_VAT")
    private BigDecimal amtVat = BigDecimal.ZERO;

    @JsonAlias("AMT_PAY")
    private BigDecimal amtPay = BigDecimal.ZERO;

    @JsonAlias("IS_INVOICE")
    private Integer isInvoice = 0;

    @JsonAlias("BILL_REVENUE_TYPE")
    private Integer billRevenueType;

    @JsonAlias("REVENUE_SOURCE")
    private String revenueSource;

    @JsonAlias("IS_SYNC")
    private Integer isSync;

    @JsonAlias("PERIOD_ID")
    private BigDecimal periodId;

    @JsonAlias("VAT")
    private Integer vat;

    @JsonAlias("COMPANY_CODE")
    private String companyCode;
}
