package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

@Getter
@AllArgsConstructor
public enum AccountingDoctype {
    V2("V2", "Chuyển nợ tiền đặt cọc", 21),
    TT02("TT02", "Chuyển nợ COD", 21),
    TT03("TT03", "Chuyển nợ cước", 21),
    V3("V3", "Chuyển nợ phí thuê sàn", 21),
    NH09("NH09", "Cấn trừ cước", 21),
    V4("V4", "Cấn trừ phí thuê sàn", 21),
    V5("V5", "Cấn trừ thuế nhà thầu", 21),
    NH08("NH08", "Chuyển khoản thanh toán tiền cọc cho nhà bán", 21);

    private final String code;
    private final String description;
    private final int id;

    public static AccountingDoctype fromCode(String code) {
        for (AccountingDoctype status : AccountingDoctype.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("AccountingDoctype Invalid status code: " + code);
    }
}
