package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.dto.InvoiceMailConfigDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

public interface InvoiceMailConfigRepository {
    Flux<InvoiceMailConfigDTO> listAll();

    Mono<InvoiceMailConfigDTO> insert(CustomUser user, InvoiceMailConfigDTO dto);

    Mono<InvoiceMailConfigDTO> update(CustomUser user, InvoiceMailConfigDTO dto);
    
    Mono<InvoiceMailConfigDTO> updateStartDate(CustomUser user, String companyCode, LocalDateTime startDate);
} 