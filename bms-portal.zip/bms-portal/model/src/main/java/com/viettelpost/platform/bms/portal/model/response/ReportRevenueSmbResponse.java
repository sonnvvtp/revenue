package com.viettelpost.platform.bms.portal.model.response;

import com.viettelpost.platform.bms.portal.model.dto.ReportRevenueSmbDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReportRevenueSmbResponse {
    private Long total;
    private List<ReportRevenueSmbDTO> details;


}
