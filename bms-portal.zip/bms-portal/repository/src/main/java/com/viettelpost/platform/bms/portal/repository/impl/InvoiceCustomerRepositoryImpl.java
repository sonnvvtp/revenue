package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.response.InvoiceCustomerDetailResponse;
import com.viettelpost.platform.bms.portal.model.response.InvoiceCustomerResponse;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import com.viettelpost.platform.bms.portal.repository.InvoiceCustomerRepository;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
@RequiredArgsConstructor
public class InvoiceCustomerRepositoryImpl implements InvoiceCustomerRepository {

    @Inject
    PgPool client;


    @Override
    public Uni<PageResponse<InvoiceCustomerResponse>> getAll(
            String customerCode,
            String customerPhone,
            String customerTax,
            int page,
            int size
    ) {
        int safePage = Math.max(page, 1);
        int offset = (safePage - 1) * size;

        StringBuilder baseSql = new StringBuilder(
                "select ic.id, ic.customer_code, ic.customer_name, ic.customer_phone, ic.customer_email, ic.customer_address, ic.customer_tax,\n" +
                "ic.budget_unit_code, ic.unit_level2_code, ic.unit_level2_id, ic.e_contract_code, ic.e_contract_signed_date, ic.partner_source \n" +
                "from bms_payment.invoice_customer ic WHERE 1=1 ");

        StringBuilder countSql = new StringBuilder("select count(*) from bms_payment.invoice_customer ic WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (customerCode != null && !customerCode.isBlank()) {
            baseSql.append(" AND customer_code = $").append(params.size() + 1);
            countSql.append(" AND customer_code = $").append(params.size() + 1);
            params.add(customerCode);
        }

        if (customerPhone != null && !customerPhone.isBlank()) {
            baseSql.append(" AND customer_phone = $").append(params.size() + 1);
            countSql.append(" AND customer_phone = $").append(params.size() + 1);
            params.add(customerPhone);
        }

        if (customerTax != null && !customerTax.isBlank()) {
            baseSql.append(" AND customer_tax = $").append(params.size() + 1);
            countSql.append(" AND customer_tax = $").append(params.size() + 1);
            params.add(customerTax);
        }

        String dataSql = baseSql + " ORDER BY ic.id DESC OFFSET $" + (params.size() + 1) + " LIMIT $" + (params.size() + 2);
        params.add(offset);
        params.add(size);

        Uni<Long> countUni = client.preparedQuery(countSql.toString())
                .execute(Tuple.from(params.subList(0, params.size() - 2)))
                .onItem().transform(rowSet -> rowSet.iterator().next().getLong(0));

        Uni<List<InvoiceCustomerResponse>> dataUni = client.preparedQuery(dataSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<InvoiceCustomerResponse> list = new ArrayList<>();
                    for (Row row : rows) {
                        InvoiceCustomerResponse dto = new InvoiceCustomerResponse();
                        dto.setId(row.getLong("id"));
                        dto.setCustomerCode(row.getString("customer_code"));
                        dto.setCustomerName(row.getString("customer_name"));
                        dto.setCustomerPhone(row.getString("customer_phone"));
                        dto.setCustomerEmail(row.getString("customer_email"));
                        dto.setCustomerAddress(row.getString("customer_address"));
                        dto.setCustomerTax(row.getString("customer_tax"));
                        dto.setBudgetUnitCode(row.getString("budget_unit_code"));
                        dto.setUnitLevel2Code(row.getString("unit_level2_code"));
                        dto.setUnitLevel2Id(row.getString("unit_level2_id"));
                        dto.setEContractCode(row.getString("e_contract_code"));
                        dto.setEContractSignedDate(row.getLocalDate("e_contract_signed_date"));
                        dto.setPartnerSource(row.getString("partner_source"));
                        list.add(dto);
                    }
                    return list;
                });

        return Uni.combine().all().unis(dataUni, countUni)
                .asTuple()
                .onItem().transform(result -> new PageResponse<>(result.getItem1(), result.getItem2()));
    }


    @Override
    public Uni<InvoiceCustomerDetailResponse> getInvoiceCustomerDetailById(Long invoiceCustomerId) {
        String customerSql = """
        SELECT invoice_detail_by_bill, budget_unit_code
        FROM bms_payment.invoice_customer
        WHERE id = $1
    """;

        String itemSql = """
        SELECT customer_item_name, customer_item_phone, customer_item_address, customer_item_tax, customer_item_email,
               customer_item_type, invoice_condition_lv1, invoice_condition_lv2, from_date, to_date, auto_merge_bill
        FROM bms_payment.invoice_item_info
        WHERE invoice_customer_id = $1
    """;

        Uni<InvoiceCustomerDetailResponse> headerUni = client.preparedQuery(customerSql)
                .execute(Tuple.of(invoiceCustomerId))
                .onItem().transform(rows -> {
                    if (!rows.iterator().hasNext()) {
                        throw new NotFoundException("Không tìm thấy khách hàng với ID: " + invoiceCustomerId);
                    }
                    Row row = rows.iterator().next();
                    InvoiceCustomerDetailResponse dto = new InvoiceCustomerDetailResponse();
                    dto.setInvoiceDetailByBill(row.getBoolean("invoice_detail_by_bill"));
                    dto.setBudgetUnitCode(row.getString("budget_unit_code"));
                    return dto;
                });

        Uni<List<InvoiceCustomerDetailResponse.InvoiceItemInfoDTO>> itemsUni = client.preparedQuery(itemSql)
                .execute(Tuple.of(invoiceCustomerId))
                .onItem().transform(rows -> {
                    List<InvoiceCustomerDetailResponse.InvoiceItemInfoDTO> items = new ArrayList<>();
                    for (Row row : rows) {
                        InvoiceCustomerDetailResponse.InvoiceItemInfoDTO item = new InvoiceCustomerDetailResponse.InvoiceItemInfoDTO();
                        item.setCustomerItemName(row.getString("customer_item_name"));
                        item.setCustomerItemPhone(row.getString("customer_item_phone"));
                        item.setCustomerItemAddress(row.getString("customer_item_address"));
                        item.setCustomerItemTax(row.getString("customer_item_tax"));
                        item.setCustomerItemEmail(row.getString("customer_item_email"));
                        item.setCustomerItemType(row.getInteger("customer_item_type"));
                        item.setInvoiceConditionLv1(row.getString("invoice_condition_lv1"));
                        item.setInvoiceConditionLv2(row.getString("invoice_condition_lv2"));
                        item.setFromDate(row.getInteger("from_date"));
                        item.setToDate(row.getInteger("to_date"));
                        item.setAutoMergeBill(row.getBoolean("auto_merge_bill"));
                        items.add(item);
                    }
                    return items;
                });

        return Uni.combine().all().unis(headerUni, itemsUni)
                .asTuple()
                .onItem().transform(tuple -> {
                    InvoiceCustomerDetailResponse response = tuple.getItem1();
                    response.setItems(tuple.getItem2());
                    return response;
                });
    }

}
