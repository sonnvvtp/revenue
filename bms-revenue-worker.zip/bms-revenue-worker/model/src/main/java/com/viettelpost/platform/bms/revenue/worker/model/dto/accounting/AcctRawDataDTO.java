package com.viettelpost.platform.bms.revenue.worker.model.dto.accounting;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AcctRawDataDTO {

    @JsonAlias("ref_number")
    private String refNumber;

    @JsonAlias("ref_number_parent")
    private String refNumberParent;
}
