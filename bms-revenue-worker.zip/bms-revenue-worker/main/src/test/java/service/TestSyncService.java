package service;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.revenue.worker.service.CalculationRevenueService;
import com.viettelpost.platform.bms.revenue.worker.service.GloExpRevenueService;
import com.viettelpost.platform.bms.revenue.worker.service.RevenueVTPService;
import com.viettelpost.platform.bms.revenue.worker.service.VTPInvoiceService;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

@QuarkusTest
@Slf4j
public class TestSyncService implements BaseRepository {

    @Inject
    CalculationRevenueService calculationRevenueService;

    @Inject
    RevenueVTPService revenueVTPService;

    @Inject
    GloExpRevenueService gloExpRevenueService;

    @Inject
    VTPInvoiceService vtpInvoiceService;

    @Test
    public void testSynFailure() {
    }

    @Test
    public void testSynSuccess() {

      calculationRevenueService.calculationAllBillToRevenue()
          .onFailure().invoke(throwable -> {
            log.error("Error calculating revenue: {}", throwable.getMessage(), throwable);
            throw new AssertionError("Calculation failed: " + throwable.getMessage(), throwable);
          })
          .await().indefinitely();

      // Day bill
//                revenueVTPService.processRevenueEveryMonth()
//          .onFailure().invoke(throwable -> {
//            log.error("Error calculating revenue: {}", throwable.getMessage(), throwable);
//            throw new AssertionError("Calculation failed: " + throwable.getMessage(), throwable);
//          })
//          .await().indefinitely(); // Ensure completion without errors

      // Day sap

                                           gloExpRevenueService.pusRevenueToAccountingSap()
//                  .flatMap(unused ->  gloExpRevenueService.accountingCompletedRevenueNoEnding())
//                  .flatMap(unused ->  gloExpRevenueService.accountingCompletedRevenueWithEnding())
          .onFailure().invoke(throwable -> {
            log.error("Error calculating revenue: {}", throwable.getMessage(), throwable);
            throw new AssertionError("Calculation failed: " + throwable.getMessage(), throwable);
          })
          .await().indefinitely();

//          vtpInvoiceService.processInvoiceRecordEveryMonth()
//          .onFailure().invoke(throwable -> {
//            log.error("Error calculating revenue: {}", throwable.getMessage(), throwable);
//            throw new AssertionError("Calculation failed: " + throwable.getMessage(), throwable);
//          })
//          .await().indefinitely(); // Ensure completion without errors

        // push hach toan sap

    }
}
