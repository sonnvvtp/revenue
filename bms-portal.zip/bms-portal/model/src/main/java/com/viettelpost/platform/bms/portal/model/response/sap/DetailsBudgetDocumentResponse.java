package com.viettelpost.platform.bms.portal.model.response.sap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class DetailsBudgetDocumentResponse {

    @JsonProperty("DETAILS")
    private List<Detail> DETAILS;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Detail {

        @JsonProperty("EXTERNAL_NUMBER")
        private String EXTERNAL_NUMBER;
        @JsonProperty("EV_ERROR")
        private int EV_ERROR;
        @JsonProperty("DOC_NUMBER")
        private Long DOC_NUMBER;
        @JsonProperty("MESSAGE_DETAIL")
        private List<MessageDetail> MESSAGE_DETAIL;

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MessageDetail {

        @JsonProperty("MESSAGE")
        private String MESSAGE;
    }
}