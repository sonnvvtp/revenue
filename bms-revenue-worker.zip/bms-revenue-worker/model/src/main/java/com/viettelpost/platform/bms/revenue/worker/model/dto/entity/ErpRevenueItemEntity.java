package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErpRevenueItemEntity {
    @JsonAlias("id")
    private Long id;

    @JsonAlias("tenant_id")
    private Integer tenantId;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @JsonAlias("updated_by")
    private Long updatedBy;

    @JsonAlias("updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    @JsonAlias("unit_level1_id")
    private Long unitLevel1Id;

    @JsonAlias("unit_level2_id")
    private Long unitLevel2Id;

    @JsonAlias("unit_info")
    private UnitInfo unitInfo;

    @JsonAlias("order_id")
    private Long orderId;

    @JsonAlias("order_code")
    private String orderCode;

    @JsonAlias("order_type")
    private Integer orderType;

    @JsonAlias("order_status")
    private Integer orderStatus;

    @JsonAlias("order_created_at")
    private LocalDateTime orderCreatedAt;

    @JsonAlias("order_delivered_at")
    private LocalDateTime orderDeliveredAt;

    @JsonAlias("customer_id")
    private Long customerId;

    @JsonAlias("customer_code")
    private String customerCode;

    @JsonAlias("service_code")
    private String serviceCode;

    @JsonAlias("unit_level1_from")
    private String unitLevel1From;

    @JsonAlias("unit_level1_to")
    private String unitLevel1To;

    @JsonAlias("payment_method")
    private Integer paymentMethod;

    @JsonAlias("payment_term_id")
    private Integer paymentTermId;

    @JsonAlias("payment_status")
    private Integer paymentStatus;

    @JsonAlias("weight")
    private Long weight;

    @JsonAlias("amount")
    private BigDecimal amount = BigDecimal.ZERO;

    @JsonAlias("amount_deduct")
    private BigDecimal amountDeduct = BigDecimal.ZERO;

    @JsonAlias("amount_vat")
    private BigDecimal amountVat = BigDecimal.ZERO;

    @JsonAlias("amount_deduct_other")
    private BigDecimal amountDeductOther = BigDecimal.ZERO;

    @JsonAlias("amount_fee")
    private BigDecimal amountFee = BigDecimal.ZERO;

    @JsonAlias("amount_fee_other")
    private BigDecimal amountFeeOther = BigDecimal.ZERO;

    @JsonAlias("amount_freight")
    private BigDecimal amountFreight = BigDecimal.ZERO;

    @JsonAlias("amount_pay")
    private BigDecimal amountPay = BigDecimal.ZERO;

    @JsonAlias("invoice_status")
    private Integer invoiceStatus;

    @JsonAlias("revenue_source")
    private String revenueSource;

    public static class UnitInfo {
        private UnitLevel unit_level1;
        private UnitLevel unit_level2;
    }

    public static class UnitLevel {
        private Long id;
        private String code;
        private String name;
    }
}
