package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EpacketTransactionLineEntity {

    @JsonAlias("req_transaction_line_id")
    private Long reqTransactionLineId;

    @JsonAlias("amount")
    private BigDecimal amount;

    @JsonAlias("item_code")
    private String itemCode;

    @JsonAlias("req_transaction_id")
    private Long reqTransactionId;

    @JsonAlias("transaction_code")
    private String transactionCode;

    @JsonAlias("transaction_type")
    private Long transactionType;

    @JsonAlias("partner_evtp")
    private String partnerEvtp;

    @JsonAlias("vendor_code")
    private String vendorCode;

    @JsonAlias("is_checked")
    private Integer isChecked;

    @JsonAlias("date_bill_record")
    private LocalDateTime dateBillRecord;
}
