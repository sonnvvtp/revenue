package com.viettelpost.platform.bms.portal.interfaces.einvoice;

import com.viettelpost.platform.bms.portal.model.request.eInvoice.CreateInvoiceCustomerRequest;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceUserService;
import io.smallrye.mutiny.Uni;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice-user")
@Tag(name = "API thông tin khách hàng")
@RequiredArgsConstructor
public class InvoiceUserController {

    private final InvoiceUserService invoiceUserService;

    @POST
    @Path("/create")
    @Operation(summary = "API đồng bộ thông tin khách hàng")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createInvoiceUser(@HeaderParam("client-id") String clientId, @HeaderParam("secret-key") String secretKey,
                                            @Valid CreateInvoiceCustomerRequest clientRequest) {
        return invoiceUserService.createInvoiceUser(clientId, secretKey, clientRequest);
    }
}
