package com.viettelpost.platform.bms.portal.model.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartnerConfigInExDto {



    @JsonAlias("partner_internal_line_id")
    private Long partnerInternalLineId;

    @JsonAlias("partner_source")
    private String partnerSource;


    @JsonAlias("merchant_type")
    private String merchantType;

    @JsonAlias("active")
    private Long active;

    @JsonAlias("prefix")
    private String prefixCode;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("updated_by")
    private Long  updatedBy;

    @JsonAlias("updated_date")
    private String updatedDate;

    @JsonAlias("service_type")
    private String serviceType;

    @JsonAlias("partner_external_code")
    private String partnerExternalCode;

}
