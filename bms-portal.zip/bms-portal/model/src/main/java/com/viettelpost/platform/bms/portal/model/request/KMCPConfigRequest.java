package com.viettelpost.platform.bms.portal.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KMCPConfigRequest {
    private Long id;
    private Long vehicleTypeGroupId;
    private Integer orgType;
    private String kmcpId;
    private String commitmentItem;
}
