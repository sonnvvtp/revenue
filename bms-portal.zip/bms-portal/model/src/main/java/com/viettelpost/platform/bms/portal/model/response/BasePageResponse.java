package com.viettelpost.platform.bms.portal.model.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BasePageResponse {
    private Long totalRow;
    private Integer pageCount;
    private Integer page;
    private Integer pageSize;
    private Object data;
}
