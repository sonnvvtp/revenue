package com.viettelpost.platform.bms.portal.interfaces.otherFunction;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.entity.CategoryMappingEntity;
import com.viettelpost.platform.bms.portal.service.handler.FunctionService;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/function")
@Tag(name = "miscellaneous api")
@RequiredArgsConstructor
@ApplicationScoped
public class FunctionApiController {
    private final FunctionService funcService;

    /*
     *  ERP_AC.BMS_SERVICE_CATEGORY_MAPPING
     */
    @GET
    @Path("/get/category-mapping")
    public Uni<Response> getCategoryMapping(@QueryParam("serviceCode") String serviceCode){
        return funcService.getCategoryMapping(serviceCode)
                .collect().asList().flatMap(list ->
                        Uni.createFrom().item(BaseResponse.successApi(list, "Success"))
                );
    }

    @POST
    @Path("/update/category-mapping")
    public Uni<Response> updateCategoryMapping(@RequestBody CategoryMappingEntity req){
        return funcService.updateCategoryMapping(req)
                .flatMap(list ->
                        Uni.createFrom().item(BaseResponse.successApi(null, "Success"))
                );
    }

    /*
     * dashboard api accounting common
     */

    @GET
    @Path("/dashboard/raw-status")
    public Uni<Response> overviewStatusRawData(@QueryParam("from") String from,
                                               @QueryParam("to") String to,
                                               @QueryParam("businessId") Long businessId){
        return funcService.getOverviewStatusRawData(from, to, businessId)
                .collect().asList()
                .flatMap(list ->
                        Uni.createFrom().item(BaseResponse.successApi(list, "Success"))
                );
    }
}
