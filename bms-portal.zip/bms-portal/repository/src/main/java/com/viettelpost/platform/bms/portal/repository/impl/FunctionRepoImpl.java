package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.entity.CategoryMappingEntity;
import com.viettelpost.platform.bms.portal.model.entity.dashboard.AccountingStatusOverview;
import com.viettelpost.platform.bms.portal.repository.FunctionRepository;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Singleton
@Slf4j
public class FunctionRepoImpl implements FunctionRepository {
    @Inject
    ConnectionPool oraclePool;

    @Override
    public Multi<CategoryMappingEntity> getCategoryMapping(String serviceCode) {
        String sql = """
                select * from ERP_AC.BMS_SERVICE_CATEGORY_MAPPING
                """;
        if(serviceCode != null && !serviceCode.isEmpty()){
            sql += " where SERVICE_CODE = '" + serviceCode + "'";
        }

        return oracleExecuteMulti(oraclePool, sql, Map.of(), CategoryMappingEntity.class);
    }

    @Override
    public Uni<Long> updateCategoryMapping(CategoryMappingEntity req) {
        if(req.getBmsServiceCategoryId() != null){
            // update
            String sqlUpdate = """
                UPDATE ERP_AC.BMS_SERVICE_CATEGORY_MAPPING
                SET SERVICE_CODE = :serviceCode,
                    PRODUCT_CATEGORY = :productCategory,
                    DESCRIPTION = :des,
                    KEY_1 = :key1,
                    KEY_2 = :key2
                WHERE BMS_SERVICE_CATEGORY_ID = :id
                """;
            return oracleExecuteUni(oraclePool, sqlUpdate, Map.of(
                    "serviceCode", req.getServiceCode(),
                    "productCategory", req.getProductCategory(),
                    "des", req.getDescription(),
                    "key1", req.getKey1(),
                    "key2", req.getKey2(),
                    "id", req.getBmsServiceCategoryId()
            ));
        } else {
            // insert
            String sqlInsert = """
                INSERT INTO ERP_AC.BMS_SERVICE_CATEGORY_MAPPING (BMS_SERVICE_CATEGORY_ID, SERVICE_CODE, PRODUCT_CATEGORY, DESCRIPTION,
                                                                 KEY_1, KEY_2)
                VALUES (ERP_AC.BMS_SERVICE_CATEGORY_SEQ.nextval, :serviceCode, :productCategory, :des, :key1, :key2)
                """;
            return oracleExecuteUni(oraclePool, sqlInsert, Map.of(
                    "serviceCode", req.getServiceCode(),
                    "productCategory", req.getProductCategory(),
                    "des", req.getDescription(),
                    "key1", req.getKey1(),
                    "key2", req.getKey2()
            ));
        }
    }

    @Override
    public Multi<AccountingStatusOverview> getOverviewStatusRawRepo(SqlConnection connection, LocalDateTime from, LocalDateTime to, Long businessId) {
        String sql = "select status, business_id, count(1) as sum from bms_payment.accounting_synthetic where created_at BETWEEN $1 AND $2 ";

        List<Object> params = new ArrayList<>(List.of(from, to));

        if(businessId != null){
            sql += " and business_id = $3";
            params.add(businessId);
        }

        sql += " group by business_id, status";

        return postgresExecuteMulti(connection, sql, Tuple.from(params), AccountingStatusOverview.class);
    }
}
