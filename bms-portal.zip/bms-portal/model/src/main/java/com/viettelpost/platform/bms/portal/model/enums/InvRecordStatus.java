package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;
@Getter
@AllArgsConstructor
public enum InvRecordStatus {
    EXPORT_ERROR(-1, "Lỗi xuất hóa đơn"),
    TAO_MOI(1, "Tạo mới"),
    CHOT_BANG_KE(2, "Chốt bảng kê"),
    CHO_PHAT_HANH(3, "Chờ phát hành"),
    DANG_PHAT_HANH(4, "Đang phát hành"),
    DA_PHAT_HANH(5, "Đã phát hành"),
    NA(0, "N/A");

    private final Integer code;
    private final String description;

    public static InvRecordStatus fromCode(Integer code) {
        for (InvRecordStatus status : InvRecordStatus.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static Integer fromStatus(InvRecordStatus status) {
        return status.getCode();
    }
}
