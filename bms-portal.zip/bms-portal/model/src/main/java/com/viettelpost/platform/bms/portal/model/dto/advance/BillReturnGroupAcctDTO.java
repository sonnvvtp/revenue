package com.viettelpost.platform.bms.portal.model.dto.advance;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillReturnGroupAcctDTO {

    private String partnerEvtp;

    private String partnerCode;

    private Long cusPostId;

    private Long cusOrgId;

    private Long postId;

    private Long orgId;

    private List<Long> listPayInId;

    private BigDecimal amount;

    private LocalDate accountingDate;

    private LocalDateTime lastDayOfMonth;
}
