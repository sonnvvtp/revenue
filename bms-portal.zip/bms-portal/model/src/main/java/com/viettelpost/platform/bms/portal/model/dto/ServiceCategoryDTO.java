package com.viettelpost.platform.bms.portal.model.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ServiceCategoryDTO {
    private String productCategory;
}
