package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceReportRequest {
    private String fromDate;
    private String toDate;
    private String invoiceNo;
    private String taxCode;
    private String customerName;
    private Integer status;
    private String customerCode;
    private Integer page = 1;
    private Integer size = 10;
    private Boolean detail = false;
    private String companyCode;
} 