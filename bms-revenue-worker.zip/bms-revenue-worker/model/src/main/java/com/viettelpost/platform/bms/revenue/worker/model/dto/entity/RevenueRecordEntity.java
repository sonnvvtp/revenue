package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevenueRecordEntity {

    @JsonAlias("id")
    private BigDecimal id;

    @JsonAlias("revenue_sync_status")
    private Integer revenueSyncStatus;

    @JsonAlias("statement_id")
    private BigDecimal statementId;

    @JsonAlias("statement_code")
    private String statementCode;

    @JsonAlias("updated_by")
    public Long updatedBy;
}
