package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BmsBillJourneyEntity {
    
    @JsonAlias("BILL_JOURNEY_ID") // mã phiếu gưi
    private BigDecimal billJourneyId;

    @JsonAlias("NOTE") // dùng làm transaction_id
    private String note;

    @JsonAlias("ORDER_NUMBER") //   loại vận đơn(4 loại như cũ)
    private String orderNumber;

    @JsonAlias("ORDER_STATUS")  //  tiền cước
    private Long orderStatus;

    @JsonAlias("POSTOFFICE_CODE") // tiền thu hộ(tổng)
    private String postofficeCode;

    @JsonAlias("EMPLOYEE_ID") // mã bưu cục phát
    private Long employeeId;

    @JsonAlias("JOURNEY_DATE")
    private LocalDateTime journeyDate;
}
