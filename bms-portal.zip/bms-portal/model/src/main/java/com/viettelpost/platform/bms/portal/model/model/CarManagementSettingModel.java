package com.viettelpost.platform.bms.portal.model.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class CarManagementSettingModel {

    private Long id;
    private String unit;
    @JsonAlias("car_license_plate")
    private String carLicensePlate;
    @JsonAlias("recover_id")
    private String recoverId;
    @JsonAlias("fuel_consumption_rate")
    private Double fuelConsumptionRate;
    @JsonAlias("car_label")
    private String carLabel;
    private String type;
    @JsonAlias("fuel_consumption_unit")
    private Double fuelConsumptionUnit;
    @JsonAlias("type_id")
    private String typeId;
    @JsonAlias("org_type")
    public Integer orgType;
    @JsonAlias("type_group_id")
    private Long typeGroupId;
    @JsonAlias("car_license_plate_key")
    private String carLicensePlateKey;
    @JsonAlias("is_active")
    private Boolean active;
    @JsonAlias("update_date")
    private LocalDateTime updateDate;
}
