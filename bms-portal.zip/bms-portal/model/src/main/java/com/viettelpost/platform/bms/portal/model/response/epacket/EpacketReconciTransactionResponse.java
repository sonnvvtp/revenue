package com.viettelpost.platform.bms.portal.model.response.epacket;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Accessors(chain = true)
public class EpacketReconciTransactionResponse {
    private boolean error;
    @JsonProperty("error_code")
    private String errorCode;
    private List<ITEMS> items;

    private long totalRecords;
    private int totalPage;
    private int currentPage;

    @Data
    public static class ITEMS {
        private String message;
        private Integer reconStatus; //0,1,2,3
        private BigDecimal amountVTP;
        private BigDecimal amountPartner;
        private BigDecimal amountDiff;        // số tiền chênh lệch = partner - local
        private String transactionCode;
        private String transactionCodePartner;
        private String createdTime;
        private String createdTimePartner;
        private BigDecimal transactionId;
        private String requestId;
        private Long transactionType;
        private Long cusId;
        private String orgCode;
        private Long orgId;
        private String postCode;
        private Long postId;
        private Boolean isMatching;       // khớp = true, chênh lệch = false
        private BigDecimal partnerInternalId;
        private String partnerBankCode;
        private BigDecimal partnerInternalLineId;
        private String reqPaymentCode;
        private Integer transactionSource; // 1 là của đối tác, là transaction_souce trong bảng
    }
}