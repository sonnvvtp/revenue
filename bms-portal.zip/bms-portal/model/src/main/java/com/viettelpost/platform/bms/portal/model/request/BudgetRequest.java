package com.viettelpost.platform.bms.portal.model.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BudgetRequest {

    @JsonProperty("FMAREA")
    private String FMAREA;
    @JsonProperty("LEDGER")
    private String LEDGER;
    @JsonProperty("FISCAL_YEAR")
    private String FISCAL_YEAR;
    @JsonProperty("BUDGET_PERIOD")
    private String BUDGET_PERIOD;
    @JsonProperty("FUNDS_CENTER")
    private String FUNDS_CENTER;
    @JsonProperty("GL_ACCOUNT")
    private String GL_ACCOUNT;
    @JsonProperty("COMMITMENT_ITEM")
    private String COMMITMENT_ITEM;
    @JsonProperty("FUNDED_PROGRAM")
    private List<FundedProgram> FUNDED_PROGRAM;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class FundedProgram {

        @JsonProperty("VALUE")
        private String VALUE;
    }
}