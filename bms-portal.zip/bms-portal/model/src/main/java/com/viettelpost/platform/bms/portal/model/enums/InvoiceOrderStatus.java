package com.viettelpost.platform.bms.portal.model.enums;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum InvoiceOrderStatus {
    TAO_MOI(0, "Chưa yc xuất HĐ"),
    DA_GOM_BANG_KE(1, "Đã đẩy yc xuất HĐ"),
    DA_XUAT_HOA_DON(2, "Đã xuất hóa đơn"),
    XUAT_HOA_DON_FAIL(-1, "xuất hóa đơn fail"),
    NA(-99, "N/A");


    private final Integer code;
    private final String description;

    public static InvoiceOrderStatus fromCode(Integer code) {
        for (InvoiceOrderStatus status : InvoiceOrderStatus.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static Integer fromStatus(InvoiceOrderStatus status) {
        return status.getCode();
    }
}
