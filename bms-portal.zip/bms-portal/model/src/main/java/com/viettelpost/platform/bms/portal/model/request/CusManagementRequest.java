package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.viettelpost.platform.bms.portal.model.enums.SearchRequestType;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CusManagementRequest {
    private String evtp;
    private String cusId;
    private PhoneEMail searchParam;
    private int page;
    private int size;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate fromDate;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    @Data
    public static class PhoneEMail{
        private SearchRequestType search;
        private String phoneEmails;
    }




}
