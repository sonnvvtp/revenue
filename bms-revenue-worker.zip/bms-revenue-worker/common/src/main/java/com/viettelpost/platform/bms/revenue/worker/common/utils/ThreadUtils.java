package com.viettelpost.platform.bms.revenue.worker.common.utils;

import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.infrastructure.Infrastructure;

public class ThreadUtils {

    public static void runInOtherThread(Runnable runnable) {
        Uni.createFrom()
                .voidItem()
                .runSubscriptionOn(Infrastructure.getDefaultExecutor())
                .invoke(runnable)
                .subscribe().with(
                        unused -> {},
                        Throwable::printStackTrace
                );
    }

}
