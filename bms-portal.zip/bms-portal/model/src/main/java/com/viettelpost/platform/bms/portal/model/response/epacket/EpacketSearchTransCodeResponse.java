package com.viettelpost.platform.bms.portal.model.response.epacket;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Accessors(chain = true)
public class EpacketSearchTransCodeResponse {
    private boolean error;
    @JsonProperty("error_code")
    private String errorCode;
    private String message;

    private List<EpacketSearchTransCodeResponse.ITEMS> items;

    @Data
    public static class ITEMS {
        private String statusText;
        private Integer status;
        private String transactionCode;
        private BigDecimal amount;
        private Integer transactionType;
        private String requestId;
        private String orgCode;
        private Long orgId;
        private String postCode;
        private Long postId;
        private String reqPaymentCode;
        private Long partnerInternalId;
        private String partnerBankCode;
        private Long reqPartnerId;
        private String createDate;
        private String updateDate;
    }
}
