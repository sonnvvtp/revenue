package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import lombok.Data;

@Data
public class FindInvoiceRecordRequest {

    @Size(max = 100, message = "Từ khóa tìm kiếm quá dài")  // số hóa đơn
    private String advancedFilter;

    @Size(max = 100, message = "Từ khóa tìm kiếm quá dài")  // số hóa đơn
    private String recordNo;

    private List<Integer> status;  // trạng thái

    private Long doctypeId;  // loại bảng kê

    private String customerCode; // mã khách hàng

    private Integer recordType;  // loại bảng kê:  1: tự động, 2: thủ công

    @JsonFormat(pattern = "dd/MM/yyyy")  // ngày tạo
    private LocalDate fromDate;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    @JsonFormat(pattern = "dd/MM/yyyy") // ngày xuất hóa đơn
    private LocalDate fromInvoiceDate;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toInvoiceDate;

    private Integer page;

    private Integer size;

}
