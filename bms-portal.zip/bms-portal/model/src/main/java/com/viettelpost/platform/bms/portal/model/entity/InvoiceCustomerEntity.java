package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceCustomerEntity {

    @JsonAlias("id")
    private BigDecimal id;

    @JsonAlias("tenant_id")
    private Integer tenantId;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("created_at")
    private LocalDateTime createdAt;

    @JsonAlias("updated_by")
    private Long updatedBy;

    @JsonAlias("updated_at")
    private LocalDateTime updatedAt;

    @JsonAlias("customer_id")
    private Long customerId;

    @JsonAlias("cus_id")
    private Long cusId;

    @JsonAlias("customer_code")
    private String customerCode;

    @JsonAlias("customer_type")
    private Short customerType;

    @JsonAlias("customer_name")
    private String customerName;

    @JsonAlias("customer_phone")
    private String customerPhone;

    @JsonAlias("customer_email")
    private String customerEmail;

    @JsonAlias("customer_address")
    private String customerAddress;

    @JsonAlias("customer_tax")
    private String customerTax;

    @JsonAlias("budget_unit_code")
    private String budgetUnitCode;

    @JsonAlias("unit_level1_id")
    private String unitLevel1Id;

    @JsonAlias("unit_level1_code")
    private String unitLevel1Code;

    @JsonAlias("unit_level2_id")
    private String unitLevel2Id;

    @JsonAlias("unit_level2_code")
    private String unitLevel2Code;

    @JsonAlias("e_contract_code")
    private String eContractCode;

    @JsonAlias("e_contract_signed_date")
    private LocalDateTime eContractSignedDate;

    @JsonAlias("invoice_detail_by_bill")
    private Boolean invoiceDetailByBill = false;

    @JsonAlias("status")
    private Integer status;

    @JsonAlias("partner_source")
    private String partnerSource;
}
