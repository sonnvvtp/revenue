package com.viettelpost.platform.bms.portal.model.dto;


import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class FuelBillingRecoveryStatus {
    @JsonAlias("reduction_status")
    private Integer reductionStatus;
    @JsonAlias("excess_status")
    private Integer excessStatus;
}
