package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryDTO;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import com.viettelpost.platform.bms.portal.repository.FuelBillingRecoveryRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class FuelBillingRecoveryRepositoryImpl implements FuelBillingRecoveryRepository {

    @Inject
    PgPool client;

    @Override
    public Mono<Void> persist(FuelBillingRecoveryDTO recoveryDTO, SqlConnection connection) {
        String query = "INSERT INTO bms_payment.fuel_billing_recovery (" +
                "receipt_number_excess, receipt_number_reduction, synthesis_period, car_license_plate, unit, budget, actual_mileage, "
                +
                "fuel_consumption_rate, fuel_consumption_unit, total_excess_amount, total_budget_excess, reduction_status, created_at, car_id, budget_reduction, excess_status, is_active "
                +
                ") VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)";

        Tuple tuple = Tuple.tuple()
                .addString(recoveryDTO.getExcessNumber())
                .addString(recoveryDTO.getReductionNumber())
                .addString(recoveryDTO.getSynthesisPeriod())
                .addString(recoveryDTO.getCarLicensePlate())
                .addString(recoveryDTO.getUnit())
                .addBigDecimal(recoveryDTO.getBudget())
                .addBigDecimal(recoveryDTO.getActualMileage())
                .addBigDecimal(recoveryDTO.getFuelConsumptionRate())
                .addBigDecimal(recoveryDTO.getFuelConsumptionUnit())
                .addBigDecimal(recoveryDTO.getTotalExcessAmount())
                .addBigDecimal(recoveryDTO.getTotalExcessBudget())
                .addInteger(recoveryDTO.getReductionStatus())
                .addLocalDateTime(recoveryDTO.getCreatedAt())
                .addLong(recoveryDTO.getCarId())
                .addBigDecimal(recoveryDTO.getBudgetReduction())
                .addInteger(recoveryDTO.getExcessStatus())
                .addBoolean(recoveryDTO.getIsActive());

        return connection.preparedQuery(query)
                .execute(tuple)
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(rows -> log.info(
                        "[DB] Inserted fuel billing recovery for license plate: {}",
                        recoveryDTO.getCarLicensePlate()))
                .doOnError(ex -> log.error(
                        "[DB] Error inserting fuel billing recovery for license plate: {}",
                        recoveryDTO.getCarLicensePlate(), ex))
                .then();
    }

@Override
public Mono<Void> updateStatus(List<String> receiptNumbers, BillingStatus status, SqlConnection connection) {
    if (receiptNumbers.isEmpty()) {
        return Mono.empty();
    }

    String placeholders = IntStream.range(0, receiptNumbers.size())
            .mapToObj(i -> "$" + (i + 2))
            .collect(Collectors.joining(", "));

    String query = "UPDATE bms_payment.fuel_billing_recovery SET " +
            "reduction_status = CASE WHEN budget_reduction = 0 THEN 0 ELSE $1 END, " +
            "excess_status = CASE WHEN total_budget_excess = 0 THEN 0 ELSE $1 END " +
            "WHERE receipt_number_reduction IN (" + placeholders + ") " +
            "AND is_active = true";
    List<Object> params = new ArrayList<>();
    params.add(status.getCode());
    params.addAll(receiptNumbers);

    return connection.preparedQuery(query)
            .execute(Tuple.from(params))
            .convert().with(UniReactorConverters.toMono())
            .doOnSuccess(rows -> log.info("Updated status to {} for {} receipt numbers", status, receiptNumbers.size()))
            .doOnError(ex -> log.error("Error updating status for receipt numbers: {}", ex.getMessage()))
            .then();
}


    @Override
    public Mono<List<FuelBillingRecoveryDTO>> getListBySynthesisPeriodAndUnit(
            String synthesisPeriod, Integer approveStatus, Integer recordFail, Integer reject) {
        String query =
                "SELECT id, receipt_number_excess, receipt_number_reduction, synthesis_period, car_license_plate, unit, budget, " +
                        "actual_mileage, fuel_consumption_rate, fuel_consumption_unit, total_excess_amount, "
                        +
                        "total_budget_excess, reduction_status, created_at, car_id, budget_reduction " +
                        "FROM bms_payment.fuel_billing_recovery WHERE synthesis_period = $1 AND " +
                        "(reduction_status = $2 OR reduction_status = $3 OR reduction_status = $4)" +
                        " and is_active = true and  budget_reduction > 0";

        return client.preparedQuery(query)
                .mapping(DataMapping.map(FuelBillingRecoveryDTO.class))
                .execute(Tuple.of(synthesisPeriod, approveStatus,recordFail, reject))
                .onItem()
                .transform(rowSet -> {
                    List<FuelBillingRecoveryDTO> resultList = new ArrayList<>();
                    rowSet.forEach(resultList::add);
                    return resultList;
                })
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Void> updateSapFields(String receiptNumber, Integer status,
            String messSap, Long sapDocNumber) {
        String query = "UPDATE bms_payment.fuel_billing_recovery SET reduction_status = $1, mess_sap = $2, doc_number_sap = $3 " +
                "WHERE receipt_number_reduction = $4 and is_active = true";
        return client.preparedQuery(query)
                .execute(Tuple.of(status, messSap, sapDocNumber, receiptNumber))
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(
                        rows -> log.info("Updated fields for receipt number: {}", receiptNumber))
                .doOnError(ex -> log.error("Error updating fields for receipt number {}: {}",
                        receiptNumber, ex.getMessage()))
                .then();
    }

    @Override
    public Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection connection) {
        String query = "UPDATE bms_payment.fuel_billing_recovery SET is_active = false WHERE synthesis_period = $1";
        return connection.preparedQuery(query)
                .execute(Tuple.of(synthesisPeriod))
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(rows -> log.info("Deactivated records for synthesis period: {}",
                        synthesisPeriod))
                .doOnError(ex -> log.error("Error deactivating records for synthesis period {}: {}",
                        synthesisPeriod, ex.getMessage()))
                .then();
    }

    @Override
    public Mono<List<FuelBillingRecoveryDTO>> getListBySynthesisPeriodAndStatusSap(
            String synthesisPeriod, Integer recordBudgetSuccess, Integer retrieveFail) {
        String query =
                "SELECT id, receipt_number_excess,receipt_number_reduction , synthesis_period, car_license_plate, unit, budget, " +
                        "actual_mileage, fuel_consumption_rate, fuel_consumption_unit, total_excess_amount, " +
                        "total_budget_excess, reduction_status, created_at, car_id, budget_reduction, doc_number_sap " +
                        "FROM bms_payment.fuel_billing_recovery WHERE synthesis_period = $1 and (reduction_status = $2 OR reduction_status = $3) " +
                        "and is_active = true and budget_reduction > 0";

        return client.preparedQuery(query)
                .mapping(DataMapping.map(FuelBillingRecoveryDTO.class))
                .execute(Tuple.of(synthesisPeriod, recordBudgetSuccess, retrieveFail))
                .onItem()
                .transform(rowSet -> {
                    List<FuelBillingRecoveryDTO> resultList = new ArrayList<>();
                    rowSet.forEach(resultList::add);
                    return resultList;
                })
                .convert()
                .with(UniReactorConverters.toMono());
    }

}
