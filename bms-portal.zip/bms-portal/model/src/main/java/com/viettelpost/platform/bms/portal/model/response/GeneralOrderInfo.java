package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GeneralOrderInfo {
    private Long id;
    private String orderId;
    private String orderCode;
    private String buyerCode;
    private String orderSource;
    private String companyCode;
    private UnitInfo unitInfo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime createdAt;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime orderDeliveredAt;
    private String serviceCode;
    private String cashflowType;
    private Long employeeId;
    private EmployeeInfo employeeInfo;
    private String invoicePartner;
    private Integer invoiceStatus;
    private Integer revenueSyncStatus;
    private Integer paymentStatus;
    private Integer paymentMethod;
    private Long paymentTermId;
    private String currency;
    private Integer orderTotalQuantity;
    private BigDecimal orderAmountBeforeTax;
    private BigDecimal orderTaxAmount;
    private BigDecimal orderAmountAfterTax;
}
