package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CostRefundDataDTO {
    @JsonAlias("PAYMENT_COST_ID")
    private Long PAYMENT_COST_ID;

    @JsonAlias("UPDATED_AT")
    private LocalDateTime UPDATED_AT;

    @JsonAlias("PAY_AMOUNT")
    private BigDecimal PAY_AMOUNT;

    @JsonAlias("REF_ID")
    private String REF_ID;

    @JsonAlias("BP_CODE")
    private String BP_CODE;

    @JsonAlias("STATEMENT_NO")
    private String STATEMENT_NO;

    @JsonAlias("BANK_FROM_ACCOUNT")
    private String BANK_FROM_ACCOUNT;

    @JsonAlias("REQ_VTP_ORDER_ID")
    private String REQ_VTP_ORDER_ID;

    @JsonAlias("SUMMARY_NO")
    private String SUMMARY_NO;

    @JsonAlias("ORG_ID")
    private Long ORG_ID;

    @JsonAlias("POST_ID")
    private Long POST_ID;

    @JsonAlias("CONTENT")
    private String CONTENT;

    @JsonAlias("TYPE")
    private String TYPE;

    @JsonAlias("BANK_ACC_NO")
    private String bankAccNo;

    @JsonAlias("TRANSACTION_CODE")
    private String transactionCode;

    @JsonAlias("REQUEST_CODE")
    private String requestCode;
}