package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

@Data
public class ErpDocTypeRequest {
    private String doctypeCode;
    private String doctypeName;
    private String description;
    private String companyCode;
}
