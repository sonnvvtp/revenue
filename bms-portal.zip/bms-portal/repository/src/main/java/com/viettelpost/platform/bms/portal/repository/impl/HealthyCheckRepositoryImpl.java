package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.response.PostgreClusterInfoResponse;
import com.viettelpost.platform.bms.portal.repository.HealthyCheckRepository;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.RowSet;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.ArrayList;

@Singleton
@Slf4j
public class HealthyCheckRepositoryImpl implements HealthyCheckRepository {

    @Inject
    PgPool client;

    @Override
    public Mono<Integer> checkDatabasePostgres() {
        String sql ="select 1 total" ;
        return client.preparedQuery(sql)
                .execute(Tuple.from(new ArrayList<>()))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getInteger("total") : 0)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Multi<PostgreClusterInfoResponse> getClusterInfo() {
        String sql = "SHOW pool_nodes";
        return client.query(sql)
                .mapping(DataMapping.map(PostgreClusterInfoResponse.class))
                .execute()
                .onItem()
                .transformToMulti(RowSet::toMulti)
                .onFailure()
                .recoverWithMulti(throwable -> {
                    log.info("[HealthyGetClusterInfo] error: {}", throwable.getMessage());
                    return Multi.createFrom().empty();
                });
    }
}