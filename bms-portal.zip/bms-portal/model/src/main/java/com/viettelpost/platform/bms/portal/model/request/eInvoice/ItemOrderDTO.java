package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import java.math.BigDecimal;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemOrderDTO {
  private String orderId;
  private String departureLocation;
  private String arrivalLocation;
  private String vehiclePlateNumber;
  private String warehouseCode;
  private Integer itemSelection;
  private String itemCode;
  private String itemName;
  private String itemNote;
  private String itemUnit;
  private Long itemQuantity;
  private BigDecimal itemPrice;
  private Integer itemWeight;
  private BigDecimal itemAmountBeforeTax;
  private Integer itemTaxType;
  private BigDecimal itemTaxPercent;
  private BigDecimal itemTaxAmount;
  private BigDecimal itemAmountAfterTax;
  private Map<String, Object> attribute1;
  private Map<String, Object> attribute2;
  private Map<String, Object> attribute3;
}

