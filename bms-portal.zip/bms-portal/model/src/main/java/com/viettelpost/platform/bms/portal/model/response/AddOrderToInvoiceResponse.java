package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class AddOrderToInvoiceResponse {
    private String orderCode;
    private Long recordId;
    private Long invoiceRecordLineId;
    private Integer itemCount;
    private Boolean success;
} 