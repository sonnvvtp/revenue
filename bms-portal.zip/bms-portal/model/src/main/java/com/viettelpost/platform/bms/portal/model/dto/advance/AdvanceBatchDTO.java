package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class AdvanceBatchDTO {

    @JsonAlias("PAY_BATCH_ID")
    private Long payBatchId;

    @JsonAlias("BATCH_NO")
    private String batchNo;

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("PARTNER_CODE")
    private String partnerCode;

    @JsonAlias("CUS_PO_CODE")
    private String partnerEvtp;

    @JsonAlias("PAY_AMOUNT")
    private BigDecimal amount;

    @JsonAlias("CREATED_AT")
    private LocalDateTime createdAt;

    @JsonAlias("CREATED_BY")
    private String createdBy;
}
