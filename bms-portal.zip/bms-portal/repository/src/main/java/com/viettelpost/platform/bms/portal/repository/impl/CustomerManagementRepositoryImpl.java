package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.common.utils.CommonUtils;
import com.viettelpost.platform.bms.portal.common.utils.OracleUtils;
import com.viettelpost.platform.bms.portal.model.dto.*;
import com.viettelpost.platform.bms.portal.model.enums.SearchRequestType;
import com.viettelpost.platform.bms.portal.model.exception.BusinessException;
import com.viettelpost.platform.bms.portal.model.request.AddPaymentPeriodCusRequest;
import com.viettelpost.platform.bms.portal.model.request.CusManagementRequest;
import com.viettelpost.platform.bms.portal.model.response.*;
import com.viettelpost.platform.bms.portal.repository.CustomerManagementRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Singleton
@Slf4j
@KeepTracedContext
public class CustomerManagementRepositoryImpl implements CustomerManagementRepository {

    @Inject
    ConnectionPool oraclePool;

    @Inject
    PgPool client;


    @ConfigProperty(name = "insert.cus.batchSize", defaultValue = "1000")
    Integer batchSize;

    @Override
    public Uni<Long> getCountManagementCus(CusManagementRequest request) {
        String moreQuery = "";
        List<Object> params = new ArrayList<>();
        boolean flag = false;
        if (!CommonUtils.isNullOrEmpty(request.getCusId())) {
           // moreQuery = " a.CUS_ID  = ?  ";
            List<Long> list = Arrays.stream(request.getCusId().replace(" ", ",").split(","))
                    .filter(s -> !s.isBlank())
                    .map(Long::parseLong)
                    .toList();
            moreQuery = "   (a.CUS_ID,0)  IN (%s)";
            String placeholder = OracleUtils.genConditionInBigSize(list.size());
            moreQuery = moreQuery.formatted(placeholder);
            params.addAll(list);
            flag = true;
        }
        if (request.getEvtp() != null && !request.getEvtp().isEmpty()) {
            if (flag) {
                moreQuery = moreQuery + " and ";
            }
            moreQuery = moreQuery + " c.EVTPCODE  = ?";
            params.add(request.getEvtp());
            flag = true;
        }
        if (request.getSearchParam() != null && SearchRequestType.EMAIL.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            if (flag) {
                moreQuery = moreQuery + " and ";
            }
            List<String> emailList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery = moreQuery + " (a.EMAIL,0)  IN (%s)";
            String placeholder = OracleUtils.genConditionInBigSize(emailList.size());
            moreQuery = moreQuery.formatted(placeholder);
            params.addAll(emailList);
            flag = true;
        }
        if (request.getSearchParam() != null && SearchRequestType.PHONE.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            if (flag) {
                moreQuery = moreQuery + " and ";
            }
            List<String> phoneList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery = moreQuery + " (a.PHONE,0)  IN (%s)";
            String placeholder = OracleUtils.genConditionInBigSize(phoneList.size());
            moreQuery = moreQuery.formatted(placeholder);
            params.addAll(phoneList);
        }


        String sql = " select COUNT(DISTINCT a.CUS_ID) AS totalCusId \n" +
                     "from ERP_CUS.CUS_CUSTOMER a \n" +
                     "left join ERP_AC.FICO_ECONTRACT b on a.CUS_ID = b.CUS_ID\n" +
                     "left join ERP_CUS.CUS_CUSTOMER_CODE c on a.CUS_ID = c.CUS_ID where " + moreQuery;
        System.out.println(sql);
        return executeAndGetValue(oraclePool, sql, params, "totalCusId", Long.class);
    }

    @Override
    public Multi<CusManagementListResponse> getListManagementCus(CusManagementRequest request) {
        String moreQuery = "";
        List<Object> params = new ArrayList<>();
        boolean flag = false;
        if (!CommonUtils.isNullOrEmpty(request.getCusId())) {
            List<Long> list = Arrays.stream(request.getCusId().replace(" ", ",").split(","))
                    .filter(s -> !s.isBlank())
                    .map(Long::parseLong)
                    .toList();
            moreQuery = "   (a.CUS_ID,0)  IN (%s)";
            String placeholder = OracleUtils.genConditionInBigSize(list.size());
            moreQuery = moreQuery.formatted(placeholder);
            params.addAll(list);
            flag = true;
        }
        if (request.getEvtp() != null && !request.getEvtp().isEmpty()) {
            if (flag) {
                moreQuery = moreQuery + " and ";
            }
            moreQuery = moreQuery + " c.EVTPCODE  = ?";
            params.add(request.getEvtp());
            flag = true;
        }
        if (request.getSearchParam() != null && SearchRequestType.EMAIL.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            if (flag) {
                moreQuery = moreQuery + " and ";
            }
            List<String> emailList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery = moreQuery + " (a.EMAIL,0)  IN (%s)";
            String placeholder = OracleUtils.genConditionInBigSize(emailList.size());
            moreQuery = moreQuery.formatted(placeholder);
            params.addAll(emailList);
            flag = true;
        }
        if (request.getSearchParam() != null && SearchRequestType.PHONE.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            if (flag) {
                moreQuery = moreQuery + " and ";
            }
            List<String> phoneList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery = moreQuery + " (a.PHONE,0)  IN (%s)";
            String placeholder = OracleUtils.genConditionInBigSize(phoneList.size());
            moreQuery = moreQuery.formatted(placeholder);
            params.addAll(phoneList);
        }

        String sql = "  select *\n" +
                     "from (\n" +
                     "         select x.*,\n" +
                     "                row_number() over (order by x.CREATEDONDATE desc) ac\n" +
                     "         from (\n" +
                     "                  select *\n" +
                     "                  from (\n" +
                     "                           select a.*,\n" +
                     "                                  row_number() over (partition by a.CUS_ID order by a.CREATEDONDATE desc) rn\n" +
                     "                           from (\n" +
                     "                                    select a.CUS_ID,\n" +
                     "                                           a.PHONE,\n" +
                     "                                           a.DISPLAYNAME,\n" +
                     "                                           a.EMAIL,\n" +
                     "                                           b.BANKNAME,\n" +
                     "                                           b.BANK_BRANCH,\n" +
                     "                                           b.ACCOUNTBANKNO,\n" +
                     "                                           b.BENEFICIARY,\n" +
                     "                                           case\n" +
                     "                                               when b.LISTDAYOFWEEK is null\n" +
                     "                                                   then ERP_AC.AC_AUTO_PAYMENT_CONFIG.Get_Type_doi_soat(c.EVTPCODE)\n" +
                     "                                               when b.LISTDAYOFWEEK = '0' then 'Thanh toán COD hằng ngày'\n" +
                     "                                               else 'Thứ ' || b.LISTDAYOFWEEK || ' hàng tuần'\n" +
                     "                                           end as PERIOD_PAYMENT,\n" +
                     "                                           a.CREATEDONDATE,\n" +
                     "                                           (select d.PAYMENT_TEAM\n" +
                     "                                            from ERP_AC.ERP_PARTNER d\n" +
                     "                                            where d.VALUE = c.EVTPCODE\n" +
                     "                                              and ROWNUM = 1) as PAYMENT_TEAM\n" +
                     "                                    from ERP_CUS.CUS_CUSTOMER a\n" +
                     "                                             left join ERP_AC.FICO_ECONTRACT b on a.CUS_ID = b.CUS_ID\n" +
                     "                                             left join ERP_CUS.CUS_CUSTOMER_CODE c on a.CUS_ID = c.CUS_ID\n" +
                     "                                    where " + moreQuery +
                     "                                      and a.ACTIVE = 'Y'\n" +
                     "                                      and c.ACTIVE = 'Y'\n" +
                     "                                ) a\n" +
                     "                       ) t\n" +
                     "                  where t.rn = 1   -- chỉ lấy dòng mới nhất cho mỗi CUS_ID\n" +
                     "              ) x\n" +
                     "     )\n" +
                     "where ac between ? and ?  ";
        params.add(((request.getPage() - 1) * request.getSize() + 1));
        params.add(request.getPage() * request.getSize());
        return executeMulti(oraclePool, sql, params, CusManagementListResponse.class);
    }

    @Override
    public Uni<Long> getCountEvtpByCus(Long cusId) {
        List<Object> params = new ArrayList<>();
        String sql = "  select count(1) count from  ERP_CUS.CUS_CUSTOMER_CODE a where a.CUS_ID = ? and ACTIVE = 'Y' and a.EVTPCODE is not null ";
        params.add(cusId);
        return executeAndGetValue(oraclePool, sql, params, "count", Long.class);

    }

    @Override
    public Multi<PartnerEvtpListByCusResponse> getListPartnerByCus(Long cusId) {
        List<Object> params = new ArrayList<>();
        String sql = "  select fcd.PAYMENT_TYPE, \n" +
                     "             fcd.PAYMENT_VALUE, \n" +
                     "             fcd.PAYMENT_PERIOD_TYPE, \n" +
                     "             fcd.PAYMENT_DATE, \n" +
                     "             fcd.CONFIG_VALUE, \n" +
                     "             tpr.POST_ID, \n" +
                     "             (select c.NAME from ERP_AC.ERP_PARTNER c where c.VALUE = tpr.EVTPCODE and ROWNUM = 1) FULL_NAME, \n" +
                     "             ERP_AC.GET_ORG_ID(tpr.POST_ID) ORG_ID \n" +
                     "      from ERP_CUS.CUS_CUSTOMER_CODE tpr \n" +
                     "               left join ERP_AC.FICO_CLEAR_CONFIG fcd on tpr.EVTPCODE = fcd.CONFIG_VALUE \n" +
                     "      where tpr.CUS_ID = ? ";
        params.add(cusId);
        return executeMulti(oraclePool, sql, params, PartnerEvtpListByCusResponse.class);
    }

    @Override
    public Uni<CusManagementListResponse> getInfoPaymentByCus(Long cusId) {
        List<Object> params = new ArrayList<>();

        String sql = """
                   select distinct a.CUS_ID,
                                a.PHONE,
                                a.DISPLAYNAME,
                                a.EMAIL,
                                case
                                    when b.LISTDAYOFWEEK is null
                                        then ERP_AC.AC_AUTO_PAYMENT_CONFIG.Get_Type_doi_soat(c.EVTPCODE)
                                    when b.LISTDAYOFWEEK = '0' then 'Thanh toán COD hằng ngày'
                                    else 'Thứ ' || b.LISTDAYOFWEEK || ' hàng tuần'
                                    end as PERIOD_PAYMENT,
                                (select NVL(TYPE_CONFIG, 1)
                                                                  from ERP_AC.ERP_PAYMENT_PERIOD z
                                                                  where z.PARTNER_EVTP = c.EVTPCODE
                                                                    and ISACTIVE = 'Y' and ROWNUM = 1) as PERIOD
                from ERP_CUS.CUS_CUSTOMER a 
                         left join ERP_AC.FICO_ECONTRACT b on a.CUS_ID = b.CUS_ID
                         left join ERP_CUS.CUS_CUSTOMER_CODE c on a.CUS_ID = c.CUS_ID
                where  a.CUS_ID = ? and exists(select 1 from ERP_AC.ERP_PARTNER t where t.VALUE = c.EVTPCODE and ISACTIVE = 'Y')
                                                        
                   """;
        params.add(cusId);
        return execute(oraclePool, sql, params, CusManagementListResponse.class);
    }

    @Override
    public Uni<Long> getCountManagementCusDeclare(CusManagementRequest request) {
        String moreQuery = "";
        StringBuilder stringBuilder = new StringBuilder();
        List<Object> params = new ArrayList<>();
        params.add(LocalDateTime.of(request.getFromDate(), LocalTime.MIN));
        params.add(LocalDateTime.of(request.getToDate(), LocalTime.MAX));
        int countParam = 3;
        if (!CommonUtils.isNullOrEmpty(request.getCusId())) {
            Long[] cusIdArray = Arrays.stream(request.getCusId().replace(" ", ",").split(","))
                    .filter(s -> !s.isBlank())
                    .map(Long::parseLong)
                    .toArray(Long[]::new);
            moreQuery = " and  a.cus_id  = any($" + countParam++ + ")";
            params.add(cusIdArray);
        }

        if (request.getSearchParam() != null && SearchRequestType.EMAIL.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            List<String> emailList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery = moreQuery + " and email = any($" + countParam++ + ")";
            params.add(emailList.toArray());
        }

        if (request.getSearchParam() != null && SearchRequestType.PHONE.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            List<String> phoneList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery = moreQuery + " and phone = any($" + countParam + ")";
            params.add(phoneList.toArray());
        }
        Tuple tuple = Tuple.from(params);

        String sql = " select count(1) count from bms_payment.bms_declare_cus_payment a where created_at between $1 and $2 and active in (0,1)   " + moreQuery;
        return executeAndGetValue(client, sql, tuple, "count", Long.class);
    }

    @Override
    public Multi<CusDeclareListResponse> getListManagementCusDeclare(CusManagementRequest request) {
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        params.add(LocalDateTime.of(request.getFromDate(), LocalTime.MIN));
        params.add(LocalDateTime.of(request.getToDate(), LocalTime.MAX));
        int paramIndex = 3;
        if (!CommonUtils.isNullOrEmpty(request.getCusId())) {
            Long[] cusIdArray = Arrays.stream(request.getCusId().replace(" ", ",").split(","))
                    .filter(s -> !s.isBlank())
                    .map(Long::parseLong)
                    .toArray(Long[]::new);
            moreQuery.append(" and a.cus_id  = any($").append(paramIndex++).append(")");
            params.add(cusIdArray);
        }
        if (request.getSearchParam() != null && SearchRequestType.EMAIL.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            List<String> emailList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery.append(" and email = any($").append(paramIndex++).append(")");
            params.add(emailList.toArray());
        }

        if (request.getSearchParam() != null && SearchRequestType.PHONE.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            List<String> phoneList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery.append(" and phone = any($").append(paramIndex++).append(")");
            params.add(phoneList.toArray());
        }
        moreQuery.append(" order by updated_at desc limit $").append(paramIndex++).append(" offset $").append(paramIndex);
        params.add(request.getSize());
        params.add((request.getPage() - 1) * request.getSize());
        String sql = " select cus_id,email,phone,full_name,payment_type,payment_period,to_char(updated_at,'dd/MM/yyyy HH24:MI:ss') as updated_declare,to_char(created_at ,'dd/MM/yyyy') as created_declare, " +
                     " bms_payment.get_fullname_by_userid(created_by) as created_by,payment_type,active  " +
                     " from bms_payment.bms_declare_cus_payment a where created_at between $1 and $2 and active in (0,1) " + moreQuery;
        return executeMulti(client, sql, Tuple.from(params), CusDeclareListResponse.class);
    }

    @Override
    public Uni<Boolean> insertManagementCusDeclare(CusManagementListResponse request, SqlConnection sqlConnection,Long userId) {
        Map<String,Object> params = new HashMap<>();
        String sqlInsert = """
                insert into bms_payment.bms_declare_cus_payment (cus_id,full_name,phone,email,payment_period,created_by,created_at,updated_at)\s
                values  (#{cusId},#{fullName},#{phone},#{email},#{paymentPeriod},#{createdBy},now(),now())
                """;
        params.put("cusId",request.getCusId());
        params.put("fullName",request.getFullName());
        params.put("phone",request.getPhone());
        params.put("email",request.getEmail());
        params.put("paymentPeriod","0");
        params.put("createdBy",userId);

        return executeOnly(sqlConnection,sqlInsert,params);
    }

    @Override
    public Uni<Void> updateFicoEContractIfExits(CusManagementListResponse request, Connection connection) {
        Map<String, Object> params = new HashMap<>();
        String sql = " UPDATE ERP_AC.FICO_ECONTRACT SET LISTDAYOFWEEK = '0',PERIOD_PAYMENT = 3 where CUS_ID  =:cusId ";
        params.put("cusId", request.getCusId());
        return executeOnly(connection, sql, params).replaceWithVoid();
    }

    @Override
    public Uni<Void> insertPaymentPeriod(List<PartnerCusDTO> partnerCusDTOList, Connection connection) {
        try {
            String sqlInsPeriod = "  INSERT INTO ERP_AC.ERP_PAYMENT_PERIOD (PAYMENT_PERIOD_ID, PARTNER_EVTP, POST_ID, PARTNER_ID, PARTNER_GROUP_ID, TYPE_CONFIG, VALUE_CONFIG, CREATEDBY, UPDATEDBY, CREATED, UPDATED, ISACTIVE) " +
                                  "VALUES (ERP_AC.ERP_PAYMENT_PERIOD_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE,SYSDATE,'Y') ";

            return executeOnlyInsertOracleBatch(connection, sqlInsPeriod, partnerCusDTOList, batchSize, "cusId","convertValue","payCategoryConfigId")
                    .replaceWithVoid();
        } catch (Exception ex) {
            throw new BusinessException("Insert ERP_PAYMENT_PERIOD thất bại!");
        }

    }

    @Override
    public Multi<PartnerCusDTO> getListPartnerByCusId(CusManagementListResponse request, Connection connection) {
        List<Object> params = new ArrayList<>();
        params.add(request.getCusId());
        String sql = """
                select distinct a.EVTPCODE as PARTNER_EVTP, a.POST_ID, a.CUS_ID, b.PARTNER_GROUP_ID, b.PARTNER_ID
                from ERP_CUS.CUS_CUSTOMER_CODE a INNER JOIN
                     ERP_AC.ERP_PARTNER b on a.EVTPCODE = b.VALUE
                LEFT JOIN ERP_AC.ERP_PARTNER_BANK EPB ON EPB.VALUE = b.VALUE
                where a.EVTPCODE = b.VALUE
                  and a.CUS_ID = ? and b.ISACTIVE = 'Y' and EPB.ISACTIVE ='Y' and EPB.CREATEDBY = 312
                """;
        return executeMulti(connection, sql, params, PartnerCusDTO.class);
    }

    @Override
    public Uni<Void> inActivePeriodPayment(List<PartnerCusDTO> partnerCusDTOList, Connection connection) {
        try {
            String sql = "UPDATE ERP_AC.ERP_PAYMENT_PERIOD SET ISACTIVE = 'N' WHERE PARTNER_EVTP = :evtp ";
            return executeOracleBatchRaw(connection, sql, partnerCusDTOList, (rs, statement) -> {
                statement.bind("evtp", rs.getEvtp());
            }, batchSize).replaceWithVoid();
        } catch (Exception ex) {
            throw new BusinessException("Cập nhật ERP_PAYMENT_PERIOD thất bại!");
        }

    }

    @Override
    public Multi<AddPaymentPeriodCusRequest> getListInfoPaymentByCusExcel(List<AddPaymentPeriodCusRequest> requests) {
        List<Long> getListCus = requests.stream()
                .map(AddPaymentPeriodCusRequest::getCusId)
                .distinct()
                .filter(Objects::nonNull)
                .toList();
        String sql = "select distinct a.CUS_ID,a.PHONE,a.DISPLAYNAME,a.EMAIL,'0' PAYMENT_PERIOD,3 TYPE_CONFIG from ERP_CUS.CUS_CUSTOMER a where  (a.CUS_ID, 0) in (%s) and a.ACTIVE = 'Y' and not exists(select 1 " +
                     "                 from ERP_CUS.CUS_CUSTOMER_CODE c, " +
                     "                      ERP_AC.ERP_PAYMENT_PERIOD d " +
                     "                 where c.EVTPCODE = d.PARTNER_EVTP " +
                     "                   and d.TYPE_CONFIG = 3 " +
                     "                   and d.VALUE_CONFIG = '0' " +
                     "                   and d.ISACTIVE = 'Y' " +
                     "                   and c.CUS_ID = a.CUS_ID)";
        String placeholder = OracleUtils.genConditionInBigSize(getListCus.size());
        sql = sql.formatted(placeholder);
        List<Object> params = new ArrayList<>(getListCus);
        return executeMulti(oraclePool, sql, params, AddPaymentPeriodCusRequest.class);
    }

    @Override
    public Multi<PaymentPeriodDTO> getListPaymentPeriodByEvtp(List<PartnerCusDTO> evtps,Connection connection) {
        List<String> getListEvtp = evtps.stream()
                .map(PartnerCusDTO::getEvtp)
                .distinct()
                .filter(Objects::nonNull)
                .toList();
        String sql = " select TYPE_CONFIG,VALUE_CONFIG,PARTNER_EVTP,PARTNER_ID,POST_ID,PARTNER_GROUP_ID from ERP_AC.ERP_PAYMENT_PERIOD where (PARTNER_EVTP, 0) in (%s) and ISACTIVE='Y'";
        String placeholder = OracleUtils.genConditionInBigSize(evtps.size());
        sql = sql.formatted(placeholder);
        List<Object> params = new ArrayList<>(getListEvtp);
        return executeMulti(connection, sql, params, PaymentPeriodDTO.class);
    }

    @Override
    public Uni<Boolean> saveLogPaymentPeriodBms(List<BmsPaymentPeriodHis> result, SqlConnection sqlConnection) {
        String sql = """
                insert into bms_payment.bms_payment_period_his(cus_id,partner_id,partner_evtp,config_type_old,config_value_old,config_type_new,config_value_new,created_by,post_id,partner_group_id,pay_category_config_id,created_at,is_active,updated_at)\s
                values 
                """;
        String sqlParamBind = "(?,?,?,?,?,?,?,?,?,?,?,now(),1,now())";
        return executeOnlyInsertPostgreBatch(sqlConnection,sql,sqlParamBind,result,1000);
    }

    @Override
    public Multi<BmsPaymentPeriodHisMap> getListBmsPaymentPeriodHis(Long cusId,SqlConnection sqlConnection) {
        String sql = """
                select config_type_old,config_value_old,partner_evtp,cus_id,partner_id,post_id,partner_group_id,pay_category_config_id from bms_payment.bms_payment_period_his  where cus_id  = $1 and is_active  = 1
                """;
        return executeMulti(sqlConnection,sql,Tuple.of(cusId),BmsPaymentPeriodHisMap.class);
    }

    @Override
    public Uni<Void> updateLogCusBmsPeriod(SqlConnection sqlConnection, Long cusId) {
        String sql = "update bms_payment.bms_payment_period_his set is_active = 0,updated_at = now() where cus_id  = $1 and is_active  = 1 ";
        return executeOnly(sqlConnection,sql,Tuple.of(cusId)).replaceWithVoid();
    }



    @Override
    public Uni<Boolean> updateFicoEContractCancel(String paramCus,Long typeConfig,Long cusId,Connection connection) {
        String moreQuery = "";
        if(typeConfig == 1 || typeConfig == 3){
            moreQuery ="LISTDAYOFWEEK = :paramCus";
        }else if(typeConfig == 2){
            moreQuery ="LISTDAYOFMONTH = :paramCus";
        }
        Map<String, Object> params = new HashMap<>();
        String sql = " UPDATE ERP_AC.FICO_ECONTRACT SET PERIOD_PAYMENT=:paymentPeriod,"+ moreQuery +" where CUS_ID  =:cusId and PERIOD_PAYMENT = 3 and CONTRACT_TYPE = 1  ";
        params.put("paymentPeriod", typeConfig);
        params.put("paramCus",paramCus);
        params.put("cusId", cusId);
        return executeOnly(connection, sql, params);
    }

    @Override
    public Uni<Boolean> updateBmsDeclareCusPayment(SqlConnection sqlConnection, Long cusId,Long userId) {
        List<Object> params = new ArrayList<>();
        params.add(userId);
        params.add(cusId);
        String sql = """
                update bms_payment.bms_declare_cus_payment set active  = 0,updated_by= $1,updated_at = now() where cus_id = $2 and active  = 1
                """;
        return executeOnly(sqlConnection,sql,Tuple.from(params));
    }

    @Override
    public Multi<AddPaymentPeriodCusRequest> getListCusInfoPayment(List<AddPaymentPeriodCusRequest> requests) {
        List<Long> getListCus = requests.stream()
                .map(AddPaymentPeriodCusRequest::getCusId)
                .distinct()
                .filter(Objects::nonNull)
                .toList();
        String sql = """
                select distinct a.CUS_ID from ERP_CUS.CUS_CUSTOMER a where  (a.CUS_ID, 0) in (%s) and a.ACTIVE = 'Y' and exists(select 1 from ERP_AC.FICO_ECONTRACT z where CONTRACT_TYPE = 1 and z.CUS_ID = a.CUS_ID )
                """;
        String placeholder = OracleUtils.genConditionInBigSize(getListCus.size());
        sql = sql.formatted(placeholder);
        List<Object> params = new ArrayList<>(getListCus);
        return executeMulti(oraclePool,sql,params,AddPaymentPeriodCusRequest.class);
    }

    @Override
    public Uni<Integer> checkCusHDDT(Long cusId) {
        Map<String, Object> params = new HashMap<>();
        params.put("cusId", cusId);
        String sql = """
                select count(1) count from ERP_AC.FICO_ECONTRACT where CUS_ID =:cusId and CONTRACT_TYPE = 1
                """;
        return executeAndGetValue(oraclePool,sql,params,"count",Integer.class);
    }

    @Override
    public Multi<CusDeclareListResponse> getListManagementCusDeclareExcel(CusManagementRequest request) {
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        boolean flag = false;
        int paramIndex = 1;
        if (request.getCusId() != null) {
            moreQuery.append(" a.cus_id  = $").append(paramIndex);
            params.add(request.getCusId());
            flag = true;
        }
        if (request.getSearchParam() != null && SearchRequestType.EMAIL.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            if (flag) {
                paramIndex++;
                moreQuery.append(" and ");
            }
            List<String> emailList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery.append(" email = any($").append(paramIndex).append(")");

            params.add(emailList.toArray());
            flag = true;
        }
        if (request.getSearchParam() != null && SearchRequestType.PHONE.equals(request.getSearchParam().getSearch()) && !request.getSearchParam().getPhoneEmails().isEmpty()) {
            if (flag) {
                paramIndex++;
                moreQuery.append(" and ");
            }
            List<String> phoneList = List.of(request.getSearchParam().getPhoneEmails().split("[,\\s]+"));
            moreQuery.append(" phone = any($").append(paramIndex).append(")");
            params.add(phoneList.toArray());
            flag = true;
        }

        moreQuery.append(" order by updated_at desc");
        if (flag) {
            moreQuery = new StringBuilder(" where " + moreQuery);
        }
        String sql = " select cus_id,email,phone,full_name,payment_type,payment_period,to_char(updated_at,'dd/MM/yyyy HH24:MI:ss') as updated_declare,to_char(created_at ,'dd/MM/yyyy') as created_declare, " +
                     " bms_payment.get_fullname_by_userid(created_by) as created_by,payment_type " +
                     " from bms_payment.bms_declare_cus_payment a  " + moreQuery;
        return executeMulti(client, sql, Tuple.from(params), CusDeclareListResponse.class);
    }

    @Override
    public Multi<FicoPayPeriodHisDTO> getConfigTypeHis(Connection connection, Long cusId) {
        String sql = "select CONFIG_TYPE_OLD, CONFIG_VALUE_OLD\n" +
                     "from ERP_AC.FICO_PAY_PERIOD_HIS\n" +
                     "where CUS_ID = ? \n" +
                     "  and DOC_TYPE = 1\n" +
                     "  and PAY_CATEGORY_CONFIG_ID = 12\n" +
                     "order by PAY_PERIOD_HIS_ID desc ";
        List<Object> params = new ArrayList<>();
        params.add(cusId);
        return executeMulti(connection, sql, params, FicoPayPeriodHisDTO.class);
    }

    @Override
    public Uni<Boolean> insertFicoPayPeriodHis(Connection connection, List<FicoPayPeriodHisDTO> ficoPayPeriodHisDTOList) {
        try {
            String sql = """
                    INSERT INTO ERP_AC.FICO_PAY_PERIOD_HIS (PAY_PERIOD_HIS_ID, CUS_ID, PARTNER_ID, PARTNER_EVTP,
                                       PARTNER_GROUP_ID, PAY_CATEGORY_CONFIG_ID, CONFIG_TYPE_OLD,
                                       CONFIG_VALUE_OLD, CONFIG_TYPE_NEW, CONFIG_VALUE_NEW, POST_ID, DOC_TYPE,
                                       UPDATED_AT, UPDATED_BY)
                                       VALUES (ERP_AC.FICO_PAY_PERIOD_HIS_SEQ.NEXTVAL, ?, ?, ?, 1, 12, ?, ?, ?, ?, ?, 1, SYSDATE, ?)
                    """;
            return executeOnlyInsertOracleBatch(connection, sql, ficoPayPeriodHisDTOList, batchSize,"payCategoryConfigId","updateByName","updateAt","updateTime","payType","bankName","accountNo","beneficiary","configTypeNewName");
        } catch (Exception ex) {
            throw new BusinessException("Insert ERP_PAYMENT_PERIOD thất bại!");
        }
    }

    @Override
    public Multi<FicoPayPeriodHisDTO> getListEditPeriodHis(Long cusId) {
        String sql = """
                select a.CUS_ID,
                                         CONFIG_TYPE_NEW,
                                         (SELECT CATEGORY_NAME FIRSTNAME
                                          FROM ERP_AC.FICO_PAY_CATEGORY_CONFIG
                                          WHERE PAY_CATEGORY_CONFIG_ID = CONFIG_TYPE_NEW
                                            AND ROWNUM = 1)          as      CONFIG_TYPE_NAME_NEW,
                                         CONFIG_VALUE_NEW,
                                         TO_CHAR(UPDATED_AT, 'dd/MM/yyyy HH24:MI:SS') as UPDATED_TIME,
                                         UPDATED_AT,
                                         UPDATED_BY ,
                                         (SELECT LASTNAME || ' ' || FIRSTNAME
                                          FROM ERP_CUS.CUS_CUSTOMER
                                          WHERE CUS_ID = UPDATED_BY
                                            AND ROWNUM = 1)          as      UPDATE_BY_NAME,
                                         b.BENEFICIARY ,
                                         b.ACCOUNTBANKNO as ACCOUNT_NO ,
                                         1                                 PAY_TYPE,
                                         b.BANKNAME as BANK_NAME
                                  FROM ERP_AC.FICO_PAY_PERIOD_HIS a
                                           left join ERP_AC.FICO_ECONTRACT b on a.CUS_ID = b.CUS_ID
                                  WHERE a.CUS_ID = :cusId
                                    AND a.PAY_CATEGORY_CONFIG_ID = 12 and b.CONTRACT_TYPE = 1
                                    and a.DOC_TYPE = 1 order by a.PAY_PERIOD_HIS_ID desc
                """;
        List<Object> params = new ArrayList<>();
        params.add(cusId);
        return executeMulti(oraclePool,sql,params,FicoPayPeriodHisDTO.class);
    }

    @Override
    public Uni<Boolean> saveLogFileExcel(UploadFileResponse response, Long userId,String note,Long totalRecord,int status) {
        List<Object> params = new ArrayList<>();
        params.add(response.getExtension());
        params.add(response.getFileName());
        params.add(response.getUrlFile());
        params.add("EXCEL_DECLARE_CUS");
        params.add(userId);
        params.add(response.getFileSize());
        params.add(note);
        params.add(totalRecord);
        params.add(status);
        params.add(response.getPathFile());
        String sql = """
                insert into bms_payment.bms_file_storage (file_type,file_name,file_url,tenant_id,"type",created_at,created_by,updated_at,file_size,note,total_record,file_status,path_file) values ($1,$2,$3,1,$4,now(),$5,now(),$6,$7,$8,$9,$10)
                """;
        return executeOnly(client,sql,Tuple.from(params));
    }

    @Override
    public Uni<Long> getCountFileUploadHis() {
        String sql = """
                select count(1) as count from bms_payment.bms_file_storage where "type" = 'EXCEL_DECLARE_CUS'
                """;
        return executeAndGetValue(client,sql,Tuple.from(new ArrayList<>()),"count",Long.class);
    }

    @Override
    public Multi<DeclareUploadHisResponse> getListFileUploadHis(Integer page, Integer size) {
        List<Object> params = new ArrayList<>();
        params.add(size);
        params.add((page - 1) * size);
        String sql = """
                select file_type,file_name,file_status,file_url,note,total_record,to_char(updated_at,'dd/MM/yyyy HH24:MI:SS') created_time,
                bms_payment.get_fullname_by_userid(created_by) full_name from bms_payment.bms_file_storage where "type" = 'EXCEL_DECLARE_CUS' order by updated_at desc  limit $1 offset $2
                """;
        return executeMulti(client,sql,Tuple.from(params),DeclareUploadHisResponse.class);
    }

    @Override
    public Uni<Integer> checkCusPaymentEveryDay(Long cusId) {
        Map<String,Object> params = new HashMap<>();
        params.put("cusId", cusId);
        String sql = """
                select count(1) as count
                from ERP_CUS.CUS_CUSTOMER a
                where a.CUS_ID = :cusId
                  and a.ACTIVE = 'Y'
                  and exists(select 1
                             from ERP_CUS.CUS_CUSTOMER_CODE c,
                                  ERP_AC.ERP_PAYMENT_PERIOD d
                             where c.EVTPCODE = d.PARTNER_EVTP
                               and d.TYPE_CONFIG = 3
                               and d.VALUE_CONFIG = '0'
                               and d.ISACTIVE = 'Y'
                               and c.CUS_ID = a.CUS_ID)
             
                """;
        return executeAndGetValue(oraclePool,sql,params,"count",Integer.class);
    }



    /*@Override
    public Uni<Long> checkCusIdExitsConfigAuto(Long cusId, Connection connection) {
        String sql = """
                select count(1) count
                from ERP_CUS.CUS_CUSTOMER_CODE c
                where c.CUS_ID = :cusId
                  and exists(select 1
                             from ERP_AC.ERP_PAYMENT_PERIOD d
                             where d.PARTNER_EVTP = c.EVTPCODE
                               and d.TYPE_CONFIG = 3
                               and d.VALUE_CONFIG = '0' and ISACTIVE = 'Y')
                """;
        return execute;
    }*/
}
