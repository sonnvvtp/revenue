package com.viettelpost.platform.bms.portal.common.utils;

import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.infrastructure.Infrastructure;

public class ThreadUtils {

    public static void runInOtherThread(Runnable runnable) {
        Uni.createFrom()
                .voidItem()
                .invoke(runnable)
                .runSubscriptionOn(Infrastructure.getDefaultExecutor())
                .subscribe().with(
                        unused -> {},
                        Throwable::printStackTrace
                );
    }

}
