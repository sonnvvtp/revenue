package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class MaSoThueInfo {

    @JsonProperty("BP_GET_LISTS")
    List<BP_GET_LIST> BP_GET_LISTS = new ArrayList<>();

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BP_GET_LIST {

        @JsonProperty("SEQ")
        String SEQ;

        @JsonProperty("VAT_REGISTRATION_NO")
        String VAT_REGISTRATION_NO;
    }
}