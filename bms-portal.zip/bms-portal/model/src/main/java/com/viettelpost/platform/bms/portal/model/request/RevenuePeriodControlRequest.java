package com.viettelpost.platform.bms.portal.model.request;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Data;

@Data
public class RevenuePeriodControlRequest {
    public Long id;
    public Integer tenantId;
    public Long createdBy;
    public LocalDateTime createdAt;
    public Long updatedBy;
    public LocalDateTime updatedAt;
    public BigDecimal periodId;
    public String periodStatus;
    public Long doctypeId;
    public String active;
    public LocalDateTime startDate;
    public LocalDateTime endDate;
}
