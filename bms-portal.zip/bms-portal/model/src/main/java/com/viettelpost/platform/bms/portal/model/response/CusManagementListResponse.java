package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CusManagementListResponse {
    @JsonAlias({"CUS_ID","cus_id"})
    private Long cusId;

    @JsonAlias({"PHONE","phone"})
    private String phone;

    @JsonAlias({"DISPLAYNAME","full_name"})
    private String fullName;

    @JsonAlias({"EMAIL","email"})
    private String email;

    @JsonAlias({"PERIOD_PAYMENT","payment_period"})
    private String periodPayment;

    @JsonAlias("BANKNAME")
    private String bankName;

    @JsonAlias("BANK_BRANCH")
    private String bankBranch;

    @JsonAlias("ACCOUNTBANKNO")
    private String accountNo;

    @JsonAlias("BENEFICIARY")
    private String beneficiary;

    @JsonAlias("PAYMENT_TEAM")
    private Long paymentType;

    @JsonAlias("PERIOD")
    private Long period;

    private String reason;


}
