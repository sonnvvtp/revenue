package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class GroupRevenueInvoiceDTO {
    @JsonAlias("buyer_code")
    private String buyerCode;

    @JsonAlias("unit_level1_id")
    private Long unitLevel1Id;

    @JsonAlias("unit_level2_id")
    private Long unitLevel2Id;

    @JsonAlias("total_bill")
    private Integer totalBill;

    @JsonAlias("amount_before_tax")
    private BigDecimal amountBeforeTax;

    @JsonAlias("tax_amount")
    private BigDecimal taxAmount;

    @JsonAlias("amount_after_tax")
    private BigDecimal amountAfterTax;

    @JsonAlias("record_source")
    private String recordSource;

    @JsonAlias("records")
    private JsonNode records;
}
