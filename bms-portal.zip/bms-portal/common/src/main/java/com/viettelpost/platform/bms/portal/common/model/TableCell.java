package com.viettelpost.platform.bms.portal.common.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Setter
@Builder
public class TableCell {

    @Getter
    private List<HeaderCell> headerCells;

    @Getter
    private Font font;

    @Getter
    private BorderStyle borderStyle;

    private List<Object[]> data;

    private List<?> rowData;

    private boolean usingRowData;

    private Class<?> rowClass;

    public Object[][] getData() {
        List<Object[]> result = new ArrayList<>();
        result.add(headerCells.stream().map(HeaderCell::getName).toArray(String[]::new));
        if (usingRowData) {

            if (Objects.isNull(rowClass)) {
                throw new RuntimeException("Row class is null");
            }

            List<Object[]> data = new ArrayList<>();
            int count = 1;
            for (Object object : rowData) {
                Object[] row = new Object[headerCells.size()];
                for (int i = 0; i < headerCells.size(); i++) {
                    HeaderCell headerCell = headerCells.get(i);
                    String fieldName = headerCell.getFieldName();
                    boolean isSerialNumber = headerCell.isSerialNumber();
                    String methodGet = "get" + StringUtils.capitalize(fieldName);
                    if (isSerialNumber) {
                        row[i] = count;
                    } else {
                        Object value = null;
                        try {
                            value = rowClass.getMethod(methodGet).invoke(object);
                        } catch (Exception ignored) {
                        }
                        row[i] = value;
                    }
                }
                count++;
                data.add(row);
            }

            result.addAll(data);
        } else {
            result.addAll(data);
        }

        return result.toArray(new Object[result.size()][]);
    }
}
