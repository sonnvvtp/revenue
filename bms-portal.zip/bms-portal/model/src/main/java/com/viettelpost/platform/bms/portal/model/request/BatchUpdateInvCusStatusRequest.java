package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

import java.util.List;

@Data
public class BatchUpdateInvCusStatusRequest {
    private List<Long> customerIds;
    private Long statusCode;
}
