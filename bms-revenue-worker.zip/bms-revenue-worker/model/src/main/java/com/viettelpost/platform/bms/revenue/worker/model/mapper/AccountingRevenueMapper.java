package com.viettelpost.platform.bms.revenue.worker.model.mapper;

import com.viettelpost.platform.bms.revenue.worker.common.enums.GroupServiceType;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueAccountingType;
import com.viettelpost.platform.bms.revenue.worker.common.enums.TaxCodeType;
import com.viettelpost.platform.bms.revenue.worker.common.utils.DateUtils;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RevenueStatementSapDTO;
import com.viettelpost.platform.bms.revenue.worker.model.model.Pair;
import com.viettelpost.platform.bms.revenue.worker.model.request.accounting.RawAcctDetailRequest;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class AccountingRevenueMapper {

  // DTNB - Doanh thu nội bộ
  // DTCHT - Doanh thu chưa hoàn thành
  // DTCKCHT - Doanh thu chiết khấu chưa hoàn thành
  public static List<RawAcctDetailRequest> convertDTCHToRawAcctDetailRequest(RevenueStatementSapDTO statementSapDTO, Map<String,
          String> serviceMap, Map<String, Integer> dichVuMap, LocalDate endOfMonth, List<String> serviceCodeNoApplyTax, List<String> serviceCodeGtbs) {
      List<RawAcctDetailRequest> listRaws = new ArrayList<>();
      LocalDate finalBaselineDate = Objects.nonNull(statementSapDTO.getRecordRevenueEntryAt()) ? DateUtils.getLocalDateBy(statementSapDTO.getRecordRevenueEntryAt()) : endOfMonth;
      Pair<String, String> pair = getUnitLevel1ServiceCode(statementSapDTO, serviceMap);

      if (serviceCodeGtbs.contains(statementSapDTO.getServiceCode())) {
        Pair<BigDecimal, BigDecimal> pairVat = calculateVatAmount(dichVuMap,
            statementSapDTO.getServiceCode(), statementSapDTO.getStatementAmountDiscount());
        // Doanh thu
        listRaws.add(
            RawAcctDetailRequest.builder()
                .refNumber("DTGTBS_" + statementSapDTO.getId())
                .refNumberParent(String.valueOf(statementSapDTO.getId()))
                .refDocNo(RevenueAccountingType.DTGTBS.getCode())
                .bkC1(statementSapDTO.getStatementCode())
                .bkC2(statementSapDTO.getStatementLevel2Code())
                .transactionCode(statementSapDTO.getStatementCode())
                .xref2Hd(statementSapDTO.getStatementLevel2Code())
                .xref1Hd(String.valueOf(statementSapDTO.getId()))
                .xref1("")
                .xref2("")
                .xref3("")
                .customerCode(statementSapDTO.getCustomerCode())
                .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                .postId1(statementSapDTO.getUnitLevel1Id())
                .orgId1(statementSapDTO.getUnitLevel2Id())
                .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                .baseLineDate(finalBaselineDate)
                .accountingDate(LocalDate.now().atStartOfDay())
                .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(),
                    serviceCodeNoApplyTax))
                .payAmount(negativeBigdecimal(pairVat.getFirst()))
                .baseAmount(negativeBigdecimal(pairVat.getFirst()))
                .partnerCode(statementSapDTO.getCustomerCode())
                .companyCode(statementSapDTO.getCompanyCode()) // TCT
                .serviceCode(statementSapDTO.getServiceCode())
                .unit1(pair.getFirst())
                .unit2("DT")
                .bpCode1(statementSapDTO.getCustomerCode())
                .bpCode2(statementSapDTO.getCustomerCode())
                .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                .typeBpCode2(1)
                .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                .description(statementSapDTO.getDescription())
                .channel("TCT")
                .valueProfitability(
                    Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                .build()
        );
        // VAT
        if (!GroupServiceType.CPQT.getCode().equals(pair.getFirst())) {
          listRaws.add(
              RawAcctDetailRequest.builder()
                  .refNumber("DTGTBS_VAT_" + statementSapDTO.getId())
                  .refNumberParent(String.valueOf(statementSapDTO.getId()))
                  .refDocNo(RevenueAccountingType.DTGTBS.getCode())
                  .bkC1(statementSapDTO.getStatementCode())
                  .bkC2(statementSapDTO.getStatementLevel2Code())
                  .transactionCode(statementSapDTO.getStatementCode())
                  .xref2Hd(statementSapDTO.getStatementLevel2Code())
                  .xref1Hd(String.valueOf(statementSapDTO.getId()))
                  .xref1("")
                  .xref2("")
                  .xref3("")
                  .customerCode(statementSapDTO.getCustomerCode())
                  .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                  .postId1(statementSapDTO.getUnitLevel1Id())
                  .orgId1(statementSapDTO.getUnitLevel2Id())
                  .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                  .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                  .baseLineDate(finalBaselineDate)
                  .accountingDate(LocalDate.now().atStartOfDay())
                  .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                  .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(),
                      serviceCodeNoApplyTax))
                  .payAmount(negativeBigdecimal(pairVat.getSecond()))
                  .baseAmount(negativeBigdecimal(pairVat.getFirst()))
                  .partnerCode(statementSapDTO.getCustomerCode())
                  .companyCode(statementSapDTO.getCompanyCode()) // TCT
                  .serviceCode(statementSapDTO.getServiceCode())
                  .unit1(pair.getFirst())
                  .unit2("VAT")
                  .bpCode1(statementSapDTO.getCustomerCode())
                  .bpCode2(statementSapDTO.getCustomerCode())
                  .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                  .typeBpCode2(1)
                  .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                  .description(statementSapDTO.getDescription())
                  .channel("TCT")
                  .valueProfitability(
                      Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                  .build()
          );
        }
      }
      else {
        // DTCHT - Doanh thu chưa hoàn thành
        listRaws.add(
            RawAcctDetailRequest.builder()
                .refNumber("DTCHT_" + statementSapDTO.getId())
                .refNumberParent(String.valueOf(statementSapDTO.getId()))
                .refDocNo(RevenueAccountingType.DTCHT.getCode())
                .bkC1(statementSapDTO.getStatementCode())
                .bkC2(statementSapDTO.getStatementLevel2Code())
                .transactionCode(statementSapDTO.getStatementCode())
                .xref2Hd(statementSapDTO.getStatementLevel2Code())
                .xref1Hd(String.valueOf(statementSapDTO.getId()))
                .xref1("")
                .xref2("")
                .xref3("")
                .customerCode(statementSapDTO.getCustomerCode())
                .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                .postId1(statementSapDTO.getUnitLevel1Id())
                .orgId1(statementSapDTO.getUnitLevel2Id())
                .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                .baseLineDate(finalBaselineDate)
                .accountingDate(LocalDate.now().atStartOfDay())
                .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(),
                    serviceCodeNoApplyTax))
                .payAmount(statementSapDTO.getStatementAmountBeforeTax())
                .baseAmount(statementSapDTO.getStatementAmountBeforeTax())
                .partnerCode(statementSapDTO.getCustomerCode())
                .companyCode(statementSapDTO.getCompanyCode()) // TCT
                .serviceCode(statementSapDTO.getServiceCode())
                .unit1(pair.getFirst())
                .unit2("DT")
                .bpCode1(statementSapDTO.getCustomerCode())
                .bpCode2(statementSapDTO.getCustomerCode())
                .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                .typeBpCode2(1)
                .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                .description(statementSapDTO.getDescription())
                .channel("TCT")
                .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                .build()
        );
        // VAT
        if (!GroupServiceType.CPQT.getCode().equals(pair.getFirst())) {
          listRaws.add(
              RawAcctDetailRequest.builder()
                  .refNumber("DTCHT_VAT_" + statementSapDTO.getId())
                  .refNumberParent(String.valueOf(statementSapDTO.getId()))
                  .refDocNo(RevenueAccountingType.DTCHT.getCode())
                  .bkC1(statementSapDTO.getStatementCode())
                  .bkC2(statementSapDTO.getStatementLevel2Code())
                  .transactionCode(statementSapDTO.getStatementCode())
                  .xref2Hd(statementSapDTO.getStatementLevel2Code())
                  .xref1Hd(String.valueOf(statementSapDTO.getId()))
                  .xref1("")
                  .xref2("")
                  .xref3("")
                  .customerCode(statementSapDTO.getCustomerCode())
                  .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                  .postId1(statementSapDTO.getUnitLevel1Id())
                  .orgId1(statementSapDTO.getUnitLevel2Id())
                  .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                  .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                  .baseLineDate(finalBaselineDate)
                  .accountingDate(LocalDate.now().atStartOfDay())
                  .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                  .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(),
                      serviceCodeNoApplyTax))
                  .payAmount(bigdecimalWithDefault(statementSapDTO.getStatementTaxAmount()))
                  .baseAmount(bigdecimalWithDefault(statementSapDTO.getStatementAmountBeforeTax()))
                  .partnerCode(statementSapDTO.getCustomerCode())
                  .companyCode(statementSapDTO.getCompanyCode()) // TCT
                  .serviceCode(statementSapDTO.getServiceCode())
                  .unit1(pair.getFirst())
                  .unit2("VAT")
                  .bpCode1(statementSapDTO.getCustomerCode())
                  .bpCode2(statementSapDTO.getCustomerCode())
                  .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                  .typeBpCode2(1)
                  .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                  .description(statementSapDTO.getDescription())
                  .channel("TCT")
                  .valueProfitability(
                      Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                  .build()
          );
        }

        // DTCKCHT - Doanh thu chiết khấu chưa hoàn thành
        if (statementSapDTO.getStatementAmountDiscount() != null
            && statementSapDTO.getStatementAmountDiscount().compareTo(BigDecimal.ZERO) > 0) {
          Pair<BigDecimal, BigDecimal> pairVat = calculateVatAmount(dichVuMap,
              statementSapDTO.getServiceCode(), statementSapDTO.getStatementAmountDiscount());
          // Doanh thu
          listRaws.add(
              RawAcctDetailRequest.builder()
                  .refNumber("DTCKCHT_" + statementSapDTO.getId())
                  .refNumberParent(String.valueOf(statementSapDTO.getId()))
                  .refDocNo(RevenueAccountingType.DTCKCHT.getCode())
                  .bkC1(statementSapDTO.getStatementCode())
                  .bkC2(statementSapDTO.getStatementLevel2Code())
                  .transactionCode(statementSapDTO.getStatementCode())
                  .xref2Hd(statementSapDTO.getStatementLevel2Code())
                  .xref1Hd(String.valueOf(statementSapDTO.getId()))
                  .xref1("")
                  .xref2("")
                  .xref3("")
                  .customerCode(statementSapDTO.getCustomerCode())
                  .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                  .postId1(statementSapDTO.getUnitLevel1Id())
                  .orgId1(statementSapDTO.getUnitLevel2Id())
                  .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                  .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                  .baseLineDate(finalBaselineDate)
                  .accountingDate(LocalDate.now().atStartOfDay())
                  .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                  .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(),
                      serviceCodeNoApplyTax))
                  .payAmount(negativeBigdecimal(pairVat.getFirst()))
                  .baseAmount(negativeBigdecimal(pairVat.getFirst()))
                  .partnerCode(statementSapDTO.getCustomerCode())
                  .companyCode(statementSapDTO.getCompanyCode()) // TCT
                  .serviceCode(statementSapDTO.getServiceCode())
                  .unit1(pair.getFirst())
                  .unit2("DT")
                  .bpCode1(statementSapDTO.getCustomerCode())
                  .bpCode2(statementSapDTO.getCustomerCode())
                  .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                  .typeBpCode2(1)
                  .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                  .description(statementSapDTO.getDescription())
                  .channel("TCT")
                  .valueProfitability(
                      Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                  .build()
          );
          // VAT
          if (!GroupServiceType.CPQT.getCode().equals(pair.getFirst())) {
            listRaws.add(
                RawAcctDetailRequest.builder()
                    .refNumber("DTCKCHT_VAT_" + statementSapDTO.getId())
                    .refNumberParent(String.valueOf(statementSapDTO.getId()))
                    .refDocNo(RevenueAccountingType.DTCKCHT.getCode())
                    .bkC1(statementSapDTO.getStatementCode())
                    .bkC2(statementSapDTO.getStatementLevel2Code())
                    .transactionCode(statementSapDTO.getStatementCode())
                    .xref2Hd(statementSapDTO.getStatementLevel2Code())
                    .xref1Hd(String.valueOf(statementSapDTO.getId()))
                    .xref1("")
                    .xref2("")
                    .xref3("")
                    .customerCode(statementSapDTO.getCustomerCode())
                    .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                    .postId1(statementSapDTO.getUnitLevel1Id())
                    .orgId1(statementSapDTO.getUnitLevel2Id())
                    .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                    .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                    .baseLineDate(finalBaselineDate)
                    .accountingDate(LocalDate.now().atStartOfDay())
                    .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                    .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(),
                        serviceCodeNoApplyTax))
                    .payAmount(negativeBigdecimal(pairVat.getSecond()))
                    .baseAmount(negativeBigdecimal(pairVat.getFirst()))
                    .partnerCode(statementSapDTO.getCustomerCode())
                    .companyCode(statementSapDTO.getCompanyCode()) // TCT
                    .serviceCode(statementSapDTO.getServiceCode())
                    .unit1(pair.getFirst())
                    .unit2("VAT")
                    .bpCode1(statementSapDTO.getCustomerCode())
                    .bpCode2(statementSapDTO.getCustomerCode())
                    .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                    .typeBpCode2(1)
                    .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                    .description(statementSapDTO.getDescription())
                    .channel("TCT")
                    .valueProfitability(
                        Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                    .build()
            );
          }
        }
      }
    return listRaws;
  }

  // DTHT_KTTC - Doanh thu hoàn thành - loại ko có trạng thái cuối
  // DTCKHT_KTTC - Doanh thu chiết khấu hoàn thành  - loại ko có trạng thái cuối
  public static List<RawAcctDetailRequest> convertDTHT_KTTCToRawAcctDetailRequest(RevenueStatementSapDTO statementSapDTO, Map<String, String> serviceMap,
      Map<String, Integer> dichVuMap, LocalDate endOfMonth, List<String> serviceCodeNoApplyTax, List<String> serviceCodeGtbs) {
    List<RawAcctDetailRequest> listRaws = new ArrayList<>();
    LocalDate finalBaselineDate = Objects.nonNull(statementSapDTO.getRecordRevenueEntryAt()) ? DateUtils.getLocalDateBy(statementSapDTO.getRecordRevenueEntryAt()) : endOfMonth;

    // DTNB - Doanh thu nội bộ
    if ("VNB".equalsIgnoreCase(statementSapDTO.getServiceCode())) {
      listRaws.add(RawAcctDetailRequest.builder()
          .refNumber("DTNB_" + statementSapDTO.getId())
          .refNumberParent(String.valueOf(statementSapDTO.getId()))
          .refDocNo(RevenueAccountingType.DTNB.getCode())
          .bkC1(statementSapDTO.getStatementCode())
          .bkC2(statementSapDTO.getStatementLevel2Code())
          .transactionCode(statementSapDTO.getStatementCode())
          .xref2Hd(statementSapDTO.getStatementLevel2Code())
          .xref1Hd(String.valueOf(statementSapDTO.getId()))
          .xref1("")
          .xref2("")
          .xref3("")
          .customerCode(statementSapDTO.getCustomerCode())
          .docDate(statementSapDTO.getCreatedAt().toLocalDate())
          .postId1(statementSapDTO.getUnitLevel1Id())
          .orgId1(statementSapDTO.getUnitLevel2Id())
          .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
          .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
          .baseLineDate(finalBaselineDate)
          .accountingDate(LocalDate.now().atStartOfDay())
          .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
          .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
          .payAmount(statementSapDTO.getStatementAmountBeforeTax())
          .partnerCode(statementSapDTO.getCustomerCode())
          .companyCode(statementSapDTO.getCompanyCode()) // TCT
          .serviceCode("VNB")
          .unit1(statementSapDTO.getGroupService())
          .bpCode1(statementSapDTO.getCustomerCode())
          .bpCode2(statementSapDTO.getCustomerCode())
          .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
          .typeBpCode2(1)
          .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
          .description(statementSapDTO.getDescription())
          .channel("TCT")
          .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
          .build());
    }
    else {
      Pair<String, String> pair = getUnitLevel1ServiceCode(statementSapDTO, serviceMap);
      // DTCHT - Doanh thu chưa hoàn thành
      listRaws.add(
          RawAcctDetailRequest.builder()
              .refNumber("DTHT_KTTC_" + statementSapDTO.getId())
              .refNumberParent(String.valueOf(statementSapDTO.getId()))
              .refDocNo(RevenueAccountingType.DTHT_KTTC.getCode())
              .bkC1(statementSapDTO.getStatementCode())
              .bkC2(statementSapDTO.getStatementLevel2Code())
              .transactionCode(statementSapDTO.getStatementCode())
              .xref2Hd(statementSapDTO.getStatementLevel2Code())
              .xref1Hd(String.valueOf(statementSapDTO.getId()))
              .xref1("")
              .xref2("")
              .xref3("")
              .customerCode(statementSapDTO.getCustomerCode())
              .docDate(statementSapDTO.getCreatedAt().toLocalDate())
              .postId1(statementSapDTO.getUnitLevel1Id())
              .orgId1(statementSapDTO.getUnitLevel2Id())
              .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
              .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
              .baseLineDate(finalBaselineDate)
              .accountingDate(LocalDate.now().atStartOfDay())
              .postingDate(endOfMonth)
  //        .transactionCode("")
  //        .paymentAccountNo("")
              .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
              .payAmount(statementSapDTO.getStatementAmountBeforeTax())
              .baseAmount(statementSapDTO.getStatementAmountBeforeTax())
              .partnerCode(statementSapDTO.getCustomerCode())
              .companyCode(statementSapDTO.getCompanyCode()) // TCT
              .serviceCode(statementSapDTO.getServiceCode())
              .unit1(pair.getFirst())
              .unit2("DT")
              .bpCode1(statementSapDTO.getCustomerCode())
              .bpCode2(statementSapDTO.getCustomerCode())
              .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
              .typeBpCode2(1)
              .refDate(statementSapDTO.getCreatedAt())
  //        .assignment(assignment)
              .description(statementSapDTO.getDescription())
              .channel("TCT")
              .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
              .build()
      );
      // VAT
      listRaws.add(
          RawAcctDetailRequest.builder()
              .refNumber("DTHT_KTTC_VAT_" + statementSapDTO.getId())
              .refNumberParent(String.valueOf(statementSapDTO.getId()))
              .refDocNo(RevenueAccountingType.DTHT_KTTC.getCode())
              .bkC1(statementSapDTO.getStatementCode())
              .bkC2(statementSapDTO.getStatementLevel2Code())
              .transactionCode(statementSapDTO.getStatementCode())
              .xref2Hd(statementSapDTO.getStatementLevel2Code())
              .xref1Hd(String.valueOf(statementSapDTO.getId()))
              .xref1("")
              .xref2("")
              .xref3("")
              .customerCode(statementSapDTO.getCustomerCode())
              .docDate(statementSapDTO.getCreatedAt().toLocalDate())
              .postId1(statementSapDTO.getUnitLevel1Id())
              .orgId1(statementSapDTO.getUnitLevel2Id())
              .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
              .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
              .baseLineDate(finalBaselineDate)
              .accountingDate(LocalDate.now().atStartOfDay())
              .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
              .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
              .payAmount(bigdecimalWithDefault(statementSapDTO.getStatementTaxAmount()))
              .baseAmount(bigdecimalWithDefault(statementSapDTO.getStatementAmountBeforeTax()))
              .partnerCode(statementSapDTO.getCustomerCode())
              .companyCode(statementSapDTO.getCompanyCode()) // TCT
              .serviceCode(statementSapDTO.getServiceCode())
              .unit1(pair.getFirst())
              .unit2("VAT")
              .bpCode1(statementSapDTO.getCustomerCode())
              .bpCode2(statementSapDTO.getCustomerCode())
              .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
              .typeBpCode2(1)
              .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
              .description(statementSapDTO.getDescription())
              .channel("TCT")
              .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
              .build()
      );
      // DTCKCHT - Doanh thu chiết khấu chưa hoàn thành
      if (statementSapDTO.getStatementAmountDiscount() != null && statementSapDTO.getStatementAmountDiscount().compareTo(BigDecimal.ZERO) > 0) {
        Pair<BigDecimal, BigDecimal> pairVat = calculateVatAmount(dichVuMap,
            statementSapDTO.getServiceCode(), statementSapDTO.getStatementAmountDiscount());
        // Doanh thu
        listRaws.add(
            RawAcctDetailRequest.builder()
                .refNumber("DTCKHT_KTTC_" + statementSapDTO.getId())
                .refNumberParent(String.valueOf(statementSapDTO.getId()))
                .refDocNo(RevenueAccountingType.DTCKHT_KTTC.getCode())
                .bkC1(statementSapDTO.getStatementCode())
                .bkC2(statementSapDTO.getStatementLevel2Code())
                .transactionCode(statementSapDTO.getStatementCode())
                .xref2Hd(statementSapDTO.getStatementLevel2Code())
                .xref1Hd(String.valueOf(statementSapDTO.getId()))
                .xref1("")
                .xref2("")
                .xref3("")
                .customerCode(statementSapDTO.getCustomerCode())
                .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                .postId1(statementSapDTO.getUnitLevel1Id())
                .orgId1(statementSapDTO.getUnitLevel2Id())
                .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                .baseLineDate(finalBaselineDate)
                .accountingDate(LocalDate.now().atStartOfDay())
                .postingDate(endOfMonth)
  //        .transactionCode("")
  //        .paymentAccountNo("")
                .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
                .payAmount(negativeBigdecimal(pairVat.getFirst()))
                .baseAmount(negativeBigdecimal(pairVat.getFirst()))
                .partnerCode(statementSapDTO.getCustomerCode())
                .companyCode(statementSapDTO.getCompanyCode()) // TCT
                .serviceCode(statementSapDTO.getServiceCode())
                .unit1(pair.getFirst())
                .unit2("DT")
                .bpCode1(statementSapDTO.getCustomerCode())
                .bpCode2(statementSapDTO.getCustomerCode())
                .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                .typeBpCode2(1)
                .refDate(statementSapDTO.getCreatedAt())
  //        .assignment(assignment)
                .description(statementSapDTO.getDescription())
                .channel("TCT")
                .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                .build()
        );
        // VAT
        listRaws.add(
            RawAcctDetailRequest.builder()
                .refNumber("DTCKHT_KTTC_VAT_" + statementSapDTO.getId())
                .refNumberParent(String.valueOf(statementSapDTO.getId()))
                .refDocNo(RevenueAccountingType.DTCKHT_KTTC.getCode())
                .bkC1(statementSapDTO.getStatementCode())
                .bkC2(statementSapDTO.getStatementLevel2Code())
                .transactionCode(statementSapDTO.getStatementCode())
                .xref2Hd(statementSapDTO.getStatementLevel2Code())
                .xref1Hd(String.valueOf(statementSapDTO.getId()))
                .xref1("")
                .xref2("")
                .xref3("")
                .customerCode(statementSapDTO.getCustomerCode())
                .docDate(statementSapDTO.getCreatedAt().toLocalDate())
                .postId1(statementSapDTO.getUnitLevel1Id())
                .orgId1(statementSapDTO.getUnitLevel2Id())
                .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
                .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
                .baseLineDate(finalBaselineDate)
                .accountingDate(LocalDate.now().atStartOfDay())
                .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
                .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
                .payAmount(negativeBigdecimal(pairVat.getSecond()))
                .baseAmount(negativeBigdecimal(pairVat.getFirst()))
                .partnerCode(statementSapDTO.getCustomerCode())
                .companyCode(statementSapDTO.getCompanyCode()) // TCT
                .serviceCode(statementSapDTO.getServiceCode())
                .unit1(pair.getFirst())
                .unit2("VAT")
                .bpCode1(statementSapDTO.getCustomerCode())
                .bpCode2(statementSapDTO.getCustomerCode())
                .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
                .typeBpCode2(1)
                .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
                .description(statementSapDTO.getDescription())
                .channel("TCT")
                .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
                .build()
        );
      }
    }
    return listRaws;
  }
  
  // DTHT_CTTC - Doanh thu hoàn thành - có trạng thái cuối
  // DTCKHT_CTTC - Doanh thu chiết khấu hoàn thành  - có trạng thái cuối
  public static List<RawAcctDetailRequest> convertDTHT_CTTCToRawAcctDetailRequest(RevenueStatementSapDTO statementSapDTO,
      Map<String, String> serviceMap, Map<String, Integer> dichVuMap, LocalDate endOfMonth, List<String> serviceCodeNoApplyTax, List<String> serviceCodeGtbs) {
    List<RawAcctDetailRequest> listRaws = new ArrayList<>();

    Pair<String, String> pair = getUnitLevel1ServiceCode(statementSapDTO, serviceMap);
    // DTCHT - Doanh thu chưa hoàn thành
    listRaws.add(
        RawAcctDetailRequest.builder()
            .refNumber("DTHT_CTTC_" + statementSapDTO.getId())
            .refNumberParent(String.valueOf(statementSapDTO.getId()))
            .refDocNo(RevenueAccountingType.DTHT_CTTC.getCode())
            .bkC1(statementSapDTO.getStatementCode())
            .bkC2(statementSapDTO.getStatementLevel2Code())
            .transactionCode(statementSapDTO.getStatementCode())
            .xref2Hd(statementSapDTO.getStatementLevel2Code())
            .xref1Hd(String.valueOf(statementSapDTO.getId()))
            .xref1("")
            .xref2("")
            .xref3("")
            .customerCode(statementSapDTO.getCustomerCode())
            .docDate(statementSapDTO.getCreatedAt().toLocalDate())
            .postId1(statementSapDTO.getUnitLevel1Id())
            .orgId1(statementSapDTO.getUnitLevel2Id())
            .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
            .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
            .baseLineDate(endOfMonth)
            .accountingDate(LocalDate.now().atStartOfDay())
            .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
            .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
            .payAmount(statementSapDTO.getStatementAmountBeforeTax())
            .baseAmount(statementSapDTO.getStatementAmountBeforeTax())
            .partnerCode(statementSapDTO.getCustomerCode())
            .companyCode(statementSapDTO.getCompanyCode()) // TCT
            .serviceCode(statementSapDTO.getServiceCode())
            .unit1(pair.getFirst())
            .unit2("DT")
            .bpCode1(statementSapDTO.getCustomerCode())
            .bpCode2(statementSapDTO.getCustomerCode())
            .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
            .typeBpCode2(1)
            .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
            .description(statementSapDTO.getDescription())
            .channel("TCT")
            .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
            .build()
    );

    // DTCKCHT - Doanh thu chiết khấu  hoàn thành
    if (statementSapDTO.getStatementAmountDiscount() != null && statementSapDTO.getStatementAmountDiscount().compareTo(BigDecimal.ZERO) > 0) {
      Pair<BigDecimal, BigDecimal> pairVat = calculateVatAmount(dichVuMap,
          statementSapDTO.getServiceCode(), statementSapDTO.getStatementAmountDiscount());
      // Doanh thu
      listRaws.add(
          RawAcctDetailRequest.builder()
              .refNumber("DTCKHT_CTTC_" + statementSapDTO.getId())
              .refNumberParent(String.valueOf(statementSapDTO.getId()))
              .refDocNo(RevenueAccountingType.DTCKHT_CTTC.getCode())
              .bkC1(statementSapDTO.getStatementCode())
              .bkC2(statementSapDTO.getStatementLevel2Code())
              .transactionCode(statementSapDTO.getStatementCode())
              .xref2Hd(statementSapDTO.getStatementLevel2Code())
              .xref1Hd(String.valueOf(statementSapDTO.getId()))
              .xref1("")
              .xref2("")
              .xref3("")
              .customerCode(statementSapDTO.getCustomerCode())
              .docDate(statementSapDTO.getCreatedAt().toLocalDate())
              .postId1(statementSapDTO.getUnitLevel1Id())
              .orgId1(statementSapDTO.getUnitLevel2Id())
              .postId2(statementSapDTO.getUnitLevel1Id()) // ID BC TCT
              .orgId2(statementSapDTO.getUnitLevel2Id()) // ID CN TCT
              .baseLineDate(endOfMonth)
              .accountingDate(LocalDate.now().atStartOfDay())
              .postingDate(endOfMonth)
//        .transactionCode("")
//        .paymentAccountNo("")
              .taxCode(getTaxCodeBy(dichVuMap, statementSapDTO.getServiceCode(), serviceCodeNoApplyTax))
              .payAmount(negativeBigdecimal(pairVat.getFirst()))
              .baseAmount(negativeBigdecimal(pairVat.getFirst()))
              .partnerCode(statementSapDTO.getCustomerCode())
              .companyCode(statementSapDTO.getCompanyCode()) // TCT
              .serviceCode(statementSapDTO.getServiceCode())
              .unit1(pair.getFirst())
              .unit2("DT")
              .bpCode1(statementSapDTO.getCustomerCode())
              .bpCode2(statementSapDTO.getCustomerCode())
              .typeBpCode1(1) // 1: khách hàng, 2: khách hàng sàn, 3: nhân viên
              .typeBpCode2(1)
              .refDate(statementSapDTO.getCreatedAt())
//        .assignment(assignment)
              .description(statementSapDTO.getDescription())
              .channel("TCT")
              .valueProfitability(Arrays.asList(statementSapDTO.getServiceCode(), "1000", "100"))
              .build()
      );
    }
    return listRaws;
  }

  private static String getTaxCodeBy(Map<String, Integer> dichVuMap, String serviceCode, List<String> serviceCodeNoApplyTax) {
    if (serviceCodeNoApplyTax.contains(serviceCode)) {
      return TaxCodeType.TAX_ON.getCode();
    }
    if (Objects.isNull(dichVuMap) || StringUtils.isEmpty(serviceCode)) {
      return TaxCodeType.TAX_O0.getCode();
    }
    Integer vat = dichVuMap.get(serviceCode);
    return TaxCodeType.getCode(vat).getCode();
  }

  private static Pair<String, String> getUnitLevel1ServiceCode(RevenueStatementSapDTO statementSapDTO, Map<String, String> serviceMap) {
    String unitLevel1 = "";
    String serviceCode = "";
    String productCategory = Optional.ofNullable(serviceMap)
        .flatMap(map -> Optional.ofNullable(statementSapDTO)
            .map(RevenueStatementSapDTO::getServiceCode)
            .flatMap(code -> Optional.ofNullable(map.get(code))))
        .orElse("");

    // Set unitLevel1 based on groupService
    if (statementSapDTO != null && GroupServiceType.CPN.getCode()
        .equalsIgnoreCase(statementSapDTO.getGroupService())) {
      unitLevel1 = GroupServiceType.CPN.getCode();
    }
    else {
      unitLevel1 = GroupServiceType.CPQT.getCode();
    }

    // Set serviceCode based on productCategory
    if (StringUtils.isNotEmpty(productCategory)) {
      serviceCode = productCategory.equals(GroupServiceType.LOG.getShortName())
          ? GroupServiceType.LOG.getShortName()
          : GroupServiceType.OTHER.getShortName();
    } else {
      serviceCode = GroupServiceType.CPN.getShortName();
    }
    return new Pair<>(unitLevel1, serviceCode);
  }

    public static Pair<BigDecimal, BigDecimal>  calculateVatAmount(Map<String, Integer> dichVuMap, String serviceCode, BigDecimal amountAfterVat) {
      if (Objects.isNull(dichVuMap) || StringUtils.isEmpty(serviceCode) || Objects.isNull(amountAfterVat)) {
        return new Pair<>(BigDecimal.ZERO, BigDecimal.ZERO);
      }

      if (Objects.nonNull(dichVuMap.get(serviceCode))) {
        Integer vat = dichVuMap.get(serviceCode);
        // Tính hệ số VAT (1 + vat/100)
        BigDecimal amountBeforeVatFactor = BigDecimal.valueOf(1 + (vat / 100.0));
        // Tính số tiền trước VAT, chỉ định scale và chế độ làm tròn
        BigDecimal amountBeforeVatAmountFactor = amountAfterVat.divide(amountBeforeVatFactor, 0, RoundingMode.HALF_UP);
        BigDecimal amountBeforeVat = amountBeforeVatAmountFactor.setScale(0, RoundingMode.HALF_UP);

//          // Tính số tiền VAT, chỉ định scale và chế độ làm tròn
//          // Tính hệ số VAT (1 + vat/100)
//          BigDecimal vatFactor = BigDecimal.valueOf(vat / 100.0);
//          BigDecimal amountVat = vatFactor.setScale(0, RoundingMode.HALF_UP);
        return new Pair<>(amountBeforeVat, amountAfterVat.subtract(amountBeforeVat));
      }
      else {
        return new Pair<>(amountAfterVat, BigDecimal.ZERO);
      }
    }

    private static BigDecimal negativeBigdecimal(BigDecimal amount) {
      if (Objects.isNull(amount)) {
        return BigDecimal.ZERO;
      }
      return amount.negate();
    }

    private static BigDecimal bigdecimalWithDefault(BigDecimal amount) {
      if (Objects.isNull(amount)) {
        return BigDecimal.ZERO;
      }
      return amount;
    }

  public static void main(String[] args) {
    Map<String, Integer> dichVuMap = new HashMap<>();
    dichVuMap.put("VCN", 5);
    Pair<BigDecimal, BigDecimal> pairVat = calculateVatAmount(dichVuMap,
        "VCN", BigDecimal.valueOf(893));
    log.info(String.valueOf(pairVat));
  }
}
