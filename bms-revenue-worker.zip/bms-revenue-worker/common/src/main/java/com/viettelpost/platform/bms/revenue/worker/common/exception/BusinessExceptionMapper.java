package com.viettelpost.platform.bms.revenue.worker.common.exception;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import lombok.extern.slf4j.Slf4j;

@Provider
@Slf4j
public class BusinessExceptionMapper implements ExceptionMapper<BusinessException> {
    @Override
    public Response toResponse(BusinessException e) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setData(null);
        baseResponse.setMessage(e.getMessage());
        baseResponse.setError(true);
        log.error("Return error to client with details: {}", e.getMessage());
        return Response.status(e.getHttpStatusCode()).entity(baseResponse).build();
    }
}
