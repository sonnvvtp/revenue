package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.response.FuelBillingRecoveryResponse;
import io.smallrye.mutiny.Uni;
import java.util.List;

public interface CarBillingRecoveryRepository {

    Uni<List<FuelBillingRecoveryResponse>> searchCarBills(
            String carLicensePlate, String synthesisPeriod, String receiptNumberLv3,
            String unit, int pageNo, int pageSize, int type, List<Integer> status);

    Uni<Long> countCarBills(String carLicensePlate, String synthesisPeriod,
                            String receiptNumberLv3, String unit, int type, List<Integer> status);

    Uni<Long> countCarBillsOfUnit(String unit, String synthesisPeriod);

    Uni<List<FuelBillingRecoveryResponse>> getCarBillsOfUnit(String unit, String synthesisPeriod,
            int pageNo, int pageSize);

    Uni<String> showNewestMonthFuelQuota();

    Uni<Boolean> updateStatus(String synthesisPeriod, Integer status, int type);
}
