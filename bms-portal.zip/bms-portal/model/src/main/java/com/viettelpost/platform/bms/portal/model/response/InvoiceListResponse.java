package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceListResponse {
    private List<InvoiceListItem> data;
    private long totalRecords;
    private int totalPage;
    private int currentPage;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceListItem {
        private Long id; // ID bản ghi
        private String orderCode; // Mã vận đơn/đơn hàng
        private String orderDate; // Ngày đơn hàng
        private String customerCode; // Mã khách hàng
        private Integer quantity; // Số lượng
        private Double amountBeforeTax; // Tiền hàng trước thuế
        private Double taxAmount; // Tiền thuế
        private Double amountAfterTax; // Thành tiền sau thuế
    }
} 