package com.viettelpost.platform.bms.portal.model.request.partnerConfig;

import com.viettelpost.platform.bms.portal.model.enums.ConfigStatus;
import com.viettelpost.platform.bms.portal.model.enums.PaymentQrType;
import com.viettelpost.platform.bms.portal.model.enums.ScopeQrType;
import lombok.Data;

import java.util.Date;

@Data
public class PartnerConfigRequest {
    private Long partnerConfigId;
    private ConfigStatus active;
    private String activeFrom;
    private String activeTo;
    private String configCode;
    private ScopeQrType scope;
    private String configName;
    private String partnerLogo;
    private Long updatedBy;
    private PaymentQrType paymentQrType;
}
