package com.viettelpost.platform.bms.portal.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.util.List;

@Getter
@Setter
@ToString
public class PaginationRes<T> {

    @Schema(description = "Total items")
    Integer totalElements;

    @Schema(description = "List items")
    List<T> content;

    public PaginationRes(){
    }

    public PaginationRes(Integer count, List<T> items){
        this.totalElements = count;
        this.content = items;
    }

    public PaginationRes(long count, List<T> items){
        this.totalElements = (int)count;
        this.content = items;
    }
}
