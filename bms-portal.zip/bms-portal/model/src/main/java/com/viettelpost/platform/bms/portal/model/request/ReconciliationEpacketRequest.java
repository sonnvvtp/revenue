package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ReconciliationEpacketRequest {

    @JsonProperty("cusId")
    private Integer cusId;
    @JsonProperty("fromDate")
    private String fromDate;
    @JsonProperty("toDate")
    private String toDate;
    @JsonProperty("referenceTime")
    private String referenceTime;
    @JsonProperty("clientId")
    private String clientId;
    @JsonProperty("secrectId")
    private String secrectId;


    public static ReconciliationEpacketRequest toRequest(Integer cusId, String fromDate, String toDate) {
        ReconciliationEpacketRequest request = new ReconciliationEpacketRequest();
        request.setCusId(cusId);
        request.setFromDate(fromDate);
        request.setToDate(toDate);
        return request;
    }

    public static ReconciliationEpacketRequest toBalanceRequest(Integer cusId, String referenceTime) {
        ReconciliationEpacketRequest request = new ReconciliationEpacketRequest();
        request.setCusId(cusId);
        request.setReferenceTime(referenceTime);
        return request;
    }
}
