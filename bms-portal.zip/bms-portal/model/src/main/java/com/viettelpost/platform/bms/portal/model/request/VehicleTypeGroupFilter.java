package com.viettelpost.platform.bms.portal.model.request;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VehicleTypeGroupFilter {

    private List<Long> groupId;

    private List<String> typeCode;

    @Builder.Default
    private int page = 1;

    @Builder.Default
    private int size = 10;

    @Builder.Default
    private boolean excludeTypes = false;

    private Boolean isSyncInvoice;

    private String search;
}
