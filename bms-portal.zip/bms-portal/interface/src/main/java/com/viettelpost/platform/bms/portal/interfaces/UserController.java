package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.dto.ApproverDTO;
import com.viettelpost.platform.bms.portal.model.request.UserSearchFilter;
import com.viettelpost.platform.bms.portal.service.handler.UserService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.common.annotation.Blocking;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/users")
@Tag(name = "Users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @POST
    @Blocking
    @Operation(summary = "Get Users")
    @APIResponse(responseCode = "200", description = "Returns users")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<List<ApproverDTO>> getUsers(UserSearchFilter filter) {
        return ReactiveConverter.toUni(userService.getUsers(
                filter.getMaNhanVien(),
                filter.getPage(),
                filter.getLimit(),
                filter.getSearch(),
                filter.getUserIds(),
                filter.getUnit()));
    }
}
