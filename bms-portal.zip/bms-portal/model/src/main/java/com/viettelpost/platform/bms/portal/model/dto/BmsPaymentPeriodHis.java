package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BmsPaymentPeriodHis {
    @JsonAlias("cus_id")
    private Integer cusId;

    @JsonAlias("partner_id")
    private Long partnerId;

    @JsonAlias("partner_evtp")
    private String partnerEvtp;

    @JsonAlias("config_type_old")
    private Integer typeConfigOld;

    @JsonAlias("config_value_old")
    private List<Integer> valueConfigOld;

    @JsonAlias("config_type_new")
    private Integer typeConfigNew;

    @JsonAlias("config_value_new")
    private List<Integer> valueConfigNew;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("post_id")
    private Long postId;

    @JsonAlias("partner_group_id")
    private Long partnerGroupId;

    @JsonAlias("pay_category_config_id")
    private Integer payCategoryConfigId;








}
