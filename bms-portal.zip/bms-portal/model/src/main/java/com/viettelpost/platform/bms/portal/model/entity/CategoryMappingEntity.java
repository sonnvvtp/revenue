package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

@Data
public class CategoryMappingEntity {
    @JsonAlias("BMS_SERVICE_CATEGORY_ID")
    private Long bmsServiceCategoryId;

    @JsonAlias("SERVICE_CODE")
    private String serviceCode;

    @JsonAlias("PRODUCT_CATEGORY")
    private String productCategory;

    @JsonAlias("DESCRIPTION")
    private String description;

    @JsonAlias("KEY_1")
    private String key1;

    @JsonAlias("KEY_2")
    private Integer key2;
}
