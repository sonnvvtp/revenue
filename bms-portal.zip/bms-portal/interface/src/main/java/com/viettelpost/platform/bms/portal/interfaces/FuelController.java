package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.request.SyncFuelQuotaRequest;
import com.viettelpost.platform.bms.portal.service.handler.FuelService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Path("/fuel")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Fuel Operations")
@RequiredArgsConstructor
public class FuelController {

    private final FuelService fuelService;

    @POST
    @Path("/sync-fuel-quota")
    @Operation(summary = "Sync fuel quota of list cars on specific month")
    @APIResponse(responseCode = "200", description = "Return total cars successfully, fail or error")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> syncFuelQuota(
            SyncFuelQuotaRequest request
    ) {
        return ReactiveConverter.toUni(fuelService.syncQuotaData(request));
    }
}
