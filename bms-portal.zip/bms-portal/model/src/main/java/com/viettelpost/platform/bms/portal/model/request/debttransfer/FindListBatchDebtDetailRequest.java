package com.viettelpost.platform.bms.portal.model.request.debttransfer;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FindListBatchDebtDetailRequest {

    @NotNull(message = "Vui lòng cung cấp ID bảng kê")
    private Long clearBatchId;

    private String advancedFilter;

    private Integer page;

    private Integer size;
}
