package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class BillReturnAcctDTO {

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_CODE")
    private String partnerCode;

    @JsonAlias("CUS_POST_ID")
    private Long cusPostId;

    @JsonAlias("CUS_ORG_ID")
    private Long cusOrgId;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("PAY_IN_ID")
    private Long payInId;

    @JsonAlias("AMOUNT")
    private BigDecimal amount;

    @JsonAlias("DATEBILL")
    private LocalDate dateBill;

    @JsonAlias("YEAR_MONTH")
    private String yearMonth;

}
