package com.viettelpost.platform.bms.portal.repository.impl.einvoice;

import com.viettelpost.platform.bms.common.utils.DataMappingUtils;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceCustomerEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceItemInfoEntity;
import com.viettelpost.platform.bms.portal.repository.InvoiceUserRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@ApplicationScoped
@RequiredArgsConstructor
public class InvoiceUserRepositoryImpl implements InvoiceUserRepository {

    private final PgPool client;

    @Override
    public Uni<Boolean> checkExistedInvoiceUser(String clientCode, String source) {
        List<Object> params = new ArrayList<>();

        String sql = """
            select 1 as existed from bms_payment.invoice_customer
            where customer_code = $1 and partner_source = $2
            """;
            params.add(clientCode);
            params.add(source);

        return executeAndGetValue(client, sql, Tuple.from(params), "existed", Integer.class)
            .map(Objects::nonNull);
    }

    @Override
    public Uni<InvoiceCustomerEntity> save(InvoiceCustomerEntity entity, SqlConnection sqlConnection) {

        String sql;

        List<Object> params = new ArrayList<>();

            sql = """
            insert into bms_payment.invoice_customer(tenant_id
                                                   ,created_by
                                                   ,created_at
                                                   ,updated_by
                                                   ,updated_at
                                                   ,customer_id
                                                   ,cus_id
                                                   ,customer_code
                                                   ,customer_type
                                                   ,customer_name
                                                   ,customer_phone
                                                   ,customer_email
                                                   ,customer_address
                                                   ,customer_tax
                                                   ,budget_unit_code
                                                   ,unit_level1_id
                                                   ,unit_level1_code
                                                   ,unit_level2_id
                                                   ,unit_level2_code
                                                   ,e_contract_code
                                                   ,e_contract_signed_date
                                                   ,invoice_detail_by_bill
                                                   ,status
                                                   ,partner_source)
            values (
                       $1
                      ,$2
                      ,current_timestamp
                      ,$3
                      ,current_timestamp
                      ,$4
                      ,$5
                      ,$6
                      ,$7
                      ,$8
                      ,$9
                      ,$10
                      ,$11
                      ,$12
                      ,$13
                      ,$14
                      ,$15
                      ,$16
                      ,$17
                      ,$18
                      ,$19
                      ,$20
                      ,$21
                      ,$22
            )
            returning *
            """;
            params.addAll(DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), InvoiceCustomerEntity.class);
        }

        return execute(client, sql, Tuple.from(params), InvoiceCustomerEntity.class);
    }

    @Override
    public Multi<InvoiceItemInfoEntity> saveBatch(List<InvoiceItemInfoEntity> entities,
        SqlConnection sqlConnection) {

        if (entities == null) {
            return Multi.createFrom().empty();
        }

        int maxBatchSize = 500;
        List<Multi<InvoiceItemInfoEntity>> bulkInsert = new ArrayList<>();

        for (int i = 0; i < entities.size(); i += maxBatchSize) {
            int end = Math.min(i + maxBatchSize, entities.size());
            List<InvoiceItemInfoEntity> chunk = entities.subList(i, end);

            String INSERT_STATEMENT = """
                insert into bms_payment.invoice_item_info (
                                            tenant_id
                                            ,created_by
                                            ,created_at
                                            ,updated_by
                                            ,updated_at
                                            ,invoice_customer_id
                                            ,customer_item_code
                                            ,customer_item_type
                                            ,customer_item_name
                                            ,customer_item_phone
                                            ,customer_item_email
                                            ,customer_item_address
                                            ,customer_item_tax
                                            ,invoice_condition_lv1
                                            ,invoice_condition_lv2
                                            ,from_date
                                            ,to_date
                                            ,auto_merge_bill
                                            ,bank_name
                                            ,bank_account_number
                                            ,bank_account_name
                                            ,payment_date
                    )
                    values
                """;

            int counter = 1;
            StringBuilder insertValues = new StringBuilder();
            List<Object> params = new ArrayList<>();
            for (InvoiceItemInfoEntity entity : chunk) {
                insertValues.append(String.format(" ($%d, $%d, current_timestamp, $%d, current_timestamp, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d),\n",
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++
                ));
                params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));
            }

            insertValues = new StringBuilder(StringUtils.removeEnd(insertValues.toString(), ",\n"));

            INSERT_STATEMENT += insertValues;
            INSERT_STATEMENT += " returning * ";

            Multi<InvoiceItemInfoEntity> insert;
            if (Objects.nonNull(sqlConnection)) {
                insert = executeMulti(sqlConnection, INSERT_STATEMENT, Tuple.from(params), InvoiceItemInfoEntity.class);
            } else {
                insert = executeMulti(client, INSERT_STATEMENT, Tuple.from(params), InvoiceItemInfoEntity.class);
            }

            bulkInsert.add(insert);
        }

        return Multi.createBy().concatenating().streams(bulkInsert);
    }
}
