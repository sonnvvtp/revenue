package com.viettelpost.platform.bms.portal.repository;
import com.viettelpost.platform.bms.portal.model.entity.EpacketTransactionLineEntity;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;
import java.util.List;
import reactor.core.publisher.Mono;
import java.util.List;

public interface EpacketTransactionLineRepository extends BaseRepository {

    Multi<EpacketTransactionLineEntity> findByTransactionCode(String transactionCode);
}
