package com.viettelpost.platform.bms.revenue.worker.common.enums;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RevenueStatus {
    TAO_MOI(0, "Chưa yc xuất HĐ"),
    DA_GOM_BANG_KE(1, "Đã đẩy yc xuất HĐ"),
    DA_XUAT_HOA_DON(2, "Đã xuất hóa đơn"),
    XUAT_HOA_DON_FAIL(-1, "xuất hóa đơn fail"),
    NA(-99, "N/A");


    private final Integer code;
    private final String description;

    public static RevenueStatus fromCode(Integer code) {
        for (RevenueStatus status : RevenueStatus.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static Integer fromStatus(RevenueStatus status) {
        return status.getCode();
    }
}
