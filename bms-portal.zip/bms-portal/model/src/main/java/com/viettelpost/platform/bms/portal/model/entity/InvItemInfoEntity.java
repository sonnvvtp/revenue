package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvItemInfoEntity {
    private Long id;
    private Long tenantId;
    private Long createBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime createdAt;
    private Long updatedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime updatedAt;
    private Long invoiceCustomerId;
    private String customerItemCode;
    private Long customerItemType;
    private String customerItemName;
    private String customerItemPhone;
    private String customerItemEmail;
    private String customerItemAddress;
    private String customerItemTax;
    private String invoiceConditionLv1;
    private String invoiceConditionLv2;
    private Long fromDate;
    private Long toDate;
    private Boolean autoMergeBill;
    private String bankName;
    private String bankAccountNumber;
    private String bankAccountName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDateTime paymentDate;

}
