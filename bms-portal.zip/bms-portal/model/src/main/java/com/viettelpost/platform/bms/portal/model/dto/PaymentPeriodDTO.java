package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentPeriodDTO {
    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("TYPE_CONFIG")
    private Integer typeConfig;

    @JsonAlias("VALUE_CONFIG")
    private Integer valueConfig;

    @JsonAlias("PARTNER_ID")
    private Long partnerId;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("PARTNER_GROUP_ID")
    private Long partnerGrId;


}
