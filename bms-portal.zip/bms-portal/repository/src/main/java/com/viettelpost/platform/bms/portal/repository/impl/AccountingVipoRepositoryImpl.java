package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.BmsRequestPaymentAndLineDTO;
import com.viettelpost.platform.bms.portal.model.dto.CostRefundDataDTO;
import com.viettelpost.platform.bms.portal.model.dto.FicoForControlLineDTO;
import com.viettelpost.platform.bms.portal.model.dto.OrgPostDTO;
import com.viettelpost.platform.bms.portal.model.request.AccountingVipoRequest;
import com.viettelpost.platform.bms.portal.repository.AccountingVipoRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.RowSet;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class AccountingVipoRepositoryImpl implements AccountingVipoRepository {
    @Inject
    PgPool client;


    @Inject
    ConnectionPool oraclePool;


    @Override
    public Multi<BmsRequestPaymentAndLineDTO> getInfoBillByTransactionPaid(AccountingVipoRequest request) {
        String moreQuery = "";
        List<Object> params = new ArrayList<>();
        if(request.getType() == 1){
            moreQuery = "AND brp.updated_date BETWEEN to_date($1,'dd/MM/yyyy') and to_date($2,'dd/MM/yyyy')";
            params.add(request.getFromDate());
            params.add(request.getToDate());
        }else {
            moreQuery = " AND brp.transaction_code = $1 ";
            params.add(request.getTransactionCode());
        }
        String sql = "  SELECT brp.transaction_code transaction_code,  \n" +
                     "    brpl.item_code bill,  \n" +
                     "    brpl.vendor_code vendor_code,  \n" +
                     "    brpl.partner_evtp partner_evtp,  \n" +
                     "    brp.created_date accounting_date, \n" +
                     "    to_char(brpl.date_bill_record,'DD/MM/YYYY') date_bill,\n" +
                     "    brp.created_by cus_id,\n" +
                     "    brpl.amount ,\n" +
                     "    brp.req_payment_id\n" +
                     " FROM bms_payment.bms_request_payment brp  \n" +
                     " JOIN bms_payment.bms_request_payment_line brpl   \n" +
                     "    ON brp.req_payment_id = brpl.req_payment_id  \n" +
                     " WHERE brp.status = 1     \n" +
                     "  AND brp.req_request_type = 10  and brpl.partner_evtp is not null\n" +
                     " and NOT EXISTS (select 1 from bms_payment.accounting_synthetic where ref_number = brpl.item_code)   " + moreQuery;

        Tuple tuple = Tuple.from(params);
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(BmsRequestPaymentAndLineDTO.class))
                .execute(tuple)
                .onItem().transformToMulti(RowSet::toMulti)
                .onFailure().invoke(error -> log.error("[getInfoBillByTransactionPaid] Error: {}", error.getMessage()));
    }

    @Override
    public Uni<Void> updateStatusPushSap(SqlConnection sqlConnection, String transactionCode, String itemCode, Integer status) {
        String sql = " update bms_payment.bms_request_payment_line set is_checked = $1 where item_code =$2 and transaction_code =$3";
        List<Object> params = Arrays.asList(status,itemCode,transactionCode);
        Function<SqlConnection, Uni<RowSet<Row>>> function =
                sqlConn -> sqlConn.preparedQuery(sql).execute(Tuple.from(params));

        return (sqlConnection == null ? client.withConnection(function) : function.apply(sqlConnection))
                .replaceWithVoid();
    }

    @Override
    public Multi<FicoForControlLineDTO> getTransactionFtByTransactionCode(List<BmsRequestPaymentAndLineDTO> request) {
        if (request.isEmpty()) {
            return Multi.createFrom().empty();
        }
        String sql = """
            SELECT PARTNER_TRANSFER_ID , REQ_VTP_ORDER_ID  
             FROM ERP_AC.FICO_FOR_CONTROL_LINE  
             WHERE (REQ_VTP_ORDER_ID, 0) IN (%s)
            """;
        String placeholder = genConditionInBigSize(request.size());
        sql = sql.formatted(placeholder);

        List<String> transactionCodes= request.stream().map(BmsRequestPaymentAndLineDTO::getTransactionCode).toList();
        return executeMulti(oraclePool, sql,  new ArrayList<>(transactionCodes), FicoForControlLineDTO.class);
    }

    @Override
    public Uni<OrgPostDTO> getOrgPostRfInternalPostgres(String transactionCode) {
        String sql = "select org_id ,post_id,cus_id   from bms_payment.bms_payment_refund bpr where transaction_code = $1 limit 1 ";
        List<Object> params = new ArrayList<>();
        params.add(transactionCode);
        return execute(client,sql,Tuple.from(params),OrgPostDTO.class);
    }

    @Override
    public Uni<OrgPostDTO> getOrgPostPostgres(String transactionCode) {
        String sql = "select post_code,post_id ,org_id,org_code,cus_id from bms_payment.bms_payment_refund brp where transaction_code = $1";
        List<Object> params = Collections.singletonList(transactionCode);
        return execute(client,sql,Tuple.from(params),OrgPostDTO.class);
    }

    @Override
    public Multi<CostRefundDataDTO> getListCostRefund(AccountingVipoRequest request) {
        String moreQuery = "";
        List<Object> params = new ArrayList<>();
        if(request.getType() == 1){
            moreQuery = " and a.UPDATED_AT BETWEEN TO_DATE(?,'dd/MM/yyyy') AND TO_DATE(?,'dd/MM/yyyy') + 1 - 0.00001 ";
            params.add(request.getFromDate());
            params.add(request.getToDate());
        }else {
            moreQuery = " and a.REF_ID = ? ";
            params.add(request.getTransactionCode());
        }
        String sql = " select a.PAYMENT_COST_ID,\n" +
                     "       a.UPDATED_AT,\n" +
                     "       a.PAY_AMOUNT,\n" +
                     "       a.REF_ID,\n" +
                     "       a.BP_CODE,\n" +
                     "       b.STATEMENT_NO,\n" +
                     "       b.BANK_FROM_ACCOUNT,\n" +
                     "       c.REQ_VTP_ORDER_ID,\n" +
                     "       d.SUMMARY_NO,\n" +
                     "       a.ORG_ID,\n" +
                     "       a.POST_ID,\n" +
                     "       a.CONTENT,\n" +
                     "       (select e.REQ_REQUEST_TYPE from ERP_AC.FICO_REQUEST_PAYMENT e where e.REQ_VTP_ORDER_ID = a.REF_KEY_3) as TYPE,\n" +
                     "       (select BANK_ACCOUNT_NO\n" +
                     "        from ERP_AC.FICO_BANK_ACCOUNT_INFO z\n" +
                     "        where z.BANK_ACCOUNT_INFO_ID = a.BANK_FROM_ID)    BANK_ACC_NO,\n" +
                     "          a.REF_KEY_3 as TRANSACTION_CODE,\n" +
                     "        e.REQUEST_CODE\n" +
                     "from ERP_AC.FICO_PAYMENT_COST a,\n" +
                     "     ERP_AC.FICO_PAYMENT_STATEMENT_COST b,\n" +
                     "     ERP_AC.FICO_BANK_TRANSFER c,\n" +
                     "     ERP_AC.FICO_PAYMENT_SUMMARY_COST d,\n" +
                     "     ERP_AC.FICO_REQUEST_CONFIG_COST e\n" +
                     "where a.STATUS = 4\n" +
                     "  and a.SOURCE_ID = 'CHI_REFUND'\n" +
                     "  and a.REF_TYPE = e.REQUEST_CONFIG_COST_ID\n" +
                     "  and a.PAY_STATEMENT_COST_ID = b.PAY_STATEMENT_COST_ID\n" +
                     "  and c.PAYMENT_BATCH_ID = a.PAYMENT_COST_ID\n" +
                     "  and d.PAY_SUMMARY_COST_ID = b.PAY_SUMMARY_COST_ID\n" +
                     "  and c.MODULE_TYPE = 13 and c.STATUS = 1 " + moreQuery;
        return executeMulti(oraclePool,sql,params,CostRefundDataDTO.class);
    }

    @Override
    public Multi<String> getCountAccountingCostReFund(List<String> paymentCostIds) {
        String sql = """
                select ref_number  from bms_payment.accounting_synthetic where ref_number = any($1) and business_id = 17
                """;
        List<Object> params = new ArrayList<>();
        params.add(paymentCostIds.toArray());
        return executeMultiAndGetValue(client,sql,Tuple.from(params),"ref_number", String.class);
    }

    @Override
    public Uni<OrgPostDTO> getOrgPostOracle(String transactionCode) {
        String  sql = "select ERP_AC.GET_POST_ID(POST_CODE) as POST_ID, ERP_AC.GET_ORG_ID(ERP_AC.GET_POST_ID(POST_CODE)) as ORG_ID " +
                      "from ERP_AC.FICO_REQUEST_PAYMENT " +
                      "where REQ_VTP_ORDER_ID = ? " +
                      "  and DOC_STATUS = 1 " ;
        List<Object> params = Collections.singletonList(transactionCode);
        return execute(oraclePool,sql,params, OrgPostDTO.class);

    }

    private  String genConditionInBigSize(Integer size) {
        return IntStream.range(0, size)
                .mapToObj(i -> "(?, 0)")
                .collect(Collectors.joining(", "));
    }
}
