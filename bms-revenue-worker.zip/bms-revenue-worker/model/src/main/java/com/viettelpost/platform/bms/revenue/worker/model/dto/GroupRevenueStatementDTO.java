package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class GroupRevenueStatementDTO {

    @JsonAlias("total_bill")
    private Long totalBill;
    @JsonAlias("total_fee_shipping")
    private BigDecimal totalFeeShipping;
    @JsonAlias("total_amt_deduct")
    private BigDecimal totalAmtDeduct;
    @JsonAlias("tax_amount")
    private BigDecimal taxAmount;
    @JsonAlias("total_amt")
    private BigDecimal totalAmt;
}
