package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class BillRevenueRequest {

    @NotNull(message = "Từ ngày không được để trống")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate fromDate;

    @NotNull(message = "Đến ngày không được để trống")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    @NotNull(message = "Vui lòng chọn loại báo cáo")
    private Integer type;

//    @NotNull(message = "Vui lòng chọn bưu cục")
    private Long postId;

    @NotNull(message = "Vui lòng chọn chi nhánh")
    private Long orgId;

    private String partnerEvtp;

    private List<String> bills;

    private Integer page;

    private Integer size;

}
