package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ItemOrderEntity {
  @JsonAlias("id")
  public Long id;

  @JsonAlias("tenant_id")
  public Integer tenantId;

  @JsonAlias("created_by")
  public Long createdBy;

  @JsonAlias("created_at")
  public LocalDateTime createdAt;

  @JsonAlias("updated_by")
  public Long updatedBy;

  @JsonAlias("updated_at")
  public LocalDateTime updatedAt;

  @JsonAlias("general_order_id")
  public BigDecimal generalOrderId;

  @JsonAlias("departure_location")
  public String departureLocation;

  @JsonAlias("arrival_location")
  public String arrivalLocation;

  @JsonAlias("vehicle_plateNumber")
  public String vehiclePlateNumber;

  @JsonAlias("warehouse_code")
  public String warehouseCode;

  @JsonAlias("item_selection")
  public Integer itemSelection;

  @JsonAlias("item_code")
  public String itemCode;

  @JsonAlias("item_name")
  public String itemName;

  @JsonAlias("item_note")
  public String itemNote;

  @JsonAlias("item_unit")
  public String itemUnit;

  @JsonAlias("item_quantity")
  public Long itemQuantity;

  @JsonAlias("item_price")
  public BigDecimal itemPrice;

  @JsonAlias("item_weight")
  public Integer itemWeight;

  @JsonAlias("item_amount_before_tax")
  public BigDecimal itemAmountBeforeTax;

  @JsonAlias("item_tax_type")
  public Integer itemTaxType;

  @JsonAlias("item_tax_percent")
  public BigDecimal itemTaxPercent;

  @JsonAlias("item_tax_amount")
  public BigDecimal itemTaxAmount;

  @JsonAlias("item_amount_after_tax")
  public BigDecimal itemAmountAfterTax;

  @JsonAlias("attribute1")
  public Map<String, Object> attribute1;

  @JsonAlias("attribute2")
  public Map<String, Object> attribute2;

  @JsonAlias("attribute3")
  public Map<String, Object> attribute3;
}
