package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.common.utils.CommonUtils;
import com.viettelpost.platform.bms.portal.model.dto.PartnerConfigByServiceDTO;
import com.viettelpost.platform.bms.portal.model.model.ConfigCallbackModel;
import com.viettelpost.platform.bms.portal.model.model.PartnerConfigInExDto;
import com.viettelpost.platform.bms.portal.model.request.epacket.EpacketTransactionRequest;
import com.viettelpost.platform.bms.portal.model.request.partnerConfig.ConfigPartnerInExRequest;
import com.viettelpost.platform.bms.portal.model.request.partnerConfig.PartnerConfigRequest;
import com.viettelpost.platform.bms.portal.model.request.partnerConfig.PartnerInternalStatusReq;
import com.viettelpost.platform.bms.portal.model.request.partnerConfig.PartnerReceiveConfigRequest;
import com.viettelpost.platform.bms.portal.model.response.PartnerExternalConfigResponse;
import com.viettelpost.platform.bms.portal.model.response.PartnerInternalConfigResponse;
import com.viettelpost.platform.bms.portal.repository.PartnerConfigRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.multi.MultiReactorConverters;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.RowSet;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.text.ParseException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.Collectors;

@Singleton
@Slf4j
@KeepTracedContext
public class PartnerConfigRepositoryImpl implements PartnerConfigRepository {

    @Inject
    PgPool client;

    final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");


    @Override
    public Flux<PartnerExternalConfigResponse> getListPartnerConfigsExternal(String partnerCode, Long active, Long activeAllArea) {
        String moreQuery = "";
        List<Object> params = new ArrayList<>();
        int paramIndex = 1;
        if (!CommonUtils.isNullOrEmpty(partnerCode)) {
            moreQuery = " and partner_external_code = $" +paramIndex;
            params.add(partnerCode);
            paramIndex++;
        }
        if (active != null) {
            moreQuery = moreQuery +  " and is_active = $" + paramIndex;
            params.add(active);
            paramIndex++;
        }
        if (activeAllArea != null) {
            moreQuery = moreQuery +  " and active_all_area = $"+ paramIndex;
            params.add(activeAllArea);
        }


        String sql = "select partner_external_id,partner_external_code,partner_external_name,partner_external_logo,partner_external_type,active_all_area,active_from,active_to,description,is_active from bms_payment.bms_partner_external bpe where 1 = 1 " + moreQuery;
        Tuple tuple = Tuple.from(params);
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(PartnerExternalConfigResponse.class))
                .execute(tuple)
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Flux<PartnerInternalConfigResponse> getListPartnerConfigsInternal() {
        String sql = "select bpi.partner_internal_id,bpil.partner_internal_line_id ,bpi.active,bpi.endpoint,bpi.partner_source,bpil.prefix,bpi.service_type,bpil.merchant_type,bpil.transaction_type_id,bpil.transaction_type_code,bpi.statement_token_partner from bms_payment.bms_partner_internal bpi,bms_payment.bms_partner_internal_line bpil where bpi.partner_internal_id = bpil.partner_internal_id order by bpil.created_date desc   ";
        List<Object> params = new ArrayList<>();
        Tuple tuple = Tuple.from(params);
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(PartnerInternalConfigResponse.class))
                .execute(tuple)
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Mono<Long> insertPartnerExternalConfig(PartnerConfigRequest req, Long userId) throws ParseException {
        String sql = "insert into bms_payment.bms_partner_external (partner_external_code,partner_external_name,description,is_active,partner_external_logo,created,created_by,updated,partner_external_type,active_all_area,active_from,active_to,updated_by,partner_external_id)\n" +
                "values ($1,$2,$3,$4,$5,now(),$6,now(),$7,$8,$9,$10,$11,$12)  returning partner_external_id";
        List<Object> params = Arrays.asList(req.getConfigCode(), req.getConfigName(), req.getPaymentQrType().getName(), req.getActive().getId(),
                req.getPartnerLogo(),
                userId, req.getPaymentQrType().getId(), req.getScope().getId(),
                LocalTime.parse(req.getActiveFrom(), timeFormatter), LocalTime.parse(req.getActiveTo(), timeFormatter), userId,req.getPartnerConfigId());
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(Tuple.from(params));
        return client.withConnection(function)
                .convert().with(UniReactorConverters.toMono())
                .map(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        return rowSet.iterator().next().getLong("partner_external_id");
                    } else {
                        return 0L; // or any default value you want to return when there is no result
                    }
                });

    }


    @Override
    public Mono<Long> updatePartnerExternalConfig(PartnerConfigRequest req, Long userId) throws ParseException {
        String sql = " update bms_payment.bms_partner_external set  active_all_area = $1,is_active = $2,updated  = now(),updated_by  = $3,active_from = $4,active_to  = $5 where partner_external_id = $6 returning partner_external_id";
        List<Object> params = Arrays.asList(req.getScope().getId(), req.getActive().getId(),
                userId,
                LocalTime.parse(req.getActiveFrom(), timeFormatter), LocalTime.parse(req.getActiveTo(), timeFormatter), req.getPartnerConfigId());
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(Tuple.from(params));
        return client.withConnection(function)
                .convert().with(UniReactorConverters.toMono())
                .map(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        return rowSet.iterator().next().getLong("partner_external_id");
                    } else {
                        return 0L; // or any default value you want to return when there is no result
                    }
                })
                .doOnError(error -> log.error("[updatePartnerExternalConfig] failed cause by {}", error.getLocalizedMessage()))
                .onErrorResume(error -> {
                    log.error("[updatePartnerExternalConfig] error handled: {}", error.getMessage());
                    return Mono.just(0L); // or any default value you want to return when handling error
                });
    }

    @Override
    public Mono<Integer> countPartnerConfigByService(String partnerSource, String serviceType, String merchantType) {
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        int paramIndex = 1;

        if (!CommonUtils.isNullOrEmpty(partnerSource)) {
            moreQuery.append(" AND bpi.partner_source = $").append(paramIndex);
            params.add(partnerSource);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(serviceType)) {
            moreQuery.append(" AND bpi.service_type = $").append(paramIndex);
            params.add(serviceType);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(merchantType)) {
            moreQuery.append(" AND bpi.merchant_type = $").append(paramIndex);
            params.add(merchantType);
        }

        String sql = "select count(distinct bpi.service_type) total \n" +
                "from  bms_payment.bms_partner_internal bpi,bms_payment.bms_partner_external bpe,bms_payment.bms_partner_revenue_config bprc \n" +
                "where  bpi.partner_internal_id = bprc.partner_internal_id and bpe.partner_external_id = bprc.partner_external_id " + moreQuery;

        return client.preparedQuery(sql)
                .execute(Tuple.from(params))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getInteger("total") : 0)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Flux<PartnerConfigByServiceDTO> getListPartnerConfigByService(String partnerSource, String serviceType, String merchantType, int page, int size) {
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        int paramIndex = 1;

        if (!CommonUtils.isNullOrEmpty(partnerSource)) {
            moreQuery.append(" AND bpi.partner_source = $").append(paramIndex);
            params.add(partnerSource);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(serviceType)) {
            moreQuery.append(" AND bpi.service_type = $").append(paramIndex);
            params.add(serviceType);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(merchantType)) {
            moreQuery.append(" AND bpi.merchant_type = $").append(paramIndex);
            params.add(merchantType);
        }

        moreQuery.append(" order by bpi.updated_date desc limit $").append(paramIndex).append(" offset $").append(paramIndex + 1);


        String sql = "select bpi.partner_internal_id ,bpi.partner_source,bpi.merchant_type,bpi.service_type,bpi.prefix_code,bpe.partner_external_code,bpi.active status_internal,bpe.is_active status_external,bpe.partner_external_name ,\n" +
                "bpe.partner_external_logo,bpe.partner_external_id from  bms_payment.bms_partner_internal bpi,bms_payment.bms_partner_external bpe,bms_payment.bms_partner_revenue_config bprc \n" +
                "where  bpi.partner_internal_id = bprc.partner_internal_id and bpe.partner_external_id = bprc.partner_external_id  " + moreQuery;

        params.add(size);
        params.add((page - 1) * size);
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(PartnerConfigByServiceDTO.class))
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Mono<Long> updatePartnerInternalConfigStatus(PartnerInternalStatusReq req,Long userId) {
        String sql = " update bms_payment.bms_partner_internal_line set active = $1,updated_date = now(),updated_by  = $2 where partner_internal_line_id = $3 returning partner_internal_line_id";
        List<Object> params = Arrays.asList(req.getConfigStatus().getId(), userId,req.getPartnerInternalLineId());
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(Tuple.from(params));
        return client.withConnection(function)
                .convert().with(UniReactorConverters.toMono())
                .map(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        return rowSet.iterator().next().getLong("partner_internal_line_id");
                    } else {
                        return 0L; // or any default value you want to return when there is no result
                    }
                })
                .doOnError(error -> log.info("[updatePartnerInternalLineConfigStatus]: {}", error.getMessage(), error));
    }

    @Override
    public Flux<String> getListPartnerSourceEx(String serviceType, String merchantType, String prefixCode) {
        String moreQueryJoin = "";
        String moreQuery = "";
        if (!CommonUtils.isNullOrEmpty(prefixCode)) {
            moreQueryJoin = ", bms_payment.bms_partner_internal_line bpil ";
            moreQuery = " and bpi.partner_internal_id = bpil.partner_internal_id ";
        }


        Map<List<Object>, String> map = moreQueryConfigByParam(null, serviceType, merchantType, prefixCode);
        Map.Entry<List<Object>, String> entry = map.entrySet().iterator().next();
        List<Object> params = entry.getKey();
        moreQuery = moreQuery + entry.getValue();
        String query = " select distinct bpi.partner_source from bms_payment.bms_partner_internal bpi " + moreQueryJoin + " where bpi.active  = 1" + moreQuery;
        return client.preparedQuery(query)
                .mapping(row -> row.getString("partner_source"))  // Mapping mỗi hàng thành một chuỗi
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Flux<String> getListServiceTypeEx(String partnerSource, String merchantType, String prefixCode) {
        String moreQueryJoin = "";
        String moreQuery = "";
        if (!CommonUtils.isNullOrEmpty(prefixCode) || !CommonUtils.isNullOrEmpty(merchantType)) {
            moreQueryJoin = ", bms_payment.bms_partner_internal_line bpil ";
            moreQuery = " and bpi.partner_internal_id = bpil.partner_internal_id ";
        }




        Map<List<Object>, String> map = moreQueryConfigByParam(partnerSource, null, merchantType, prefixCode);
        Map.Entry<List<Object>, String> entry = map.entrySet().iterator().next();
        List<Object> params = entry.getKey();
        moreQuery = moreQuery + entry.getValue();
        String query = "  select distinct bpi.service_type from bms_payment.bms_partner_internal bpi " + moreQueryJoin + " where  bpi.active  = 1 " + moreQuery;
        return client.preparedQuery(query)
                .mapping(row -> row.getString("service_type"))  // Mapping mỗi hàng thành một chuỗi
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Flux<String> getListMerchantTypeEx(String partnerSource, String serviceType, String prefixCode) {
        String moreQueryJoin = "";
        String moreQuery = "";
        if (!CommonUtils.isNullOrEmpty(partnerSource) || !CommonUtils.isNullOrEmpty(serviceType)) {
            moreQueryJoin = ", bms_payment.bms_partner_internal bpi ";
            moreQuery = " and bpi.partner_internal_id = bpil.partner_internal_id ";
        }

        Map<List<Object>, String> map = moreQueryConfigByParam(partnerSource, serviceType, null, prefixCode);
        Map.Entry<List<Object>, String> entry = map.entrySet().iterator().next();
        List<Object> params = entry.getKey();
        moreQuery = moreQuery + entry.getValue();

        String query = "  select distinct bpil.merchant_type from bms_payment.bms_partner_internal_line bpil " + moreQueryJoin + " where bpil.active  = 1 " + moreQuery;
        return client.preparedQuery(query)
                .mapping(row -> row.getString("merchant_type"))  // Mapping mỗi hàng thành một chuỗi
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Flux<String> getListPrefixCodeEx(String partnerSource, String serviceType, String merchantType) {
        String moreQueryJoin = "";
        String moreQuery = "";
        if (!CommonUtils.isNullOrEmpty(partnerSource) || !CommonUtils.isNullOrEmpty(serviceType)) {
            moreQueryJoin = ", bms_payment.bms_partner_internal bpi ";
            moreQuery = " and bpi.partner_internal_id = bpil.partner_internal_id ";
        }

        Map<List<Object>, String> map = moreQueryConfigByParam(partnerSource, serviceType, merchantType, null);
        Map.Entry<List<Object>, String> entry = map.entrySet().iterator().next();
        List<Object> params = entry.getKey();
        moreQuery = moreQuery + entry.getValue();


        String query = "  select distinct bpil.prefix from bms_payment.bms_partner_internal_line bpil " + moreQueryJoin + " where bpil.active  = 1 and bpil.prefix is not null " + moreQuery;
        return client.preparedQuery(query)
                .mapping(row -> row.getString("prefix"))  // Mapping mỗi hàng thành một chuỗi
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Mono<Integer> exitsPartnerInternalConfig(SqlConnection connection, ConfigPartnerInExRequest req) {
        String sql = "select bpil.partner_internal_line_id from \n" +
                "    bms_payment.bms_partner_internal bpi\n" +
                "INNER JOIN\n" +
                "    bms_payment.bms_partner_internal_line bpil ON bpi.partner_internal_id = bpil.partner_internal_id " +
                "where bpi.partner_source  = $1 and bpi.service_type  = $2 and bpil.merchant_type = $3 and bpil.prefix = $4  ";
        List<Object> params = Arrays.asList(req.getPartnerSource(), req.getServiceType(), req.getMerchantType(), req.getPrefixCode());
        Function<SqlConnection, Uni<Integer>> function = sqlConn ->
                sqlConn.preparedQuery(sql)
                        .execute(Tuple.from(params))
                        .map(rowSet -> rowSet.iterator().hasNext() ?
                                rowSet.iterator().next().getInteger("partner_internal_line_id") : 0);

        return (connection == null ? client.withConnection(function) : function.apply(connection))
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Long> insertPartnerConfigBankQrCode(SqlConnection connection, Integer partnerInternalLineId, List<Integer> partnerExternalId, Long userId) {
        String sql = "INSERT INTO bms_payment.bms_partner_receive_config (" +
                "    partner_internal_line_id , " +
                "    partner_external_id , " +
                "    created_date , " +
                "    created_by , " +
                "    updated_date , " +
                "    updated_by" +
                ") " +
                "VALUES (" +
                "    $1, $2, now(), $3, now(), $4 " +
                ") " +
                "ON CONFLICT (partner_external_id, partner_internal_line_id) DO UPDATE SET " +
                "    updated_date = EXCLUDED.updated_date, " +
                "    updated_by = EXCLUDED.updated_by " +
                "RETURNING partner_config_id";

        return Flux.fromIterable(partnerExternalId)
                .flatMap(externalId -> {
                    return connection.preparedQuery(sql)
                            .execute(Tuple.of(partnerInternalLineId, externalId, userId, userId))
                            .onItem().transform(rowSet -> {
                                if (rowSet.iterator().hasNext()) {
                                    return rowSet.iterator().next().getLong("partner_config_id");
                                } else {
                                    return 0L;
                                }
                            })
                            .convert().with(UniReactorConverters.toMono());  // Convert Uni to Mono
                })
                .collectList()
                .flatMap(results -> {
                    long successCount = results.stream().filter(id -> id > 0).count();
                    return Mono.just(successCount == partnerExternalId.size() ? successCount : 0L);
                });
    }


    @Override
    public Mono<Long> deletePartnerConfigBankQrCode(SqlConnection connection, Integer partnerInternalId, List<Integer> bankExternalId) {
        // Dynamically build the placeholders for the IN clause
        String moreQuery = "";
        if(bankExternalId != null){
            String placeholders = bankExternalId.stream()
                    .map(i -> "$" + (bankExternalId.indexOf(i) + 2)) // +2 because $1 is used for partnerInternalId
                    .collect(Collectors.joining(", "));
            moreQuery = String.format(
                    " and partner_external_id not in (%s)",
                    placeholders);
        }

        String sqlDelete = " delete from bms_payment.bms_partner_receive_config where partner_internal_line_id = $1 " + moreQuery;

        // Create a Tuple and add the partnerInternalId and then all bankExternalId values
        Tuple params = Tuple.of(partnerInternalId);
        if(bankExternalId != null){
            bankExternalId.forEach(params::addInteger);
        }

        Function<SqlConnection, Uni<Long>> function = sqlConn ->
                sqlConn.preparedQuery(sqlDelete)
                        .execute(params)
                        .map(rowSet -> {
                            int affectedRows = rowSet.rowCount(); // Get the number of affected rows
                            return affectedRows > 0 ? 1L : 0L;   // Return 1 if rows were affected, 0 otherwise
                        });

        return (connection == null ? client.withConnection(function) : function.apply(connection))
                .convert().with(UniReactorConverters.toMono());
    }

    @Override
    public Flux<PartnerConfigInExDto> getListPartnerBankQrCodes(String partnerSource, String merchant, String transactionType,String serviceType) {
        List<Object> params = new ArrayList<>();
        String moreQuery = "";
        int paramIndex = 1;
        if (!CommonUtils.isNullOrEmpty(partnerSource)) {
            moreQuery = " and bpi.partner_source = $" + paramIndex;
            params.add(partnerSource);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(merchant)) {
            moreQuery = moreQuery + " and bpil.merchant_type = $" + paramIndex;
            params.add(merchant);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(serviceType)) {
            moreQuery = moreQuery + " and bpi.service_type = $" + paramIndex;
            params.add(serviceType);
            paramIndex++;
        }
        if (transactionType != null) {
            moreQuery = moreQuery + " and bpil.transaction_type_code = $" + paramIndex;
            params.add(transactionType);
        }


        String sql = " select " +
                " bpil.partner_internal_line_id  , " +
                " bpi.partner_source , " +
                " bpil.merchant_type, " +
                " bpi.service_type , " +
                " bpil.prefix, " +
                " bpil.active, " +
                " bpe.partner_external_code, " +
                " to_char(bprc.updated_date,'dd/MM/yyyy HH24:MI:SS') updated_date  " +
                "from " +
                " bms_payment.bms_partner_internal bpi, " +
                " bms_payment.bms_partner_internal_line bpil , " +
                " bms_payment.bms_partner_external bpe, " +
                " bms_payment.bms_partner_receive_config bprc " +
                "where " +
                " bpil.partner_internal_id = bpi.partner_internal_id " +
                " and bpe.partner_external_id = bprc.partner_external_id  " +
                " and bprc.partner_internal_line_id  = bpil.partner_internal_line_id  " + moreQuery +
                " order by bprc.updated_date  desc  ";
        Tuple tuple = Tuple.from(params);
        return client.preparedQuery(sql)
                .mapping(DataMapping.map(PartnerConfigInExDto.class))
                .execute(tuple)
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Flux<String> getListTransactionType(String partnerSource, String serviceType, String merchantType) {
        String moreQueryJoin = "";
        String moreQuery = "";
        if (!CommonUtils.isNullOrEmpty(partnerSource) || !CommonUtils.isNullOrEmpty(serviceType)) {
            moreQueryJoin = ", bms_payment.bms_partner_internal bpi ";
            moreQuery = " and bpi.partner_internal_id = bpil.partner_internal_id ";
        }

        Map<List<Object>, String> map = moreQueryConfigByParam(partnerSource, serviceType, merchantType, null);
        Map.Entry<List<Object>, String> entry = map.entrySet().iterator().next();
        List<Object> params = entry.getKey();
        moreQuery = moreQuery + entry.getValue();

        String query = "  select distinct bpil.transaction_type_code from bms_payment.bms_partner_internal_line bpil " + moreQueryJoin + " where bpil.active  = 1 " + moreQuery;
        return client.preparedQuery(query)
                .mapping(row -> row.getString("transaction_type_code"))  // Mapping mỗi hàng thành một chuỗi
                .execute(Tuple.from(params))
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    @Override
    public Mono<Long> deletePartnerInternalLine(SqlConnection connection, Long partnerInternalLineId) {
        // Dynamically build the placeholders for the IN clause

        String sqlDeleteInLine = " delete from bms_payment.bms_partner_internal_line where partner_internal_line_id = $1  " ;
        // Create a Tuple and add the partnerInternalId and then all bankExternalId values
        Tuple params = Tuple.of(partnerInternalLineId);
        Function<SqlConnection, Uni<Long>> function = sqlConn ->
                sqlConn.preparedQuery(sqlDeleteInLine)
                        .execute(params)
                        .map(rowSet -> {
                            int affectedRows = rowSet.rowCount(); // Get the number of affected rows
                            return affectedRows > 0 ? 1L : 0L;   // Return 1 if rows were affected, 0 otherwise
                        });

        return (connection == null ? client.withConnection(function) : function.apply(connection))
                .convert().with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Integer> exitsPartnerReceiveConfig(SqlConnection connection,Long partnerInLineId) {
        String sql = " select partner_internal_line_id  from bms_payment.bms_partner_receive_config bprc where partner_internal_line_id  = $1  ";
        List<Object> params = new ArrayList<>();
        params.add(partnerInLineId);
        Function<SqlConnection, Uni<Integer>> function = sqlConn ->
                sqlConn.preparedQuery(sql)
                        .execute(Tuple.from(params))
                        .map(rowSet -> rowSet.iterator().hasNext() ?
                                rowSet.iterator().next().getInteger("partner_internal_line_id") : 0);

        return (connection == null ? client.withConnection(function) : function.apply(connection))
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Long> updateConfigBankQrCode(PartnerReceiveConfigRequest request, Long userId) {
        String sql = "   update  bms_payment.bms_partner_receive_config set partner_external_id = $1,updated_date = now(),updated_by=$2 where  partner_internal_line_id = $3 returning partner_internal_line_id ";
        List<Object> params = Arrays.asList(request.getPartnerBankId(),userId, request.getPartnerInternalLineId());
        Function<SqlConnection, Uni<RowSet<io.vertx.mutiny.sqlclient.Row>>> function = sqlConn -> sqlConn.preparedQuery(sql).execute(Tuple.from(params));
        return client.withConnection(function)
                .convert().with(UniReactorConverters.toMono())
                .map(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        return rowSet.iterator().next().getLong("partner_internal_line_id");
                    } else {
                        return 0L;
                    }
                })
                .doOnError(error -> log.error("[updateConfigBankQrCode] failed cause by {}", error.getLocalizedMessage()))
                .onErrorResume(error -> {
                    log.error("[updateConfigBankQrCode] error handled: {}", error.getMessage());
                    return Mono.just(0L);
                });
    }


    private Map<List<Object>, String> moreQueryConfigByParam(String partnerSource, String serviceType, String merchantType, String prefixCode) {
        Map<List<Object>, String> map = new HashMap<>();
        StringBuilder moreQuery = new StringBuilder();
        List<Object> params = new ArrayList<>();
        int paramIndex = 1;
        if (!CommonUtils.isNullOrEmpty(partnerSource)) {
            moreQuery.append(" AND bpi.partner_source = $").append(paramIndex);
            params.add(partnerSource);
            paramIndex++;
        }
        if (!CommonUtils.isNullOrEmpty(serviceType)) {
            moreQuery.append(" AND bpi.service_type = $").append(paramIndex);
            params.add(serviceType);
            paramIndex++;
        }

        if (!CommonUtils.isNullOrEmpty(merchantType)) {
            moreQuery.append(" AND bpil.merchant_type = $").append(paramIndex);
            params.add(merchantType);
        }
        if (!CommonUtils.isNullOrEmpty(prefixCode)) {
            moreQuery.append(" AND bpil.prefix = $").append(paramIndex);
            params.add(prefixCode);
        }
        map.put(params, moreQuery.toString());
        return map;
    }


    /**
     * Check nhanh 1 cấu hình khớp request.
     * Ưu tiên lọc theo transaction_type_code nếu req có (tùy hệ thống bạn dùng code hay name).
     * Trả về MONO (bản ghi mới nhất). Không có thì throw BusinessException.
     */
    public Mono<PartnerInternalConfigResponse> findPartnerConfig(String partnerSource, String serviceType, String merchantType) {


        StringBuilder sql = new StringBuilder(
                "select " +
                        "  bpi.partner_internal_id, " +
                        "  bpil.partner_internal_line_id, " +
                        "  bpi.active, " +
                        "  bpi.endpoint, " +
                        "  bpi.partner_source, " +
                        "  bpil.prefix, " +
                        "  bpi.service_type, " +
                        "  bpil.merchant_type, " +
                        "  bpil.transaction_type_id, " +
                        "  bpil.transaction_type_code, " +
                        "  bpi.statement_token_partner " +
                        "from bms_payment.bms_partner_internal bpi " +
                        "join bms_payment.bms_partner_internal_line bpil on bpi.partner_internal_id = bpil.partner_internal_id " +
                        "where coalesce(bpi.active, 0) = 1 " +
                        "  and bpi.partner_source = $1 " +
                        "  and bpi.service_type   = $2 " +
                        "  and bpil.merchant_type = $3 limit 1"
        );

        List<Object> params = new ArrayList<>();
        params.add(partnerSource);
        params.add(serviceType);
        params.add(merchantType);

        Tuple tuple = Tuple.from(params);
        return client.preparedQuery(sql.toString())
                .mapping(DataMapping.map(PartnerInternalConfigResponse.class))
                .execute(tuple)
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux())
                .next(); // lấy bản ghi đầu tiên
    }

}
