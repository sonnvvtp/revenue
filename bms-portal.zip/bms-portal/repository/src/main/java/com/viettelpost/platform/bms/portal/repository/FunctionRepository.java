package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepositoryPlus;
import com.viettelpost.platform.bms.portal.model.entity.CategoryMappingEntity;
import com.viettelpost.platform.bms.portal.model.entity.dashboard.AccountingStatusOverview;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;

import java.time.LocalDateTime;
import java.util.List;

public interface FunctionRepository extends BaseRepositoryPlus {
    Multi<CategoryMappingEntity> getCategoryMapping(String serviceCode);
    Uni<Long> updateCategoryMapping(CategoryMappingEntity req);

    Multi<AccountingStatusOverview> getOverviewStatusRawRepo(SqlConnection connection, LocalDateTime from, LocalDateTime to, Long businessId);
}
