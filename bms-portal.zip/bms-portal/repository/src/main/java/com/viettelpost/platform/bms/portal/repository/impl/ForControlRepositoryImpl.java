package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.utils.SqlQueryBuilder;
import com.viettelpost.platform.bms.portal.model.request.forControl.GetDataComparisonInternalForm;
import com.viettelpost.platform.bms.portal.model.request.forControl.SyntheticDataReq;
import com.viettelpost.platform.bms.portal.model.response.forControl.BmsDebtComparisonExternalDTO;
import com.viettelpost.platform.bms.portal.model.response.forControl.BmsDebtComparisonInternalDTO;
import com.viettelpost.platform.bms.portal.repository.ForControlRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.converters.multi.MultiReactorConverters;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

@Singleton
@Slf4j
@KeepTracedContext
public class ForControlRepositoryImpl implements ForControlRepository {
    @Inject
    PgPool client;
    @Override
    public Mono<Long> countReqDocStatus(SyntheticDataReq req) {
        List<Object> params = new ArrayList<>();

        String sql = "select count(1) count from bms_report.bms_debt_comparison_externals bmsDebt_ " +
                " left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                " left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id " +
                " where bmsDebt_.req_doc_status in (1,2) " +
                " and bmsDebt_.partner_id = $1 " +
                " and bmsDebt_.req_payment_date >= to_date($2,'dd/MM/yyyy') " +
                " and bmsDebt_.req_payment_date <= (to_date($3 ,'dd/MM/yyyy') + 1)";
        String finalSql = setParamSearch(4, sql, req, params);

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getLong("count") : 0L)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Long> amountReqDocStatus(SyntheticDataReq req) {
        List<Object> params = new ArrayList<>();

        String sql = "select coalesce(sum(bmsDebt_.req_collect_amount), 0) sum from bms_report.bms_debt_comparison_externals bmsDebt_ " +
                 " left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                 " left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id " +
                " where bmsDebt_.req_doc_status in (1,2) " +
                " and bmsDebt_.partner_id = $1 " +
                " and bmsDebt_.req_payment_date >= to_date($2,'dd/MM/yyyy') " +
                " and bmsDebt_.req_payment_date <= (to_date($3 ,'dd/MM/yyyy') + 1)";
        String finalSql = setParamSearch(4, sql, req, params);

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getLong("sum") : 0L)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Long> countResDocStatus(SyntheticDataReq req) {
        List<Object> params = new ArrayList<>();

        String sql = "select count(*) count from bms_report.bms_debt_comparison_externals bmsDebt_ " +
                 " left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                 " left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id " +
                " where bmsDebt_.res_doc_status = 1 " +
                " and bmsDebt_.partner_id = $1 " +
                " and bmsDebt_.req_payment_date >= to_date($2,'dd/MM/yyyy') " +
                " and bmsDebt_.req_payment_date <= (to_date($3 ,'dd/MM/yyyy') + 1)";
        String finalSql = setParamSearch(4, sql, req, params);

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getLong("count") : 0L)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Long> amountResDocStatus(SyntheticDataReq req) {
        List<Object> params = new ArrayList<>();

        String sql = "select coalesce(sum(bmsDebt_.res_collect_amount), 0) res_amount from bms_report.bms_debt_comparison_externals bmsDebt_ " +
                 " left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                 " left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id " +
                " where bmsDebt_.res_doc_status = 1 " +
                " and bmsDebt_.partner_id = $1 " +
                " and bmsDebt_.req_payment_date >= to_date($2,'dd/MM/yyyy') " +
                " and bmsDebt_.req_payment_date <= (to_date($3 ,'dd/MM/yyyy') + 1)";
        String finalSql = setParamSearch(4, sql, req, params);

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getLong("res_amount") : 0L)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Integer> countAllComparisonExternal(SyntheticDataReq req) {
        SqlQueryBuilder sqlBuffer = new SqlQueryBuilder();
        sqlBuffer.append("""
                select COALESCE(count(bmsDebt_.debt_comparison_id),0) as count
                 from bms_report.bms_debt_comparison_externals bmsDebt_
                                   left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id
                                   left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id
                """);

        sqlBuffer.append(" where bmsDebt_.req_payment_date >= to_date( {} ,'dd/MM/yyyy') and bmsDebt_.req_payment_date < (to_date( {} ,'dd/MM/yyyy') + 1) ", req.getFromDate(), req.getToDate());

        externalSetParamSearch(req, sqlBuffer);
        return client.preparedQuery(sqlBuffer.getSql())
                .execute(sqlBuffer.getTuple())
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getInteger("count") : 0)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Flux<BmsDebtComparisonExternalDTO> getAllComparisonExternal(SyntheticDataReq req) {
        SqlQueryBuilder sqlBuffer = new SqlQueryBuilder();
        sqlBuffer.append(" select e.* ");
        sqlBuffer.append(" from ( select ");
        sqlBuffer.append(" bmsDebt_.debt_comparison_id as debtComparisonId, ");
        sqlBuffer.append(" bmsDebt_.req_payment_id as reqPaymentId,  ");
        sqlBuffer.append(" bmsDebt_.req_vtp_order_id as reqVtpOderId, ");
        sqlBuffer.append(" bmsDebt_.partner_trans_id as partnerTransId, ");
        sqlBuffer.append(" bmsDebt_.req_collect_amount as reqCollectAmount, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.req_payment_date, 'DD/MM/YYYY HH24:MI:SS') as reqPaymentDate, ");
        sqlBuffer.append(" bmsDebt_.req_doc_status as reqDocStatus, ");
        sqlBuffer.append(" bmsDebt_.res_collect_amount as resCollectAmount, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.res_payment_date, 'DD/MM/YYYY HH24:MI:SS') as resPaymentDate, ");
        sqlBuffer.append(" bmsDebt_.res_doc_status as resDocStatus, ");
        sqlBuffer.append(" bmsDebt_.pay_code as payCode, ");
        sqlBuffer.append(" bmsDebt_.checked_amount as checkedAmount, ");
        sqlBuffer.append(" bmsDebt_.checked_status as checkedStatus, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.created, 'DD/MM/YYYY HH24:MI:SS') as created, ");
        sqlBuffer.append(" bmsDebt_.created_by as createdBy, ");
        sqlBuffer.append(" bmsDebt_.doc_status as docStatus, ");
        sqlBuffer.append(" bmsDebt_.doc_type as docType, ");
        sqlBuffer.append(" bmsDebt_.post_id as postId, ");
        sqlBuffer.append(" bmsDebt_.post_code as postCode, ");
        sqlBuffer.append(" bmsDebt_.org_id as orgId, ");
        sqlBuffer.append(" bmsDebt_.org_code as orgCode, ");
        sqlBuffer.append(" bmsDebt_.partner_id as partnerId, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.updated, 'DD/MM/YYYY HH24:MI:SS') as updated, ");
        sqlBuffer.append(" bmsDebt_.update_by as updateBy, ");
        sqlBuffer.append(" bmsDebt_.is_checked as isChecked, ");
        sqlBuffer.append(" bmsDebt_.pay_code as partnerTransferId, ");
        sqlBuffer.append(" pil.merchant_type as merchantType, ");
        sqlBuffer.append(" pi.service_type as serviceType, ");
        sqlBuffer.append(" pi.partner_source as partnerSource, ");

        if (req.getPartnerId().equals(12L)) {
            sqlBuffer.append(" row_number() over (order by bmsDebt_.res_payment_date desc) as seqnum ");
        } else {
            sqlBuffer.append(" row_number() over (order by bmsDebt_.req_payment_date desc) as seqnum ");
        }

        sqlBuffer.append(" from bms_report.bms_debt_comparison_externals bmsDebt_  " +
                         " left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                         " left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id ");

        if (req.getPartnerId().equals(12L)) {
            sqlBuffer.append(" where bmsDebt_.res_payment_date>= to_date({},'dd/MM/yyyy') and bmsDebt_.res_payment_date< (to_date({} ,'dd/MM/yyyy') + 1) ", req.getFromDate(), req.getToDate());
        }else {
            sqlBuffer.append(" where bmsDebt_.req_payment_date>= to_date({},'dd/MM/yyyy') and bmsDebt_.req_payment_date< (to_date({} ,'dd/MM/yyyy') + 1) ", req.getFromDate(), req.getToDate());
        }
        externalSetParamSearch(req, sqlBuffer);
        sqlBuffer.append(String.format(" ) e where e.seqnum between %d and %d ", (req.getPage() - 1) * req.getSize() + 1, req.getPage() * req.getSize()));
        return client.preparedQuery(sqlBuffer.getSql())
                .mapping(DataMapping.map(BmsDebtComparisonExternalDTO.class))
                .execute(sqlBuffer.getTuple())
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }

    private void externalSetParamSearch (SyntheticDataReq req, SqlQueryBuilder sqlBuffer) {
        if(Objects.nonNull(req.getPostCode())) {
            sqlBuffer.append(" and bmsDebt_.post_code= {} ", req.getPostCode());
        }
        if(Objects.nonNull(req.getOrgCode())) {
            sqlBuffer.append(" and bmsDebt_.org_code= {} ", req.getOrgCode());
        }
        if(Objects.nonNull(req.getPartnerId())) {
            sqlBuffer.append(" and bmsDebt_.partner_id= {} ", req.getPartnerId());
        }
        if(Objects.nonNull(req.getReqVtpOderId())) {
            sqlBuffer.append(" and bmsDebt_.req_vtp_order_id= {} ", req.getReqVtpOderId());
        }
        if(Objects.nonNull(req.getCheckedStatus())) {
            sqlBuffer.append(" and bmsDebt_.checked_status = {} " , req.getCheckedStatus());
        }

        advanceParamSearchForControl(req.getReqRequestType(), req.getMerchantType(), req.getServiceType(), req.getPartnerSource(),sqlBuffer);

    }

    @Override
    public Mono<Integer> countAllComparisonInternal(GetDataComparisonInternalForm req) {
        SqlQueryBuilder sqlBuffer = new SqlQueryBuilder();
        sqlBuffer.append(" select COALESCE(count(bmsDebt_.comparison_id) ,0) as count ");
        sqlBuffer.append(" from bms_report.bms_debt_comparison_internal bmsDebt_ " +
                         "left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                         "left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id ");

        sqlBuffer.append(" where (bmsDebt_.pay_date >= to_date({},'dd/MM/yyyy') and bmsDebt_.pay_date< (to_date({} ,'dd/MM/yyyy') + 1)) ", req.getFromDate(), req.getToDate());
        sqlBuffer.append(" and bmsDebt_.partner_id = {} ", Long.valueOf(req.getPartnerId()));

        internalSetParamSearch(req, sqlBuffer);
        
        return client.preparedQuery(sqlBuffer.getSql())
                .execute(sqlBuffer.getTuple())
                .onItem()
                .transform(rows -> rows.iterator().hasNext() ? rows.iterator().next().getInteger("count") : 0)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Flux<BmsDebtComparisonInternalDTO> getAllComparisonInternal(GetDataComparisonInternalForm req) {
        SqlQueryBuilder sqlBuffer = new SqlQueryBuilder();
        sqlBuffer.append(" select e.* from ( ");
        sqlBuffer.append(" select bmsDebt_.comparison_id as comparisonId, ");
        sqlBuffer.append(" bmsDebt_.check_amount as checkAmount, ");
        sqlBuffer.append(" bmsDebt_.check_status as checkStatus, ");
        sqlBuffer.append(" bmsDebt_.collect_amount as collectAmount, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.created, 'DD/MM/YYYY HH24:MI:SS') as created,  ");
        sqlBuffer.append(" bmsDebt_.created_by as createdBy, ");
        sqlBuffer.append(" bmsDebt_.debt_amount as debtAmount, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.debt_date, 'DD/MM/YYYY HH24:MI:SS') as debtDate, ");
        sqlBuffer.append(" bmsDebt_.debt_status as debtStatus, ");
        sqlBuffer.append(" bmsDebt_.doc_status as docStatus, ");
        sqlBuffer.append(" bmsDebt_.doc_type as docType,  ");
        sqlBuffer.append(" bmsDebt_.is_checked as isChecked, ");
        sqlBuffer.append(" bmsDebt_.is_sync as isSync, ");
        sqlBuffer.append(" bmsDebt_.item_code as itemCode, ");
        sqlBuffer.append(" bmsDebt_.org_code as orgCode, ");
        sqlBuffer.append(" bmsDebt_.org_id as orgId, ");
        sqlBuffer.append(" bmsDebt_.partner_id as partnerId, ");
        sqlBuffer.append(" bmsDebt_.pay_code as payCode, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.pay_date, 'DD/MM/YYYY HH24:MI:SS') as payDate,  ");
        sqlBuffer.append(" bmsDebt_.pay_status as payStatus, ");
        sqlBuffer.append(" bmsDebt_.post_code as postCode,  ");
        sqlBuffer.append(" bmsDebt_.post_id as postId, ");
        sqlBuffer.append(" bmsDebt_.bank_code as bankCodePartner, ");
        sqlBuffer.append(" bmsDebt_.req_vtp_order_id as reqVtpOrderId,  ");
        sqlBuffer.append(" bmsDebt_.update_by as updateBy, ");
        sqlBuffer.append(" TO_CHAR(bmsDebt_.updated, 'DD/MM/YYYY HH24:MI:SS') as updated, ");
        sqlBuffer.append(" pil.merchant_type as merchantType, ");
        sqlBuffer.append(" pi.service_type as serviceType, ");
        sqlBuffer.append(" pi.partner_source as partnerSource, ");
//        sqlBuffer.append(" VTP.GET_FULLNAME(bmsDebt_.EMPLOYEE_ID) as fullName, ");
        sqlBuffer.append(" bmsDebt_.evtp_code as evtpCode, ");
        sqlBuffer.append(" bmsDebt_.request_id as requestId, ");
        sqlBuffer.append(" bmsDebt_.documentno as documentno, ");
        sqlBuffer.append(" row_number() over (order by bmsDebt_.pay_date desc) as seqnum ");
        sqlBuffer.append(" from bms_report.bms_debt_comparison_internal bmsDebt_ " +
                         " left join bms_payment.bms_partner_internal_line pil on pil.partner_internal_line_id = bmsDebt_.partner_internal_id " +
                         " left join bms_payment.bms_partner_internal pi on pi.partner_internal_id = pil.partner_internal_id ");

        sqlBuffer.append(" where (bmsDebt_.pay_date >= to_date({} ,'dd/MM/yyyy') and bmsDebt_.pay_date< (to_date({} ,'dd/MM/yyyy') + 1)) ", req.getFromDate(), req.getToDate());
        sqlBuffer.append(" and bmsDebt_.partner_id = {} ", Long.valueOf(req.getPartnerId()));

        internalSetParamSearch(req, sqlBuffer);
        
        sqlBuffer.append(" order by bmsDebt_.pay_date desc ");
        sqlBuffer.append(" ) e ");
        sqlBuffer.append(" where e.seqnum between {} and {} ", (req.getPage() - 1) * req.getSize() + 1, req.getPage() * req.getSize());

        return client.preparedQuery(sqlBuffer.getSql())
                .mapping(DataMapping.map(BmsDebtComparisonInternalDTO.class))
                .execute(sqlBuffer.getTuple())
                .onItem().transformToMulti(rowSet -> Multi.createFrom().iterable(rowSet))
                .convert().with(MultiReactorConverters.toFlux());
    }
    
    private void internalSetParamSearch(GetDataComparisonInternalForm req, SqlQueryBuilder sqlBuffer) {
        if (Objects.nonNull(req.getPostCode())) {
            sqlBuffer.append(" and bmsDebt_.post_code = {} ", req.getPostCode());
        }
        if (Objects.nonNull(req.getOrgCode())) {
            sqlBuffer.append(" and bmsDebt_.org_code = {} ", req.getOrgCode());
        }
        if (Objects.nonNull(req.getReqVtpOrderId())) {
            sqlBuffer.append(" and bmsDebt_.req_vtp_order_id = {} ", req.getReqVtpOrderId());
        }
        if (Objects.nonNull(req.getItemCode())) {
            sqlBuffer.append(" and bmsDebt_.item_code = {} ", req.getItemCode());
        }
        if (!collectionIsEmpty(req.getDocTypeIds())) {
            // sqlBuffer.append(" and bmsDebt_.doc_type IN ( "+ req.getDocTypeIds().stream().map(Object::toString).collect(Collectors.joining(", ")) + " )");
            sqlBuffer.in(" and bmsDebt_.doc_type ", req.getDocTypeIds().stream().toList());
        }
        if (!isEmpty(req.getDocumentno())) {
            sqlBuffer.append(" and bmsDebt_.documentno = {} ", req.getDocumentno());
        }
        if (Objects.nonNull(req.getCheckedStatus())) {
            sqlBuffer.append(" and bmsDebt_.check_status = {} ", req.getCheckedStatus());
        }

        advanceParamSearchForControl(req.getReqRequestType(), req.getMerchantType(), req.getServiceType(), req.getPartnerSource(), sqlBuffer);
    }
    
    private void advanceParamSearchForControl(Long reqRequestType, String merchantType, String serviceType, String partnerSource, SqlQueryBuilder sqlBuffer) {
        if(Objects.nonNull(reqRequestType)) {
            sqlBuffer.append(" and bmsDebt_.req_request_type = {} " , reqRequestType);
        }
        if(Objects.nonNull(partnerSource)) {
            sqlBuffer.append(" and pi.partner_source = {} " , partnerSource);
        }
        if(Objects.nonNull(merchantType)) {
            sqlBuffer.append(" and pil.merchant_type = {} " , merchantType);
        }
        if(Objects.nonNull(serviceType)) {
            sqlBuffer.append(" and pi.service_type = {} " , serviceType);
        }
    }

    private String setParamSearch(int countNumber, String sql, SyntheticDataReq req, List<Object> params) {
        params.add(req.getPartnerId());
        params.add(req.getFromDate());
        params.add(req.getToDate());
        if(req.getPostCode() != null){
            sql += String.format(" and bmsDebt_.post_code = $%d", countNumber++);
            params.add(req.getPostCode());
        }
        if(req.getOrgCode() != null){
            sql += String.format(" and bmsDebt_.org_code = $%d", countNumber++);
            params.add(req.getOrgCode());
        }
        if(req.getReqVtpOderId() != null){
            sql += String.format(" and bmsDebt_.req_vtp_order_id = $%d", countNumber++);
            params.add(req.getReqVtpOderId());
        }
        if(req.getCheckedStatus() != null){
            sql += String.format(" and bmsDebt_.checked_status = $%d", countNumber++ );
            params.add(req.getCheckedStatus());
        }
        if(Objects.nonNull(req.getReqRequestType())) {
            sql += String.format(" and bmsDebt_.req_request_type = $%d", countNumber++ );
            params.add(req.getReqRequestType());
        }
        if(Objects.nonNull(req.getMerchantType())) {
            sql += String.format(" and pil.merchant_type = $%d", countNumber++ );
            params.add(req.getMerchantType());
        }
        if(Objects.nonNull(req.getPartnerSource())) {
            sql += String.format(" and pi.partner_source = $%d", countNumber++ );
            params.add(req.getPartnerSource());
        }
        if(Objects.nonNull(req.getServiceType())) {
            sql += String.format(" and pi.service_type = $%d", countNumber );
            params.add(req.getServiceType());
        }
        return sql;
    }

    private boolean collectionIsEmpty(Collection<?> collection) {
        return collection == null || collection.isEmpty();
    }

    private boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }
}
