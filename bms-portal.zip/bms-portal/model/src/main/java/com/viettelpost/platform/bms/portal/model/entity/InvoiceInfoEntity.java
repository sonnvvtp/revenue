package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceInfoEntity {
  @JsonAlias("id")
  public Long id;

  @JsonAlias("tenant_id")
  public Integer tenantId;

  @JsonAlias("created_by")
  public Long createdBy;

  @JsonAlias("created_at")
  public LocalDateTime createdAt;

  @JsonAlias("updated_by")
  public Long updatedBy;

  @JsonAlias("updated_at")
  public LocalDateTime updatedAt;

  @JsonAlias("general_order_id")
  public BigDecimal generalOrderId;

  @JsonAlias("order_id")
  public String orderId;

  @JsonAlias("buyer_id")
  public Long buyerId;

  @JsonAlias("buyer_type")
  public String buyerType;

  @JsonAlias("buyer_name")
  public String buyerName;

  @JsonAlias("partner_name")
  public String partnerName;

  @JsonAlias("buyer_phone")
  public String buyerPhone;

  @JsonAlias("buyer_email")
  public String buyerEmail;

  @JsonAlias("buyer_tax_code")
  public String buyerTaxCode;

  @JsonAlias("buyer_address")
  public String buyerAddress;

  @JsonAlias("buyer_bank_account")
  public String buyerBankAccount;

  @JsonAlias("buyer_bank_name")
  public String buyerBankName;
}
