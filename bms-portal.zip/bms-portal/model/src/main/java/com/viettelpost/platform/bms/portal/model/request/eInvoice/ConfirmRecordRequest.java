package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ConfirmRecordRequest {
  @NotNull(message = "vui lòng điền Ids đơn")
  private List<BigDecimal> listRecordIds;
}

