package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartnerCusDTO {
    @JsonAlias({"PARTNER_EVTP"})
    private String evtp;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("PARTNER_ID")
    private Long partnerId;

    @JsonAlias("PARTNER_GROUP_ID")
    private Long partnerGrId;

    @JsonAlias("TYPE_CONFIG")
    private Integer typeConfig;

    @JsonAlias("VALUE_CONFIG")
    private Long valueConfig;

    @JsonAlias("CREATEDBY")
    private Long createdBy;

    @JsonAlias("UPDATEDBY")
    private Long updatedBy;

    private String convertValue;

    private Long payCategoryConfigId;

}
