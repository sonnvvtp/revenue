package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.entity.EpacketTransactionLineEntity;


import com.viettelpost.platform.bms.portal.repository.EpacketTransactionLineRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

@ApplicationScoped
@RequiredArgsConstructor
public class EpacketTransactionLineRepositoryImpl implements EpacketTransactionLineRepository {

    private final PgPool pgClient;


    @Override
    public Multi<EpacketTransactionLineEntity> findByTransactionCode(String transactionCode) {
        String sql = """
            SELECT *
            FROM bms_payment.bms_transaction_epacket_line
            WHERE transaction_code = :transactionCode
        """;
        return null;
    }
}
