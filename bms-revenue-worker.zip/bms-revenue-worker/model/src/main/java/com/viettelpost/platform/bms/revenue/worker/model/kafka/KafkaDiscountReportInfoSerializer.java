package com.viettelpost.platform.bms.revenue.worker.model.kafka;

import io.quarkus.kafka.client.serialization.ObjectMapperSerializer;

public class KafkaDiscountReportInfoSerializer extends ObjectMapperSerializer<DiscountReportInfoKafka> {
    public KafkaDiscountReportInfoSerializer() {
        super();
    }
}