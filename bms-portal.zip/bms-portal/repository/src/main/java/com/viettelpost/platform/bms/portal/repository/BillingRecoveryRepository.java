package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.ApproverDTO;
import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryConfigDTO;
import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryLevel3DTO;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import com.viettelpost.platform.bms.portal.model.response.BillingRecoveryResponse;
import com.viettelpost.platform.bms.portal.model.response.FuelBillingRecoveryLevel3DetailResponse;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;
import java.util.List;
import reactor.core.publisher.Mono;

public interface BillingRecoveryRepository {

    Uni<List<BillingRecoveryResponse>> searchBills(
            String receiptNumber, String synthesisPeriod, List<Integer> status, int pageNo,
            int pageSize, int type);

    Uni<BillingRecoveryResponse> searchBillById(Long id);

    Uni<FuelBillingRecoveryLevel3DTO> searchBillBySynthesisPeriod(String synthesisPeriod);

    Uni<String> showNewestMonthBillingRecovery();

    Mono<List<String>> showSynthesisPeriodsByStatus(List<Integer> status);

    Mono<Integer> getReductionStatusByPeriod(String period);

    Uni<Long> countBills(String receiptNumber, String synthesisPeriod, List<Integer> status, int type);

    Uni<Boolean> saveFuelBillingRecoveryDetail(Long receiptId, Long userId, BigDecimal amount,
            String note, String carLicensePlate, Long carId, String userCodeBp, Integer status);

    Uni<Boolean> updateApprovedBillStatus(Long id, Integer status);

    Uni<Boolean> updateRefusedBillStatus(Long id, Integer status, String refuseReason, int type);

    Mono<Boolean> updateApprover(String appoverId, List<String> synthesisPeriods ,int type);

    Mono<Boolean> updateNewApprover(String approverId);

    Mono<Void> updateFuelBillingRecoveryStatus(String synthesisPeriod, BillingStatus status,
                                               SqlConnection connection, String statusName);

    Mono<List<ApproverDTO>> getApprover(String maNhanVien, Connection connection, int page,
            int limit, String search, List<Long> userId, String unit);

    Mono<Void> sendNotificationToApprover(ApproverDTO approver, String message,
            Connection connection);

    Mono<FuelBillingRecoveryLevel3DTO> findFuelBillingRecoveryLevel3BySynthesisPeriod(
            String synthesisPeriod, SqlConnection connection);

    Mono<ApproverDTO> getApproverByUserId(String approverId, Connection oracleConnection);

    Uni<List<FuelBillingRecoveryLevel3DetailResponse.Result>> getExcessDetail(
            String receiptNumberLv3, String synthesisPeriod, String unit, String carLicensePlate, int pageNo, int pageSize);

    Uni<Long> countExcessDetail(String receiptNumberLv3, String synthesisPeriod, String unit, String carLicensePlate);
}
