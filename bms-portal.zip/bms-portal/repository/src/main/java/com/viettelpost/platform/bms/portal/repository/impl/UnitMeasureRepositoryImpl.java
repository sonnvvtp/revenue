package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.model.entity.UnitMeasureEntity;
import com.viettelpost.platform.bms.portal.model.request.UnitMeasureRequest;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import com.viettelpost.platform.bms.portal.repository.UnitMeasureRepository;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;


@ApplicationScoped
@RequiredArgsConstructor
public class UnitMeasureRepositoryImpl implements UnitMeasureRepository {
    @Inject
    PgPool client;

    @Inject
    AuthenticationContext authCtx;


    @Override
    public Uni<UnitMeasureEntity> save(UnitMeasureRequest request) {
        String sql = """
                    INSERT INTO bms_payment.unit_measure (
                        measure_name,
                        is_active,
                        created_at,
                        created_by,
                        updated_at,
                        updated_by,
                        tenant_id
                    ) VALUES (
                        $1, $2, CURRENT_TIMESTAMP, $3, CURRENT_TIMESTAMP, $3, $4
                    ) RETURNING *
                """;

        Tuple params = Tuple.of(
                request.getMeasureName(),
                request.getIsActive() != null ? request.getIsActive() : true,
                authCtx.getCurrentUser().getName(),
                1
        );

        return client.preparedQuery(sql)
                .execute(params)
                .onItem()
                .transform(rowSet -> {
                    Row row = rowSet.iterator().next();
                    return UnitMeasureEntity.builder()
                            .measureId(row.getLong("measure_id"))
                            .measureName(row.getString("measure_name"))
                            .isActive(row.getBoolean("is_active"))
                            .createdAt(row.getLocalDateTime("created_at"))
                            .createdBy(row.getString("created_by"))
                            .updatedAt(row.getLocalDateTime("updated_at"))
                            .updatedBy(row.getString("updated_by"))
                            .tenantId(row.getShort("tenant_id"))
                            .build();
                });
    }

    @Override
    public Uni<UnitMeasureEntity> update(Long id, UnitMeasureRequest request) {
        String sql = """
        UPDATE bms_payment.unit_measure
        SET
            measure_name = $1,
            is_active = $2,
            updated_at = CURRENT_TIMESTAMP,
            updated_by = $3
        WHERE measure_id = $4
        RETURNING *
    """;

        Tuple params = Tuple.of(
                request.getMeasureName(),
                request.getIsActive() != null ? request.getIsActive() : true,
                authCtx.getCurrentUser().getName(),
                id
        );

        return client.preparedQuery(sql)
                .execute(params)
                .onItem()
                .transform(rowSet -> {
                    if (!rowSet.iterator().hasNext()) {
                        return null; // hoặc throw exception nếu không tìm thấy
                    }

                    Row row = rowSet.iterator().next();
                    return UnitMeasureEntity.builder()
                            .measureId(row.getLong("measure_id"))
                            .measureName(row.getString("measure_name"))
                            .isActive(row.getBoolean("is_active"))
                            .createdAt(row.getLocalDateTime("created_at"))
                            .createdBy(row.getString("created_by"))
                            .updatedAt(row.getLocalDateTime("updated_at"))
                            .updatedBy(row.getString("updated_by"))
                            .tenantId(row.getShort("tenant_id"))
                            .build();
                });
    }


    @Override
    public Uni<PageResponse<UnitMeasureEntity>> getSearch(String keyword, int page, int size) {
        boolean hasKeyword = keyword != null && !keyword.isBlank();
        String searchKeyword = hasKeyword ? keyword.trim() : null;
        int safePage = Math.max(page, 1);
        int offset = (safePage - 1) * size;

        String baseSql = hasKeyword
                ? "FROM bms_payment.unit_measure WHERE measure_name ILIKE '%' || $1 || '%'"
                : "FROM bms_payment.unit_measure";


        String dataSql = hasKeyword
                ? "SELECT * " + baseSql + " ORDER BY measure_id OFFSET $2 LIMIT $3"
                : "SELECT * " + baseSql + " ORDER BY measure_id OFFSET $1 LIMIT $2";


        String countSql = hasKeyword
                ? "SELECT COUNT(*) " + baseSql
                : "SELECT COUNT(*) " + baseSql;


        Tuple dataParams = hasKeyword
                ? Tuple.of(searchKeyword, offset, size)
                : Tuple.of(offset, size);

        Tuple countParams = hasKeyword
                ? Tuple.of(searchKeyword)
                : Tuple.tuple(); // empty tuple

        Uni<List<UnitMeasureEntity>> dataUni = client.preparedQuery(dataSql)
                .execute(dataParams)
                .onItem()
                .transform(rowSet -> {
                    List<UnitMeasureEntity> list = new ArrayList<>();
                    for (Row row : rowSet) {
                        list.add(
                                UnitMeasureEntity.builder()
                                        .measureId(row.getLong("measure_id"))
                                        .measureName(row.getString("measure_name"))
                                        .isActive(row.getBoolean("is_active"))
                                        .createdAt(row.getLocalDateTime("created_at"))
                                        .createdBy(row.getString("created_by"))
                                        .updatedAt(row.getLocalDateTime("updated_at"))
                                        .updatedBy(row.getString("updated_by"))
                                        .tenantId(row.getShort("tenant_id"))
                                        .build()
                        );
                    }
                    return list;
                });

        Uni<Long> countUni = client.preparedQuery(countSql)
                .execute(countParams)
                .onItem()
                .transform(rowSet -> rowSet.iterator().next().getLong(0));

        return Uni.combine().all().unis(dataUni, countUni)
                .asTuple()
                .onItem()
                .transform(tupleResult -> new PageResponse<>(tupleResult.getItem1(), tupleResult.getItem2()));
    }

    @Override
    public Uni<List<UnitMeasureEntity>> getAll() {
        String sql = """
        SELECT *
        FROM bms_payment.unit_measure
        ORDER BY measure_id
    """;

        return client.preparedQuery(sql)
                .execute()
                .onItem()
                .transform(rowSet -> {
                    List<UnitMeasureEntity> list = new ArrayList<>();
                    for (Row row : rowSet) {
                        list.add(
                                UnitMeasureEntity.builder()
                                        .measureId(row.getLong("measure_id"))
                                        .measureName(row.getString("measure_name"))
                                        .isActive(row.getBoolean("is_active"))
                                        .createdAt(row.getLocalDateTime("created_at"))
                                        .createdBy(row.getString("created_by"))
                                        .updatedAt(row.getLocalDateTime("updated_at"))
                                        .updatedBy(row.getString("updated_by"))
                                        .tenantId(row.getShort("tenant_id"))
                                        .build()
                        );
                    }
                    return list;
                });
    }
}
