package com.viettelpost.platform.bms.portal.model.request.advance;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class AdvanceAcctDetailRequest {

    @NotNull(message = "Vui lòng cung cấp id bảng kê")
    private Long refNumber;

    private List<String> businessTypeList;

    @NotNull(message = "Vui lòng cung cấp loại bảng kê")
    private Integer docType;

    private Integer page;

    private Integer size;
}
