package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.entity.BmsRequestApiLogEntity;
import com.viettelpost.platform.bms.portal.model.entity.GeneralOrderEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceOrderRequest;
import com.viettelpost.platform.bms.portal.model.response.einvoice.FindInvoiceOrderResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.QueryInvoiceOrderResponse;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;

import java.math.BigDecimal;
import java.util.List;

public interface InvoiceOrderRepository extends BaseRepository {

    Uni<Boolean> checkExistedInvoiceOrder(String domainType, String orderCode, String source);

    Uni<GeneralOrderEntity> save(String domainType, GeneralOrderEntity entity, SqlConnection sqlConnection);

    Uni<InvoiceInfoEntity> save(InvoiceInfoEntity entity, SqlConnection sqlConnection);

    Multi<ItemOrderEntity> saveBatch(String domainType, List<ItemOrderEntity> entities, SqlConnection sqlConnection);

    Uni<QueryInvoiceOrderResponse> queryInvoiceOrder(String orderCode, String companyCode, String source);

    Uni<Integer> findInvoiceOrderCount(FindInvoiceOrderRequest findInvoiceOrderRequest, List<String> companyCodes);

    Multi<FindInvoiceOrderResponse> findInvoiceOrder(FindInvoiceOrderRequest findInvoiceOrderRequest, List<String> companyCodes);

    Uni<BmsRequestApiLogEntity> save(BmsRequestApiLogEntity entity);

    Uni<Boolean> checkPartnerExists(String partnerCode);

    Uni<QueryInvoiceOrderResponse> queryLogRequest(BigDecimal recordId);

    Multi<String> getCompanyCodeBy(String postCode);
}
