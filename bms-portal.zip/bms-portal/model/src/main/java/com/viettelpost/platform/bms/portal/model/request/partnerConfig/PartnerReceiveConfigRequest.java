package com.viettelpost.platform.bms.portal.model.request.partnerConfig;

import lombok.Data;

@Data
public class PartnerReceiveConfigRequest {
    private Long partnerInternalLineId;
    private Long partnerBankId;
    private Long partnerConfigId;
}
