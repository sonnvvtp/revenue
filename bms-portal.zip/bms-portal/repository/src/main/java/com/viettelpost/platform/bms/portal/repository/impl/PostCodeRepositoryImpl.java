package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.PostCodeDTO;
import com.viettelpost.platform.bms.portal.repository.PostCodeRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.r2dbc.spi.Connection;
import jakarta.inject.Singleton;
import java.util.Collections;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class PostCodeRepositoryImpl implements PostCodeRepository {

    @Override
    public Mono<List<PostCodeDTO>> getPostCodeFromCodes(List<String> postcodes,
            Connection connection) {
        String placeholders = String.join(",", Collections.nCopies(postcodes.size(), "?"));
        String sql =
                "SELECT fspcc.COMPANY_CODE, hp.POSTCODE, fspcc.COST_CENTER, hp.POST_NAME, hp.POST_ID,fspcc.PROFIT_CENTER, hp.ORGANIZATION_ID "
                        +
                        "FROM ERP_AC.FICO_SAP_POST_CODE_CENTER fspcc " +
                        "JOIN ERP_AC.HR_POSTCODE hp ON fspcc.POST_ID = hp.POST_ID " +
                        "WHERE hp.POSTCODE IN (" + placeholders + ")";

        log.info("Executing query: {} with parameters: {}", sql, postcodes);

        var statement = connection.createStatement(sql);
        for (int i = 0; i < postcodes.size(); i++) {
            statement = statement.bind(i, postcodes.get(i));
        }

        return Flux.from(statement.execute())
                .flatMap(result -> result.map((row, metadata) -> {
                    PostCodeDTO dto = new PostCodeDTO();
                    dto.setCompanyCode(row.get("COMPANY_CODE", String.class));
                    dto.setPostCode(row.get("POSTCODE", String.class));
                    dto.setCostCenter(row.get("COST_CENTER", String.class));
                    dto.setPostName(row.get("POST_NAME", String.class));
                    dto.setPostId(row.get("POST_ID", Long.class));
                    dto.setProfitCenter(row.get("PROFIT_CENTER", String.class));
                    dto.setOrgId(row.get("ORGANIZATION_ID", Long.class));
                    return dto;
                }))
                .collectList()
                .doOnNext(postCodeDTOs -> log.info("Retrieved PostCodeDTOs: {}", postCodeDTOs))
                .doOnError(error -> log.error("Error retrieving PostCodeDTOs: ", error));
    }
}
