package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BatchInfoRequest {

    @JsonProperty("bmsBatchInfoReq")
    private BmsBatchInfoReq bmsBatchInfoReq;
    @JsonProperty("bmsFiDocuments")
    private List<BmsFiDocument> bmsFiDocuments;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class BmsBatchInfoReq {

        @JsonProperty("businessId")
        private int businessId;
        @JsonProperty("businessName")
        private String businessName;
        @JsonProperty("batchId")
        private long batchId;
        @JsonProperty("batchCode")
        private String batchCode;
        @JsonProperty("userAccountant")
        private String userAccountant;
        @JsonProperty("currency")
        private String currency;
        @JsonProperty("totalAmount")
        private double totalAmount;
        @JsonProperty("totalCount")
        private int totalCount;
        @JsonProperty("createdBy")
        private long createdBy;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class BmsFiDocument {

        @JsonProperty("bmsHeader")
        private BmsHeader bmsHeader;
        @JsonProperty("bmsItems")
        private List<BmsItem> bmsItems;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class BmsHeader {

        @JsonProperty("businessType")
        private String businessType;
        @JsonProperty("businessId")
        private int businessId;
        @JsonProperty("docType")
        private String docType;
        @JsonProperty("companyCode")
        private String companyCode;
        @JsonProperty("docDate")
        private String docDate;
        @JsonProperty("postingDate")
        private String postingDate;
        @JsonProperty("description")
        private String description;
        @JsonProperty("headerAmount")
        private BigDecimal headerAmount;
        @JsonProperty("headerCount")
        private int headerCount;
        @JsonProperty("currency")
        private String currency;
        @JsonProperty("transCode")
        private String transCode;
        @JsonProperty("transRef01")
        private String transRef01;
        @JsonProperty("transRef02")
        private String transRef02;
        @JsonProperty("transRef03")
        private String transRef03;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class BmsItem {

        @JsonProperty("drct")
        private String drct;
        @JsonProperty("glAccount")
        private String glAccount;
        @JsonProperty("amount")
        private double amount;
        @JsonProperty("itemText")
        private String itemText;
        @JsonProperty("postId")
        private int postId;
        @JsonProperty("postCode")
        private String postCode;
        @JsonProperty("postName")
        private String postName;
        @JsonProperty("pc")
        private String pc;
        @JsonProperty("cc")
        private String cc;
        @JsonProperty("baseLineDate")
        private String baseLineDate;
        @JsonProperty("partner")
        private String partner;

    }
}
