package com.viettelpost.platform.bms.portal.model.response;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ResponseObjectVTracking {

    private boolean error;
    private String message;
    private List<VTrackingResponse> data;
}
