package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BillEvtpPayInDTO {

    @JsonAlias("PAY_IN_ID")
    private Long payInId;

    @JsonAlias("BILL")
    private String bill;

    @JsonAlias("BILL_ID")
    private Long billId;

    @JsonAlias("TYPE")
    private Integer type;

    @JsonAlias("DATEBILL")
    private LocalDateTime dateBill;

    @JsonAlias("DATEINSERT")
    private LocalDateTime dateInsert;

    @JsonAlias("PERIOD_ID")
    private Long periodId;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_ID")
    private Long partnerId;

    @JsonAlias("M_PRODUCT")
    private String mProduct;

    @JsonAlias("PAYMENTTEAM_ID")
    private Integer paymentTeamId;

    @JsonAlias("IS_PAID")
    private Integer isPaid;

    @JsonAlias("WEIGHT")
    private Integer weight;

    @JsonAlias("AMT")
    private BigDecimal amt;

    @JsonAlias("AMT_PAY")
    private BigDecimal amtPay;

    @JsonAlias("CITY_TO")
    private String cityTo;

    @JsonAlias("CITY_FROM")
    private String cityFrom;

    @JsonAlias("FEE")
    private BigDecimal fee;

    @JsonAlias("FREIGHT")
    private BigDecimal freight;

    @JsonAlias("IS_DEDUCT")
    private Integer isDeduct;

    @JsonAlias("PARTNER_GROUP_ID")
    private Long partnerGroupId;

    @JsonAlias("AMT_VAT")
    private BigDecimal amtVat;

    @JsonAlias("VAT")
    private Integer taxPercent;

    @JsonAlias("BILL_STATUS")
    private Long billStatus;

    @JsonAlias("COMPANY_CODE")
    private String companyCode;

    private int recordType;
}
