package com.viettelpost.platform.bms.portal.interfaces;


import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.request.ErpDocTypeRequest;
import com.viettelpost.platform.bms.portal.service.handler.ErpDoctypeService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/erp-doctype")
@Tag(name = "API quản lý doctype (xuất hóa đơn)")
@Slf4j
@RequiredArgsConstructor
public class ErpDoctypeController {

    private final ErpDoctypeService erpDoctypeService;

    @POST
    @Path("/create")
    @Operation(summary = "Tạo cấu hình quản lý doctype")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> createErpDoctype(@RequestBody ErpDocTypeRequest request) {
        return erpDoctypeService.create(request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Operation(summary = "Lấy cấu hình quản lý doctype")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    @Path("")
    public Uni<Response> getAll(
            @QueryParam("page") @DefaultValue("0") int page,
            @QueryParam("size") @DefaultValue("20") int size
    ) {
        return erpDoctypeService.getAll(page, size)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @PUT
    @Path("/{id}")
    @Operation(summary = "Cập nhật cấu hình quản lý doctype")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateErpDoctype(@PathParam("id") Long id, @RequestBody ErpDocTypeRequest request) {
        return erpDoctypeService.update(id, request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Path("/company-code/{companyCode}")
    @Operation(summary = "Lấy doctype theo companyCode")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getDocTypeByCompanyCode(@PathParam("companyCode") String companyCode) {
        return erpDoctypeService.getDocTypeByCompanyCode(companyCode)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

}
