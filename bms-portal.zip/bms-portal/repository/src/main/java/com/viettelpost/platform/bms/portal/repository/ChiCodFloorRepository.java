package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.model.BillModel;
import com.viettelpost.platform.bms.portal.model.model.PayBatchModel;
import com.viettelpost.platform.bms.portal.model.request.AccountingFloorRequest;
import io.r2dbc.spi.Connection;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ChiCodFloorRepository {

    Mono<String> getBusinessConfigById(Integer businessConfigId);

    Flux<Long> getRefNumberByBusinessConfigId(Integer businessConfigId, List<Long> payCostIdList);

    Flux<PayBatchModel> getPayBatch(Connection connection, Integer reqTypeFloor, Integer status, Integer configDay, AccountingFloorRequest request, boolean isVP);

    Flux<BillModel> getBillInPayBatch(Connection connection, Long batchId, boolean isVP);

    Mono<Boolean> checkConfig(Connection connection, Long configId);

    Mono<Long> countBillsInPayBatch(Connection connection, Long batchId, boolean isVP);

}
