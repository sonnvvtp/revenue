package com.viettelpost.platform.bms.portal.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.viettelpost.platform.bms.portal.common.config.CustomLocalDateTimeDeserializer;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import jdk.jfr.Description;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderRecordResponse {

    @JsonAlias("id")
    private Long id;

    @JsonAlias("order_id")
    private String orderId;

    @Description("Mã đơn hàng")
    @JsonAlias("order_code")
    private String orderCode;

    @Description("Ngày tạo đơn")
    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    @JsonAlias("order_created_at")
    private LocalDateTime orderCreatedAt;

    @JsonAlias("order_delivered_at")
    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    public LocalDateTime orderDeliveredAt;

    @Description("Mã công ty")
    @JsonAlias("company_code")
    private String companyCode;

    @Description("cus id - Bắt buộc với đơn chuyển phát")
    @JsonAlias("seller_id")
    private Long sellerId;

    @Description("Mã khách hàng E2 - Bắt buộc với đơn chuyển phát")
    @JsonAlias("seller_code")
    private String sellerCode;

    @Description("Tổng số sản phẩm của đơn hàng")
    @JsonAlias("order_total_quantity")
    private Long orderTotalQuantity;

    @Description("Thành tiền đơn hàng trước thuế")
    @JsonAlias("order_amount_before_tax")
    private BigDecimal orderAmountBeforeTax;

    @Description("Tiền thuế của đơn hàng")
    @JsonAlias("order_tax_amount")
    private BigDecimal orderTaxAmount;

    @Description("Thành tiền đơn hàng sau thuế")
    @JsonAlias("order_amount_after_tax")
    private BigDecimal orderAmountAfterTax;

    @Description("")
    @JsonAlias("total_amount")
    private BigDecimal totalAmount;
}
