package com.viettelpost.platform.bms.revenue.worker.common.utils;

import org.apache.commons.codec.binary.Hex;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static java.time.temporal.TemporalAdjusters.lastInMonth;

public class AppUtils {

    public static String getHash(Object object) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] bytes = digest.digest(object.toString().getBytes());
            return new String(Hex.encodeHex(bytes));
        } catch (NoSuchAlgorithmException ignored) {
            return object.toString();
        }
    }

    public static boolean lastDayOfMonth(Date reportDate, String day) {
        LocalDate lastDayOfMonth = LocalDate.now().with(lastInMonth(DayOfWeek.valueOf(day)));
        return resetHourOfDateEnd(reportDate, 0).compareTo(Date.from(lastDayOfMonth.atStartOfDay(ZoneId.systemDefault()).toInstant())) == 0;
    }

    public static Date resetHourOfDateEnd(Date date, int hour) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static boolean checkDate(int dayOf) {
        try {
            Calendar cal = Calendar.getInstance();
            int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == dayOf) {
                return true;
            }
        } catch (Exception ignored) {

        }
        return false;
    }

    public static String getShortDayOfWeek(LocalDate date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();

        Map<DayOfWeek, String> dayOfWeekMap = new HashMap<>();
        dayOfWeekMap.put(DayOfWeek.MONDAY, "T2");
        dayOfWeekMap.put(DayOfWeek.TUESDAY, "T3");
        dayOfWeekMap.put(DayOfWeek.WEDNESDAY, "T4");
        dayOfWeekMap.put(DayOfWeek.THURSDAY, "T5");
        dayOfWeekMap.put(DayOfWeek.FRIDAY, "T6");
        dayOfWeekMap.put(DayOfWeek.SATURDAY, "T7");
        dayOfWeekMap.put(DayOfWeek.SUNDAY, "CN");

        return dayOfWeekMap.get(dayOfWeek);
    }
}
