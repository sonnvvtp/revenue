package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.request.AddOrderToInvoiceRequest;
import com.viettelpost.platform.bms.portal.model.response.AddOrderToInvoiceResponse;
import com.viettelpost.platform.bms.portal.repository.InvoiceRecordOrderRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import io.smallrye.mutiny.Uni;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import com.viettelpost.platform.bms.portal.model.request.RemoveOrderFromInvoiceRequest;
import com.viettelpost.platform.bms.portal.model.response.RemoveOrderFromInvoiceResponse;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class InvoiceRecordOrderRepositoryImpl implements InvoiceRecordOrderRepository {

    @Inject
    PgPool client;
    
    @Override
    public Mono<Boolean> isOrderExistsInInvoice(String orderId, Long recordId) {
        final String sql = "SELECT COUNT(*) FROM bms_payment.invoice_record_line " +
                "WHERE order_code = $1 AND record_id = $2";
        
        Uni<Boolean> existsUni = client.preparedQuery(sql)
                .execute(Tuple.of(orderId, recordId))
                .map(rows -> {
                    if (rows.iterator().hasNext()) {
                        Long count = rows.iterator().next().getLong(0);
                        return count > 0;
                    }
                    return false;
                });
        
        return Mono.fromFuture(existsUni.subscribeAsCompletionStage());
    } 

    @Override
    public Mono<AddOrderToInvoiceResponse> addOrderToInvoice(AddOrderToInvoiceRequest request) {
        return isOrderExistsInInvoice(request.getOrderCode(), request.getRecordId())
                .flatMap(exists -> {
                    if (exists) {
                        // Nếu đơn hàng đã tồn tại trong bảng kê, trả về lỗi
                        log.warn("Order {} already exists in invoice record {}", request.getOrderCode(), request.getRecordId());
                        return Mono.just(new AddOrderToInvoiceResponse()
                                .setOrderCode(request.getOrderCode())
                                .setRecordId(request.getRecordId())
                                .setSuccess(false)
                                .setItemCount(0));
                    } else {
                        return addOrderToInvoiceInternal(request);
                    }
                });
    }

    private Mono<AddOrderToInvoiceResponse> addOrderToInvoiceInternal(AddOrderToInvoiceRequest request) {
        return Mono.defer(() -> {
            // Lấy thông tin đơn hàng từ bảng general_order
            final String getOrderSql = "SELECT order_code, order_amount_before_tax, order_tax_amount, order_amount_after_tax " +
                    "FROM bms_payment.general_order WHERE order_code = $1 and invoice_status = 0";

            return Mono.fromFuture(client.preparedQuery(getOrderSql)
                    .execute(Tuple.of(request.getOrderCode()))
                    .map(rows -> {
                        if (rows.iterator().hasNext()) {
                            return rows.iterator().next();
                        }
                        return null;
                    })
                    .subscribeAsCompletionStage())
                    .flatMap(orderRow -> {
                        if (orderRow == null) {
                            // Nếu không tìm thấy đơn hàng, trả về lỗi
                            log.warn("Order {} not found", request.getOrderCode());
                            return Mono.just(new AddOrderToInvoiceResponse()
                                    .setOrderCode(request.getOrderCode())
                                    .setRecordId(request.getRecordId())
                                    .setSuccess(false)
                                    .setItemCount(0));
                        }

                        // Lấy danh sách mặt hàng từ bảng item_order
                        final String getItemsSql = "SELECT id, order_id, product_code, product_name, quantity, unit_price, amount " +
                                "FROM bms_payment.item_order WHERE order_id = $1";

                        return Mono.fromFuture(client.preparedQuery(getItemsSql)
                                .execute(Tuple.of(request.getOrderCode()))
                                .subscribeAsCompletionStage())
                                .flatMap(itemRows -> {
                                    // Bắt đầu transaction
                                    return Mono.fromFuture(client.withTransaction(conn -> {
                                        Double amount = orderRow.getDouble("order_amount_after_tax");

                                        // 1. Thêm vào bảng invoice_record_line
                                        final String insertLineSql = "INSERT INTO bms_payment.invoice_record_line " +
                                                "(tenant_id, created_by, created_at, updated_by, updated_at, record_id, order_id, order_code, amount) " +
                                                "VALUES (1, 1, CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, $1, $2, $3, $4) RETURNING id";

                                        return conn.preparedQuery(insertLineSql)
                                                .execute(Tuple.of(
                                                        request.getRecordId(),
                                                        request.getOrderCode(),
                                                        orderRow.getString("order_code"),
                                                        amount
                                                ))
                                                .flatMap(lineResult -> {
                                                    if (!lineResult.iterator().hasNext()) {
                                                        // Nếu không thêm được vào bảng invoice_record_line, trả về lỗi
                                                        return Uni.createFrom().item(new AddOrderToInvoiceResponse()
                                                                .setOrderCode(request.getOrderCode())
                                                                .setRecordId(request.getRecordId())
                                                                .setSuccess(false)
                                                                .setItemCount(0));
                                                    }

                                                    Long lineId = lineResult.iterator().next().getLong("id");
                                                    AtomicInteger itemCount = new AtomicInteger(0);
                                                    List<Uni<Integer>> insertItemUnis = new ArrayList<>();

                                                    // 2. Thêm các mặt hàng vào bảng invoice_record_item
                                                    for (Row itemRow : itemRows) {
                                                        final String insertItemSql = "INSERT INTO bms_payment.invoice_record_item " +
                                                                "(tenant_id, created_by, created_at, updated_by, updated_at, unit_level1_id, unit_level2_id, " +
                                                                "invoice_record_id, isactive, rn, product_type, note, unit, quantity, unit_price, amount) " +
                                                                "VALUES (1, 1, CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, NULL, NULL, " +
                                                                "$1, 'y', $2, $3, $4, $5, $6, $7, $8)";

                                                        int currentIndex = itemCount.incrementAndGet();
                                                        String productCode = itemRow.getString("product_code");
                                                        String productName = itemRow.getString("product_name");
                                                        String unit = "Cái"; // Mặc định đơn vị tính
                                                        Integer quantity = itemRow.getInteger("quantity");
                                                        Double unitPrice = itemRow.getDouble("unit_price");
                                                        Double itemAmount = itemRow.getDouble("amount");

                                                        Tuple tuple = Tuple.tuple();
                                                        tuple.addLong(request.getRecordId());
                                                        tuple.addInteger(currentIndex);
                                                        tuple.addString(productCode);
                                                        tuple.addString(productName);
                                                        tuple.addString(unit);
                                                        tuple.addInteger(quantity);
                                                        tuple.addDouble(unitPrice);
                                                        tuple.addDouble(itemAmount);

                                                        insertItemUnis.add(conn.preparedQuery(insertItemSql)
                                                                .execute(tuple)
                                                                .map(result -> 1));
                                                    }

                                                    // 3. Cập nhật trạng thái đơn hàng
                                                    final String updateOrderStatusSql = "UPDATE bms_payment.general_order " +
                                                            "SET invoice_status = 1 " +
                                                            "WHERE order_code = $1";

                                                    insertItemUnis.add(conn.preparedQuery(updateOrderStatusSql)
                                                            .execute(Tuple.of(request.getOrderCode()))
                                                            .map(result -> 1));

                                                    // Chờ tất cả các thao tác thêm mặt hàng hoàn thành
                                                    return Uni.combine().all().unis(insertItemUnis)
                                                            .combinedWith(results -> {
                                                                return new AddOrderToInvoiceResponse()
                                                                        .setOrderCode(request.getOrderCode())
                                                                        .setRecordId(request.getRecordId())
                                                                        .setInvoiceRecordLineId(lineId)
                                                                        .setItemCount(itemCount.get())
                                                                        .setSuccess(true);
                                                            });
                                                });
                                    }).subscribeAsCompletionStage());
                                });
                    });
        });
    }

    @Override
    public Mono<RemoveOrderFromInvoiceResponse> removeOrderFromInvoice(RemoveOrderFromInvoiceRequest request) {
        // Kiểm tra trạng thái của bảng kê
        return isInvoiceRecordValidForModification(request.getRecordId())
                .flatMap(isValid -> {
                    if (!isValid) {
                        // Nếu bảng kê không ở trạng thái cho phép chỉnh sửa (record_status != 0)
                        log.warn("Invoice record {} is not in valid status for modification (status must be 0)", request.getRecordId());
                        return Mono.just(new RemoveOrderFromInvoiceResponse()
                                .setOrderId(request.getOrderCode())
                                .setRecordId(request.getRecordId())
                                .setDeletedLineCount(0)
                                .setDeletedItemCount(0)
                                .setOrderStatusUpdated(false)
                                .setSuccess(false)
                                .setMessage("Bảng kê không ở trạng thái Tạo mới"));
                    }
                    
                    // Kiểm tra đơn hàng có tồn tại trong bảng kê không
                    return isOrderExistsInInvoice(request.getOrderCode(), request.getRecordId())
                            .flatMap(exists -> {
                                if (!exists) {
                                    // Nếu đơn hàng không tồn tại trong bảng kê, trả về lỗi
                                    log.warn("Order {} does not exist in invoice record {}", request.getOrderCode(), request.getRecordId());
                                    return Mono.just(new RemoveOrderFromInvoiceResponse()
                                            .setOrderId(request.getOrderCode())
                                            .setRecordId(request.getRecordId())
                                            .setDeletedLineCount(0)
                                            .setDeletedItemCount(0)
                                            .setOrderStatusUpdated(false)
                                            .setSuccess(false)
                                            .setMessage("Đơn hàng không tồn tại trong bảng kê"));
                                } else {
                                    // Nếu đơn hàng tồn tại, tiến hành loại bỏ
                                    return removeOrderFromInvoiceInternal(request);
                                }
                            });
                });
    }
    
    private Mono<RemoveOrderFromInvoiceResponse> removeOrderFromInvoiceInternal(RemoveOrderFromInvoiceRequest request) {
        return Mono.defer(() -> {
            // Thực hiện các thao tác trong một transaction
            return Mono.fromFuture(client.withTransaction(conn -> {
                // 1. Xóa dữ liệu từ bảng invoice_record_item
                final String deleteItemsSql = "DELETE FROM bms_payment.invoice_record_item_order " +
                        "WHERE record_id = $1 " +
                        "AND EXISTS (SELECT 1 FROM bms_payment.invoice_record_line " +
                        "WHERE record_id = $1 AND order_code = $2)";
                
                return conn.preparedQuery(deleteItemsSql)
                        .execute(Tuple.of(request.getRecordId(), request.getOrderCode()))
                        .flatMap(itemResult -> {
                            int deletedItemCount = itemResult.rowCount();
                            
                            // 2. Xóa dữ liệu từ bảng invoice_record_line
                            final String deleteLineSql = "DELETE FROM bms_payment.invoice_record_line " +
                                    "WHERE record_id = $1 AND order_code = $2";
                            
                            return conn.preparedQuery(deleteLineSql)
                                    .execute(Tuple.of(request.getRecordId(), request.getOrderCode()))
                                    .flatMap(lineResult -> {
                                        int deletedLineCount = lineResult.rowCount();
                                        
                                        // Nếu không xóa được bản ghi nào, trả về lỗi
                                        if (deletedLineCount == 0) {
                                            return Uni.createFrom().item(new RemoveOrderFromInvoiceResponse()
                                                    .setOrderId(request.getOrderCode())
                                                    .setRecordId(request.getRecordId())
                                                    .setDeletedLineCount(0)
                                                    .setDeletedItemCount(0)
                                                    .setOrderStatusUpdated(false)
                                                    .setSuccess(false)
                                                    .setMessage("Không thể xóa đơn hàng khỏi bảng kê"));
                                        }
                                        
                                        // 3. Cập nhật trạng thái đơn hàng trong bảng general_order
                                        final String updateOrderStatusSql = "UPDATE bms_payment.general_order " +
                                                "SET invoice_status = 0 " +
                                                "WHERE order_code = $1";
                                        
                                        return conn.preparedQuery(updateOrderStatusSql)
                                                .execute(Tuple.of(request.getOrderCode()))
                                                .map(statusResult -> {
                                                    int updatedOrderCount = statusResult.rowCount();
                                                    
                                                    return new RemoveOrderFromInvoiceResponse()
                                                            .setOrderId(request.getOrderCode())
                                                            .setRecordId(request.getRecordId())
                                                            .setDeletedItemCount(deletedItemCount)
                                                            .setDeletedLineCount(deletedLineCount)
                                                            .setOrderStatusUpdated(updatedOrderCount > 0)
                                                            .setSuccess(true)
                                                            .setMessage("Đã xóa đơn hàng khỏi bảng kê thành công");
                                                });
                                    });
                        });
            }).subscribeAsCompletionStage())
            .onErrorResume(e -> {
                log.error("Transaction failed", e);
                return Mono.just(new RemoveOrderFromInvoiceResponse()
                        .setOrderId(request.getOrderCode())
                        .setRecordId(request.getRecordId())
                        .setDeletedLineCount(0)
                        .setDeletedItemCount(0)
                        .setOrderStatusUpdated(false)
                        .setSuccess(false)
                        .setMessage("Lỗi xử lý dữ liệu: " + e.getMessage()));
            });
        });
    }

    private Mono<Boolean> isInvoiceRecordValidForModification(Long recordId) {
        final String sql = "SELECT record_status FROM bms_payment.invoice_record WHERE id = $1";
        Uni<Boolean> validStatusUni = client.preparedQuery(sql)
                .execute(Tuple.of(recordId))
                .map(rows -> {
                    if (rows.iterator().hasNext()) {
                        Integer status = rows.iterator().next().getInteger("record_status");
                        return status != null && status == 1;
                    }
                    return false;
                });
        
        return Mono.fromFuture(validStatusUni.subscribeAsCompletionStage());
    }
} 