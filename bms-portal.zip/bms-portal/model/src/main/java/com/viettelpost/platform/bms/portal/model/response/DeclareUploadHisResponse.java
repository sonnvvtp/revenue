package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DeclareUploadHisResponse {
    @JsonAlias("file_name")
    private String fileName;

    @JsonAlias("created_time")
    private String createdUpload;

    @JsonAlias("full_name")
    private String updatedName;

    @JsonAlias("file_status")
    private Integer status;

    @JsonAlias("total_record")
    private String totalRecord;

    @JsonAlias("file_type")
    private String fileType;

    @JsonAlias("note")
    private String note;

    @JsonAlias("file_url")
    private String urlFile;
}
