package com.viettelpost.platform.bms.portal.model.response.debttransfer;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

@Data
public class DocTypeBatchResponse {

    @JsonAlias("DOCTYPE_ID")
    private Long docTypeId;

    @JsonAlias("NAME")
    private String name;

}
