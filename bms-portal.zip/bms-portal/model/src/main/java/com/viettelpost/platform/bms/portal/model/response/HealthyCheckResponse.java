package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HealthyCheckResponse {
    private String status;
    private String uptime;
    private String postgres;
    private List<PostgreClusterInfoResponse> postgreClusterInfo;

}
