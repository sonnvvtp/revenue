package com.viettelpost.platform.bms.portal.common.config;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;

import java.util.Objects;

@ApplicationScoped
public class AuthenticationContextImpl implements AuthenticationContext {

    private CustomUser user;
    @Setter
    private String token;


    @Override
    public CustomUser getCurrentUser() {
        if (Objects.isNull(user)) {
            CustomUser customUser = new CustomUser();
            customUser.setUserId(-1L);
            return customUser;
        }
        return user;
    }

    @Override
    public String getToken() {
        return token;
    }


    public void setCurrentUser(CustomUser user) {
        this.user = user;
    }
}
