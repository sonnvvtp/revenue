package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.service.handler.AccountingSapService;
import com.viettelpost.platform.bms.portal.service.handler.ForwardingService;
import com.viettelpost.platform.model.request.forwarding.CreateSapPC;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/forwarding")
@Tag(name = "API for partner, authentication by both clientId, clientSecret")
@RequiredArgsConstructor
@ApplicationScoped
public class ForwardingController {

    private final ForwardingService forwardingService;

    private final AccountingSapService accountingSapService;

    /**
     * sync pc cc sap
     * SAP -> FICO, BMS
     */

    @GET
    @Path("/pc-cc")
    public Uni<Response> getPcCc(@QueryParam("page") Integer page, @QueryParam("pageSize") Integer pageSize){
        return forwardingService.getPcCc(page, pageSize);
    }

    @GET
    @Path("/org/post-office")
    public Uni<Response> fwGetPostOffice(@QueryParam("orgCode") String orgCode, @QueryParam("postCode") String postCode){
        return forwardingService.findByOrgCodeOrPostCode(orgCode, postCode);
    }

    @POST
    @Path("/kmcp/createSapPCC")
    public Uni<Response> createSapPc(@RequestBody CreateSapPC bodyReq){
        return forwardingService.syncPcCcSapToBms(bodyReq);
    }

    @POST
    @Path("/sap/{key}")
    public Uni<?> fwToSap(@PathParam("key") String endpoint, @RequestBody Object bodyReq){
        return forwardingService.forwardCallSap(endpoint, bodyReq);
    }

    @POST
    @Path("/{key}")
    public Uni<?> fwAsset(@PathParam("key") String endpoint, @RequestBody Object bodyReq){
        return forwardingService.forwardAsset(endpoint, bodyReq);
    }

    /**
     * PARTER -> BMS : Check thông tin lô, chi tiết lô, item
     */

    @GET
    @Path("/get-acct-batch")
    @Operation(summary = "get batch group by param")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getPayBatchGroupList(
            @QueryParam("batchId") List<Long> batchId,
            @QueryParam("batchName") String batchName,
            @QueryParam("businessId") Integer businessId,
            @QueryParam("status") Integer status,
            @QueryParam("fromDate") String fromDate,
            @QueryParam("toDate") String toDate,
            @QueryParam("page") Integer page,
            @QueryParam("size") Integer size) {
        return accountingSapService.getAcctBatchInfo(batchId, batchName, businessId, status, fromDate, toDate, page, size);
    }

    @GET
    @Path("/get-sub-business")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSubBusiness(@QueryParam("acctBatchId") Long acctBatchId,
                                 @QueryParam("status") Integer status,
                                 @QueryParam("page") Integer page,
                                 @QueryParam("size") Integer size,
                                 @QueryParam("fromDate") String fromDate,
                                 @QueryParam("toDate") String toDate) {
        return accountingSapService.getSubBusiness(acctBatchId, status, fromDate, toDate, page, size);
    }

    @GET
    @Path("/get-sub-business-detail")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSubBusinessDetail(@QueryParam("acctBatchId") Long acctBatchId,
                                       @QueryParam("acctSubBusinessId") Long acctSubBusinessId,
                                       @QueryParam("page") Integer page,
                                       @QueryParam("size") Integer size,
                                       @QueryParam("fromDate") String fromDate,
                                       @QueryParam("toDate") String toDate) {
        return accountingSapService.getSubBusinessDetail(acctBatchId, acctSubBusinessId, fromDate, toDate, page, size);
    }

    @GET
    @Path("/search-result")
    @Operation(summary = "cho đối tác - tổng hợp nghiệp vụ đã gom theo 1 raw theo refNumber, refNumberParent")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> searchResultAccounting(@QueryParam("businessId") Long businessId,
                                         @QueryParam("refNumber") String refNumber,
                                         @QueryParam("refNumberParent") String refNumberParent,
                                         @QueryParam("bkC1") String bkC1,
                                         @QueryParam("bkC2") String bkC2,
                                         @QueryParam("bkC3") String bkC3
    ) {
        return accountingSapService.getResultAccounting(businessId, refNumber, refNumberParent, bkC1, bkC2, bkC3);
    }
}
