package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.request.InvoiceLogRequest;
import com.viettelpost.platform.bms.portal.model.response.InvoiceLogResponse;
import reactor.core.publisher.Mono;

public interface InvoiceLogRepository {
    Mono<InvoiceLogResponse> getInvoiceLog(InvoiceLogRequest request);
} 