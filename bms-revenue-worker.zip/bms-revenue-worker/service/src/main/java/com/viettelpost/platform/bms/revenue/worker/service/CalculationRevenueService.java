package com.viettelpost.platform.bms.revenue.worker.service;

import io.smallrye.mutiny.Uni;

public interface CalculationRevenueService {
    Uni<Void> calculationAllBillToRevenue();

    Uni<Void> postInspectionEveryDayJob();
}
