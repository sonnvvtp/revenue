package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.model.entity.ErpDoctypeEntity;
import com.viettelpost.platform.bms.portal.model.request.ErpDocTypeRequest;
import com.viettelpost.platform.bms.portal.model.response.DocTypeResponse;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import com.viettelpost.platform.bms.portal.repository.ErpDoctypeRepository;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;


@ApplicationScoped
@RequiredArgsConstructor
public class ErpDoctypeRepositoryImpl implements ErpDoctypeRepository {

    private final PgPool client;

    private final AuthenticationContext authCtx;

    @Override
    public Uni<ErpDoctypeEntity> create(ErpDocTypeRequest request) {
        String checkSql = """
                    SELECT 1
                    FROM bms_payment.erp_doctype
                    WHERE doctype_code = $1
                """;

        String insertSql = """
                    INSERT INTO bms_payment.erp_doctype (
                        doctype_code,
                        doctype_name,
                        description,
                        company_code,
                        is_active,
                        created_at,
                        created_by,
                        update_at,
                        update_by,
                        tenant_id
                    ) VALUES (
                        $1, $2, $3, $4, TRUE,
                        CURRENT_TIMESTAMP, $5,
                        CURRENT_TIMESTAMP, $5,
                        1
                    ) RETURNING *
                """;


        // check trùng mã doctype
        return client.preparedQuery(checkSql)
                .execute(Tuple.of(request.getDoctypeCode()))
                .onItem().transformToUni(rows -> {
                    if (rows.iterator().hasNext()) {
                        return Uni.createFrom().failure(
                                new IllegalArgumentException("DocType code đã tồn tại")
                        );
                    }

                    // insert mới
                    Tuple insertParams = Tuple.of(
                            request.getDoctypeCode(),
                            request.getDoctypeName(),
                            request.getDescription(),
                            request.getCompanyCode(),
                            authCtx.getCurrentUser().getName()
                    );

                    return client.preparedQuery(insertSql)
                            .execute(insertParams)
                            .onItem()
                            .transform(rowSet -> {
                                Row row = rowSet.iterator().next();
                                return ErpDoctypeEntity.builder()
                                        .doctypeId(row.getLong("doctype_id"))
                                        .doctypeCode(row.getString("doctype_code"))
                                        .doctypeName(row.getString("doctype_name"))
                                        .description(row.getString("description"))
                                        .companyCode(row.getString("company_code"))
                                        .isActive(row.getBoolean("is_active"))
                                        .createdAt(row.getLocalDateTime("created_at"))
                                        .createdBy(row.getString("created_by"))
                                        .updateAt(row.getLocalDateTime("update_at"))
                                        .updateBy(row.getString("update_by"))
                                        .tenantId(row.getShort("tenant_id"))
                                        .build();
                            });
                });
    }


    @Override
    public Uni<PageResponse<ErpDoctypeEntity>> getAll(int page, int size) {
        String dataSql = """
                    SELECT *
                    FROM bms_payment.erp_doctype
                    ORDER BY created_at DESC
                    LIMIT $1 OFFSET $2
                """;

        String countSql = """
                    SELECT COUNT(*) AS total
                    FROM bms_payment.erp_doctype
                """;

        int offset = (page - 1) * size;


        Uni<Long> totalCountUni = client.preparedQuery(countSql)
                .execute()
                .onItem()
                .transform(rowSet -> rowSet.iterator().next().getLong("total"));


        Uni<List<ErpDoctypeEntity>> dataUni = client.preparedQuery(dataSql)
                .execute(Tuple.of(size, offset))
                .onItem()
                .transform(rowSet -> {
                    List<ErpDoctypeEntity> list = new ArrayList<>();
                    for (Row row : rowSet) {
                        list.add(ErpDoctypeEntity.builder()
                                .doctypeId(row.getLong("doctype_id"))
                                .doctypeCode(row.getString("doctype_code"))
                                .doctypeName(row.getString("doctype_name"))
                                .description(row.getString("description"))
                                .companyCode(row.getString("company_code"))
                                .isActive(row.getBoolean("is_active"))
                                .createdAt(row.getLocalDateTime("created_at"))
                                .createdBy(row.getString("created_by"))
                                .updateAt(row.getLocalDateTime("update_at"))
                                .updateBy(row.getString("update_by"))
                                .tenantId(row.getShort("tenant_id"))
                                .build());
                    }
                    return list;
                });


        return Uni.combine().all().unis(dataUni, totalCountUni).asTuple()
                .onItem()
                .transform(tuple -> {
                    List<ErpDoctypeEntity> items = tuple.getItem1();
                    long totalItems = tuple.getItem2();

                    return new PageResponse<>(
                            items,
                            totalItems
                    );
                });
    }

    @Override
    public Uni<ErpDoctypeEntity> update(Long doctypeId, ErpDocTypeRequest request) {
        String checkSql = """
                    SELECT 1
                    FROM bms_payment.erp_doctype
                    WHERE doctype_code = $1 AND doctype_id <> $2
                """;

        String updateSql = """
                    UPDATE bms_payment.erp_doctype
                    SET
                        doctype_code = $1,
                        doctype_name = $2,
                        description = $3,
                        company_code = $4,
                        update_at = CURRENT_TIMESTAMP,
                        update_by = $5
                    WHERE doctype_id = $6
                    RETURNING *
                """;

        return client.preparedQuery(checkSql)
                .execute(Tuple.of(request.getDoctypeCode(), doctypeId))
                .onItem().transformToUni(rows -> {
                    if (rows.iterator().hasNext()) {
                        return Uni.createFrom().failure(
                                new IllegalArgumentException("DocType code đã tồn tại")
                        );
                    }

                    Tuple updateParams = Tuple.of(
                            request.getDoctypeCode(),
                            request.getDoctypeName(),
                            request.getDescription(),
                            request.getCompanyCode(),
                            authCtx.getCurrentUser().getName(),
                            doctypeId
                    );

                    return client.preparedQuery(updateSql)
                            .execute(updateParams)
                            .onItem().transform(rowSet -> {
                                if (!rowSet.iterator().hasNext()) {
                                    throw new RuntimeException("DocType không tồn tại với ID: " + doctypeId);
                                }

                                Row row = rowSet.iterator().next();
                                return ErpDoctypeEntity.builder()
                                        .doctypeId(row.getLong("doctype_id"))
                                        .doctypeCode(row.getString("doctype_code"))
                                        .doctypeName(row.getString("doctype_name"))
                                        .description(row.getString("description"))
                                        .companyCode(row.getString("company_code"))
                                        .isActive(row.getBoolean("is_active"))
                                        .createdAt(row.getLocalDateTime("created_at"))
                                        .createdBy(row.getString("created_by"))
                                        .updateAt(row.getLocalDateTime("update_at"))
                                        .updateBy(row.getString("update_by"))
                                        .tenantId(row.getShort("tenant_id"))
                                        .build();
                            });
                });
    }

    @Override
    public Uni<List<DocTypeResponse>> getDocTypeByCompanyCode(String companyCode) {
        String sql = "select ed.doctype_id, ed.doctype_code, ed.doctype_name from bms_payment.erp_doctype ed where ed.company_code = $1";

        return client.preparedQuery(sql)
                .execute(Tuple.of(companyCode)).onItem().transform(rows -> {
                    List<DocTypeResponse> list = new ArrayList<>();
                    for (Row row : rows) {
                        DocTypeResponse dto = new DocTypeResponse();
                        dto.setDocTypeId(row.getLong("doctype_id"));
                        dto.setDocTypeCode(row.getString("doctype_code"));
                        dto.setDocTypeName(row.getString("doctype_name"));
                        list.add(dto);
                    }
                    return list;
                });
    }


}
