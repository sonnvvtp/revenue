package com.viettelpost.platform.bms.portal.common.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomUser {
    private Long userId;
    private String post;
    private String org;
    private String name;
    private String phone;
    private String roleCode;
    private String username;
    private String staffCode;
    private Long dnUserId;
    private Long employeeGroupId;
    private Long cusId;
    private String sub;
    private Integer fromSource;
    private String chiNhanh;
    private String maBuCuc;
}
