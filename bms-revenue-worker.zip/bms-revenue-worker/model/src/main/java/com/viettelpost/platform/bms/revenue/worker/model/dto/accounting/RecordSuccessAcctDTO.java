package com.viettelpost.platform.bms.revenue.worker.model.dto.accounting;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RecordSuccessAcctDTO {

    @JsonAlias("PRE_RECORD_ADVANCE_ID")
    private Long preRecordAdvanceId;

    @JsonAlias("ADVANCE_NO")
    private String advanceNo;

    @JsonAlias("PAY_AMOUNT")
    private BigDecimal payAmount;

    @JsonAlias("ACCOUNTING_DATE")
    private LocalDateTime accountingDate;

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("CUS_PO_CODE")
    private String cusPoCode;

    @JsonAlias("PARTNER_CODE")
    private String partnerCode;

    @JsonAlias("RES_TRANSACTION_ID")
    private String resTransactionId;

    @JsonAlias("BANK_ACCOUNT_NO")
    private String bankAccountNo;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("POST_CODE")
    private String postCode;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("ORG_CODE")
    private String orgCode;

    @JsonAlias("CREATED_AT")
    private LocalDateTime createdAt;
}
