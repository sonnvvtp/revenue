package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.epacket.*;
import com.viettelpost.platform.bms.portal.model.request.partnerConfig.*;
import com.viettelpost.platform.bms.portal.model.response.epacket.EpacketInsertMissingResponse;
import com.viettelpost.platform.bms.portal.service.handler.EpacketPartnerInternalService;
import com.viettelpost.platform.bms.portal.service.handler.PartnerConfigService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import reactor.core.publisher.Mono;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.ParseException;

@Slf4j
@Path("partner")
@Tag(name = "Partner-epacket")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@RequiredArgsConstructor
public class EpacketPartnerInternalController {

    private final EpacketPartnerInternalService epacketPartnerService;

    @POST
    @Path("/epacket/manual-deposit")
    @Operation(summary = "partner epacket manual-deposit")
    @APIResponse(responseCode = "200", description = "epacket manual deposit success")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> manualDepositPartnerEpacket(@RequestBody EpacketManualDepositRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.manualDepositPartnerEpacket(req));
    }

    @POST
    @Path("/epacket/transaction-epacket")
    @Operation(summary = "partner create - cancel transaction")
    @APIResponse(responseCode = "200", description = "transaction success")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> partnerTransactionEpacket(@RequestBody EpacketTransactionRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.partnerTransactionEpacket(req));
    }

   /* @GET
    @Path("/epacket/reconciliation-epacket")
    @Operation(summary = "get list danh sách các transaction từ đối tác nội bộ để đối soát")
    @APIResponse(responseCode = "200", description = "return danh sách các transaction")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> ReconciliationTransactionEpacket(@QueryParam("cusId") Integer cusId,
                                                   @QueryParam("page") Integer page,
                                                   @QueryParam("size") Integer size,
                                                   @QueryParam("fromDate") String fromDate,
                                                   @QueryParam("toDate") String toDate) throws ParseException {
        int p = page == null ? 0 : page;
        int s = size == null ? 20 : size;
        log.info("reconciliation-epacket endpoint: {}",cusId);
        return ReactiveConverter.toUni(epacketPartnerService.reconciliationTransactionEpacket(cusId, fromDate, toDate, p, s));
    }*/

    @POST
    @Path("/epacket/search-transaction-epacket")
    @Operation(summary = "search transaction epacket")
    @APIResponse(responseCode = "200", description = "search transaction success")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> searchTransactionEpacket(@RequestBody EpacketSearchTransactionRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.searchTransactionEpacket(req));
    }

    @POST
    @Path("/epacket/cancel-transaction-epacket")
    @Operation(summary = "cancel transaction epacket")
    @APIResponse(responseCode = "200", description = "cancel transaction success")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> cancelTransactionsEpacket(@RequestBody EpacketCancelTransactionReq req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.cancelTransactionsEpacket(req));
    }

    @POST
    @Path("/epacket/re-callback-transaction")
    @Operation(summary = "re-callback-transaction")
    @APIResponse(responseCode = "200", description = "recallback transaction when miss callback to Logistek")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> reCallbackTransaction(@RequestBody EpacketCallbackRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.reCallbackTransaction(req));
    }

    /*@GET
    @Path("/epacket/balance-period-epacket")
    @Operation(summary = "đối soát số dư")
    @APIResponse(responseCode = "200", description = "return kết quả số dư khớp hay không")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> balancePeriodEpacket(@QueryParam("cusId") Integer cusId,
                                              @QueryParam("referenceTime") String referenceTime) throws ParseException {
        log.info("balance-period-epacket: {}",cusId);
        return ReactiveConverter.toUni(epacketPartnerService.balancePeriodEpacket(cusId, referenceTime));
    }*/

    /*@GET
    @Path("/epacket/list-transaction-epacket")
    @Operation(summary = "Lấy danh sách các giao dịch cả 2 bảng")
    @APIResponse(responseCode = "200", description = "Trả về danh sách các giao dịch")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> listTransactionEpacket(@QueryParam("cusId") Integer cusId,
                                                @QueryParam("walletType") String walletType,
                                                @QueryParam("transactionType") Integer transactionType,
                                                @QueryParam("fromDate") String fromDate,
                                                @QueryParam("toDate") String toDate,
                                                @QueryParam("transactionCode") String transactionCode,
                                                @QueryParam("reconStatus") Integer reconStatus,
                                                @QueryParam("accountingStatus") Integer accountingStatus) throws ParseException {
        log.info("balance-period-epacket: {}",cusId);
        return ReactiveConverter.toUni(epacketPartnerService.listTransactionEpacket(cusId, walletType,transactionType,fromDate,toDate,transactionCode,reconStatus,accountingStatus));
    }*/

    @POST
    @Path("/epacket/list-transaction-epacket")
    @Operation(summary = "Lấy danh sách các giao dịch")
    @APIResponse(responseCode = "200", description = "Trả về danh sách các giao dịch")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> searchAllTransEpacket(@RequestBody EpacketListTransactionRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.listTransactionEpacket(req));
    }

    @POST
    @Path("/epacket/list-export-to-excel")
    @Operation(summary = "Xuất excel danh sách giao dịch")
    @APIResponse(responseCode = "200", description = "Trả về danh sách các giao dịch")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportToExcelTransactionEpacket(@RequestBody EpacketListTransactionRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.exportToExcelEpacket(req));
    }

    @POST
    @Path("/epacket/reconciliation-epacket")
    @Operation(summary = "lấy danh sách các transaction từ đối tác nội bộ và fico để đối soát")
    @APIResponse(responseCode = "200", description = "return danh sách các transaction")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> reconciliationEpacket(@RequestBody EpacketReconciliationEpacketRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.reconciliationEpacket(req));
    }

    @POST
    @Path("/epacket/insert-missing-transactions")
    @Operation(summary = "Insert dữ liệu VTP bị thiếu")
    @APIResponse(responseCode = "200", description = "return kết quả insert")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> insertMissingTransactions(@RequestBody EpacketInsertMissTransactionsRequest req) throws ParseException {
        return ReactiveConverter.toUni(epacketPartnerService.insertMissingTransactions(req));
    }

}
