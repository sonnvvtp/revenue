package com.viettelpost.platform.bms.revenue.worker.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueAccountingType;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueRecordDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueStatementDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RevenueStatementSapDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.GeneralOrderEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueRecordEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLevel2Entity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLevel2LineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLineEntity;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface GloExpRevenueRepository extends BaseRepository {

    Uni<Boolean> checkExistedInvoiceOrder(String domainType, String orderCode, Integer orderType, Integer picType, String source);

    Multi<GeneralOrderEntity> saveBatchGeneralOrder(String domainType, List<GeneralOrderEntity> entities, SqlConnection sqlConnection);

    Multi<ItemOrderEntity> saveBatchItemOrder(String domainType, List<ItemOrderEntity> entities, SqlConnection sqlConnection);

    Multi<InvoiceInfoEntity> saveInvoiceInfo(String domainType, List<InvoiceInfoEntity> entities, SqlConnection sqlConnection);

    Uni<Integer> groupByBillRevenueCount(BigDecimal periodId, String domainType, RevenueType revenueType);

    Multi<GroupRevenueRecordDTO> findGroupByRevenueRecord(BigDecimal periodId, String domainType, RevenueType revenueType, Integer page, Integer size);

    Uni<Integer> groupByBillRevenueCountV2(BigDecimal periodId, String domainType, RevenueType revenueType);

    Multi<GroupRevenueRecordDTO> findGroupByRevenueRecordV2(BigDecimal periodId, String domainType, RevenueType revenueType, Integer page, Integer size);

    Multi<RevenueStatementEntity> saveBatchRevenueStatement(List<RevenueStatementEntity> entities, SqlConnection sqlConnection);

    Multi<RevenueStatementLineEntity> saveBatchRevenueStatementLine(List<RevenueStatementLineEntity> entities, SqlConnection sqlConnection);

    Uni<RevenueStatementLevel2Entity> saveRevenueStatementLevel2(RevenueStatementLevel2Entity entity, SqlConnection sqlConnection);

    Uni<Integer> findGroupByRevenueStatementCount(BigDecimal periodId, SqlConnection sqlConnection);

    Multi<RevenueStatementEntity> findRevenueStatementBy(BigDecimal periodId, Integer page, Integer size, SqlConnection sqlConnection);

    Uni<GroupRevenueStatementDTO> findGroupByRevenueStatement(BigDecimal periodId, SqlConnection sqlConnection);

    Multi<RevenueStatementLevel2LineEntity> saveBatchRevenueStatementLevel2Line(List<RevenueStatementLevel2LineEntity> entities, SqlConnection sqlConnection);

    Uni<Boolean> updateRevenueStatementLevel2By(BigDecimal debtId, GroupRevenueStatementDTO groupRevenueStatementDTO, SqlConnection sqlConnection);

    Uni<Integer> findAllRevenueStatementCount(BigDecimal periodId, RevenueType revenueType, SqlConnection sqlConnection);

    Multi<RevenueStatementSapDTO> findAllRevenueStatementBy(BigDecimal periodId, RevenueType revenueType , Integer page, Integer size, SqlConnection sqlConnection);

    Uni<Boolean> updateRevenueStatementBy(List<BigDecimal> ids, int status, SqlConnection sqlConnection);

    Uni<Boolean> updateRevenueRecordBy(List<BigDecimal> ids, int status, SqlConnection sqlConnection);

    Uni<Void> updateBatchRevenueRecord(List<RevenueRecordEntity> statementLineEntityList, SqlConnection sqlConnection);

    Multi<RevenuePeriodControlEntity> findRevenuePeriodControlBy(String status);

    Uni<Long> findAllRevenueVtpRecordCount(BigDecimal periodId, String domainType);

    Uni<Long> findAllRevenueRecordCount(BigDecimal periodId, String domainType);

    Uni<Boolean> updateRevenuePeriodControl(BigDecimal id, String status, LocalDateTime startDate, LocalDateTime endDate, SqlConnection sqlConnection);

    Uni<Integer> checkRevenuePeriodControlIsExists(BigDecimal periodId);

    Uni<RevenuePeriodControlEntity> save(RevenuePeriodControlEntity entity, SqlConnection sqlConnection);

    Uni<Integer> groupByRevenueBillEditCount(BigDecimal periodId, String domainType, RevenueType revenueType);

    Multi<GroupRevenueRecordDTO> findGroupByRevenueBillEdit(BigDecimal periodId, String domainType, RevenueType revenueType, Integer page, Integer size);
}
