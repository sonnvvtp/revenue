package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartnerConfigByServiceDTO {
    @JsonAlias("partner_source")
    private String partnerSource;

    @JsonAlias("service_type")
    private String serviceType;

    @JsonAlias("merchant_type")
    private String merchantType;

    @JsonAlias("prefix_code")
    private String prefixCode;

    @JsonAlias("partner_external_code")
    private String bankCode;

    @JsonAlias("status_internal")
    private int statusInternal;

    @JsonAlias("status_external")
    private int statusExternal;

    @JsonAlias("partner_external_logo")
    private String logoPartnerExternal;

    @JsonAlias("partner_external_name")
    private String partnerExternalName;

    @JsonAlias("partner_internal_id")
    private Long partnerInternalId;

    @JsonAlias("partner_external_id")
    private Long partnerExternalId;

    private String updated;

}
