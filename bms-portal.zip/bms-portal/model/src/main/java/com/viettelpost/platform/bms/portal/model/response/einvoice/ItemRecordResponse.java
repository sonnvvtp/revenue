package com.viettelpost.platform.bms.portal.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemRecordResponse {

    @JsonAlias("id")
    public BigDecimal id;

    @JsonAlias("general_order_id")
    public BigDecimal generalOrderId;

    @JsonAlias("item_selection")
    public Integer itemSelection;

    @JsonAlias("item_code")
    public String itemCode;

    @JsonAlias("item_name")
    public String itemName;

    @JsonAlias("item_unit")
    public String itemUnit;

    @JsonAlias("item_quantity")
    public Long itemQuantity;

    @JsonAlias("item_price")
    public BigDecimal itemPrice;

    @JsonAlias("item_amount_before_tax")
    public BigDecimal itemAmountBeforeTax;

    @JsonAlias("item_tax_type")
    public Integer itemTaxType;

    @JsonAlias("item_tax_percent")
    public BigDecimal itemTaxPercent;

    @JsonAlias("item_tax_amount")
    public BigDecimal itemTaxAmount;

    @JsonAlias("item_amount_after_tax")
    public BigDecimal itemAmountAfterTax;

    public ItemRecordResponse(ItemRecordResponse item) {
        this.id = item.id;
        this.generalOrderId = item.generalOrderId;
        this.itemSelection = item.itemSelection;
        this.itemCode = item.itemCode;
        this.itemName = item.itemName;
        this.itemUnit = item.itemUnit;
        this.itemQuantity = item.itemQuantity;
        this.itemPrice = item.itemPrice;
        this.itemAmountBeforeTax = item.itemAmountBeforeTax;
        this.itemTaxType = item.itemTaxType;
        this.itemTaxPercent = item.itemTaxPercent;
        this.itemTaxAmount = item.itemTaxAmount;
        this.itemAmountAfterTax = item.itemAmountAfterTax;
    }
}
