// BudgetResponse.java
package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BudgetResponse {

    @JsonProperty("RESULT")
    private List<Result> result;

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class Result {

        @JsonProperty("FMAREA")
        private int fmArea;

        @JsonProperty("LEDGER")
        private String ledger;

        @JsonProperty("FISCAL_YEAR")
        private int fiscalYear;

        @JsonProperty("BUDGET_PERIOD")
        private String budgetPeriod;

        @JsonProperty("FUNDS_CENTER")
        private String fundsCenter;

        @JsonProperty("COMMITMENT_ITEM")
        private String commitmentItem;

        @JsonProperty("FUNDED_PROGRAM")
        private String fundedProgram;

        @JsonProperty("CONSUMABLE_AMOUNT")
        private String consumableAmount;

        @JsonProperty("CONSUMED_AMOUNT")
        private String consumedAmount;

        @JsonProperty("AVAILABLE_AMOUNT")
        private String availableAmount;
    }

}