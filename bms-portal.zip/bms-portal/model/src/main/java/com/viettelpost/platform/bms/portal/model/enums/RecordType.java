package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

@Getter
@AllArgsConstructor
public enum RecordType {
    CUOC(1, "Đơn thu hộ cước"),
    COD(2, "Đơn thu hộ COD"),
    CHI_COD(3, "Đơn chi COD"),
    NA(0, "N/A");

    private final Integer code;
    private final String description;

    public static RecordType fromCode(Integer code) {
        for (RecordType status : RecordType.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }
}
