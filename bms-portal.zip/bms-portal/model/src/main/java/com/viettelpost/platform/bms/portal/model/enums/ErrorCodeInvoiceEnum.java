package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum ErrorCodeInvoiceEnum {

    SUCCESS("00", "SUCCESS"),
    UNAUTHORIZED("01", "UNAUTHORIZED"),
    DATA_ERROR("02", "DATA_ERROR"),
    INTERNAL_SERVER_ERROR("99", "INTERNAL_SERVER_ERROR"),
    SQL_TIMEOUT("ERROR_SQL_TIMEOUT", "SQL_TIMEOUT"),
    INVOICE_NOT_FOUND("INVOICE_NOT_FOUND", "Không tìm thấy thông tin hóa đơn: %s"),
    QUANTITY_NOT_MATCH("QUANTITY_NOT_MATCH", "Tổng chi tiết mặt hàng của đơn không khớp Tổng số lượng mặt hàng của đơn hàng"),
    TOTAL_MONEY_NOT_MATCH("TOTAL_MONEY_NOT_MATCH", "Tổng tiền các mặt hàng không khớp Tổng tiền của đơn"),
    INVOICE_ORER_EXISTS("INVOICE_ORER_EXISTS", "Bill %s đã tồn tại"),
    INVOICE_USER_EXISTS("INVOICE_USER_EXISTS", "User %s đã tồn tại"),
    LIST_ORDER_NOT_VALID("LIST_ORDER_NOT_VALID", "Danh sách đơn xuất hóa đơn không hợp lệ"),
    LIST_RECORD_NOT_VALID("LIST_RECORD_NOT_VALID", "Danh sách bảng kê không hợp lệ");

    private final String code;
    private final String message;

    public String format(String ...value) {
        return String.format(this.message, Arrays.stream(value).toArray());
    }
}
