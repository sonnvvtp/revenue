package com.viettelpost.platform.bms.portal.model.response;

import lombok.Data;

import java.time.LocalDate;

@Data
public class InvoiceCustomerResponse {
    private Long id;
    private String customerCode;
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private String customerAddress;
    private String customerTax;
    private String budgetUnitCode;
    private String unitLevel2Code;
    private String unitLevel2Id;
    private String eContractCode;
    private LocalDate eContractSignedDate;
    private String partnerSource;
}
