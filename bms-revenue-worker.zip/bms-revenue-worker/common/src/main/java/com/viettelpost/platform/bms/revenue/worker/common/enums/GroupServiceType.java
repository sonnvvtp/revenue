package com.viettelpost.platform.bms.revenue.worker.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum GroupServiceType {
    CPN(1, "CPNTN", "CPN", "CPN Trong nước"),
    CPQT(2, "CPQT","CPQT", "CP Quốc tế"),
    LOG(3, "LOG","LOG", "Logistics"),
    OTHER(4, "KHAC","KHAC", "KHAC"),
    ALL(5, "ALL","ALL", "ALL");

    private final int value;
    private final String code;
    private final String shortName;
    private final String name;
}
