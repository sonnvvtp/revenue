package com.viettelpost.platform.bms.portal.model.request.epacket;

import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import io.r2dbc.spi.Parameter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketInsertMissTransactionsRequest {
    private List<ITEMS> items;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ITEMS {
        private String requestId;
        private String transactionCode;
        private BigDecimal amount;
        private PartnerSource partnerSource;
        private ServiceType serviceType;
        private MerchantType merchantType;
        private Long cusId;
        private String accountName;
        private Long orgId;
        private Long postId;
        private String postCode;
        private String orgCode;
        private String reqPaymentTime;
        private Integer transactionType;
        private String reqPaymentCode;
        private Integer reconStatus;
    }
}
