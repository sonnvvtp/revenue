package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BmsRequestPaymentAndLineDTO {

    @JsonAlias("transaction_code")
    private String transactionCode;

    private String bill;

    @JsonAlias("vendor_code")
    private String vendorCode;

    @JsonAlias("partner_evtp")
    private String partnerEvtp;

    @JsonAlias("date_bill")
    private String dateBill;

    @JsonAlias("accounting_date")
    private LocalDateTime accountingDate;

    private BigDecimal amount;

    @JsonAlias("cus_id")
    private Long cusId;

    @JsonAlias("req_payment_id")
    private Long reqPaymentId;


}
