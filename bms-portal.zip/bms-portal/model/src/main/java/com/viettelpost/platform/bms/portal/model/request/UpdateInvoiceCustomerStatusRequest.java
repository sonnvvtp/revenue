package com.viettelpost.platform.bms.portal.model.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateInvoiceCustomerStatusRequest {
    @NotNull(message = "Trạng thái là bắt buộc")
    private Integer statusCode;

    private String reason;
}
