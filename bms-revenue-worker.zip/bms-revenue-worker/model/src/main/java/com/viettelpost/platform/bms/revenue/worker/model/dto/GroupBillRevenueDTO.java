package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class GroupBillRevenueDTO {

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("ORGCODE")
    private String orgcode;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("POSTCODE")
    private String postcode;

    @JsonAlias("PARTNER_ID")
    private Long partnerId;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("M_PRODUCT")
    private String mProduct;

    @JsonAlias("PRODUCT_CATEGORY")
    private String productCategory;

    @JsonAlias("TOTAL_BILL")
    private BigDecimal totalBill;

    @JsonAlias("AMT")
    private BigDecimal amt;

    @JsonAlias("AMT_DEDUCT")
    private BigDecimal amtDeduct;

    @JsonAlias("FREIGHT")
    private BigDecimal freight;
}
