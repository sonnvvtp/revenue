package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BillPetroSuccessDataResponse {

    private String billCode;
    private String billCharacters;
    private String status;
    private String plateNumber;
    private String postOffice;
}
