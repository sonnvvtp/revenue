package com.viettelpost.platform.bms.portal.model.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class VehicleTypeGroupKmcpModel {

    private Long id;
    @JsonAlias("vehicle_type_group_id")
    private Long groupId;
    @JsonAlias("org_type")
    private Integer orgType;
    @JsonAlias("kmcp_id")
    private String kmcpId;
}
