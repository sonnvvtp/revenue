package com.viettelpost.platform.bms.portal.model.response;

import lombok.Data;

@Data
public class DocTypeResponse {
    private Long docTypeId;
    private String docTypeCode;
    private String docTypeName;
}
