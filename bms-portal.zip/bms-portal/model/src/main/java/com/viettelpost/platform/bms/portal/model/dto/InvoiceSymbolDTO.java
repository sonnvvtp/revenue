package com.viettelpost.platform.bms.portal.model.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class InvoiceSymbolDTO {
    private Long symbolId;
    private String symbolCode;
    private Integer invoiceType;
    private String invoiceTypeName;
    private Integer currentNumber;
    private Long maxThreshold;
    private Boolean isActive;
    private String companyCode;
    private String issueDateType;
    private LocalDateTime createdAt;
    private String createdBy;
    private LocalDateTime updateAt;
    private String updateBy;
} 