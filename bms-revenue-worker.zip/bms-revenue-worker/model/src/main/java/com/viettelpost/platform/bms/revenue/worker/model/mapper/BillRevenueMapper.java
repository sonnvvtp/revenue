package com.viettelpost.platform.bms.revenue.worker.model.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
import com.viettelpost.platform.bms.revenue.worker.model.model.Pair;
import com.viettelpost.platform.bms.revenue.worker.model.request.InvoiceInfoDTO;
import com.viettelpost.platform.bms.revenue.worker.model.request.ItemOrderDTO;
import com.viettelpost.platform.bms.revenue.worker.model.request.general.GeneralOrderRequest;
import com.viettelpost.platform.bms.revenue.worker.model.request.general.UnitInfoDTO;
import com.viettelpost.platform.bms.revenue.worker.model.request.general.UnitLevelDTO;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BillRevenueMapper {
  public static List<GeneralOrderRequest> toGeneralOrderRequests(List<BmsBillRevenueDTO> billRevenueDTOList, ObjectMapper objectMapper) {
    return billRevenueDTOList.stream()
        .map(bill -> mapToGeneralOrderRequest(bill, objectMapper))
        .collect(Collectors.toList());
  }

  private static GeneralOrderRequest mapToGeneralOrderRequest(BmsBillRevenueDTO dto, ObjectMapper objectMapper) {
    String billRevenueId = dto.getBillRevenueId() != null ? dto.getBillRevenueId().toString() : null;
    UnitLevelDTO unitLevel1 =  UnitLevelDTO.builder()
        .id(dto.getPostId())
        .code(dto.getPostCode())
        .name(dto.getPostName())
        .build();

    UnitLevelDTO unitLevel2 =  UnitLevelDTO.builder()
        .id(dto.getOrgId())
        .code(dto.getOrgCode())
        .name(dto.getOrgName())
        .build();
    UnitInfoDTO unitInfoDTO = new UnitInfoDTO();
    unitInfoDTO.setUnitLevel1(unitLevel1);
    unitInfoDTO.setUnitLevel2(unitLevel2);

    try {
      return GeneralOrderRequest.builder()
          .orderId(billRevenueId)
          .orderCode(String.format("%s-%s", dto.getBill(), billRevenueId))                                  // BILL
          .orderParent(null)
          .orderReference(dto.getBill())
          .orderName("")
          .cashflowType("REVENUE")
          .serviceCode(dto.getMProduct())
          .orderCreatedAt(dto.getDateBill())                       // DATEINSERT
          .orderRevenueEntryAt(null)
          .orderDeliveredAt(dto.getDateInsert())                       // DATEBILL
          .employeeId(null)
          .employeeInfo(null)
          .unitLevel1Id(dto.getPostId())
          .unitLevel2Id(dto.getOrgId())
          .unitInfo(convertToMap(unitInfoDTO, objectMapper))
          .companyCode(dto.getCompanyCode())
          .sellerId(null)
          .sellerCode(null)
          .sellerInfo(null)
          .buyerId(null)
          .buyerCode(dto.getPartnerEvtp())
          .buyerInfo(null)
          .consigneeId(null)
          .consignee(null)
          .orderTotalQuantity(2L)
          .orderAmountBeforeTax(dto.getAmtBeforeTax())
          .orderTaxAmount(dto.getAmtVat())                           // AMT_VAT
          .orderAmountAfterTax(dto.getAmt())                         // AMT
          .totalAmount(dto.getAmt().subtract(Objects.nonNull(dto.getFee()) ? dto.getFee() : BigDecimal.ZERO))
          .paymentInfo(null)
          .paymentMethod(0)
          .paymentTermId(dto.getPaymentTeamId())
          .paymentStatus(0)
          .invoicePartner("")
          .currency("VND")
          .invoiceInfo(mapToInvoiceInfo(dto))             // object con
          .itemOrderList(mapToItemOrder(dto))    // list object con
          .recordType(dto.getBillRevenueType())
          .picType(2)
          .requestType(new Integer[]{1, 2})
          .periodId(dto.getPeriodId())
          .recordRevenueEntryAt(dto.getOrgDatebill())
          .build();
    } catch (Exception e) {
      log.info("mapToGeneralOrderRequest_parser_error: {}", e.getMessage(), e);
      throw new RuntimeException(e);
    }
  }

  private static InvoiceInfoDTO mapToInvoiceInfo(BmsBillRevenueDTO dto) {
    return InvoiceInfoDTO.builder()
        .orderId(String.valueOf(dto.getBillId()))
        .buyerId(null)
        .buyerType(null)
        .buyerName(dto.getFullname())
        .partnerName(dto.getFullname())
        .buyerPhone(dto.getPhone())
        .buyerEmail(dto.getEmail())
        .buyerTaxCode(dto.getTaxid())
        .buyerAddress(dto.getAddress())
        .buyerBankAccount(null)
        .buyerBankName(null)
        .build();
  }

  private static List<ItemOrderDTO> mapToItemOrder(BmsBillRevenueDTO dto) {
    List<ItemOrderDTO>  list = new ArrayList<>();
    list.add(
        ItemOrderDTO.builder()
            .orderId(null)
            .departureLocation(null)
            .arrivalLocation(null)
            .vehiclePlateNumber(null)
            .warehouseCode(null)
            .itemSelection(1)
            .itemCode(dto.getBill())
            .itemName(dto.getBill())
            .itemNote(null)
            .itemUnit("bill")
            .itemQuantity(1L)
            .itemPrice(dto.getAmt())
            .itemWeight(dto.getWeight())
            .itemAmountBeforeTax(dto.getAmtBeforeTax())
            .itemTaxType(1)
            .itemTaxPercent(dto.getVat())
            .itemTaxAmount(dto.getAmtVat())
            .itemAmountAfterTax(dto.getAmt())
            .attribute1(null)
            .attribute2(null)
            .attribute3(null)
            .build()
    );
    Pair<BigDecimal, BigDecimal> pairVat = calculateVatAmount(dto.getFee(), dto.getVat());
    list.add(
        ItemOrderDTO.builder()
            .orderId(null)
            .departureLocation(null)
            .arrivalLocation(null)
            .vehiclePlateNumber(null)
            .warehouseCode(null)
            .itemSelection(3)
            .itemCode("discount")
            .itemName("discount")
            .itemNote(null)
            .itemUnit("discount")
            .itemQuantity(1L)
            .itemPrice(BigDecimal.ZERO)
            .itemWeight(0)
            .itemAmountBeforeTax(pairVat.getFirst())
            .itemTaxType(1)
            .itemTaxPercent(dto.getVat())
            .itemTaxAmount(pairVat.getSecond())
            .itemAmountAfterTax(dto.getFee())
            .attribute1(null)
            .attribute2(null)
            .attribute3(null)
            .build()
    );
    return list;
  }

  public static Map convertToMap(UnitInfoDTO unitInfoDTO, ObjectMapper objectMapper) throws Exception {
    return objectMapper.convertValue(unitInfoDTO, Map.class);
  }

  public static Pair<BigDecimal, BigDecimal> calculateVatAmount(BigDecimal amountAfterVat, Integer vat) {
    if (Objects.isNull(amountAfterVat)) {
      return new Pair<>(BigDecimal.ZERO, BigDecimal.ZERO);
    }

    if (Objects.nonNull(vat)) {
      // Tính hệ số VAT (1 + vat/100)
      BigDecimal amountBeforeVatFactor = BigDecimal.valueOf(1 + (vat / 100.0));
      // Tính số tiền trước VAT, chỉ định scale và chế độ làm tròn
      BigDecimal amountBeforeVatAmountFactor = amountAfterVat.divide(amountBeforeVatFactor, 0, RoundingMode.HALF_UP);
      BigDecimal amountBeforeVat = amountBeforeVatAmountFactor.setScale(0, RoundingMode.HALF_UP);
      return new Pair<>(amountBeforeVat, amountAfterVat.subtract(amountBeforeVat));
    }
    else {
      return new Pair<>(amountAfterVat, BigDecimal.ZERO);
    }
  }
}
