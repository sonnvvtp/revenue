package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BmsServiceCategoryMappingEntity {
    
    @JsonAlias("BMS_SERVICE_CATEGORY_ID")
    private Long bmsServiceCategoryId;

    @JsonAlias("SERVICE_CODE")
    private String serviceCode;

    @JsonAlias("PRODUCT_CATEGORY")
    private String productCategory;
}
