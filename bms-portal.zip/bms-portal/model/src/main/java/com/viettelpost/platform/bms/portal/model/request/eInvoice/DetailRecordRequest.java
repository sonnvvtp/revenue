package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import lombok.Data;

@Data
public class DetailRecordRequest {

    @Size(max = 100, message = "Từ khóa tìm kiếm quá dài")  // số hóa đơn
    private String orderCode;

    @JsonFormat(pattern = "dd/MM/yyyy")  // ngày tạo
    private LocalDate fromDate;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    private Integer page;

    private Integer size;

}
