package com.viettelpost.platform.bms.portal.repository;


import com.viettelpost.platform.bms.portal.model.dto.CarLicensePlateAndCIDTO;
import com.viettelpost.platform.bms.portal.model.model.CarManagementSettingModel;
import io.smallrye.mutiny.Uni;
import java.util.List;
import java.util.Map;
import reactor.core.publisher.Mono;

public interface CarRepository {

    Mono<List<CarManagementSettingModel>> getAllByCarType(List<String> carTypes);

    Uni<List<CarManagementSettingModel>> findAll();

    Mono<List<CarManagementSettingModel>> findByLicensePlates(List<String> licensePlates);

    Mono<List<CarLicensePlateAndCIDTO>> findLicensePlatesWithCI(List<String> licensePlates);

    Uni<Boolean> upsertCar(CarManagementSettingModel car);
}
