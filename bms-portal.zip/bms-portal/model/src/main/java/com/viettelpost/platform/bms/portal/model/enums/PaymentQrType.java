package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum PaymentQrType {
    QR_CODE(1,"QR_CODE", "Thanh toán qua QR code"),
    TKLK(2, "TKLK", "Thanh toán qua tài khoản liên kết"),
    MNT(3, "MNT", "Thanh toán qua mã nộp tiền"),
    NA(-1,"N/A","N/A");
    private int id;
    private String code;
    private String name;

    public static PaymentQrType get(Integer id) {
        return Arrays.stream(PaymentQrType.values())
                .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(NA);
    }
}
