package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateInvoiceCustomerRequest {
  private Integer tenantId;
  private Long customerId;
  private Long cusId;
  private String customerCode;
  private Short customerType;
  private String customerName;
  private String customerPhone;
  private String customerEmail;
  private String customerAddress;
  private String customerTax;
  private String budgetUnitCode;
  private String unitLevel1Id;
  private String unitLevel1Code;
  private String unitLevel2Id;
  private String unitLevel2Code;
  private String eContractCode;
  private LocalDateTime eContractSignedDate;
  private Boolean invoiceDetailByBill = false;
  private List<InvoiceItemInfo> invoiceitems;
  private String partnerSource;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class InvoiceItemInfo {
    private BigDecimal invoiceCustomerId;
    private String customerItemCode;
    private Short customerItemType;
    private String customerItemName;
    private String customerItemPhone;
    private String customerItemEmail;
    private String customerItemAddress;
    private String customerItemTax;
    private String invoiceConditionLv1;
    private String invoiceConditionLv2;
    private Integer fromDate;
    private Integer toDate;
    private Boolean autoMergeBill = false;
    private String bankName;
    private String bankAccountNumber;
    private String bankAccountName;
    private LocalDateTime paymentDate;
  }
}

