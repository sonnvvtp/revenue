package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ScopeQrType {

    NATIONAL(0,"NATIONAL", "Phạm vi toàn quốc"),
    SPECIAL(1, "SPECIAL", "Phạm vi đặc biệt"),
    NA(-1,"N/A","N/A");
    private int id;
    private String code;
    private String name;

    public static ScopeQrType get(Integer id) {
        return Arrays.stream(ScopeQrType.values())
                .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(NA);
    }
}
