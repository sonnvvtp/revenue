package com.viettelpost.platform.bms.portal.model.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class InvoiceMailConfigDTO {
    private Long id;
    private String sendName;
    private String content;
    private Boolean isActive;
    private String companyCode;
    private String title;
    private LocalDateTime createdAt;
    private String createdBy;
    private LocalDateTime updateAt;
    private String updateBy;
    private LocalDateTime startDate;
} 