package com.viettelpost.platform.bms.portal.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KMCPConfigFilter {

    private List<Long> vehicleTypeGroupId;

    @Builder.Default
    private int page = 1;

    @Builder.Default
    private int size = 10;
}
