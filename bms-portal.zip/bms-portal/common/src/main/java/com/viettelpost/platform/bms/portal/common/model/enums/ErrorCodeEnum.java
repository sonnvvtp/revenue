package com.viettelpost.platform.bms.portal.common.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodeEnum {

    SUCCESS("00", "SUCCESS"),
    UNAUTHORIZED("01", "UNAUTHORIZED"),
    DATA_ERROR("02", "DATA_ERROR"),
    INTERNAL_SERVER_ERROR("99", "INTERNAL_SERVER_ERROR"),
    RECORD_COD_NOT_FOUND("03", "Không tìm thấy bảng kê"),
    CREATE_RECORD_ERROR("04", "Danh sách bill không cùng khách hàng hoặc loại bill"),
    ADD_BILL_RECORD_ERROR("05", "Bill với mã %d không hợp lệ"),
    BILL_NOT_FOUND("06", "Không tìm thấy bill"),
    CREATE_BATCH_ERROR("07", "Danh sách bảng kê không cùng khách hàng hoặc loại bill"),
    PAY_BATCH_NOT_FOUND("08", "Không tìm thấy bảng kê chi"),
    CUSTOMER_NOT_FOUND("09", "Không tìm thấy mã khách hàng"),
    CREATE_STATEMENT_ERROR("10", "Danh sách bảng kê không cùng ngân hàng chi"),
    PAY_BATCH_BANK_ERROR("11", "Bảng kê chưa có cấu hình thông tin ngân hàng"),
    STATEMENT_NOT_FOUND("12", "Không tìm thấy UNC"),
    SUMMARY_NOT_FOUND("13", "Không tìm thấy bảng THTT")
    ,;

    private final String code;
    private final String message;
}
