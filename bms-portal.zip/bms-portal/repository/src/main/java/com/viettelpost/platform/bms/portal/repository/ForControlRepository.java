package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.request.forControl.GetDataComparisonInternalForm;
import com.viettelpost.platform.bms.portal.model.request.forControl.SyntheticDataReq;
import com.viettelpost.platform.bms.portal.model.response.forControl.BmsDebtComparisonExternalDTO;
import com.viettelpost.platform.bms.portal.model.response.forControl.BmsDebtComparisonInternalDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ForControlRepository {
    Mono<Long> countReqDocStatus(SyntheticDataReq req);
    Mono<Long> amountReqDocStatus(SyntheticDataReq req);
    Mono<Long> countResDocStatus(SyntheticDataReq req);
    Mono<Long> amountResDocStatus(SyntheticDataReq req);
    Mono<Integer> countAllComparisonExternal(SyntheticDataReq req);
    Flux<BmsDebtComparisonExternalDTO> getAllComparisonExternal(SyntheticDataReq req);

    Mono<Integer> countAllComparisonInternal(GetDataComparisonInternalForm req);
    Flux<BmsDebtComparisonInternalDTO> getAllComparisonInternal(GetDataComparisonInternalForm req);

}
