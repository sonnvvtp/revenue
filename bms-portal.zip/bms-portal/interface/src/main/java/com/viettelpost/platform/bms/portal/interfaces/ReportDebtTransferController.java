package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.DebtTransferReportRequest;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.FindListBatchDebtDetailRequest;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.FindListBatchDebtRequest;
import com.viettelpost.platform.bms.portal.service.handler.debttransfer.DebtTransferReportService;
import io.smallrye.mutiny.Uni;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/report-debt-transfer")
@Tag(name = "report-debt-transfer")
@RequiredArgsConstructor
public class ReportDebtTransferController {

    private final DebtTransferReportService debtTransferReportService;

    @GET
    @Path("/doctype-list")
    @Operation(summary = "Danh sách loại bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getDocTypeBatchList() {
        return debtTransferReportService.getDocTypeBatchList()
                .map(docTypeList -> BaseResponse.successApi(docTypeList, "OK"));
    }

    @POST
    @Path("/print")
    @Operation(summary = "In báo cáo chuyển nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> printReportDebtTransfer(@Valid DebtTransferReportRequest debtTransferReportRequest) {
        return debtTransferReportService.printReportDebtTransfer(debtTransferReportRequest)
                .map(printResponse -> BaseResponse.successApi(printResponse, "OK"));
    }

    @POST
    @Path("/excel")
    @Operation(summary = "Xuất excel báo cáo chuyển nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportExcelDebtTransferReport(@Valid DebtTransferReportRequest debtTransferReportRequest) {
        return debtTransferReportService.exportExcelDebtTransferReport(debtTransferReportRequest)
                .flatMap(os ->  {
                            String fileName = "BAOCAO_CONGNO_BG" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".xlsx";
                            return Uni.createFrom().item(Response.ok(os.toByteArray())
                                    .header("content-disposition", "attachment; filename=" + fileName)
                                    .header("content-type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                    .build());
                        }
                );
    }

    @POST
    @Path("/batch/list")
    @Operation(summary = "Danh sách phiếu thu công nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findListBatchDebt(@Valid FindListBatchDebtRequest findListBatchDebtRequest) {
        return debtTransferReportService.findListBatchDebt(findListBatchDebtRequest)
                .map(listBillDebt -> BaseResponse.successApi(listBillDebt, "OK"));
    }

    @POST
    @Path("/batch/detail")
    @Operation(summary = "Chi tiết phiếu thu công nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findListBatchDebtDetail(@Valid FindListBatchDebtDetailRequest findListBatchDebtDetailRequest) {
        return debtTransferReportService.findListBatchDebtDetail(findListBatchDebtDetailRequest)
                .map(listBillDebt -> BaseResponse.successApi(listBillDebt, "OK"));
    }

    @POST
    @Path("/batch/list-excel")
    @Operation(summary = "Xuất excel danh sách phiếu thu công nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportExcelListBatchDebt(@Valid FindListBatchDebtRequest findListBatchDebtRequest) {
        return debtTransferReportService.exportExcelListBatchDebt(findListBatchDebtRequest)
                .flatMap(os ->  {
                            String fileName = "DSPHIEUTHUCN" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".xlsx";
                            return Uni.createFrom().item(Response.ok(os.toByteArray())
                                    .header("content-disposition", "attachment; filename=" + fileName)
                                    .header("content-type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                    .build());
                        }
                );
    }

    @POST
    @Path("/batch/detail-excel")
    @Operation(summary = "Xuất excel chi tiết phiếu thu công nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportExcelListBatchDetailDebt(@Valid FindListBatchDebtDetailRequest findListBatchDebtDetailRequest) {
        return debtTransferReportService.exportExcelListBatchDetailDebt(findListBatchDebtDetailRequest)
                .flatMap(os ->  {
                            String fileName = "PHIEUTHUCN" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".xlsx";
                            return Uni.createFrom().item(Response.ok(os.toByteArray())
                                    .header("content-disposition", "attachment; filename=" + fileName)
                                    .header("content-type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                    .build());
                        }
                );
    }

    @POST
    @Path("/batch/detail-print")
    @Operation(summary = "In chi tiết phiếu thu công nợ")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> printListBatchDetailDebt(@Valid Long clearBatchId) {
        return debtTransferReportService.printListBatchDetailDebt(clearBatchId)
                .map(printResponse -> BaseResponse.successApi(printResponse, "OK"));
    }
}
