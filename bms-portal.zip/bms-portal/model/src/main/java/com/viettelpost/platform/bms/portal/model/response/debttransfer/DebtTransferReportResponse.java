package com.viettelpost.platform.bms.portal.model.response.debttransfer;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DebtTransferReportResponse {

    @JsonAlias("DEBT_TYPE_NAME")
    private String debtTypeName;

    @JsonAlias("ORG_NAME")
    private String orgName;

    @JsonAlias("POST_NAME")
    private String postName;

    @JsonAlias("ORG_NAME_TO")
    private String orgNameTo;

    @JsonAlias("POST_NAME_TO")
    private String postNameTo;

    @JsonAlias("DOCUMENT_NO")
    private String documentNo;

    @JsonAlias("M_PRODUCT")
    private String mProduct;

    @JsonAlias("ACCOUNTING_DATE")
    private String accountingDate;

    @JsonAlias("PERIOD_NAME")
    private String periodName;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_NAME")
    private String partnerName;

    @JsonAlias("PARTNER_NAME_TO")
    private String partnerNameTo;

    @JsonAlias("PARTNER_EVTP_TO")
    private String partnerEvtpTo;

    @JsonAlias("DESCRIPTION")
    private String description;

    @JsonAlias("AMT")
    private BigDecimal amt;

    @JsonAlias("AMT_DEDUCT")
    private BigDecimal amtDeduct;

    @JsonAlias("AMT_DEDUCT_OTHER")
    private BigDecimal amtDeductOther;

    @JsonAlias("AMT_PAY")
    private BigDecimal amtPay;
}
