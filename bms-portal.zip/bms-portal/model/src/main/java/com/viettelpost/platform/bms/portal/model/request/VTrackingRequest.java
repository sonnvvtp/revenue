package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class VTrackingRequest {

    @JsonProperty("month")
    private String month;
    @JsonProperty("codeFico")
    private String codeFico;
    @JsonProperty("regNo")
    private String regNo;

    public static VTrackingRequest toRequest(List<String> licensePlates, String timeReq) {
        VTrackingRequest request = new VTrackingRequest();
        request.setMonth(getTimeFormatted(timeReq));
        request.setCodeFico("");
        request.setRegNo(normalizeLicensePlates(licensePlates));
        return request;
    }

    private static String normalizeLicensePlates(List<String> carLicensePlates) {
        if (carLicensePlates == null || carLicensePlates.isEmpty()) {
            return "";
        }

        return carLicensePlates.stream()
                .map(carLicensePlate -> carLicensePlate.replaceAll("-", "")
                        .replaceAll("\\.", ""))
                .collect(Collectors.joining(","));
    }

    private static String getTimeFormatted(String synthesisPeriod) {
        String[] parts = synthesisPeriod.split("/");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        return String.format("%d-%02d", year, month);
    }
}
