package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BillReturnAggregateAcctDTO {

    @JsonAlias("ADVANCE_ACCT_ID")
    private Long advanceAcctId;

    @JsonAlias("ADVANCE_ACCT_NO")
    private String advanceAcctNo;

    @JsonAlias("DEBT_DATE")
    private LocalDateTime debtDate;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_CODE")
    private String partnerCode;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("CUS_POST_ID")
    private Long cusPostId;

    @JsonAlias("CUS_ORG_ID")
    private Long cusOrgId;

    @JsonAlias("AMOUNT")
    private BigDecimal amount;

    @JsonAlias("CREATED_AT")
    private LocalDateTime createdAt;

    @JsonAlias("ACCOUNTING_DATE")
    private LocalDateTime accountingDate;

    @JsonAlias("DOC_DATE")
    private LocalDateTime docDate;
}
