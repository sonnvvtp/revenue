package com.viettelpost.platform.bms.revenue.worker.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupCustomeCodeDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueInvoiceDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueRecordDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceDoctypeEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceRecordEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceRecordLineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceSymbolEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceTypeEntity;
import com.viettelpost.platform.bms.revenue.worker.model.response.einvoice.FindRevenueRecordResponse;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;
import java.util.List;

public interface VtpInvoiceRepository extends BaseRepository {

    Uni<Integer> findCustomerCodeToInvoiceCount(BigDecimal periodId, String domainType);

    Multi<GroupCustomeCodeDTO> findCustomerCodeToInvoice(BigDecimal periodId, String domainType, Integer page, Integer size);

    Uni<Boolean> checkPartnerExists(String partnerCode);

    Multi<FindRevenueRecordResponse> findRevenueRecordBy(BigDecimal periodId, String domainType, List<GroupCustomeCodeDTO> customerCodes);

    Uni<InvoiceDoctypeEntity> finErpDoctypeBy(Long doctypeId, SqlConnection sqlConnection);

    Uni<InvoiceTypeEntity> findInvoiceTypeBy(String companyCode, SqlConnection sqlConnection);

    Uni<InvoiceSymbolEntity> findInvoiceSymbolBy(String companyCode, SqlConnection sqlConnection);

    Multi<ItemOrderEntity> findItemOrderBy(BigDecimal orderId, SqlConnection sqlConnection);

    Multi<GroupRevenueInvoiceDTO> findGroupByRevenueRecord(String domainType, BigDecimal periodId, List<GroupCustomeCodeDTO> customeCodeDTOList);

    Multi<InvoiceRecordEntity> saveBatchInvoiceRecord(List<InvoiceRecordEntity> entities, SqlConnection sqlConnection);

    Multi<InvoiceRecordLineEntity> saveBatchInvoiceRecordLine(List<InvoiceRecordLineEntity> entities, SqlConnection sqlConnection);

    Uni<Boolean> updateInvoiceStatusBy(String domainType,List<BigDecimal> ids, Integer status, SqlConnection sqlConnection);
}
