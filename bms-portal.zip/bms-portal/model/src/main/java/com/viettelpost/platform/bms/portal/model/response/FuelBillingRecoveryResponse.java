package com.viettelpost.platform.bms.portal.model.response;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FuelBillingRecoveryResponse {

    private Long id;
    private String receiptNumber;
    private String synthesisPeriod;
    private String carLicensePlate;
    private String unit;
    private BigDecimal budget;
    private BigDecimal actualMileage;
    private BigDecimal fuelConsumptionRate;
    private BigDecimal fuelConsumptionUnit;
    private BigDecimal budgetExcess;
    private BigDecimal totalExcessAmount;
    private BigDecimal budgetReduction;
    private String messSap;
    private String receiptNumberLv3;
    private String recoverId;
    private Integer status;
}
