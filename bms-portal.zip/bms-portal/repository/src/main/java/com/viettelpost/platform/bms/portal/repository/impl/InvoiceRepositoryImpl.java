package com.viettelpost.platform.bms.portal.repository.impl;


import com.viettelpost.platform.bms.portal.model.dto.CarLicensePlatePostcode;
import com.viettelpost.platform.bms.portal.model.model.InvoiceModel;
import com.viettelpost.platform.bms.portal.repository.InvoiceRepository;
import com.viettelpost.platform.root.common.data.collections.Pair;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.Parameters;
import io.r2dbc.spi.R2dbcType;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import io.r2dbc.spi.Statement;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class InvoiceRepositoryImpl implements InvoiceRepository {

    private static final int MAX_CONDITION = 1000;
    @Inject
    ConnectionPool oraclePool;
    //ADD more field if need
    public static final BiFunction<Row, RowMetadata, InvoiceModel> LIST_INVOICE_MAPPING =
            (row, rowMetaData) -> new InvoiceModel()
                    .setId(row.get("ID", String.class))
                    .setSerial(row.get("SERIAL", String.class))
                    .setInvNo(row.get("INV_NO", String.class))
                    .setPostOfficeCreateInv(row.get("POST_OFFICE_CREATE_INV", String.class))
                    .setCarLicensePlate(row.get("CAR_LICENSE_PLATE", String.class));

    @Override
    public Mono<Long> createInvoiceFile(Connection connection, String invId,
                                        InvoiceModel.FileInvoiceModel file) {
        String query =
                "INSERT INTO ERP_AC.FILE_INVOICE(ID, ID_INVOICE, FILE_NAME, FILE_SIZE, FILE_TYPE, URL_FILE, PATH_FILE)"
                        +
                        " VALUES (ERP_AC.FILE_INVOICE_ID_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?)";
        return Mono.from(connection.createStatement(query)
                        .bind(0, Parameters.in(R2dbcType.VARCHAR, invId))
                        .bind(1, Parameters.in(R2dbcType.VARCHAR, file.getFileName()))
                        .bind(2, Parameters.in(R2dbcType.NUMERIC, file.getFileSize()))
                        .bind(3, Parameters.in(R2dbcType.VARCHAR, file.getFileType()))
                        .bind(4, Parameters.in(R2dbcType.VARCHAR, file.getUrlFile()))
                        .bind(5, Parameters.in(R2dbcType.VARCHAR, file.getPathFile())).execute())
                .doOnSuccess(rowsUpdated -> log.info(
                        "insert invoice file successful for recordId {} {}: rows updated: {}",
                        invId, file, rowsUpdated))
                .onErrorResume(error -> {
                    log.error("Error in invoice file for recordId {} {}: {}", invId, file,
                            error.getMessage(), error);
                    return Mono.error(error);
                })
                .flatMap(queryResult -> Mono.from(queryResult.getRowsUpdated()));
    }

    @Override
    public Flux<CarLicensePlatePostcode> getCarLicensePlateAndPostCode(String synthesisPeriod) {
        var timeMap = getTime(synthesisPeriod);
        int month = timeMap.getLeft();
        int year = timeMap.getRight();

        String sql = "SELECT DISTINCT " +
                "i.CAR_LICENSE_PLATE, " +
                "i.POST_OFFICE_CREATE_INV " +
                "FROM " +
                "ERP_AC.INVOICE i " +
                "LEFT JOIN BK_INV ii ON i.ID = ii.INV_ID " +
                "LEFT JOIN ERP_AC.BKE_CAP1 c1 ON ii.BK_NO = c1.BK_NO " +
                "LEFT JOIN ERP_AC.GROUP_BKE_C1 g1 ON c1.BK_NO = g1.BK_NO_C1 " +
                "LEFT JOIN BKE_CAP2 c2 ON g1.BK_NO_C2 = c2.BK_NO " +
                "WHERE " +
                "EXTRACT(MONTH FROM c2.PERIOD) = :month " +
                "AND EXTRACT(YEAR FROM c2.PERIOD) = :year " +
                "AND i.CAR_LICENSE_PLATE IS NOT NULL " +
                "AND i.STATUS = 21";


        log.info("Executing query: {} with parameters: month={}, year={}", sql, month, year);

        return Flux.usingWhen(
                oraclePool.create(),
                connection -> Flux.from(
                                connection.createStatement(sql)
                                        .bind("month", Parameters.in(R2dbcType.INTEGER, month))
                                        .bind("year", Parameters.in(R2dbcType.INTEGER, year))
                                        .execute()
                        )
                        .flatMap(result -> result.map((row, metadata) ->
                                new CarLicensePlatePostcode(
                                        row.get("CAR_LICENSE_PLATE", String.class),
                                        row.get("POST_OFFICE_CREATE_INV", String.class)
                                )
                        )),
                Connection::close
        );
    }

    @Override
    public Mono<Map<String, List<InvoiceModel>>> getInvoicesByLicensePlates(String synthesisPeriod,
                                                                            List<String> licensePlates, Connection connection) {
        var extractParam = getTime(synthesisPeriod);
        var month = extractParam.getLeft();
        var year = extractParam.getRight();

        String placeholders = String.join(",", Collections.nCopies(licensePlates.size(), "?"));
        String sql =
                "    SELECT " +
                        "        i.*, " +
                        "        ii.ID AS ITEM_ID, " +
                        "        ii.QUANTITY AS ITEM_QUANTITY, " +
                        "        TRIM(i.CAR_LICENSE_PLATE) AS CAR_LICENSE_PLATE " +
                        "    FROM " +
                        "        ERP_AC.INVOICE i " +
                        "    LEFT JOIN " +
                        "        ERP_AC.INV_ITEMS ii ON i.ID = ii.ID_INV " +
                        "    LEFT JOIN " +
                        "        BK_INV inv ON i.ID = inv.INV_ID " +
                        "    LEFT JOIN " +
                        "        ERP_AC.BKE_CAP1 c1 ON inv.BK_NO = c1.BK_NO " +
                        "    LEFT JOIN " +
                        "        ERP_AC.GROUP_BKE_C1 g1 ON c1.BK_NO = g1.BK_NO_C1 " +
                        "    LEFT JOIN " +
                        "        BKE_CAP2 c2 ON g1.BK_NO_C2 = c2.BK_NO " +
                        "    WHERE " +
                        "        EXTRACT(MONTH FROM C2.PERIOD) = ? " +
                        "        AND EXTRACT(YEAR FROM C2.PERIOD) = ? " +
                        "        AND TRIM(i.CAR_LICENSE_PLATE) IN (" + placeholders + ") " +
                        "        AND i.STATUS = 21";


        log.info("Executing query: {} with parameters: month={}, year={}, licensePlates={}", sql,
                month, year, licensePlates);

        var statement = connection.createStatement(sql)
                .bind(0, month)
                .bind(1, year);

        for (int i = 0; i < licensePlates.size(); i++) {
            statement = statement.bind(i + 2, licensePlates.get(i).trim());
        }

        return Flux.from(statement.execute())
                .flatMap(result -> result.map((row, metadata) -> {
                    InvoiceModel invoiceDTO = bindRowToInvoiceModel(row);

                    if (!ObjectUtils.isEmpty(row.get("ITEM_ID"))) {
                        InvoiceModel.InvItemModel itemDTO = bindRowToInvoiceItemModel(row);
                        invoiceDTO.getItemsInv().add(itemDTO);
                    }

                    String normalizedPlate = row.get("CAR_LICENSE_PLATE", String.class).trim();
                    invoiceDTO.setCarLicensePlate(normalizedPlate);
                    return invoiceDTO;
                }))
                .collectMultimap(invoice -> invoice.getCarLicensePlate().trim())
                .map(multimap -> multimap.entrySet().stream()
                        .collect(Collectors.toMap(
                                entry -> entry.getKey().trim(),
                                entry -> (List<InvoiceModel>) new ArrayList<>(entry.getValue())
                        )))
                .doOnSuccess(resultMap -> log.info(
                        "[DB] Successfully retrieved invoices for {} license plates.",
                        resultMap.size()))
                .doOnError(ex -> log.error(
                        "[DB] Error retrieving invoices for license plates: {}. Error: {}",
                        licensePlates, ex));
    }

    private InvoiceModel.InvItemModel bindRowToInvoiceItemModel(Row row) {
        return new InvoiceModel.InvItemModel()
                .setId(row.get("ITEM_ID", String.class))
                .setQuantity(row.get("ITEM_QUANTITY", Double.class));
    }

    private InvoiceModel bindRowToInvoiceModel(Row row) {
        return new InvoiceModel()
                .setId(row.get("ID", String.class))
                .setAmount(row.get("AMOUNT", Long.class))
                .setSubFee(row.get("SUB_FEE", Long.class))
                .setVat(row.get("VAT", Long.class))
                .setTotal(row.get("TOTAL", Long.class))
                .setItemsInv(new ArrayList<>());
    }

    @Override
    public Mono<Long> create(Connection connection, InvoiceModel invoiceModel) {
        String sql =
                "INSERT INTO ERP_AC.INVOICE(ID, SERIAL,INV_TYPE,INV_NO,FORM,IDT,SNAME,STAX,AMOUNT,SUB_FEE,VAT,TOTAL,"
                        +
                        "STATUS,BP_CODE,CREATE_DATE, POST_OFFICE_CREATE_INV, TYPE_PAY,UPDATE_DATE,LINK_IMG, BP_SALE,SADDRESS,"
                        +
                        " TAX_CODE, SUPPLIER_NAME, SUPPLIER_ADDRESS, CAR_LICENSE_PLATE, CREATE_BY, BP_SALE_DEBT, IS_AUTO, TOTAL_ORIGIN, VERSION, INCLUDE_INV)"
                        +
                        " VALUES(?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?,?, ?,?,?,?,?,?,?,?,?,?,?, 1,?,2,1)";
        return Mono.from(connection.createStatement(sql)
                        .bind(0, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getId()))
                        .bind(1, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getSerial()))
                        .bind(2, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getInvType()))
                        .bind(3, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getInvNo()))
                        .bind(4, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getFrom()))
                        .bind(5, Parameters.in(R2dbcType.TIMESTAMP, invoiceModel.getIdt()))
                        .bind(6, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getSName()))
                        .bind(7, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getSTax()))
                        .bind(8, Parameters.in(R2dbcType.BIGINT, invoiceModel.getAmount()))
                        .bind(9, Parameters.in(R2dbcType.BIGINT, invoiceModel.getSubFee()))
                        .bind(10, Parameters.in(R2dbcType.BIGINT, invoiceModel.getVat()))
                        .bind(11, Parameters.in(R2dbcType.BIGINT, invoiceModel.getTotal()))
                        .bind(12, Parameters.in(R2dbcType.INTEGER, invoiceModel.getStatus()))
                        .bind(13, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getBpCode()))
                        .bind(14, Parameters.in(R2dbcType.TIMESTAMP, invoiceModel.getCreateDate()))
                        .bind(15, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getPostOfficeCreateInv()))
                        .bind(16, Parameters.in(R2dbcType.INTEGER, invoiceModel.getTypePay()))
                        .bind(17, Parameters.in(R2dbcType.TIMESTAMP, invoiceModel.getUpdateDate()))
                        .bind(18, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getLinkImg()))
                        .bind(19, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getBpSale()))
                        .bind(20, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getSAddress()))
                        .bind(21, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getTaxCode()))
                        .bind(22, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getSupplierName()))
                        .bind(23, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getSupplierAddress()))
                        .bind(24, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getCarLicensePlate()))
                        .bind(25, Parameters.in(R2dbcType.INTEGER, invoiceModel.getCreatedBy()))
                        .bind(26, Parameters.in(R2dbcType.VARCHAR, invoiceModel.getBpSaleDebt()))
                        .bind(27, Parameters.in(R2dbcType.BIGINT, invoiceModel.getTotal()))
                        .execute())
                .doOnSuccess(rowsUpdated -> log.info(
                        "insert invoice successful for recordId {}: rows updated: {}", invoiceModel,
                        rowsUpdated))
                .onErrorResume(error -> {
                    log.error("Error in invoice for recordId {}: {}", invoiceModel,
                            error.getMessage(), error);
                    return Mono.error(error);
                })
                .flatMap(queryResult -> Mono.from(queryResult.getRowsUpdated()));

    }

    @Override
    public Mono<Integer> saveInvoiceItems(Connection connection,
            List<InvoiceModel.InvItemModel> items) {
        String sql =
                "INSERT INTO ERP_AC.INV_ITEMS(ID, ID_INV, USER_CREATE, DATE_CREATE, SUB_FEE, NAME_HH,ID_TYPE_CP,TYPE_CP, VAT, VAT_RATE, TOTAL, PRICE ,AMOUNT,QUANTITY,STATUS,BP_CODE,STK,ALLOCATION)"
                        +
                        " VALUES(?, ?,?, ?,?,?, ?,?,?, ?,?, ?,?, ?,?, ?,?,0)";
        return Flux.fromIterable(items)
                .flatMap(item ->
                                Mono.from(connection.createStatement(sql)
                                                .bind(0, Parameters.in(R2dbcType.VARCHAR, item.getId()))
                                                .bind(1, Parameters.in(R2dbcType.VARCHAR, item.getInvoiceId()))
                                                .bind(2, Parameters.in(R2dbcType.VARCHAR, item.getUserCreate()))
                                                .bind(3, Parameters.in(R2dbcType.TIMESTAMP, item.getCreateDate()))
                                                .bind(4, Parameters.in(R2dbcType.BIGINT, item.getSubFee()))
                                                .bind(5, Parameters.in(R2dbcType.VARCHAR, item.getNameHH()))
                                                .bind(6, Parameters.in(R2dbcType.VARCHAR, item.getIdTypeCp()))
                                                .bind(7, Parameters.in(R2dbcType.VARCHAR, item.getTypeCp()))
                                                .bind(8, Parameters.in(R2dbcType.INTEGER, item.getVat()))
                                                .bind(9, Parameters.in(R2dbcType.DOUBLE, item.getVatRate()))
                                                .bind(10, Parameters.in(R2dbcType.BIGINT, item.getTotal()))
                                                .bind(11, Parameters.in(R2dbcType.DOUBLE, item.getPrice()))
                                                .bind(12, Parameters.in(R2dbcType.BIGINT, item.getAmount()))
                                                .bind(13, Parameters.in(R2dbcType.DOUBLE, item.getQuantity()))
                                                .bind(14, Parameters.in(R2dbcType.INTEGER, item.getStatus()))
                                                .bind(15, Parameters.in(R2dbcType.VARCHAR, item.getBpCode()))
                                                .bind(16, Parameters.in(R2dbcType.VARCHAR, item.getStk()))
                                                .execute())
                                        .flatMap(queryResult -> Mono.from(queryResult.getRowsUpdated()))
                                        .doOnSuccess(rowsUpdated -> log.info(
                                                "insert invoice item successful for recordId {}: rows updated: {}",
                                                item, rowsUpdated))
                                        .onErrorResume(error -> {
                                            log.error("Error in invoice item for recordId {}: {}", item,
                                                    error.getMessage(), error);
                                            return Mono.error(error);
                                        })
                        //.onErrorReturn(0L) // Return 0 in case of error
                )
                .collectList() // Collect results into a List
                .map(results -> {
                    // Check if any result is 0 (indicating a failure)
                    boolean anyFailed = results.stream().anyMatch(result -> result == 0);
                    if (anyFailed) {
                        return 0;
                    } else {
                        return results.size(); // Return the count of successful updates
                    }
                });
    }

    @Override
    public Mono<List<InvoiceModel>> findAllByInvoiceNo(List<String> invoices) {
        return Mono.usingWhen(oraclePool.create(), connection ->
                        Flux.fromIterable(partition(invoices))
                                .flatMap(chunk -> {
                                    String placeholders = String.join(",", chunk.stream().map(id -> "?").toArray(String[]::new));
                                    String query = "SELECT ID, SERIAL, INV_NO,CAR_LICENSE_PLATE, POST_OFFICE_CREATE_INV FROM ERP_AC.INVOICE WHERE INV_NO IN (" + placeholders + ")";
                                    Statement statement = connection.createStatement(query);
                                    for (int i = 0; i < chunk.size(); i++) {
                                        statement.bind(i, chunk.get(i));
                                    }
                                    return Flux.from(statement.execute());
                                })
                                .flatMap(result -> result.map(LIST_INVOICE_MAPPING))
                                .collectList(),
                Connection::close);
    }

    private <T> List<List<T>> partition(List<T> list) {
        List<List<T>> chunks = new ArrayList<>();
        int size = list.size();
        for (int i = 0; i < size; i += MAX_CONDITION) {
            chunks.add(new ArrayList<>(list.subList(i, Math.min(size, i + MAX_CONDITION))));
        }
        return chunks;
    }

    private Pair<Integer, Integer> getTime(String synthesisPeriod) {
        String[] parts = synthesisPeriod.split("/");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        return new Pair<>(month, year);
    }
}
