package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceSellerInfoEntity {

  @JsonAlias("seller_id")
  private BigDecimal sellerId;

  @JsonAlias("seller_name")
  private String sellerName;

  @JsonAlias("tax_code")
  private String taxCode;

  @JsonAlias("address")
  private String address;

  @JsonAlias("phone")
  private String phone;

  @JsonAlias("email")
  private String email;

  @JsonAlias("bank_name")
  private String bankName;

  @JsonAlias("bank_account")
  private String bankAccount;

  @JsonAlias("company_code")
  private String companyCode;

  @JsonAlias("created_at")
  private LocalDateTime createdAt;

  @JsonAlias("created_by")
  private String createdBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt;

  @JsonAlias("updated_by")
  private String updatedBy;

  @JsonAlias("tenant_id")
  private Short tenantId;
}
