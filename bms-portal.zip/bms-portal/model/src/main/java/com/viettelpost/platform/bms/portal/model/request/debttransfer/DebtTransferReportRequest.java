package com.viettelpost.platform.bms.portal.model.request.debttransfer;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class DebtTransferReportRequest {

    private Integer docStatus;

    @NotNull(message = "Vui lòng cung cấp ngày bắt đầu")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate fromDate;

    @NotNull(message = "Vui lòng cung cấp ngày kết thúc")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    private Long postId;
}
