package com.viettelpost.platform.bms.revenue.worker.model.request.accounting;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RawAcctDetailRequest {

    private String refNumber;

    private String refNumberParent;

    private String refDocNo;

    private String customerCode;

    private String customerCodeParent;

    private Long employeeId1;

    private Long employeeId2;

    private String channel;

    private String companyCode;

    private String contractType;

    private String unit1;

    private String unit2;

    private String unit3;

    private String serviceCode;

    private String idAccountant;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate postingDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    private LocalDateTime accountingDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate docDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private LocalDate baseLineDate;

    private String sys;

    private String currency;

    private Double exchangeRate;

    private Long reqId;

    private BigDecimal payAmount;

    private BigDecimal totalAmount;

    private String paymentAccountNo;

    private String serviceGroup;

    private String bpCode1;

    private String bpCode2;

    private Integer typeBpCode1;

    private Integer typeBpCode2;

    private Long postId1;

    private Long orgId1;

    private Long postId2;

    private Long orgId2;

    private String pcCode1;

    private String pcCode2;

    private String ccCode1;

    private String ccCode2;

    private String taxAccountNo;

    private String taxType;

    private String taxCode;

    private BigDecimal taxAmount;

    private BigDecimal taxRefund;

    private String assignment;

    private String description;

    private String transactionCode;

    private String bkC1;

    private String bkC2;

    private String bkC3;

    private String des1;

    private String des2;

    private String des3;

    private Long documentMonth;

    private String partnerCode;

    private BigDecimal discountAmount;

    private LocalDateTime refDate;

    private BigDecimal baseAmount;

    private String xref1;

    private String xref2;

    private String xref3;

    private String xref4;

    private String xref1Hd;

    private String xref2Hd;
    /**
     * PROFITABILITY_SEGMENT
     */
    private List<String> valueProfitability;
}
