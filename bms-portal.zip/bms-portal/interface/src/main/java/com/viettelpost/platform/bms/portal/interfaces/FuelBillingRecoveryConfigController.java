package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.request.FuelBillingRecoveryConfigRequest;
import com.viettelpost.platform.bms.portal.model.request.KMCPConfigFilter;
import com.viettelpost.platform.bms.portal.model.request.KMCPConfigRequest;
import com.viettelpost.platform.bms.portal.model.response.CommitmentItemResponse;
import com.viettelpost.platform.bms.portal.service.handler.FuelBillingRecoveryConfigService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;
import java.util.Map;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/config-manage")
@Tag(name = "Management configuration")
@RequiredArgsConstructor
public class FuelBillingRecoveryConfigController {

    @Inject
    FuelBillingRecoveryConfigService fuelBillingRecoveryConfigService;

    @POST
    @Path("/create")
    @Operation(summary = "Change Config")
    public Uni<Boolean> createConfigManage(FuelBillingRecoveryConfigRequest request) {
        return ReactiveConverter.toUni(
                fuelBillingRecoveryConfigService.changeConfigManage(request));
    }

    @GET
    @Path("/get-detail")
    @Operation(summary = "Show Config")
    public Uni<Response> showConfigManage(
            @QueryParam("type") Integer type) {
        return fuelBillingRecoveryConfigService.configManageDetail(type)
                .onItem().transform(configResponse -> {
                    if (configResponse != null) {
                        return Response.ok(configResponse).build();
                    } else {
                        return Response.ok(null).build();
                    }
                })
                .onFailure().recoverWithItem(throwable ->
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                                .entity("Error retrieving configuration: " + throwable.getMessage())
                                .build()
                );
    }

    @GET
    @Path("/get-commitment-items")
    @Operation(summary = "Show CIs")
    public Uni<List<CommitmentItemResponse>> getCommitmentItems(
            @QueryParam("page") int page,
            @QueryParam("size") int size,
            @QueryParam("search") String search) {
        return ReactiveConverter.toUni(
                fuelBillingRecoveryConfigService.getCommitmentItems(search, page, size));
    }

    @POST
    @Path("/kmcp")
    @Operation(summary = "Show KMCP Config")
    public Uni<Map<String, Object>> getKmcpConfig(KMCPConfigFilter filter) {
        return ReactiveConverter.toUni(
                fuelBillingRecoveryConfigService.kmcpConfigs(filter == null ? new KMCPConfigFilter() : filter));
    }

    @POST
    @Path("/kmcp/update")
    @Operation(summary = "Change KMCP Configs")
    public Uni<Response> updateKMCPConfigs(List<KMCPConfigRequest> request) {
        return fuelBillingRecoveryConfigService.updateKMCPConfigs(request)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Lưu cấu hình KMCP thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Lưu cấu hình KMCP không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }


    @POST
    @Path("/kmcp/create")
    @Operation(summary = "Create KMCP Config")
    public Uni<Response> createKMCPConfig(KMCPConfigRequest request) {
        return fuelBillingRecoveryConfigService.createKMCPConfigs(request)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Tạo cấu hình KMCP thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Tạo cấu hình KMCP không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }

    @DELETE
    @Path("/kmcp/delete/{id}")
    @Operation(summary = "Delete Vehicle Type Group")
    @APIResponse(responseCode = "200", description = "Vehicle Type Group deleted successfully")
    @APIResponse(responseCode = "400", description = "Failed to delete")
    public Uni<Response> deleteKMCPConfig(Long id) {
        return fuelBillingRecoveryConfigService.deleteKMCPConfig(id)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Xóa KMCP thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Xóa không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }

    @PUT
    @Path("/kmcp/update")
    @Operation(summary = "Update KMCP Config")
    public Uni<Response> updateKMCPConfig(KMCPConfigRequest request) {
        return fuelBillingRecoveryConfigService.updateKMCPConfig(request)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Update cấu hình KMCP thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Update cấu hình KMCP không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }
}
