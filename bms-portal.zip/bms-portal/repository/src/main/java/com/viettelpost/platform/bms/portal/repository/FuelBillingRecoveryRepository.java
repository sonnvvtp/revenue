package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryDTO;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.util.List;
import reactor.core.publisher.Mono;

public interface FuelBillingRecoveryRepository {

    Mono<Void> persist(FuelBillingRecoveryDTO recoveryDTO, SqlConnection connection);

    Mono<Void> updateStatus(List<String> receiptNumbers, BillingStatus status,
            SqlConnection connection);

    Mono<List<FuelBillingRecoveryDTO>> getListBySynthesisPeriodAndUnit(String synthesisPeriod, Integer approveStatus,
                                                                       Integer recordFail, Integer reject);

    Mono<Void> updateSapFields(String receiptNumber, Integer status,
            String messSap, Long sapDocNumber);

    Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection connection);

    Mono<List<FuelBillingRecoveryDTO>> getListBySynthesisPeriodAndStatusSap(
            String synthesisPeriod, Integer recordBudgetSuccess, Integer retrieveFail);
}
