package com.viettelpost.platform.bms.revenue.worker.service.impl;

import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueStatementStatus;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RevenueStatementSapDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.accounting.AcctBusinessConfigDTO;
import com.viettelpost.platform.bms.revenue.worker.model.mapper.AccountingRevenueMapper;
import com.viettelpost.platform.bms.revenue.worker.model.request.accounting.PushRawAcctRequest;
import com.viettelpost.platform.bms.revenue.worker.model.request.accounting.RawAcctDetailRequest;
import com.viettelpost.platform.bms.revenue.worker.model.response.PushRawAcctResponse;
import com.viettelpost.platform.bms.revenue.worker.repository.CalculationRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.repository.GloExpRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.service.PushingRevenueSapService;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.Json;
import io.vertx.mutiny.ext.web.client.WebClient;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PushingRevenueSapServiceImpl implements PushingRevenueSapService {

    private final CalculationRevenueRepository calculationRevenueRepository;

    private final GloExpRevenueRepository gloExpRevenueRepository;

    private static DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @ConfigProperty(name = "job.calculation.discount.batch.handle.size", defaultValue = "10000")
    Integer batchBillHandleSize;

    private final WebClient webClient;

    @ConfigProperty(name = "acct.push.raw.data.url")
    String accountingPushUrl;

    @ConfigProperty(name = "config.acct.maxPushRawSize", defaultValue = "1000")
    Integer maxPushRawSize;

    @ConfigProperty(name = "revenue.acct.assignment", defaultValue = "PTCKT")
    String assignment;

    @ConfigProperty(name = "revenue.businessId.id", defaultValue = "19")
    Long configRevenueBusinessId;

//    @ConfigProperty(name = "config.revenue.post.id.test", defaultValue = "421,5027")
//    List<Long> postIdTestList;

    @ConfigProperty(name = "config.revenue.service.code.no.tax", defaultValue = "ECC,ECT,ECM")
    List<String> serviceCodeNoApplyTax;

    @ConfigProperty(name = "config.revenue.service.code.gtbs", defaultValue = "GTBS,GTNK")
    List<String> serviceCodeGtbs;

    public  Uni<Void> handlePushRawData(List<RevenueStatementSapDTO> rawDTOList, RevenueType revenueType, AcctBusinessConfigDTO acctBusinessConfigDTO, Map<String, String> serviceMap, Map<String, Integer> dichVuMap, LocalDate endOfMonth) {
      log.info("handlePushRawData_type: {}, size: {}", revenueType.getValue(), rawDTOList.size());
      if (CollectionUtils.isEmpty(rawDTOList)) {
        return Uni.createFrom().voidItem();
      }
      acctBusinessConfigDTO = AcctBusinessConfigDTO.builder()
          .businessId(configRevenueBusinessId)
          .businessCode("REVENUE_VTP")
          .build();

      log.info("size need to push acct raw: {}", rawDTOList.size());

      List<RawAcctDetailRequest> rawAcctDetails = new ArrayList<>();
      for (RevenueStatementSapDTO rawDTO : rawDTOList) {
        List<RawAcctDetailRequest> rawAcctDetailRequestList = convertGenericToRawAcctDetailRequest(rawDTO, revenueType, serviceMap, dichVuMap, endOfMonth);
        if (CollectionUtils.isNotEmpty(rawAcctDetailRequestList)) {
          rawAcctDetails.addAll(rawAcctDetailRequestList);
        }
      }

      AcctBusinessConfigDTO finalAcctBusinessConfigDTO = acctBusinessConfigDTO;
      return removeDuplicateRawData(rawAcctDetails, acctBusinessConfigDTO.getBusinessId())
          .flatMap(rawAcctDetailRequests -> {

            log.info("size need to push acct raw (after remove duplicate and test post id): {}",rawDTOList.size());
            if (Objects.isNull(rawAcctDetailRequests) || rawAcctDetailRequests.isEmpty()) {
              return Uni.createFrom().voidItem();
            }

            Uni<Void> uniChain = Uni.createFrom().voidItem();

            // Xu ly day 1000 raw data lan luot
            for (int i = 0; i < rawAcctDetailRequests.size(); i += maxPushRawSize) {
              int end = Math.min(i + maxPushRawSize, rawAcctDetailRequests.size());
              List<RawAcctDetailRequest> subPushRawRequest = rawAcctDetailRequests.subList(i, end);
              PushRawAcctRequest pushRawAcctRequest = PushRawAcctRequest.builder()
                  .businessCode(finalAcctBusinessConfigDTO.getBusinessCode())
                  .businessId(finalAcctBusinessConfigDTO.getBusinessId())
                  .build();
              pushRawAcctRequest.setDetail(subPushRawRequest);

              uniChain = uniChain.chain(() -> pushRawDataAccounting(pushRawAcctRequest)
                  .onFailure()
                  .recoverWithUni(throwable -> {
                    log.error("handlePushRawData_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().item(false);
                  })
                  .flatMap(aBoolean -> {
                    if (aBoolean) {
                      log.info("handlePushRawData_success");

                    }
                    log.info("handlePushRawData_failed");
                    return Uni.createFrom().voidItem();
                  }));
            }
            return uniChain.flatMap(unused -> {
              return Uni.createFrom().item(true);
            }).replaceWithVoid();
          });
    }

    private Uni<List<RawAcctDetailRequest>> removeDuplicateRawData(List<RawAcctDetailRequest> rawAcctDetailRequests, Long businessId) {

      Set<String> refNumberList = rawAcctDetailRequests.stream().map(RawAcctDetailRequest::getRefNumber).collect(Collectors.toSet());
      Set<String> refNumberParentList = rawAcctDetailRequests.stream().map(RawAcctDetailRequest::getRefNumberParent).collect(Collectors.toSet());

      return calculationRevenueRepository.findListRawDataByListRefNumber(refNumberList, refNumberParentList, businessId)
          .collect()
          .asList()
          .flatMap(refNumberExisted -> {
            List<RawAcctDetailRequest> result = new ArrayList<>();
            if (CollectionUtils.isEmpty(refNumberExisted)) {
              result = rawAcctDetailRequests.stream()
                  .filter(dto ->
                      isNotPostIdTest(dto.getPostId1())
                  )
                  .toList();
            }
            else {
              result =  rawAcctDetailRequests.stream()
                    .filter(request -> refNumberExisted.stream()
                        .noneMatch(dto ->
                            (dto.getRefNumber() == null ? request.getRefNumber() == null : dto.getRefNumber().equals(request.getRefNumber())) &&
                                (dto.getRefNumberParent() == null ? request.getRefNumberParent() == null : dto.getRefNumberParent().equals(request.getRefNumberParent()))))
                    .collect(Collectors.toList());

//                rawAcctDetailRequests
//                .stream()
//                .filter(rawAcctDetailRequest -> !refNumberExisted.contains(rawAcctDetailRequest.getRefNumber())
//                    && isNotPostIdTest(rawAcctDetailRequest.getPostId1())
//                    && isNotPostIdTest(rawAcctDetailRequest.getPostId2())
//                )
//                .collect(Collectors.toList());
            }
            return Uni.createFrom().item(result);
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("findListRawDataByListRefNumber_error : {}", throwable.getMessage(), throwable);
          });
    }

    private boolean isNotPostIdTest(Long postId) {
      return true;
//      if (Objects.isNull(postId) || CollectionUtils.isEmpty(postIdTestList)) {
//        return true;
//      }
//      return postIdTestList.contains(postId);
    }

    private List<RawAcctDetailRequest>  convertGenericToRawAcctDetailRequest(RevenueStatementSapDTO rawDTO, RevenueType revenueType, Map<String, String> serviceMap, Map<String, Integer> dichVuMap, LocalDate endOfMonth) {

      return switch (revenueType) {
        case TEMPORARY_REVENUE -> // DTCHT - Doanh thu chưa hoàn thành
            AccountingRevenueMapper.convertDTCHToRawAcctDetailRequest(rawDTO, serviceMap, dichVuMap,
                endOfMonth, serviceCodeNoApplyTax, serviceCodeGtbs);
        case COMPLETED_REVENUE2 -> // DTHT_KTTC - Doanh thu hoàn thành - loại ko có trạng thái cuối
            AccountingRevenueMapper.convertDTHT_KTTCToRawAcctDetailRequest(rawDTO, serviceMap,
                dichVuMap, endOfMonth, serviceCodeNoApplyTax, serviceCodeGtbs);
        case COMPLETED_REVENUE3 -> // DTHT_CTTC - Doanh thu hoàn thành - có trạng thái cuối
            AccountingRevenueMapper.convertDTHT_CTTCToRawAcctDetailRequest(rawDTO, serviceMap,
                dichVuMap, endOfMonth, serviceCodeNoApplyTax, serviceCodeGtbs);
        default -> null;
      };
    }

    public Uni<Boolean> pushRawDataAccounting(PushRawAcctRequest pushRawAcctRequest) {

      List<RawAcctDetailRequest> rawAcctDetailRequestList =  pushRawAcctRequest.getDetail();
      List<BigDecimal> ids = rawAcctDetailRequestList.stream()
          .map(RawAcctDetailRequest::getRefNumberParent)
          .filter(Objects::nonNull)
          .map(BigDecimal::new)
          .toList();
      log.info("Request push raw data accounting: {}", Json.encode(pushRawAcctRequest));

      return webClient.postAbs(accountingPushUrl)
          .sendJson(pushRawAcctRequest)
          .flatMap(bufferHttpResponse -> {
            boolean isError= false;
            if (bufferHttpResponse.statusCode() != 200) {
              isError =true;
              log.info("Push_raw_data_failed_with_response: {}", bufferHttpResponse.bodyAsString());
            }

            log.info("Response from accounting server: {}", bufferHttpResponse.bodyAsString());
            PushRawAcctResponse response = bufferHttpResponse.bodyAsJsonObject().mapTo(PushRawAcctResponse.class);

            String messageError = "";
            if (bufferHttpResponse.statusCode() != 200) {
              isError =true;
              log.info("Response_status_code_from_accounting_server_is_not_200: {}", ids);
            }

            if (Objects.isNull(response)) {
              isError = true;
              log.info("Response_from_accounting_server_is_null: {}", ids);
            }

            if (!Objects.equals(response.getHttpStatusCode(), 200)) {
              isError = true;
              log.info("Response_from_accounting_server_is_error: {}, ids: {}",  response.getDetail(), ids);
            }
            log.info("updateRevenueStatementBy_size: {}", ids.size());
            return gloExpRevenueRepository.updateRevenueStatementBy(ids, isError ? RevenueStatementStatus.DONG_BO_THAT_BAI.getCode() : RevenueStatementStatus.DONG_BO_THANH_CONG.getCode() , null);
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("pushRawDataAccounting_error : {}", throwable.getMessage(), throwable);
          });
    }
}
