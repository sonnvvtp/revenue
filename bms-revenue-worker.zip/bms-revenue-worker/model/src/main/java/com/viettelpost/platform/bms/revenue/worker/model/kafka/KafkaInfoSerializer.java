package com.viettelpost.platform.bms.revenue.worker.model.kafka;

import io.quarkus.kafka.client.serialization.ObjectMapperSerializer;
import org.apache.kafka.common.header.Headers;

public class KafkaInfoSerializer extends ObjectMapperSerializer<Object> {
    @Override
    public byte[] serialize(String topic, Headers headers, Object data) {
        return super.serialize(topic, headers, data);
    }

}
