package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceFullDetailResponse {
    // Thông tin chung của hóa đơn
    private String invoiceType; // Loại bảng kê
    private String customerCode; // Mã KH
    private String taxFormType; // Hình thức TT
    private String companyCode; // CompanyCode
    private String invoiceCode; // Mã BK
    private String unitName; // Tên đơn vị
    private String invoicePattern; // Mã số
    private String buyerName; // Tên người mua hàng
    private String taxCode; // SDT
    private String invoiceDate; // Ngày hóa đơn
    private String taxRegistrationCode; // Mã số thuế/Mã định danh cá nhân
    private String createdDate; // Ngày tạo
    private String unitCodeAndBank; // Mã đơn vị ngân sách
    private String invoiceSymbol; // Ký hiệu
    private String email; // Email
    private String invoiceNo; // Số hóa đơn
    private String address; // Địa chỉ
    private Boolean isExportInvoice; // Có XK hóa đơn hàng
    
    // Thông tin chi tiết các mặt hàng
    private List<InvoiceItemDetail> items;
    
    // Thông tin đơn hàng
    private List<InvoiceOrderDetail> orders;
    
    // Thông tin tổng hợp
    private Double totalAmountBeforeTax; // Tổng tiền không chịu thuế
    private Double totalTaxAmount5; // Tổng tiền chịu thuế 5%
    private Double totalTaxAmount8; // Tổng tiền thuế GTGT 8%
    private Double totalTaxAmount10; // Tổng tiền chịu thuế 10%
    private Double totalTaxGtgt5; // Tổng tiền thuế GTGT 5%
    private Double totalTaxGtgt8; // Tổng tiền thuế GTGT 8%
    private Double totalTaxGtgt10; // Tổng tiền thuế GTGT 10%
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceItemDetail {
        private Integer index; // STT
        private String productName; // Tên hàng hóa dịch vụ
        private String unit; // Đơn vị tính
        private Integer quantity; // Số lượng
        private Double unitPrice; // Đơn giá
        private Double amountBeforeTax; // Tiền hàng trước thuế
        private Double taxRate; // Thuế suất
        private Double taxAmount; // Tiền thuế
        private Double discountAmount; // Thành tiền sau thuế
        private String type; // Loại
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceOrderDetail {
        private String orderCode; // Đơn hàng
        private Double amount; // Số tiền
    }
} 