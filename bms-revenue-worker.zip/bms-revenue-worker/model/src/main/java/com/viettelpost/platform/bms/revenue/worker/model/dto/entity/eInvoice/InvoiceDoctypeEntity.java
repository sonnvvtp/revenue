package com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceDoctypeEntity {

  @JsonAlias("doctype_id")
  private BigDecimal id;

  @JsonAlias("doctype_code")
  private String doctypeCode;

  @JsonAlias("doctype_name")
  private String doctypeName;

  @JsonAlias("description")
  private String description;

  @JsonAlias("company_code")
  private String companyCode;

  @JsonAlias("is_active")
  private Boolean isActive = true;

  @JsonAlias("created_at")
  private LocalDateTime createdAt = LocalDateTime.now();

  @JsonAlias("created_by")
  private String createdBy;

  @JsonAlias("update_at")
  private LocalDateTime updateAt = LocalDateTime.now();

  @JsonAlias("update_by")
  private String updateBy;

  @JsonAlias("tenant_id")
  private Integer tenantId = 1;
}
