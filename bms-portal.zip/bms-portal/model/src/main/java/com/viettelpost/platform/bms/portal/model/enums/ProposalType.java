package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ProposalType {
    QRCODETGTT("H1","QRCODETGTT","Hoàn tiền QR code qua TGTT"),
    QRCODEBANK("H2","QRCODEBANK","Hoàn tiền QR code qua ngân hàng"),
    REFUNDINTERNAL("H3","REFUNDINTERNAL","Hoàn tiền nội bộ"),
    REFUNDVIPO("H4","REFUNDVIPO","Hoàn tiền VIPO");



    private String type;
    private String code;
    private String description;

    public static ProposalType get(String code) {
        return Arrays.stream(ProposalType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(null);
    }
}
