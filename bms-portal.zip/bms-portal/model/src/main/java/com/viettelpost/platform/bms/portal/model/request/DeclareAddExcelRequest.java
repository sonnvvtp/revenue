package com.viettelpost.platform.bms.portal.model.request;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.MediaType;
import lombok.Data;
import org.jboss.resteasy.reactive.PartType;
import org.jboss.resteasy.reactive.RestForm;
import org.jboss.resteasy.reactive.multipart.FileUpload;

@Data
public class DeclareAddExcelRequest {
    @RestForm("file")
    @PartType(MediaType.MULTIPART_FORM_DATA)
    @NotNull(message = "Vui lòng import file")
    private FileUpload file;
}
