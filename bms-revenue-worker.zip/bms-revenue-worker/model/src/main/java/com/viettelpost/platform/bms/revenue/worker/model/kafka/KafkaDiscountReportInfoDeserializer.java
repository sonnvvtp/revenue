package com.viettelpost.platform.bms.revenue.worker.model.kafka;

import io.quarkus.kafka.client.serialization.ObjectMapperDeserializer;

public class KafkaDiscountReportInfoDeserializer extends ObjectMapperDeserializer<DiscountReportInfoKafka> {
    public KafkaDiscountReportInfoDeserializer() {
        super(DiscountReportInfoKafka.class);
    }
}
