package com.viettelpost.platform.bms.portal.common.config;

import org.eclipse.microprofile.config.ConfigProvider;

import java.util.Objects;

public class BaseRepositoryConfig {
    public static boolean showSql() {
        return Objects.equals(ConfigProvider
                .getConfig()
                .getOptionalValue("base.repository.show.sql", Boolean.class)
                .orElse(false), true);
    }
}
