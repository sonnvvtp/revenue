package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.JsonNode;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RecordDto;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevenueStatementEntity {
    
    @JsonAlias("id")
    private BigDecimal id;

    @JsonAlias("tenant_id")
    private Integer tenantId;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("created_at")
    private LocalDateTime createdAt;

    @JsonAlias("updated_by")
    private Long updatedBy;

    @JsonAlias("updated_at")
    private LocalDateTime updatedAt;

    @JsonAlias("statement_code")
    private String statementCode;

    @JsonAlias("description")
    private String description;

    @JsonAlias("service_code")
    private String serviceCode;

    @JsonAlias("unit_level1_id")
    private Long unitLevel1Id;

    @JsonAlias("unit_level1_code")
    private String unitLevel1Code;

    @JsonAlias("unit_level1_name")
    private String unitLevel1Name;

    @JsonAlias("unit_level2_id")
    private Long unitLevel2Id;

    @JsonAlias("unit_level2_code")
    private String unitLevel2Code;

    @JsonAlias("unit_level2_name")
    private String unitLevel2Name;

    @JsonAlias("company_code")
    private String companyCode;

    @JsonAlias("customer_code")
    private String customerCode;

    @JsonAlias("customer_name")
    private String customerName;

    @JsonAlias("statement_amount_before_tax")
    private BigDecimal statementAmountBeforeTax;

    @JsonAlias("statement_tax_amount")
    private BigDecimal statementTaxAmount;

    @JsonAlias("statement_amount_after_tax")
    private BigDecimal statementAmountAfterTax;

    @JsonAlias("statement_amount_discount")
    private BigDecimal statementAmountDiscount;

    @JsonAlias("total_amount")
    private BigDecimal totalAmount;

    @JsonAlias("revenue_sync_status")
    private Integer revenueSyncStatus;

    @JsonAlias("revenue_accounting_status")
    private Integer revenueAccountingStatus;

    @JsonAlias("currency")
    private String currency;

    @JsonAlias("statement_source")
    private String statementSource;

    @JsonAlias("record_size")
    private Integer recordSize;

    @JsonAlias("record_type")
    private Integer recordType;

    @JsonAlias("period_id")
    private BigDecimal periodId;

    @JsonAlias("statement_business_id")
    private Integer statementBusinessId;

    //    @JsonAlias("statement_accounting_date")
//    private LocalDateTime statementAccountingDate;

    @JsonAlias("amount_discount_before_tax")
    private BigDecimal amountDiscountBeforeTax;

    @JsonAlias("amount_discount_tax")
    private BigDecimal amountDiscountTax;

    private List<RecordDto> records;
}
