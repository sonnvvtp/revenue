package com.viettelpost.platform.bms.portal.model.request.advance;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class DeleteRecordGroupRequest {

    @NotEmpty(message = "Vui lòng cung cấp danh sách id bảng kê")
    private List<Long> advanceAcctIdList;
}
