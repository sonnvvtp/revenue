package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.response.HealthyCheckResponse;
import com.viettelpost.platform.bms.portal.service.handler.HealthyCheckService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/healthy-check")
@Tag(name = "healthy check")
@RequiredArgsConstructor
public class HealthyController {

    private final HealthyCheckService healthyCheckService;

    @GET
    @Path("/bms-report-service")
    @Operation(summary = "Healthy check bms-report-service")
    @APIResponse(responseCode = "200", description = "return list bill")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<HealthyCheckResponse> getInfoCheckHealthyService() {
        return ReactiveConverter.toUni(healthyCheckService.checkHealthyService());
    }
}
