package com.viettelpost.platform.bms.revenue.worker.common.enums;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RevenueStatementStatus {
    TAO_MOI(0, "Tạo mới"),
    DONG_BO_THANH_CONG(1, "Đồng bộ thành công"),
    DONG_BO_THAT_BAI(2, "Đồng bộ thất bại"),
    DANG_DONG_BO(3, "Đang đồng bộ"),
    CHOT_BANG_KE(4, "Chốt bảng kê"),
    HACH_TOAN_THANH_CONG(5, "Hạch toán thành công"),
    HACH_TOAN_THAT_BAI(6, "Hạch toán thất bại");


    private final Integer code;
    private final String description;

    public static RevenueStatementStatus fromCode(Integer code) {
        for (RevenueStatementStatus status : RevenueStatementStatus.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static Integer fromStatus(RevenueStatementStatus status) {
        return status.getCode();
    }
}
