package com.viettelpost.platform.bms.portal.model.response;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleTypeGroupResponse {

    private Long id;
    private String name;
    private boolean isSyncInvoice;
    private List<VehicleTypeResponse> vehicleTypes;
}
