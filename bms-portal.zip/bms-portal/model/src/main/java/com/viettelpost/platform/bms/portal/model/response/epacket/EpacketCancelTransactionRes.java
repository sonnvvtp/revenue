package com.viettelpost.platform.bms.portal.model.response.epacket;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Accessors(chain = true)
public class EpacketCancelTransactionRes {
    private boolean error;
    @JsonProperty("error_code")
    private String errorCode;
    private String message;

    private List<EpacketCancelTransactionRes.ITEMS> items;
    @Data
    public static class ITEMS {
        private String transactionCode;
        private int statusCode;
        private String message;
    }
}
