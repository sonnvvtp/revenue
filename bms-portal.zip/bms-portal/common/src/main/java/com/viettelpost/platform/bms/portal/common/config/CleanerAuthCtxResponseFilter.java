package com.viettelpost.platform.bms.portal.common.config;

import jakarta.inject.Inject;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;

import java.io.IOException;

public class CleanerAuthCtxResponseFilter implements ContainerResponseFilter {

    @Inject
    AuthenticationContextImpl authCtx;

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
        authCtx.setCurrentUser(null);
        authCtx.setToken(null);
    }
}
