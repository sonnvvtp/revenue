package com.viettelpost.platform.bms.revenue.worker.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BillEvtpPayInDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.accounting.AcctRawDataDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BgDichvuEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsBillJourneyEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsBillRevenueEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsServiceCategoryMappingEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueServiceGroupEntity;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface CalculationRevenueRepository extends BaseRepository {

    Uni<Integer> findAllEvtpPayInCount(LocalDate startDate, LocalDate endDate);

    Multi<BillEvtpPayInDTO> findAllEvtpPayIn(LocalDate startDate, LocalDate endDate, Integer page, Integer size);

    Uni<BigDecimal> findPeriodIdBy(LocalDate date);

    Uni<ErpPeriodEntity> findPeriodBy(BigDecimal id);

    Uni<ErpPeriodEntity> findPeriodBy(LocalDate date);

    Multi<RevenueServiceGroupEntity> findRevenueServiceGroupBy();

    Uni<Boolean> saveBatchBmsBillRevenue(List<BmsBillRevenueEntity> entities, Connection sqlConnection);

    Multi<BmsBillJourneyEntity> findG2bVanDonBy();

    Uni<Boolean> saveBatchBmsBillJourney(List<BmsBillJourneyEntity> entities, Connection sqlConnection);

    Uni<Integer> findAllBillSucessCount(LocalDate startDate, LocalDate endDate);

    Multi<BillEvtpPayInDTO> findAllBillSucess(LocalDate startDate, LocalDate endDate, Integer page, Integer size);

    Multi<AcctRawDataDTO> findListRawDataByListRefNumber(Set<String> refNumberList, Set<String> refNumberParentList, Long businessId);

    Uni<Integer> findBillRevenueCount(BigDecimal periodId, RevenueType revenueType);

    Multi<BmsBillRevenueDTO> findBillRevenueBy(BigDecimal periodId, RevenueType revenueType, Integer page, Integer size);

    Uni<Boolean> updateStatusBillRevenueBy(List<BigDecimal> listIds, Integer status);

    Multi<BmsServiceCategoryMappingEntity> findAllServiceCategoryMapping();

    Multi<BgDichvuEntity> findAllBgDichVu();
}
