package com.viettelpost.platform.bms.portal.model.request;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleTypeGroupRequest {

    private String name;
    private List<String> vehicleTypes;
    private boolean isSyncInvoice;
}
