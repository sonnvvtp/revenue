package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.enums.BusinessAdvanceAcctType;
import com.viettelpost.platform.bms.portal.model.enums.DocTypeAdvanceAcct;
import com.viettelpost.platform.bms.portal.model.request.advance.*;
import com.viettelpost.platform.bms.portal.model.response.advance.AdvanceAcctBusinessTypeResponse;
import com.viettelpost.platform.bms.portal.model.response.advance.AdvanceAcctDocTypeResponse;
import com.viettelpost.platform.bms.portal.service.handler.AdvanceAcctService;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/advance/accounting")
@Tag(name = "API Accounting SAP Common")
@RequiredArgsConstructor
@ApplicationScoped
public class AdvanceAcctAPI {

    private final AdvanceAcctService advanceAcctService;

    @POST
    @Path("/find-list")
    public Uni<Response> findListAdvanceAcct(@Valid AdvanceAcctRequest advanceAcctRequest){
        return advanceAcctService.findListAdvanceAcct(advanceAcctRequest)
                .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/detail/find-list")
    public Uni<Response> findListAdvanceDetailAcct(@Valid AdvanceAcctDetailRequest advanceAcctDetailRequest){
        return advanceAcctService.findListAdvanceDetailAcct(advanceAcctDetailRequest)
                .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/export-list")
    public Uni<Response> exportExcelListAdvanceAcct(@Valid AdvanceAcctRequest advanceAcctRequest){
        return advanceAcctService.exportExcelListAdvanceAcct(advanceAcctRequest)
                .map(bos -> {
                    String fileName = "DS_BK_HOACH_TOAN_" + System.currentTimeMillis() + ".xlsx";
                    return Response.ok(bos.toByteArray())
                            .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                            .header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            .build();
                });
    }

    @POST
    @Path("/detail/export-list")
    public Uni<Response> exportExcelListAdvanceDetailAcct(@Valid AdvanceAcctDetailRequest advanceAcctDetailRequest){
        return advanceAcctService.exportExcelListAdvanceDetailAcct(advanceAcctDetailRequest)
                .map(bos -> {
                    String fileName = "DS_BK_CT_HOACH_TOAN_" + System.currentTimeMillis() + ".xlsx";
                    return Response.ok(bos.toByteArray())
                            .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                            .header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            .build();
                });
    }

    @GET
    @Path("/list-doc-type")
    public Uni<Response> getListDocType(){
        List<AdvanceAcctDocTypeResponse> result = new ArrayList<>();
        Arrays.stream(DocTypeAdvanceAcct.values()).filter(docTypeAdvanceAcct -> !Objects.equals(DocTypeAdvanceAcct.NA, docTypeAdvanceAcct))
                .forEach(docTypeAdvanceAcct -> result.add(new AdvanceAcctDocTypeResponse(docTypeAdvanceAcct.getCode(), docTypeAdvanceAcct.getName())));
        return Uni.createFrom().item(BaseResponse.successApi(result, "OK"));
    }

    @GET
    @Path("/list-business-type")
    public Uni<Response> getListBusinessType(@QueryParam("docType") Integer docType){
        List<AdvanceAcctBusinessTypeResponse> result = new ArrayList<>();
        DocTypeAdvanceAcct docTypeAdvanceAcct = DocTypeAdvanceAcct.getDocTypeAdvanceAcct(docType);
        if (Objects.equals(DocTypeAdvanceAcct.NA, docTypeAdvanceAcct)) {
            return Uni.createFrom().item(BaseResponse.successApi(result, "OK"));
        }

        docTypeAdvanceAcct.getTypes().stream().filter(type -> !Objects.equals(BusinessAdvanceAcctType.NA, type))
                .forEach(type -> result.add(new AdvanceAcctBusinessTypeResponse(type.name(), type.getBusinessName())));

        return Uni.createFrom().item(BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/record-group/find-list")
    public Uni<Response> findListRecordGroup(@Valid AdvanceRecordGroupRequest advanceRecordGroupRequest){
        return advanceAcctService.findListRecordGroup(advanceRecordGroupRequest)
                .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/record-group/detail/find-list")
    public Uni<Response> findListDetailRecordGroup(@Valid AdvanceRecordGroupDetailRequest request) {
        return advanceAcctService.findListRecordGroupDetail(request)
                .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/record-group/find-by-bill")
    public Uni<Response> findListDetailRecordGroup(@Valid AdvanceRecordByBillRequest request) {
        return advanceAcctService.findListRecordGroupByBill(request)
                .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @DELETE
    @Path("/record-group/delete-list")
    public Uni<Response> deleteRecordGroup(@Valid DeleteRecordGroupRequest deleteRecordGroupRequest){
        return advanceAcctService.deleteRecordGroup(deleteRecordGroupRequest)
                .map(result -> BaseResponse.successApi(null, "OK"));
    }

    @POST
    @Path("/re-push")
    public Uni<Response> rePushBillAcct(@Valid RePushBillAcctRequest rePushBillAcctRequest) {
        return advanceAcctService.rePushBillAcct(rePushBillAcctRequest)
                .map(aBoolean -> BaseResponse.successApi(aBoolean, "OK"));
    }
}
