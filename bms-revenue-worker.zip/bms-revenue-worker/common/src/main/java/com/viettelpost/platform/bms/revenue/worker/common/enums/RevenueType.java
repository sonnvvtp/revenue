package com.viettelpost.platform.bms.revenue.worker.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RevenueType {
    TEMPORARY_REVENUE(1, "Doanh thu tạm tính"),
    COMPLETED_REVENUE2(2, "Doanh thu hoàn thành - Bill ko có trạng thái cuối"),
    COMPLETED_REVENUE3(3, "Doanh thu hoàn thành - bill PTC");

//    TEMPORARY_REVENUE(4, "Doanh thu tạm tính - Bill ko có trạng thái cuối"),
//    COMPLETED_REVENUE2(5, "Doanh thu hoàn thành - Bill ko có trạng thái cuối"),
//    COMPLETED_REVENUE3(6, "Doanh thu hoàn thành - bill PTC");

    private final int value;
    private final String name;
}
