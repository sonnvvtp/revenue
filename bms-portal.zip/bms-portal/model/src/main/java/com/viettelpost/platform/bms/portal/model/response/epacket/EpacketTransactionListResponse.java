package com.viettelpost.platform.bms.portal.model.response.epacket;
import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class EpacketTransactionListResponse {
    private List<ITEMS> items;
    private long totalRecords;
    private int totalPage;
    private int currentPage;
    @Data
    @Accessors(chain = true)
    public static class ITEMS {
        private String statusText;
        private String transactionCode;
        private Integer transactionType;
        private String reqPaymentCode;
        private Integer walletType;
        private String transactionCodeGori;
        private Long cusId;
        private String cusName;
        private String email;
        private String phone;
        private BigDecimal amount;
        private BigDecimal amountPartner;
        private Integer reconStatus;
        private Integer accountingStatus;
        private String orgCode;
        private Long orgId;
        private String postCode;
        private Long postId;
        private String requestId;
        private PartnerSource partnerSource;
        private ServiceType serviceType;
        private MerchantType merchantType;
        private BigDecimal partnerInternalId;
        private String partnerBankCode;
        private BigDecimal partnerInternalLineId;
        private String createDate;
        private String updateDate;
        private String reqPaymentTime;
    }
}
