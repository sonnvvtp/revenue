package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BudgetDocumentRequest {

    @JsonProperty("FM_DOCS")
    private List<FmDoc> FM_DOCS;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class FmDoc {

        @JsonProperty("DOC_STATE")
        private String DOC_STATE;
        @JsonProperty("EXTERNAL_NUMBER")
        private String EXTERNAL_NUMBER;
        @JsonProperty("PROCESS")
        private String PROCESS;
        @JsonProperty("DOC_TYPE")
        private String DOC_TYPE;
        @JsonProperty("FM_AREA")
        private String FM_AREA;
        @JsonProperty("FIS_YEAR")
        private String FIS_YEAR;
        @JsonProperty("DOC_DATE")
        private String DOC_DATE;
        @JsonProperty("HEADER_TEXT")
        private String HEADER_TEXT;
        @JsonProperty("ITEMS")
        private List<Item> ITEMS;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class Item {

        @JsonProperty("FUNDS_CTR_RECV")
        private String FUNDS_CTR_RECV;
        @JsonProperty("CMMT_ITEM_RECV")
        private String CMMT_ITEM_RECV;
        @JsonProperty("MEASURE_RECV")
        private String MEASURE_RECV;
        @JsonProperty("PERIOD_RECV")
        private String PERIOD_RECV;
        @JsonProperty("ITEM_TEXT")
        private String ITEM_TEXT;
        @JsonProperty("BUDGET_AMOUNT")
        private Long BUDGET_AMOUNT;
    }
}
