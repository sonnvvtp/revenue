package com.viettelpost.platform.bms.revenue.worker.model.request.general;

import io.vertx.core.json.JsonObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UnitInfoDTO {
  private UnitLevelDTO unitLevel1;
  private UnitLevelDTO unitLevel2;

  public JsonObject toJsonObject() {
    return JsonObject.mapFrom(this);
  }
}

