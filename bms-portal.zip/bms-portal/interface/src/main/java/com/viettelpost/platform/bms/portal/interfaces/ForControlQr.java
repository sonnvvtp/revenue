package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.forControl.GetDataComparisonInternalForm;
import com.viettelpost.platform.bms.portal.model.request.forControl.SyntheticDataReq;
import com.viettelpost.platform.bms.portal.service.handler.ForControlService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("for-control")
@Tag(name = "For-control")
@RequiredArgsConstructor
public class ForControlQr {
    @Inject
    AuthenticationContext authCtx;

    private final ForControlService forControlService;

    @POST
    @Path("/synthetic")
    @Operation(summary = "synthetic data external for control")
    @APIResponse(responseCode = "200", description = "reutrn data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getDataSynthetic(@RequestBody SyntheticDataReq req) {
        return ReactiveConverter.toUni(forControlService.getDataSynthetic(req));
    }

    @POST
    @Path("/external")
    @Operation(summary = "get data compare external")
    @APIResponse(responseCode = "200", description = "reutrn data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListExternal(@RequestBody SyntheticDataReq req) {
        return ReactiveConverter.toUni(forControlService.getAllComparisonExternal(req));
    }

    @POST
    @Path("/internal")
    @Operation(summary = "get data compare internal")
    @APIResponse(responseCode = "200", description = "reutrn data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListInternal(@HeaderParam("Encrypt-Data") String encryptData, @RequestBody GetDataComparisonInternalForm req) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return ReactiveConverter.toUni(forControlService.getAllComparisonInternal(req, infoUser, encryptData));
    }
}
