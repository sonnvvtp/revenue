package com.viettelpost.platform.bms.portal.repository.impl.einvoice;

import com.viettelpost.platform.bms.portal.model.entity.InvoiceDoctypeEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordItemEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordItemOrderEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordLineEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceSellerInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceStatusJourneyEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceSymbolEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceTypeEntity;
import com.viettelpost.platform.bms.portal.model.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.CreateInvoiceRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.DetailRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceOrderRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceRecordRequest;
import com.viettelpost.platform.bms.portal.model.response.einvoice.InvoiceRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.ItemRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.OrderRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.FindInvoiceOrderResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.FindInvoiceRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.QuerySearchItemRecord;
import com.viettelpost.platform.bms.portal.model.response.einvoice.QuerySearchRecordOrder;
import com.viettelpost.platform.bms.portal.repository.InvoiceRecordRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

@ApplicationScoped
@RequiredArgsConstructor
public class InvoiceRecordRepositoryImpl implements InvoiceRecordRepository {

    private final PgPool client;

    @Override
    public Multi<FindInvoiceOrderResponse> findInvoiceOrderBy(CreateInvoiceRecordRequest request) {

        String sql = """
                    select io.*,
                      ii.id invoice_buyer_id,
                     	ii.buyer_type,
                     	ii.buyer_name,
                     	ii.partner_name,
                     	ii.buyer_phone ,
                     	ii.buyer_email,
                     	ii.buyer_tax_code,
                     	ii.buyer_address,
                     	ii.buyer_bank_account,
                     	ii.buyer_bank_name,
                     	ii.doctype_id,
                     	ii.group_order_id
                     from bms_payment.general_order io
                     left join bms_payment.invoice_info ii on ii.general_order_id = io.id and ii.domain_type = 'FMCG'
                      where 1 = 1 
                """;

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (!CollectionUtils.isEmpty(request.getListOrderIds())) {
            sql += String.format(" and io.id = any($%d) and io.invoice_status = 0", counter);
            params.add(request.getListOrderIds().toArray());
        }

        return executeMulti(client, sql, Tuple.from(params), FindInvoiceOrderResponse.class);
    }

    @Override
    public Uni<InvoiceRecordEntity> save(InvoiceRecordEntity entity, SqlConnection sqlConnection) {
        String sql;

        List<Object> params = new ArrayList<>();

        sql = """
            insert into bms_payment.invoice_record( id
                                                 ,tenant_id
                                                 ,created_by
                                                 ,created_at
                                                 ,updated_by
                                                 ,updated_at
                                                 ,record_status
                                                 ,record_no
                                                 ,unit_level1_id
                                                 ,unit_level2_id
                                                 ,buyer_id
                                                 ,buyer_code
                                                 ,accounting_date
                                                 ,accountant_id
                                                 ,payment_method
                                                 ,tax_percent
                                                 ,email
                                                 ,phone
                                                 ,tax_code
                                                 ,account_no
                                                 ,customer_name
                                                 ,address
                                                 ,invoice_type
                                                 ,invoice_number
                                                 ,invoice_serial
                                                 ,invoice_form
                                                 ,invoice_ref_id
                                                 ,invoice_export_date
                                                 ,record_type_id
                                                 ,amount_before_tax
                                                 ,amount_tax
                                                 ,amount_deduct
                                                 ,amount_total
                                                 ,company_code
                                                 ,record_type
                                                 ,record_source
                                                 ,unit_name
                                                 )
            values (   $1
                      ,$2
                      ,$3
                      ,current_timestamp
                      ,$4
                      ,current_timestamp
                      ,$5
                      ,$6
                      ,$7
                      ,$8
                      ,$9
                      ,$10
                      ,$11
                      ,$12
                      ,$13
                      ,$14
                      ,$15
                      ,$16
                      ,$17
                      ,$18
                      ,$19
                      ,$20
                      ,$21
                      ,$22
                      ,$23
                      ,$24
                      ,$25
                      ,$26
                      ,$27
                      ,$28
                      ,$29
                      ,$30
                      ,$31
                      ,$32
                      ,$33
                      ,$34
                      ,$35
            )
            returning *
            """;
        params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "createdAt", "updatedAt", "invoiceUrl"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), InvoiceRecordEntity.class);
        }

        return execute(client, sql, Tuple.from(params), InvoiceRecordEntity.class);
    }

    @Override
    public Uni<InvoiceRecordItemEntity> save(InvoiceRecordItemEntity entity,
        SqlConnection sqlConnection) {
        String sql;

        List<Object> params = new ArrayList<>();

        sql = """
            insert into bms_payment.invoice_record_item( tenant_id
                                                     ,created_by
                                                     ,created_at
                                                     ,updated_by
                                                     ,updated_at
                                                     ,unit_level1_id
                                                     ,unit_level2_id
                                                     ,invoice_record_id
                                                     ,isactive
                                                     ,rn
                                                     ,is_note
                                                     ,product_type
                                                     ,note
                                                     ,unit
                                                     ,quantity
                                                     ,unit_price
                                                     ,amount
                                                     ,invoice_item_ref_id
                                                     ,invoice_adjust_id)
            values (   $1
                      ,$2
                      ,current_timestamp
                      ,$3
                      ,current_timestamp
                      ,$4
                      ,$5
                      ,$6
                      ,$7
                      ,$8
                      ,$9
                      ,$10
                      ,$11
                      ,$12
                      ,$13
                      ,$14
                      ,$15
                      ,$16
                      ,$17
            )
            returning *
            """;
        params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), InvoiceRecordItemEntity.class);
        }

        return execute(client, sql, Tuple.from(params), InvoiceRecordItemEntity.class);
    }

    @Override
    public Multi<InvoiceRecordLineEntity> saveBatch(List<InvoiceRecordLineEntity> entities,
        SqlConnection sqlConnection) {
        int maxBatchSize = 500;
        List<Multi<InvoiceRecordLineEntity>> bulkInsert = new ArrayList<>();

        for (int i = 0; i < entities.size(); i += maxBatchSize) {
            int end = Math.min(i + maxBatchSize, entities.size());
            List<InvoiceRecordLineEntity> chunk = entities.subList(i, end);

            String INSERT_STATEMENT = """
                insert into bms_payment.invoice_record_line (
                                                            tenant_id
                                                            ,created_by
                                                            ,created_at
                                                            ,updated_by
                                                            ,updated_at
                                                            ,record_id
                                                            ,order_id
                                                            ,order_code
                                                            ,amount
                    )
                    values
                """;

            int counter = 1;
            StringBuilder insertValues = new StringBuilder();
            List<Object> params = new ArrayList<>();
            for (InvoiceRecordLineEntity entity : chunk) {
                insertValues.append(String.format(" ($%d, $%d, current_timestamp, $%d, current_timestamp, $%d, $%d, $%d, $%d),\n",
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter
                ));
                params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));
            }

            insertValues = new StringBuilder(StringUtils.removeEnd(insertValues.toString(), ",\n"));

            INSERT_STATEMENT += insertValues;
            INSERT_STATEMENT += " returning * ";

            Multi<InvoiceRecordLineEntity> insert;
            if (Objects.nonNull(sqlConnection)) {
                insert = executeMulti(sqlConnection, INSERT_STATEMENT, Tuple.from(params), InvoiceRecordLineEntity.class);
            } else {
                insert = executeMulti(client, INSERT_STATEMENT, Tuple.from(params), InvoiceRecordLineEntity.class);
            }

            bulkInsert.add(insert);
        }

        return Multi.createBy().concatenating().streams(bulkInsert);
    }

    @Override
    public Uni<Boolean> updateInvoiceStatusBy(List<BigDecimal> ids, Integer status,
        SqlConnection sqlConnection) {
        String sql = """
                update
                  bms_payment.general_order
                set
                    invoice_status = $1 
                where
                  id = any($2)
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.of(status, ids.toArray()));
        }

        return executeOnly(client, sql, Tuple.of(status, ids.toArray()));
    }

    @Override
    public Uni<Boolean> updateTotalAmountRecord(InvoiceRecordEntity entity, SqlConnection sqlConnection) {
        String sql = """
                update
                  bms_payment.invoice_record
                set
                  amount_total = (
                  select
                    sum(amount)
                  from
                    bms_payment.invoice_record_line
                  where
                    record_id = $1 )
                where
                  id = $2
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.of(entity.getId(), entity.getId()));
        }

        return executeOnly(client, sql, Tuple.of(entity.getId(), entity.getId()));
    }

    @Override
    public Uni<Long> getNextSequenceBy(String schemaName, String seqName, SqlConnection sqlConnection) {

        String sql = """ 
                SELECT nextval($1)
                """;
        List<Object> params = new ArrayList<>();
        params.add(String.format("%s.%s", schemaName, seqName));
        if (Objects.nonNull(sqlConnection)) {
            return executeAndGetValue(sqlConnection, sql, Tuple.from(params), "nextval", Long.class);
        }
        return executeAndGetValue(client, sql, Tuple.from(params), "nextval", Long.class);

    }

    @Override
    public Uni<Integer> findInvoiceRecordCount(FindInvoiceRecordRequest findInvoiceOrderRequest, List<String> companyCodes) {
        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        String recordNo = findInvoiceOrderRequest.getRecordNo();
        List<Integer> status = findInvoiceOrderRequest.getStatus();
        Long doctypeId = findInvoiceOrderRequest.getDoctypeId();
        String customerCode = findInvoiceOrderRequest.getCustomerCode();
        Integer recordType = findInvoiceOrderRequest.getRecordType();
        LocalDate fromDate = findInvoiceOrderRequest.getFromDate();
        LocalDate toDate = findInvoiceOrderRequest.getToDate();
        LocalDate fromInvoiceDate = findInvoiceOrderRequest.getFromInvoiceDate();
        LocalDate toInvoiceDate = findInvoiceOrderRequest.getToInvoiceDate();

        String sql = """
        select count(1) as total from bms_payment.invoice_record
        where 1 = 1
        """;

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and CONCAT(invoice_serial, invoice_number) = $%d ", counter++);
            params.add(advancedFilter.trim());
        }

        if (StringUtils.isNotEmpty(recordNo)) {
            sql += String.format(" and record_no = $%d ", counter++);
            params.add(recordNo.trim());
        }

        if (!CollectionUtils.isEmpty(companyCodes)) {
            sql += String.format(" and company_code = any($%d) ", counter++);
            params.add(companyCodes.toArray());
        }

        if (Objects.nonNull(status) && !status.isEmpty()) {
            sql += String.format(" and record_status = any($%d) ", counter++);
            params.add(status.toArray());
        }

        if (Objects.nonNull(doctypeId)) {
            sql += String.format(" and record_type_id = $%d ", counter++);
            params.add(doctypeId);
        }

        if (StringUtils.isNotEmpty(customerCode)) {
            sql += String.format(" and buyer_code = $%d ", counter++);
            params.add(customerCode);
        }

        if (Objects.nonNull(recordType)) {
            sql += String.format(" and record_type = $%d ", counter++);
            params.add(recordType);
        }
        //
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and created_at between $%d and $%d ", counter++, counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and created_at >= $%d ", counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and created_at <= $%d ", counter);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }
        //
        if (Objects.nonNull(fromInvoiceDate) && Objects.nonNull(toInvoiceDate)) {
            sql += String.format(" and invoice_export_date between $%d and $%d ", counter++, counter);
            params.add(LocalDateTime.of(fromInvoiceDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toInvoiceDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromInvoiceDate)) {
            sql += String.format(" and invoice_export_date >= $%d ", counter);
            params.add(LocalDateTime.of(fromInvoiceDate, LocalTime.MIN));
        } else if (Objects.nonNull(toInvoiceDate)) {
            sql += String.format(" and invoice_export_date <= $%d ", counter);
            params.add(LocalDateTime.of(toInvoiceDate, LocalTime.MAX));
        }

        return executeAndGetValue(client, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<FindInvoiceRecordResponse> findInvoiceRecord(
        FindInvoiceRecordRequest findInvoiceOrderRequest, List<String> companyCodes) {

        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        String recordNo = findInvoiceOrderRequest.getRecordNo();
        List<Integer> status = findInvoiceOrderRequest.getStatus();
        Long doctypeId = findInvoiceOrderRequest.getDoctypeId();
        String customerCode = findInvoiceOrderRequest.getCustomerCode();
        Integer recordType = findInvoiceOrderRequest.getRecordType();
        LocalDate fromDate = findInvoiceOrderRequest.getFromDate();
        LocalDate toDate = findInvoiceOrderRequest.getToDate();
        LocalDate fromInvoiceDate = findInvoiceOrderRequest.getFromInvoiceDate();
        LocalDate toInvoiceDate = findInvoiceOrderRequest.getToInvoiceDate();
        int page = Objects.nonNull(findInvoiceOrderRequest.getPage()) ? findInvoiceOrderRequest.getPage() : 1;
        int size = Objects.nonNull(findInvoiceOrderRequest.getSize()) ? findInvoiceOrderRequest.getSize() : 10;

        String sql = """
                select *,
                (select firstname || ' ' || lastname  from bms_payment.vtp_susers where userid = created_by limit 1) created_by_name
                from bms_payment.invoice_record
                where 1=1
                """;

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (StringUtils.isNotEmpty(advancedFilter)) {
            sql += String.format(" and CONCAT(invoice_serial, invoice_number) = $%d ", counter++);
            params.add(advancedFilter.trim());
        }

        if (StringUtils.isNotEmpty(recordNo)) {
            sql += String.format(" and record_no = $%d ", counter++);
            params.add(recordNo.trim());
        }

        if (!CollectionUtils.isEmpty(companyCodes)) {
            sql += String.format(" and company_code = any($%d) ", counter++);
            params.add(companyCodes.toArray());
        }

        if (CollectionUtils.isNotEmpty(status)) {
            sql += String.format(" and record_status = any($%d) ", counter++);
            params.add(status.toArray());
        }

        if (Objects.nonNull(doctypeId)) {
            sql += String.format(" and record_type_id = $%d ", counter++);
            params.add(doctypeId);
        }

        if (StringUtils.isNotEmpty(customerCode)) {
            sql += String.format(" and buyer_code = $%d ", counter++);
            params.add(customerCode);
        }

        if (Objects.nonNull(recordType)) {
            sql += String.format(" and record_type = $%d ", counter++);
            params.add(recordType);
        }
        //
        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and created_at >= $%d and created_at <= $%d ", counter++, counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and created_at >= $%d ", counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and created_at <= $%d ", counter++);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }
        //
        if (Objects.nonNull(fromInvoiceDate) && Objects.nonNull(toInvoiceDate)) {
            sql += String.format(" and invoice_export_date between $%d and $%d ", counter++, counter++);
            params.add(LocalDateTime.of(fromInvoiceDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toInvoiceDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromInvoiceDate)) {
            sql += String.format(" and invoice_export_date >= $%d ", counter++);
            params.add(LocalDateTime.of(fromInvoiceDate, LocalTime.MIN));
        } else if (Objects.nonNull(toInvoiceDate)) {
            sql += String.format(" and invoice_export_date <= $%d ", counter++);
            params.add(LocalDateTime.of(toInvoiceDate, LocalTime.MAX));
        }

        sql += String.format(" order by created_at desc limit $%d offset $%d ", counter++, counter);
        params.add(size);
        params.add(size * (page - 1));

        return executeMulti(client, sql, Tuple.from(params), FindInvoiceRecordResponse.class);
    }

    @Override
    public Uni<InvoiceRecordResponse> findInvoiceRecordById(BigDecimal recordId) {
        String sql = """
                select * from bms_payment.invoice_record
                where id = $1
                """;
        return execute(client, sql, Tuple.of(recordId), InvoiceRecordResponse.class);
    }

    @Override
    public Uni<QuerySearchRecordOrder> findListOrderCount(BigDecimal recordId, DetailRecordRequest request) {

        String orderCode = request.getOrderCode();
        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();

        String sql = """
                     select count(io.id) count, sum(io.order_amount_before_tax) order_amount_before_tax, sum(io.order_tax_amount) order_tax_amount, sum(io.order_amount_after_tax) order_amount_after_tax
                      from bms_payment.general_order io
                      join bms_payment.invoice_record_line rdl on rdl.order_id = io.id
                      join bms_payment.invoice_record rd on rd.id = rdl.record_id
                      where rd.id = $1
        """;
        List<Object> params = new ArrayList<>();
        params.add(recordId);
        int counter = 2;

        if (StringUtils.isNotEmpty(orderCode)) {
            sql += String.format(" and io.order_code = $%d ", counter++);
            params.add(orderCode.trim());
        }

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and io.created_at between $%d and $%d ", counter++, counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and io.created_at >= $%d ", counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and io.created_at <= $%d ", counter);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }
        return execute(client, sql, Tuple.from(params), QuerySearchRecordOrder.class);
    }

    @Override
    public Multi<OrderRecordResponse> findListOrder(BigDecimal recordId, DetailRecordRequest request) {
        String orderCode = request.getOrderCode();
        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();
        int page = Objects.nonNull(request.getPage()) ? request.getPage() : 1;
        int size = Objects.nonNull(request.getSize()) ? request.getSize() : 10;

        String sql = """
                     select io.* 
                      from bms_payment.general_order io 
                      join bms_payment.invoice_record_line rdl on rdl.order_id = io.id 
                      join bms_payment.invoice_record rd on rd.id = rdl.record_id
                      where rd.id = $1
        """;
        List<Object> params = new ArrayList<>();
        params.add(recordId);
        int counter = 2;

        if (StringUtils.isNotEmpty(orderCode)) {
            sql += String.format(" and io.order_code = $%d ", counter++);
            params.add(orderCode.trim());
        }

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and io.created_at between $%d and $%d ", counter++, counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and io.created_at >= $%d ", counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and io.created_at <= $%d ", counter++);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }

        sql += String.format(" order by io.created_at desc limit $%d offset $%d ", counter++, counter);
        params.add(size);
        params.add(size * (page - 1));

        return executeMulti(client, sql, Tuple.from(params), OrderRecordResponse.class);
    }

    @Override
    public Uni<QuerySearchItemRecord> findListItemCount(BigDecimal recordId) {

        String sql = """
                        select
                            COUNT(io.id) AS count,
                            SUM(CASE\s
                                WHEN io.item_selection = 3 THEN -io.item_amount_before_tax\s
                                ELSE io.item_amount_before_tax\s
                            END) AS order_amount_before_tax,
                            SUM(CASE\s
                                WHEN io.item_selection = 3 THEN -io.item_tax_amount\s
                                ELSE io.item_tax_amount\s
                            END) AS order_tax_amount,
                            SUM(CASE\s
                                WHEN io.item_selection = 3 THEN -io.item_amount_after_tax\s
                                ELSE io.item_amount_after_tax\s
                            END) AS order_amount_after_tax
                       from
                            bms_payment.invoice_record_item_order io
                       where
                            io.record_id = $1
                """;
        List<Object> params = new ArrayList<>();
        params.add(recordId);

        return execute(client, sql, Tuple.from(params), QuerySearchItemRecord.class);
    }

    @Override
    public Multi<ItemRecordResponse> findListItem(BigDecimal recordId) {
        int page =  1;
        int size = 100;

        String sql = """
                    select io.*
                    from
                        bms_payment.invoice_record_item_order io
                    where
                        io.record_id = $1
                """;

        List<Object> params = new ArrayList<>();
        params.add(recordId);
        int counter = 2;

        sql += String.format(" order by item_code asc, item_selection asc  limit $%d offset $%d ", counter++, counter);
        params.add(size);
        params.add(size * (page - 1));

        return executeMulti(client, sql, Tuple.from(params), ItemRecordResponse.class);
    }

    @Override
    public Multi<InvoiceRecordResponse> findListInvoiceRecordBy(List<BigDecimal> ids,
        List<Integer> status) {
        String sql = """
                select * from bms_payment.invoice_record
                where 1=1
                """;

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (!CollectionUtils.isEmpty(ids)) {
            sql += String.format(" and id = any($%d)", counter++);
            params.add(ids.toArray());
        }
        if (!CollectionUtils.isEmpty(status)) {
            sql += String.format(" and record_status = any($%d)", counter);
            params.add(status.toArray());
        }
        return executeMulti(client, sql, Tuple.from(params), InvoiceRecordResponse.class);
    }

    @Override
    public Uni<Boolean> updateStatusInvoiceRecord(List<BigDecimal> ids, Integer status, List<Integer> statusNeedUpd, Long userId, SqlConnection sqlConnection) {
        String sql = """
                update
                  bms_payment.invoice_record
                set
                    record_status = $1,
                    updated_at = current_timestamp,
                    updated_by = $2
                where 1 = 1
                """;

        List<Object> params = new ArrayList<>();
        params.add(status);
        params.add(userId);
        int counter = 3;

        if (!CollectionUtils.isEmpty(ids)) {
            sql += String.format(" and id = any($%d)", counter++);
            params.add(ids.toArray());
        }
        if (!CollectionUtils.isEmpty(statusNeedUpd)) {
            sql += String.format(" and record_status = any($%d)", counter);
            params.add(statusNeedUpd.toArray());
        }
        return executeOnly(client, sql, Tuple.from(params));
    }

    @Override
    public Multi<OrderRecordResponse> findListOrderBy(List<BigDecimal> recordIds, SqlConnection sqlConnection) {

        String sql = """
                    select io.* 
                      from bms_payment.general_order io 
                      join bms_payment.invoice_record_line rdl on rdl.order_id = io.id 
                      join bms_payment.invoice_record rd on rd.id = rdl.record_id
                      where rd.id = any($1)
                """;

        List<Object> params = new ArrayList<>();
        params.add(recordIds.toArray());

        return executeMulti(client, sql, Tuple.from(params), OrderRecordResponse.class);
    }

    @Override
    public Uni<Boolean> save(InvoiceStatusJourneyEntity entity, SqlConnection sqlConnection) {
        String sql;

        List<Object> params = new ArrayList<>();

        sql = """
            insert into bms_payment.invoice_status_journey( tenant_id
                                                       ,created_by
                                                       ,created_at
                                                       ,updated_by
                                                       ,updated_at
                                                       ,order_code
                                                       ,company_code
                                                       ,invoice_error_code
                                                       ,invoice_status
                                                       ,invoice_message
                                                       ,invoice_code
                                                       ,invoice_number
                                                       ,invoice_date
                                                       ,pdf_url
                                                       ,xml_url
                                                       ,callback_status
                                                       ,callback_count
                                                       ,order_source)
            values (   $1
                      ,$2
                      ,current_timestamp
                      ,$3
                      ,current_timestamp
                      ,$4
                      ,$5
                      ,$6
                      ,$7
                      ,$8
                      ,$9
                      ,$10
                      ,$11
                      ,$12
                      ,$13
                      ,$14
                      ,$15
                      ,$16
            )
            returning *
            """;
        params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));

        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.from(params));
        }

        return executeOnly(client, sql, Tuple.from(params));
    }

    @Override
    public Multi<InvoiceStatusJourneyEntity> saveBatchJourney(List<InvoiceStatusJourneyEntity> entities,
        SqlConnection sqlConnection) {
        int maxBatchSize = 500;
        List<Multi<InvoiceStatusJourneyEntity>> bulkInsert = new ArrayList<>();

        for (int i = 0; i < entities.size(); i += maxBatchSize) {
            int end = Math.min(i + maxBatchSize, entities.size());
            List<InvoiceStatusJourneyEntity> chunk = entities.subList(i, end);

            String INSERT_STATEMENT = """
                insert into bms_payment.invoice_status_journey (
                                                            tenant_id
                                                           ,created_by
                                                           ,created_at
                                                           ,updated_by
                                                           ,updated_at
                                                           ,order_code
                                                           ,company_code
                                                           ,invoice_error_code
                                                           ,invoice_status
                                                           ,invoice_message
                                                           ,invoice_code
                                                           ,invoice_number
                                                           ,invoice_date
                                                           ,pdf_url
                                                           ,xml_url
                                                           ,callback_status
                                                           ,callback_count
                                                           ,order_source
                    )
                    values
                """;

            int counter = 1;
            StringBuilder insertValues = new StringBuilder();
            List<Object> params = new ArrayList<>();
            for (InvoiceStatusJourneyEntity entity : chunk) {
                insertValues.append(String.format(" ($%d, $%d, current_timestamp, $%d, current_timestamp, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d,$%d,$%d,$%d,$%d),\n",
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter
                ));
                params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));
            }

            insertValues = new StringBuilder(StringUtils.removeEnd(insertValues.toString(), ",\n"));

            INSERT_STATEMENT += insertValues;
            INSERT_STATEMENT += " returning * ";

            Multi<InvoiceStatusJourneyEntity> insert;
            if (Objects.nonNull(sqlConnection)) {
                insert = executeMulti(sqlConnection, INSERT_STATEMENT, Tuple.from(params), InvoiceStatusJourneyEntity.class);
            } else {
                insert = executeMulti(client, INSERT_STATEMENT, Tuple.from(params), InvoiceStatusJourneyEntity.class);
            }

            bulkInsert.add(insert);
        }

        return Multi.createBy().concatenating().streams(bulkInsert);
    }

    @Override
    public Uni<InvoiceDoctypeEntity> finErpDoctypeBy(Long doctypeId, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.erp_doctype
                where doctype_id = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(doctypeId), InvoiceDoctypeEntity.class);
        }

        return execute(client, sql, Tuple.of(doctypeId), InvoiceDoctypeEntity.class);
    }

    @Override
    public Uni<InvoiceTypeEntity> findInvoiceTypeBy(String companyCode, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.invoice_type
                where company_code = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(companyCode), InvoiceTypeEntity.class);
        }

        return execute(client, sql, Tuple.of(companyCode), InvoiceTypeEntity.class);
    }

    @Override
    public Uni<InvoiceSymbolEntity> findInvoiceSymbolBy(String companyCode, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.invoice_symbol
                where company_code = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(companyCode), InvoiceSymbolEntity.class);
        }

        return execute(client, sql, Tuple.of(companyCode), InvoiceSymbolEntity.class);
    }

    @Override
    public Multi<ItemOrderEntity> findItemOrderBy(BigDecimal orderId, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.item_order
                where general_order_id = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeMulti(sqlConnection, sql, Tuple.of(orderId), ItemOrderEntity.class);
        }

        return executeMulti(client, sql, Tuple.of(orderId), ItemOrderEntity.class);
    }

    @Override
    public Multi<InvoiceRecordItemOrderEntity> saveBatchItemOrder(List<InvoiceRecordItemOrderEntity> entities, SqlConnection sqlConnection) {
        int maxBatchSize = 500;
        List<Multi<InvoiceRecordItemOrderEntity>> bulkInsert = new ArrayList<>();

        for (int i = 0; i < entities.size(); i += maxBatchSize) {
            int end = Math.min(i + maxBatchSize, entities.size());
            List<InvoiceRecordItemOrderEntity> chunk = entities.subList(i, end);

            String INSERT_STATEMENT = """
                insert into bms_payment.invoice_record_item_order (
                                 tenant_id
                                 ,created_by
                                 ,created_at
                                 ,updated_by
                                 ,updated_at
                                 ,record_id
                                 ,order_id
                                 ,item_selection
                                 ,item_code
                                 ,item_name
                                 ,item_note
                                 ,item_unit
                                 ,item_quantity
                                 ,item_price
                                 ,item_weight
                                 ,item_amount_before_tax
                                 ,item_tax_type
                                 ,item_tax_percent
                                 ,item_tax_amount
                                 ,item_amount_after_tax
                    )
                    values
                """;

            int counter = 1;
            StringBuilder insertValues = new StringBuilder();
            List<Object> params = new ArrayList<>();
            for (InvoiceRecordItemOrderEntity entity : chunk) {
                insertValues.append(String.format(" ($%d, $%d, current_timestamp, $%d, current_timestamp, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d),\n",
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++,
                    counter++, counter++, counter++, counter++, counter++, counter++
                ));
                params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));
            }

            insertValues = new StringBuilder(StringUtils.removeEnd(insertValues.toString(), ",\n"));

            INSERT_STATEMENT += insertValues;
            INSERT_STATEMENT += " returning * ";

            Multi<InvoiceRecordItemOrderEntity> insert;
            if (Objects.nonNull(sqlConnection)) {
                insert = executeMulti(sqlConnection, INSERT_STATEMENT, Tuple.from(params), InvoiceRecordItemOrderEntity.class);
            } else {
                insert = executeMulti(client, INSERT_STATEMENT, Tuple.from(params), InvoiceRecordItemOrderEntity.class);
            }

            bulkInsert.add(insert);
        }

        return Multi.createBy().concatenating().streams(bulkInsert);
    }

    @Override
    public Uni<Integer> findOrderByRecordIdCount(BigDecimal recordId, FindInvoiceOrderRequest findInvoiceOrderRequest) {
        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        String sql = """
                      select count(io.id) total
                      from bms_payment.general_order io
                      join bms_payment.invoice_record_line rdl on rdl.order_id = io.id
                      join bms_payment.invoice_record rd on rd.id = rdl.record_id
                      where rd.id = $1
        """;

        List<Object> params = new ArrayList<>();
        params.add(recordId);
        int counter = 2;
        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and io.order_code = $%d ", counter);
            params.add(advancedFilter.trim());
        }
        return executeAndGetValue(client, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<FindInvoiceOrderResponse> findOrderByRecordId(BigDecimal recordId, FindInvoiceOrderRequest findInvoiceOrderRequest) {
        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        String sql = """
                    select io.*,
                          ii.buyer_type,
                          ii.buyer_name,
                          ii.partner_name,
                          ii.buyer_phone ,
                          ii.buyer_email,
                          ii.buyer_tax_code,
                          ii.buyer_address,
                          ii.buyer_bank_account,
                          ii.buyer_bank_name,
                          ii.doctype_id,
                          ii.group_order_id
                      from bms_payment.general_order io
                      join bms_payment.invoice_record_line rdl on rdl.order_id = io.id
                      join bms_payment.invoice_record rd on rd.id = rdl.record_id
                      left join bms_payment.invoice_info ii on ii.general_order_id = io.id and ii.domain_type = 'FMCG'
                      where rd.id = $1  
                """;
        int page = Objects.nonNull(findInvoiceOrderRequest.getPage()) ? findInvoiceOrderRequest.getPage() : 1;
        int size = Objects.nonNull(findInvoiceOrderRequest.getSize()) ? findInvoiceOrderRequest.getSize() : 10;

        List<Object> params = new ArrayList<>();
        params.add(recordId);
        int counter = 2;
        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and io.order_code = $%d ", counter++);
            params.add(advancedFilter.trim());
        }
        sql += String.format(" order by created_at desc limit $%d offset $%d ", counter++, counter);
        params.add(size);
        params.add(size * (page - 1));

        return executeMulti(client, sql, Tuple.from(params), FindInvoiceOrderResponse.class);
    }

    @Override
    public Uni<InvoiceSellerInfoEntity> findInvoiceSellerInfoBy(BigDecimal recordId, SqlConnection sqlConnection) {
        String sql = """
                       select *
                       from
                        bms_payment.seller_info si
                       where
                        company_code in (
                        select
                          company_code
                        from
                          bms_payment.invoice_record
                        where
                          id = $1
                       )  limit 1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(recordId), InvoiceSellerInfoEntity.class);
        }

        return execute(client, sql, Tuple.of(recordId), InvoiceSellerInfoEntity.class);
    }

    @Override
    public Multi<InvoiceInfoEntity> findInvoiceInfoBy(BigDecimal recordId, SqlConnection sqlConnection) {
        String sql = """
                       select
                          ii.*
                         from
                          bms_payment.invoice_info ii
                         join bms_payment.invoice_record_line rdl on
                          rdl.order_id = ii.general_order_id 
                         join bms_payment.invoice_record rd on
                          rd.id = rdl.record_id
                         where
                          rd.id = $1 and ii.domain_type = 'FMCG' 
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeMulti(sqlConnection, sql, Tuple.of(recordId), InvoiceInfoEntity.class);
        }

        return executeMulti(client, sql, Tuple.of(recordId), InvoiceInfoEntity.class);
    }

    @Override
    public Uni<ItemRecordResponse> findInvoiceRecordItemOrder(BigDecimal itemOrderId, BigDecimal recordId) {

        String sql = """
                    select *
                    from
                        bms_payment.invoice_record_item_order
                    where
                        id = $1 and record_id = $2
                """;

        List<Object> params = new ArrayList<>();
        params.add(itemOrderId);
        params.add(recordId);

        return execute(client, sql, Tuple.from(params), ItemRecordResponse.class);
    }

    @Override
    public Uni<Boolean> updateTaxAmount(BigDecimal recordId, BigDecimal itemOrderId, BigDecimal taxAmountUpdate, Long userId, SqlConnection sqlConnection) {
        String sql = """
                        update
                         bms_payment.invoice_record_item_order
                        set
                           item_tax_amount = $1,
                           item_amount_after_tax = item_amount_before_tax + $2,
                           updated_at = current_timestamp,
                           updated_by = $3
                        where id = $4 and record_id = $5
                """;

        List<Object> params = new ArrayList<>();
        params.add(taxAmountUpdate);
        params.add(taxAmountUpdate);
        params.add(userId);
        params.add(itemOrderId);
        params.add(recordId);
        return executeOnly(client, sql, Tuple.from(params));
    }

    @Override
    public Uni<Boolean> updateRecordAmount(BigDecimal recordId, Long userId, SqlConnection sqlConnection) {
        String sql = """
                    update
                       bms_payment.invoice_record
                     set
                       amount_tax = (
                        select
                             SUM(CASE
                                 WHEN io.item_selection = 3 THEN -io.item_tax_amount
                                 ELSE io.item_tax_amount
                             END) AS order_tax_amount
                        from
                             bms_payment.invoice_record_item_order io
                        where
                             io.record_id = $1
                       ),
                       amount_total = (
                        select
                             SUM(CASE
                                 WHEN io.item_selection = 3 THEN -io.item_amount_after_tax
                                 ELSE io.item_amount_after_tax
                             END) AS order_amount_after_tax
                        from
                             bms_payment.invoice_record_item_order io
                        where
                             io.record_id = $2
                       ),
                       updated_at = current_timestamp,
                       updated_by = $3
                     where
                       id = $4
            """;

        List<Object> params = new ArrayList<>();
        params.add(recordId);
        params.add(recordId);
        params.add(userId);
        params.add(recordId);

        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.from(params));
        }

        return executeOnly(client, sql, Tuple.from(params));
    }

    @Override
    public Multi<ItemOrderEntity> findItemOrderBy(BigDecimal itemOrderId, BigDecimal recordId, SqlConnection sqlConnection) {
        String sql = """
                 select item_selection, item_code, item_tax_percent, item_price, item_tax_amount 
                 from bms_payment.item_order
                 where general_order_id in (select order_id from bms_payment.invoice_record_item_order irio where id = $1 and record_id  = $2)
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeMulti(sqlConnection, sql, Tuple.of(itemOrderId, recordId), ItemOrderEntity.class);
        }

        return executeMulti(client, sql, Tuple.of(itemOrderId, recordId), ItemOrderEntity.class);
    }
}
