package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum PartnerSource {
    VTP(1, "VTP", "đối tác VTP"),
    MSS(2, "MSS", "đối tác MSS"),
    TMS(3, "TMS", "đối tác TMS"),
    WMS(4, "WMS", "đối tác WMS"),
    LGT(5, "LGT", "đối tác Logitek"),
    NA(-1, "N/A", "N/A");
    private int id;
    private String code;
    private String name;

    public static PartnerSource get(String code) {
        return Arrays.stream(PartnerSource.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(NA);
    }
}
