package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.entity.ErpDoctypeEntity;
import com.viettelpost.platform.bms.portal.model.request.ErpDocTypeRequest;
import com.viettelpost.platform.bms.portal.model.response.DocTypeResponse;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import io.smallrye.mutiny.Uni;

import java.util.List;

public interface ErpDoctypeRepository {
    Uni<ErpDoctypeEntity> create(ErpDocTypeRequest request);

    Uni<PageResponse<ErpDoctypeEntity>> getAll(int page, int size);

    Uni<ErpDoctypeEntity> update(Long doctypeId,ErpDocTypeRequest request);

    Uni<List<DocTypeResponse>> getDocTypeByCompanyCode(String companyCode);
}
