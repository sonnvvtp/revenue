package com.viettelpost.platform.bms.revenue.worker.model.response;

import java.math.BigDecimal;
import java.util.List;
import lombok.Data;

@Data
public class CreateBatchResponse {
    private boolean error;
    private String errorCode;
    private String message;
    private ResponseData data;

    @Data
    public static class ResponseData {
        private String success;
        private List<BigDecimal> ids;
        private Integer status;
        private String createdAt;
    }
}