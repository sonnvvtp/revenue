package com.viettelpost.platform.bms.revenue.worker.repository.impl;

import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.common.utils.OracleUtils;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BillEvtpPayInDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.accounting.AcctRawDataDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BgDichvuEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsBillJourneyEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsBillRevenueEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsServiceCategoryMappingEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueServiceGroupEntity;
import com.viettelpost.platform.bms.revenue.worker.repository.CalculationRevenueRepository;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@ApplicationScoped
@RequiredArgsConstructor
public class CalculationRevenueRepositoryImpl implements CalculationRevenueRepository {

    private final ConnectionPool oracleClient;

    private final PgPool pgClient;

    private final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @ConfigProperty(name = "config.bill.revenue.batchSize", defaultValue = "500")
    Integer batchSize;

    @ConfigProperty(name = "config.delivery.status", defaultValue = "1,3,4")
    List<Long> configDeliveryStatus;

    @ConfigProperty(name = "config.revenue.post.id.test", defaultValue = "ALL")  // ALL
    String postIdTestList;

    @ConfigProperty(name = "config.service.code.no.revenue", defaultValue = "PRT,GPHU,FCWT,GPUT")
    List<String> serviceCodeNoRevenue;

    public List<Long> getPostIdTestList() {
        if(StringUtils.isEmpty(postIdTestList) || "ALL".equalsIgnoreCase(postIdTestList)) {
            return Collections.emptyList();
        }
        try {
            return Arrays.stream(postIdTestList.split(","))
                .map(String::trim) // Remove any whitespace
                .map(Long::parseLong) // Convert to Long
                .collect(Collectors.toList()); // Collect into List<Long>
        } catch (Exception e) {
            // Handle invalid number format
            log.error("Invalid_postIdTestList_ex: {}", postIdTestList, e);
        }
        return Collections.emptyList();
    }

    @Override
    public Uni<Integer> findAllEvtpPayInCount(LocalDate startDate, LocalDate endDate) {
        String sql = """
                select count(1) as total
                from ERP_AC.EVTP_PAY_IN epi
                  where epi.DATEBILL between to_date(?, 'dd/MM/yyyy') and to_date(?, 'dd/MM/yyyy') + 1 - 0.00001
                        AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_BILL_REVENUE WHERE BILL = epi.BILL AND PAY_IN_ID = epi.PAY_IN_ID AND BILL_REVENUE_TYPE IN (%s))
                """;

        List<Integer> billStatus = Arrays.asList(RevenueType.TEMPORARY_REVENUE.getValue(), RevenueType.COMPLETED_REVENUE2.getValue());
        String placeholder = IntStream.range(0, billStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));
        sql = sql.formatted(placeholder);

        List<Object> params = new ArrayList<>();
        params.add(startDate.format(dtf));
        params.add(endDate.format(dtf));
        params.addAll(billStatus);
        if (CollectionUtils.isNotEmpty(getPostIdTestList())) {
            sql = sql + """
                    AND POST_ID IN (%s)
             """;
            String placeholderPost = IntStream.range(0, getPostIdTestList().size())
                .mapToObj(i -> "?")
                .collect(Collectors.joining(","));
            sql = sql.formatted(placeholderPost);
            params.addAll(getPostIdTestList());
        }
        if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
            sql = sql + """
                    AND M_PRODUCT NOT IN (%s)
             """;
            String placeholderDv = IntStream.range(0, serviceCodeNoRevenue.size())
                .mapToObj(i -> "?")
                .collect(Collectors.joining(","));
            sql = sql.formatted(placeholderDv);
            params.addAll(serviceCodeNoRevenue);
        }
        return executeAndGetValue(oracleClient, sql, params, "total", Integer.class);
    }

    @Override
    public Multi<BillEvtpPayInDTO> findAllEvtpPayIn(LocalDate startDate, LocalDate endDate, Integer page, Integer size) {

        String sql = """
            SELECT a.*
              FROM (SELECT ROW_NUMBER () OVER (ORDER BY epi.DATEBILL, epi.PAY_IN_ID)     ROWSNUM,
                           epi.PAY_IN_ID,
                           epi.BILL,
                           epi.BILL_ID,
                           200 BILL_STATUS,
                           epi.TYPE,
                           epi.DATEBILL,
                           epi.DATEINSERT,
                           epi.PERIOD_ID,
                           epi.ORG_ID,
                           epi.POST_ID,
                           epi.PARTNER_EVTP,
                           epi.PARTNER_ID,
                           epi.M_PRODUCT,
                           epi.PAYMENTTEAM_ID,
                           epi.IS_PAID,
                           epi.WEIGHT,
                           epi.AMT,
                           epi.AMT_INVOICE,
                           epi.AMT_DEDUCT,
                           epi.AMT_PAY,
                           epi.BILL_REF,
                           epi.AMT_DIFF,
                           epi.AMT_DEDUCT_OTHER,
                           epi.CITY_TO,
                           epi.CITY_FROM,
                           epi.DISTRICT_TO,
                           epi.DISTRICT_FROM,
                           epi.PARTNER_GROUP_ID,
                           epi.FREIGHT,
                           epi.FEE,
                           epi.FEE_OTHER,
                           dv.VAT,
                           CASE
                               WHEN dv.VAT > 0 THEN
                               (epi.AMT - NVL(ROUND(epi.AMT/(1 + dv.VAT/100)), 0))
                               ELSE 0
                           END AMT_VAT,
                           nvl((SELECT COMPANY_CODE FROM ERP_AC.FICO_SAP_POST_CODE_CENTER WHERE POST_ID = epi.POST_ID AND ROWNUM = 1), '1000') COMPANY_CODE
                      FROM ERP_AC.EVTP_PAY_IN epi
                      LEFT JOIN VTP.BG_DICHVU dv ON MA_DICHVU = epi.M_PRODUCT AND dv.SU_DUNG = 1
                     WHERE     epi.DATEBILL BETWEEN TO_DATE (?, 'dd/MM/yyyy')
                                                AND   TO_DATE (?,
                                                               'dd/MM/yyyy')
                                                    + 1
                                                    - 0.00001
                               AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_BILL_REVENUE WHERE BILL = epi.BILL AND PAY_IN_ID = epi.PAY_IN_ID AND BILL_REVENUE_TYPE IN (%s))
            """;

            if (CollectionUtils.isNotEmpty(getPostIdTestList())) {
                sql = sql + """
                        AND POST_ID IN (%s)
                 """;
            }

            if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
                sql = sql + """
                        AND M_PRODUCT NOT IN (%s)
                 """;
            }

            sql = sql + """
                     ) a
             WHERE a.ROWSNUM BETWEEN ? AND ?
            """;

        List<Integer> billStatus = Arrays.asList(RevenueType.TEMPORARY_REVENUE.getValue(), RevenueType.COMPLETED_REVENUE2.getValue());
        String placeholder = IntStream.range(0, billStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));

        // DV
        String placeholderDv = IntStream.range(0, serviceCodeNoRevenue.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));

        List<Object> params = new ArrayList<>();
        params.add(startDate.format(dtf));
        params.add(endDate.format(dtf));
        params.addAll(billStatus);
        if (CollectionUtils.isNotEmpty(getPostIdTestList())) {
            String placeholderPost = IntStream.range(0, getPostIdTestList().size())
                .mapToObj(i -> "?")
                .collect(Collectors.joining(","));

            if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
                sql = sql.formatted(placeholder, placeholderPost, placeholderDv);
                params.addAll(getPostIdTestList());
                params.addAll(serviceCodeNoRevenue);
            }
            else {
                sql = sql.formatted(placeholder, placeholderPost);
                params.addAll(getPostIdTestList());
            }
        }
        else {
            sql = sql.formatted(placeholder);

            if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
                sql = sql.formatted(placeholder, placeholderDv);
                params.addAll(serviceCodeNoRevenue);
            }
            else {
                sql = sql.formatted(placeholder);
            }
        }
        params.add(size * page + 1);
        params.add((size * page + size));

        return executeMulti(oracleClient, sql, params, BillEvtpPayInDTO.class);
    }

    @Override
    public Uni<BigDecimal> findPeriodIdBy(LocalDate date) {
        String sql = """
                select ERP_AC.GET_PERIOD_ID(TO_DATE(?, 'dd/MM/yyyy')) as periodid from Dual
                """;

        List<Object> params = new ArrayList<>();
        params.add(date.format(dtf));
        return executeAndGetValue(oracleClient, sql, params, "periodid", BigDecimal.class);
    }

    @Override
    public Uni<ErpPeriodEntity> findPeriodBy(BigDecimal id) {
        String sql = """
                select PERIOD_ID, STARTDATE, ENDDATE from ERP_AC.ERP_PERIOD where PERIOD_ID = ? and ROWNUM = 1
                """;

        List<Object> params = new ArrayList<>();
        params.add(id);
        return execute(oracleClient, sql, params, ErpPeriodEntity.class);
    }

    @Override
    public Multi<RevenueServiceGroupEntity> findRevenueServiceGroupBy() {
        String sql = """
                select
                	service_code
                from
                	bms_payment.revenue_service_group rsg
                where
                	apply_status = $1
            """;
        return executeMulti(pgClient, sql, Tuple.of(1), RevenueServiceGroupEntity.class);
    }

    @Override
    public Uni<Boolean> saveBatchBmsBillRevenue(List<BmsBillRevenueEntity> entities, Connection sqlConnection) {
        String sqlInsert = """
            insert into ERP_AC.BMS_BILL_REVENUE (
               BILL_REVENUE_ID   ,
               CREATED           ,
               CREATEDBY         ,
               UPDATED           ,
               UPDATEDBY         ,
               ORG_ID            ,
               POST_ID           ,
               PAY_IN_ID         ,
               BILL              ,
               TYPE              ,
               BILL_ID           ,
               BILL_STATUS       ,
               DATEBILL          ,
               DATEINSERT        ,
               CUS_ID            ,
               PARTNER_EVTP      ,
               M_PRODUCT         ,
               CITY_FROM         ,
               CITY_TO           ,
               PAYMENTTEAM_ID    ,
               IS_PAID           ,
               WEIGHT            ,
               AMT               ,
               AMT_DEDUCT        ,
               AMT_DEDUCT_OTHER  ,
               FEE               ,
               FREIGHT           ,
               FEE_OTHER         ,
               AMT_VAT           ,
               AMT_PAY           ,
               IS_INVOICE        ,
               BILL_REVENUE_TYPE ,
               REVENUE_SOURCE    ,
               IS_SYNC,
               PERIOD_ID,
               VAT,
               COMPANY_CODE
            ) values
            (
            ERP_AC.BILL_REVENUE_ID_SEQ.NEXTVAL,
                                   SYSDATE,
                                   ?,
                                   SYSDATE,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?
            )
            """;

        return executeOnlyInsertOracleBatch(
            sqlConnection,
            sqlInsert,
            entities,
            batchSize,
            "billRevenueId", "created", "updated");
    }

    @Override
    public Multi<BmsBillJourneyEntity> findG2bVanDonBy() {

        String sql = """
                SELECT /*+ parallel(8)*/
                       ''
                           NOTE,
                       (SELECT MA_PHIEUGUI
                          FROM VTP.VC_PHIEUGUI
                         WHERE ID_PHIEUGUI = PBC.ID_PHIEUGUI AND ROWNUM = 1)
                           ORDER_NUMBER,
                       TO_NUMBER ('50' || TRANG_THAI)
                           ORDER_STATUS,
                       NULL
                           EMPLOYEE_ID,
                       NGAY_PHAT
                           JOURNEY_DATE
                  FROM VTP.PHAT_BUUGUI_CHITIET PBC
                 WHERE     PBC.NGAY_NM BETWEEN SYSDATE - 60 AND SYSDATE
                       AND PBC.TRANG_THAI IN (%s)
                       AND NOT EXISTS
                               (SELECT 1
                                  FROM ERP_AC.BMS_BILL_JOURNEY
                                 WHERE ORDER_NUMBER =
                                       (SELECT MA_PHIEUGUI
                                          FROM VTP.VC_PHIEUGUI
                                         WHERE ID_PHIEUGUI = PBC.ID_PHIEUGUI AND ROWNUM = 1))
                       AND ROWNUM < 100000
            """;

        String placeholder = IntStream.range(0, configDeliveryStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));

        sql = sql.formatted(placeholder);

        List<Object> params = new ArrayList<>();

        params.addAll(configDeliveryStatus);
        return executeMulti(oracleClient, sql, params, BmsBillJourneyEntity.class);
    }

    @Override
    public Uni<Boolean> saveBatchBmsBillJourney(List<BmsBillJourneyEntity> entities,
        Connection sqlConnection) {
        String sqlInsert = """
            insert into ERP_AC.BMS_BILL_JOURNEY (
                      BILL_JOURNEY_ID,
                      NOTE           ,
                      ORDER_NUMBER   ,
                      ORDER_STATUS   ,
                      POSTOFFICE_CODE,
                      EMPLOYEE_ID    ,
                      JOURNEY_DATE
            ) values
            (
            ERP_AC.BILL_JOURNEY_ID_SEQ.NEXTVAL,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?,
                                   ?
            )
            """;

        return executeOnlyInsertOracleBatch(
            oracleClient,
            sqlInsert,
            entities,
            batchSize,
            "billJourneyId");
    }

    @Override
    public Uni<Integer> findAllBillSucessCount(LocalDate startDate, LocalDate endDate) {
        String sql = """
                        SELECT COUNT (1)     AS total
                           FROM ERP_AC.EVTP_PAY_IN  epi
                                JOIN ERP_AC.BMS_BILL_JOURNEY BJ ON BJ.ORDER_NUMBER = epi.BILL
                          WHERE     BJ.JOURNEY_DATE BETWEEN TO_DATE (?, 'dd/MM/yyyy')
                                                        AND TO_DATE (?, 'dd/MM/yyyy') + 1 - 0.00001
                                AND epi.M_PRODUCT NOT IN ('VNB') 
                                AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_BILL_REVENUE WHERE BILL = epi.BILL AND PAY_IN_ID = epi.PAY_IN_ID AND BILL_REVENUE_TYPE IN (%s))
                """;

        List<Integer> billStatus = List.of(RevenueType.COMPLETED_REVENUE3.getValue());
        String placeholder = IntStream.range(0, billStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));
        sql = sql.formatted(placeholder);

        List<Object> params = new ArrayList<>();
        params.add(startDate.format(dtf));
        params.add(endDate.format(dtf));
        params.addAll(billStatus);
        if (CollectionUtils.isNotEmpty(getPostIdTestList())) {
            sql = sql + """
                    AND POST_ID IN (%s)
             """;
            String placeholderPost = IntStream.range(0, getPostIdTestList().size())
                .mapToObj(i -> "?")
                .collect(Collectors.joining(","));
            sql = sql.formatted(placeholderPost);
            params.addAll(getPostIdTestList());
        }
        return executeAndGetValue(oracleClient, sql, params, "total", Integer.class);
    }

    @Override
    public Multi<BillEvtpPayInDTO> findAllBillSucess(LocalDate startDate, LocalDate endDate,
        Integer page, Integer size) {
        String sql = """
            SELECT a.*
              FROM (SELECT ROW_NUMBER () OVER (ORDER BY epi.DATEBILL, epi.PAY_IN_ID)     ROWSNUM,
                           epi.PAY_IN_ID,
                           epi.BILL,
                           epi.BILL_ID,
                           BJ.ORDER_STATUS BILL_STATUS,
                           epi.TYPE,
                           epi.DATEBILL,
                           BJ.JOURNEY_DATE DATEINSERT,
                           epi.PERIOD_ID,
                           epi.ORG_ID,
                           epi.POST_ID,
                           epi.PARTNER_EVTP,
                           epi.PARTNER_ID,
                           epi.M_PRODUCT,
                           epi.PAYMENTTEAM_ID,
                           epi.IS_PAID,
                           epi.WEIGHT,
                           epi.AMT,
                           epi.AMT_INVOICE,
                           epi.AMT_DEDUCT,
                           epi.AMT_PAY,
                           epi.BILL_REF,
                           epi.AMT_DIFF,
                           epi.AMT_DEDUCT_OTHER,
                           epi.CITY_TO,
                           epi.CITY_FROM,
                           epi.DISTRICT_TO,
                           epi.DISTRICT_FROM,
                           epi.PARTNER_GROUP_ID,
                           epi.FREIGHT,
                           epi.FEE,
                           epi.FEE_OTHER,
                           dv.VAT,
                           CASE
                               WHEN dv.VAT > 0 THEN
                               (epi.AMT - NVL(ROUND(epi.AMT/(1 + dv.VAT/100)), 0))
                               ELSE 0
                           END AMT_VAT,
                           nvl((SELECT COMPANY_CODE FROM ERP_AC.FICO_SAP_POST_CODE_CENTER WHERE POST_ID = epi.POST_ID AND ROWNUM = 1), '1000') COMPANY_CODE
                      FROM ERP_AC.EVTP_PAY_IN epi
                      JOIN ERP_AC.BMS_BILL_JOURNEY BJ ON BJ.ORDER_NUMBER = epi.BILL
                      LEFT JOIN VTP.BG_DICHVU dv ON MA_DICHVU = epi.M_PRODUCT AND dv.SU_DUNG = 1
                     WHERE     BJ.JOURNEY_DATE BETWEEN TO_DATE (?, 'dd/MM/yyyy')
                                                AND   TO_DATE (?,
                                                               'dd/MM/yyyy')
                                                    + 1
                                                    - 0.00001 
                           AND epi.M_PRODUCT NOT IN ('VNB')                         
                           AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_BILL_REVENUE WHERE BILL = epi.BILL AND PAY_IN_ID = epi.PAY_IN_ID AND BILL_REVENUE_TYPE IN (%s))
               """;

            if (CollectionUtils.isNotEmpty(getPostIdTestList())) {
                sql = sql + """
                            AND POST_ID IN (%s)
                     """;
            }

            if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
                sql = sql + """
                            AND M_PRODUCT NOT IN (%s)
                     """;
            }

            sql = sql + """
                         ) a
                 WHERE a.ROWSNUM BETWEEN ? AND ?
                """;

        List<Integer> billStatus = List.of(RevenueType.COMPLETED_REVENUE3.getValue());
        String placeholder = IntStream.range(0, billStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));

        // DV
        String placeholderDv = IntStream.range(0, serviceCodeNoRevenue.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));

        List<Object> params = new ArrayList<>();
        params.add(startDate.format(dtf));
        params.add(endDate.format(dtf));
        params.addAll(billStatus);
        if (CollectionUtils.isNotEmpty(getPostIdTestList())) {
            String placeholderPost = IntStream.range(0, getPostIdTestList().size())
                .mapToObj(i -> "?")
                .collect(Collectors.joining(","));

            if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
                sql = sql.formatted(placeholder, placeholderPost, placeholderDv);
                params.addAll(getPostIdTestList());
                params.addAll(serviceCodeNoRevenue);
            }
            else {
                sql = sql.formatted(placeholder, placeholderPost);
                params.addAll(getPostIdTestList());
            }
        }
        else {
            sql = sql.formatted(placeholder);

            if (CollectionUtils.isNotEmpty(serviceCodeNoRevenue)) {
                sql = sql.formatted(placeholder, placeholderDv);
                params.addAll(serviceCodeNoRevenue);
            }
            else {
                sql = sql.formatted(placeholder);
            }
        }
        params.add(size * page + 1);
        params.add((size * page + size));

        return executeMulti(oracleClient, sql, params, BillEvtpPayInDTO.class);
    }

    @Override
    public Multi<AcctRawDataDTO> findListRawDataByListRefNumber(Set<String> refNumberList, Set<String> refNumberParentList, Long businessId) {

        String sql = """
                select ref_number, ref_number_parent
                from bms_payment.accounting_synthetic
                where ref_number = any($1) and ref_number_parent = any($2) and business_id = $3
                """;

        return executeMulti(pgClient, sql, Tuple.of(refNumberList.toArray(), refNumberParentList.toArray(), businessId),  AcctRawDataDTO.class);
    }

    @Override
    public Uni<Integer> findBillRevenueCount(BigDecimal periodId, RevenueType revenueType) {
        String sql = """
                        SELECT COUNT(1) AS total
                        FROM ERP_AC.BMS_BILL_REVENUE
                       WHERE PERIOD_ID = ? AND BILL_REVENUE_TYPE = ? AND IS_SYNC IN (-1,0)
                    """;

        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(revenueType.getValue());
        return executeAndGetValue(oracleClient, sql, params, "total", Integer.class);
    }

    @Override
    public Multi<BmsBillRevenueDTO> findBillRevenueBy(BigDecimal periodId,
        RevenueType revenueType,
        Integer page, Integer size) {
        String sql = """
            SELECT a.*
              FROM (
                    SELECT ROW_NUMBER () OVER (ORDER BY BBR.BILL_REVENUE_ID) ROWSNUM,
                          BBR.*,
                          ROUND(BBR.AMT - BBR.AMT_VAT) AMT_BEFORE_TAX,
                          ERP_AC.GET_ORGCODE(BBR.POST_ID) ORG_CODE,
                          ERP_AC.GET_ORGNAME(BBR.POST_ID) ORG_NAME,
                          ERP_AC.GET_POSTCODE (BBR.POST_ID) POST_CODE,
                          ERP_AC.GET_POSTNAME(BBR.POST_ID) POST_NAME,
                          EP.EMAIL,
                          EP.PHONE,
                          EP.FULLNAME,
                          EP.ADDRESS,
                          EP.TAXID,
                          (SELECT NVL (IDENTIFIERNUMBER, NULL)     AS IDENTIFIERNUMBER
                             FROM ERP_CUS.CUS_CUSTOMER_CODE a, ERP_AC.FICO_ECONTRACT b
                            WHERE     a.CUS_ID = b.CUS_ID
                                  AND a.EVTPCODE = BBR.PARTNER_EVTP
                                  AND IDENTIFIERNUMBER IS NOT NULL
                                  AND ROWNUM = 1)
                          IDENTIFIERNUMBER,
                          CASE
                              WHEN BBR.AMT < 0 THEN
                              (SELECT DATEBILL from ERP_AC.EVTP_PAY_IN where BILL = BBR.BILL AND TYPE = 0)
                              ELSE NULL
                          END ORG_DATEBILL 
                    FROM ERP_AC.BMS_BILL_REVENUE BBR
                    LEFT JOIN (
                      SELECT *
                      FROM (
                          SELECT ROW_NUMBER() OVER (PARTITION BY VALUE ORDER BY UPDATED DESC, EPP.PARTNER_ID DESC) AS rn,
                                 EPP.PARTNER_ID,
                                 EPP.VALUE,
                                 EPP.EMAIL,
                                 EPP.PHONE,
                                 EPP.FULLNAME,
                                 EPP.DESCRIPTION ADDRESS,
                                 EPP.TAXID
                          FROM ERP_AC.ERP_PARTNER EPP
                      ) t
                      WHERE rn = 1
                  ) EP ON EP.VALUE = BBR.PARTNER_EVTP
                  WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE = ? AND IS_SYNC IN (-1,0)
                 ) a
             WHERE a.ROWSNUM BETWEEN ? AND ?
            """;

        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(revenueType.getValue());
        params.add(size * page + 1);
        params.add((size * page + size));

        return executeMulti(oracleClient, sql, params, BmsBillRevenueDTO.class);
    }

    @Override
    public Uni<Boolean> updateStatusBillRevenueBy(List<BigDecimal> listIds, Integer status) {
        String sqlUpdateStatus = """
                            update ERP_AC.BMS_BILL_REVENUE
                            set
                            IS_SYNC = ?
                            where
                                (BILL_REVENUE_ID, 0) in (%s)
                            """;
        String placeholder = OracleUtils.genConditionInBigSize(listIds.size());
        sqlUpdateStatus = sqlUpdateStatus.formatted(placeholder, placeholder);

        List<Object> params = new ArrayList<>();
        params.add(status);
        params.addAll(listIds);
        return executeOnly(oracleClient, sqlUpdateStatus, params);
    }

    @Override
    public Multi<BmsServiceCategoryMappingEntity> findAllServiceCategoryMapping() {

        String sql = """
            SELECT SERVICE_CODE, PRODUCT_CATEGORY
                                              FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING
            """;


        List<Object> params = new ArrayList<>();

        return executeMulti(oracleClient, sql, params, BmsServiceCategoryMappingEntity.class);
    }

    @Override
    public Multi<BgDichvuEntity> findAllBgDichVu() {
        String sql = """
                SELECT MA_DICHVU, VAT
                 FROM VTP.BG_DICHVU
                WHERE SU_DUNG = 1
            """;

        List<Object> params = new ArrayList<>();
        return executeMulti(oracleClient, sql, params, BgDichvuEntity.class);
    }

    @Override
    public Uni<ErpPeriodEntity> findPeriodBy(LocalDate date) {
        String sql = """
                        SELECT PERIOD_ID, STARTDATE, ENDDATE
                         FROM ERP_AC.ERP_PERIOD
                        WHERE     PERIOD_ID IN
                                      ERP_AC.GET_PERIOD_ID (TO_DATE (?, 'dd/MM/yyyy'))
                              AND ROWNUM = 1
                """;

        List<Object> params = new ArrayList<>();
        params.add(date.format(dtf));
        return execute(oracleClient, sql, params,  ErpPeriodEntity.class);
    }
}
