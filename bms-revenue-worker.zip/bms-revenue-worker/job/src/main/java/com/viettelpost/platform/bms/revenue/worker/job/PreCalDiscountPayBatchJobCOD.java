//package com.viettelpost.platform.bms.revenue.worker.job;
//
//import com.viettelpost.platform.bms.revenue.worker.service.CalculationRevenueService;
//import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
//import com.viettelpost.platform.root.common.quarkus.job.JobAbs;
//import io.quarkus.scheduler.Scheduled;
//import io.smallrye.mutiny.Uni;
//import jakarta.enterprise.context.ApplicationScoped;
//import jakarta.inject.Inject;
//import jakarta.inject.Named;
//import lombok.extern.slf4j.Slf4j;
//import org.eclipse.microprofile.config.inject.ConfigProperty;
//import reactor.core.publisher.Mono;
//
//@Slf4j
//@ApplicationScoped
//@Named("PreCalDiscountPayBatchJobCOD")
//public class PreCalDiscountPayBatchJobCOD extends JobAbs<Void> {
//
//    @ConfigProperty(name = "job.cron.preCalDiscountPayBatchCod", defaultValue = "0 23 * * * ?")
//    String jobCron;
//
//    @Inject
//    CalculationRevenueService calculationRevenueService;
//
//    @Scheduled(cron = "${job.cron.preCalDiscountPayBatchCod:0 23 * * * ?}")
//    public Uni<Void> preCalDiscountPayBatchCod() {
//        return ReactiveConverter.toUni(super.executeTask("preCalDiscountPayBatchCod", jobCron));
//    }
//
//    @Override
//    protected Mono<Void> taskAction() {
//        log.info("[PreCalDiscountPayBatchCod] job started");
//        long currentTime = System.currentTimeMillis();
//        return ReactiveConverter.toMono(calculationRevenueService.calculationAllBillToRevenue())
//                .doFinally(s -> log.info("PreCalDiscountPayBatchCod_finished_time: {}", System.currentTimeMillis() - currentTime));
//    }
//}
