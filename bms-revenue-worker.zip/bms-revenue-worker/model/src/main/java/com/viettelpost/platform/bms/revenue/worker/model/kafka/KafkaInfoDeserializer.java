package com.viettelpost.platform.bms.revenue.worker.model.kafka;

import io.quarkus.kafka.client.serialization.ObjectMapperDeserializer;

public class KafkaInfoDeserializer extends ObjectMapperDeserializer<Object> {

    public KafkaInfoDeserializer() {
        super(Object.class);
    }

    @Override
    public Object deserialize(String topic, byte[] data) {
        try {
            // Attempt to deserialize the Kafka message
            return super.deserialize(topic, data);
        } catch (Exception e) {
            // Catch any other exceptions that might occur
            return new Object();
        }
    }
}
