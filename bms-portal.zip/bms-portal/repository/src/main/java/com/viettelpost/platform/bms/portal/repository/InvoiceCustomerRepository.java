package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.response.InvoiceCustomerDetailResponse;
import com.viettelpost.platform.bms.portal.model.response.InvoiceCustomerResponse;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import io.smallrye.mutiny.Uni;

public interface InvoiceCustomerRepository {

    Uni<PageResponse<InvoiceCustomerResponse>> getAll(String customerCode, String customerPhone, String customerTax, int page, int size);

    Uni<InvoiceCustomerDetailResponse> getInvoiceCustomerDetailById(Long invoiceCustomerId);

}
