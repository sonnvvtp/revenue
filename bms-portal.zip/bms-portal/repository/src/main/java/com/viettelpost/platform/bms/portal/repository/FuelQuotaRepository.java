package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.BudgetReductionDTO;
import com.viettelpost.platform.bms.portal.model.dto.FuelQuotaDTO;
import com.viettelpost.platform.bms.portal.model.response.FuelQuotaResponse;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.util.List;
import reactor.core.publisher.Mono;

public interface FuelQuotaRepository {

    Uni<List<FuelQuotaResponse>> searchFuelQuotas(
            String carLicensePlate, String synthesisPeriod, String unit, int pageNo, int pageSize);

    Uni<Long> countFuelQuotas(String carLicensePlate, String synthesisPeriod, String unit);

    Uni<String> showNewestMonthFuelQuota();

    Uni<FuelQuotaResponse> getFuelQuotaByCarLicensePlateAndSynthesisPeriod(String carLicensePlate,
            String synthesisPeriod);

    Uni<List<String>> showListMonth();

    Mono<Integer> create(List<FuelQuotaDTO> list, SqlConnection sqlConnection);


    Mono<Integer> update(List<FuelQuotaDTO> updateItems, SqlConnection sqlConnection);


    Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection sqlConnection);
}
