package com.viettelpost.platform.bms.revenue.worker.common.enums;

import java.util.Arrays;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RevenueAccountingType {
    DTNB(1, "DTNB",  "Doanh thu nội bộ"),
    DTCHT(2, "DTCHT",  "Doanh thu chưa hoàn thành"),
    DTCKCHT(3, "DTCKCHT",  "Doanh thu chiết khấu chưa hoàn thành"),
    DTHT_KTTC(4, "DTHT_KTTC",  "Doanh thu hoàn thành - loại ko có trạng thái cuối"),
    DTHT_CTTC(5, "DTHT_CTTC",  "Doanh thu hoàn thành - có trạng thái cuối"),
    DTCKHT_KTTC(6, "DTCKHT_KTTC",  "Doanh thu chiết khấu hoàn thành  - loại ko có trạng thái cuối"),
    DTCKHT_CTTC(7, "DTCKHT_CTTC",  "Doanh thu chiết khấu hoàn thành  - có trạng thái cuối"),
    DTGTBS(8, "DTGTBS",  "Doanh thu giảm trừ bổ sung");

    private Integer id;
    private String code;
    private String name;

    public static RevenueAccountingType getId(String code) {
        return Arrays.stream(RevenueAccountingType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(null);
    }

    public static RevenueAccountingType getCode(Integer id) {
        return Arrays.stream(RevenueAccountingType.values())
                .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(null);
    }
}
