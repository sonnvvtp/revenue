package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

@Data
public class GroupCustomeCodeDTO {

    @JsonAlias("unit_level2_id")
    private Long unitLevel2Id;
    @JsonAlias("buyer_code")
    private String buyerCode;
    @JsonAlias("record_source")
    private String recordSource;
}
