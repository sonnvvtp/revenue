package com.viettelpost.platform.bms.revenue.worker.model.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecordDto {
    private BigDecimal id;
    private String code;
    private BigDecimal amount;
    private String company;
    private String postCode;
    private String postName;
    private String orgCode;
    private String orgName;
    private LocalDateTime revenueEntryAt;
}
