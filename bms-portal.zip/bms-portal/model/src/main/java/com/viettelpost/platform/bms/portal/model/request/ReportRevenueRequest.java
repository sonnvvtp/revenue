package com.viettelpost.platform.bms.portal.model.request;

import com.viettelpost.platform.bms.portal.model.enums.ReportDebtType;
import com.viettelpost.platform.bms.portal.model.enums.ReportRevenueType;
import com.viettelpost.platform.bms.portal.model.enums.ReportShowType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReportRevenueRequest {
    @NotNull
    ReportRevenueType reportRevenueType;
    @NotNull
    ReportDebtType reportDebtType;
    @NotNull
    ReportShowType reportShowType;
    @NotNull
    Long periodId;
}
