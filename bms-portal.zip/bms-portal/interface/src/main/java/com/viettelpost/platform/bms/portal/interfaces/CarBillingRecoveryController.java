package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.request.CarBillingRecoveryFilter;
import com.viettelpost.platform.bms.portal.service.handler.CarBillingRecoveryService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.ByteArrayInputStream;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/car-billing-recovery")
@Tag(name = "Car Billing Recovery")
@RequiredArgsConstructor
public class CarBillingRecoveryController {

    private final CarBillingRecoveryService carBillingRecoveryService;

    @POST
    @Operation(summary = "Search Car Bill")
    @APIResponse(responseCode = "200", description = "Returns a list of car bills")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Map<String, Object>> searchCarBills(CarBillingRecoveryFilter filter){

        return carBillingRecoveryService.searchCarBills(
                filter.getCarLicensePlate(),
                filter.getSynthesisPeriod(),
                filter.getReceiptNumberLv3(),
                filter.getUnit(),
                filter.getPageNo(),
                filter.getPageSize(),
                filter.getType(),
                filter.getStatus());
    }

    @GET
    @Operation(summary = "Get Car Bills belong to Unit")
    @Path("/from-unit")
    @APIResponse(responseCode = "200", description = "Returns Car Bills belong to Unit")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Map<String, Object>> getCarBillsOfUnit(
            @QueryParam("unit") String unit,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("pageNo") int pageNo,
            @QueryParam("pageSize") int pageSize) {

        return carBillingRecoveryService.getCarBillsOfUnit(unit, synthesisPeriod, pageNo, pageSize);
    }

    @GET
    @Path("/export-to-excel")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON})
    @Operation(summary = "Export Fuel Billing Recovery to Excel")
    @APIResponse(responseCode = "200", description = "Returns an Excel file containing Fuel Billing Recovery")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportToExcel(
            @QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("unit") String unit,
            @QueryParam("type") int type
    ) {
        return carBillingRecoveryService.exportToExcel(carLicensePlate, synthesisPeriod, unit, type)
                .onItem().transform(excelData -> {
                    String fileName = carBillingRecoveryService.generateFileName(
                            "Fuel_Billing_Recovery.xlsx");
                    return Response.ok(new ByteArrayInputStream(excelData))
                            .header("Content-Disposition",
                                    "attachment; filename=\"" + fileName + "\"")
                            .build();
                })
                .onFailure().recoverWithItem(throwable ->
                        Response.serverError().entity("Failed to generate Excel file").build()
                );
    }

    @GET
    @Path("/export-to-pdf")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response carBillingRecoveryPdf(
            @QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("unit") String unit,
            @QueryParam("type") int type
    ) {
        try {
            byte[] pdfData = carBillingRecoveryService.carBillingRecoveryToPDF(carLicensePlate,
                    synthesisPeriod, unit, type);
            return Response.ok(pdfData)
                    .header("Content-Disposition",
                            "attachment; filename=\"car_billing_recovery_report.pdf\"")
                    .build();
        } catch (Exception e) {
            log.error("Failed to generate PDF", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to generate PDF: " + e.getMessage())
                    .build();
        }
    }
}
