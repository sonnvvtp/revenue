package com.viettelpost.platform.bms.revenue.worker.service.impl;

import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.common.utils.DateUtils;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BillEvtpPayInDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RevenueStatementSapDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BgDichvuEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsServiceCategoryMappingEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueServiceGroupEntity;
import com.viettelpost.platform.bms.revenue.worker.model.request.ItemOrderDTO;
import com.viettelpost.platform.bms.revenue.worker.model.request.general.GeneralOrderRequest;
import com.viettelpost.platform.bms.revenue.worker.model.response.RevenuePushResponse;
import com.viettelpost.platform.bms.revenue.worker.repository.CalculationRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.repository.GloExpRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.service.GloExpRevenueService;
import com.viettelpost.platform.bms.revenue.worker.service.PushingRevenueSapService;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.Json;
import io.vertx.mutiny.ext.web.client.WebClient;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class GloExpRevenueServiceImpl implements GloExpRevenueService {

    private final CalculationRevenueRepository calculationRevenueRepository;

    private final GloExpRevenueRepository gloExpRevenueRepository;

    private final PushingRevenueSapService pushingRevenueSapService;

    @ConfigProperty(name = "job.calculation.discount.batch.handle.size", defaultValue = "1000")
    Integer batchBillHandleSize;

    private final WebClient webClient;

    @ConfigProperty(name = "revenue.push.order.data.url")
    String revenuePushUrl;

    @ConfigProperty(name = "revenue.client-id")
    String revenueClientId;

    @ConfigProperty(name = "revenue.secret-key")
    String revenueClientKey;

    @ConfigProperty(name = "revenue.config.partner", defaultValue = "REVENUE_VTP")
    String revenueConfigPartner;

    @ConfigProperty(name = "revenue.request.type", defaultValue = "1")
    List<Integer> revenueRequestType;

    @Override
    public Uni<Void> pusAllBillToRevenue() {
        long currentTime = System.currentTimeMillis();
        // Lấy ngày hiện tại
        LocalDate today = LocalDate.now().minusMonths(1);

        // Lấy ngày bắt đầu của tháng hiện tại (ngày 1)
        LocalDate startOfMonth = today.with(TemporalAdjusters.firstDayOfMonth());

        // Lấy ngày kết thúc của tháng hiện tại
        LocalDate endOfMonth = today.with(TemporalAdjusters.lastDayOfMonth());

        Uni<BigDecimal> periodUni = calculationRevenueRepository.findPeriodIdBy(startOfMonth);

        Uni<Integer> countUni = calculationRevenueRepository.findAllEvtpPayInCount(startOfMonth, endOfMonth);

        Multi<RevenueServiceGroupEntity> revenueServiceGroupMulti = calculationRevenueRepository.findRevenueServiceGroupBy();
        AtomicReference<BigDecimal> periodIdFinal = new AtomicReference<>();
        return Uni.combine().all().unis(periodUni, countUni, revenueServiceGroupMulti.collect().asList())
            .withUni((periodId, totalItems, revenueServiceGroupEntities) -> {
                log.info("calculationAllBillToRevenue_size: {}, startOfMonth: {}, endOfMonth: {}",  totalItems,  startOfMonth, endOfMonth);
                int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
                List<Multi<BillEvtpPayInDTO>> multiList = new ArrayList<>();
                periodIdFinal.set(periodId);
                Map<String, String> serviceMap = revenueServiceGroupEntities.stream()
                    .collect(Collectors.toMap(
                        RevenueServiceGroupEntity::getServiceCode,
                        RevenueServiceGroupEntity::getServiceCode,
                        (oldValue, newValue) -> oldValue // nếu trùng thì giữ lại giá trị cũ
                    ));

                for (int i = 0; i < maxPage; i++) {
                    multiList.add(
                        calculationRevenueRepository.findAllEvtpPayIn(startOfMonth, endOfMonth, i, batchBillHandleSize));
                }

                Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

                for (Multi<BillEvtpPayInDTO> multi : multiList) {
                    uniChainProcess = uniChainProcess.chain(() ->
                            multi.collect().asList()
                            .flatMap(listBill -> processSaveBatch(listBill, serviceMap, periodId)))
                        .onFailure()
                        .recoverWithUni((throwable) -> {
                            log.error("saveBatch_fail: {}", throwable.getMessage(), throwable);
                            return Uni.createFrom().voidItem();
                        });
                }
                return uniChainProcess;
            })
            .onFailure()
            .recoverWithUni(throwable -> {
                log.info("calculationAllBillToRevenue_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
                return Uni.createFrom().voidItem();
            });
    }

    private Uni<Void> processSaveBatch(List<BillEvtpPayInDTO> listBill, Map<String, String> serviceMap, BigDecimal periodId) {

      Uni<Void> uniChain = Uni.createFrom().voidItem();

      for (BillEvtpPayInDTO billEvtpPayIn : listBill) {
        uniChain = uniChain.chain(() -> pushRevenueData(mapToGeneralOrderRequest(billEvtpPayIn, serviceMap)))
            .onFailure()
            .recoverWithUni((throwable) -> {
              log.error("saveBatch_fail: {}", throwable.getMessage(), throwable);
              return Uni.createFrom().voidItem();
            });
      }
      return uniChain;
    }

    private Uni<Void> pushRevenueData(GeneralOrderRequest generalOrderRequest) {

      log.info("Request push raw data accounting: {}", Json.encode(generalOrderRequest));
      return webClient.postAbs(revenuePushUrl)
          .putHeader("Content-Type", "application/json")
          .putHeader("client-id", revenueClientId)
          .putHeader("secret-key", revenueClientKey)
          .sendJson(generalOrderRequest)
          .flatMap(bufferHttpResponse -> {
            if (bufferHttpResponse.statusCode() != HttpStatus.SC_OK) {
              return Uni.createFrom().failure(new RuntimeException("Push raw data failed with response: " + bufferHttpResponse.bodyAsString()));
            }
            log.info("Response from accounting server: {}", bufferHttpResponse.bodyAsString());
            RevenuePushResponse response = bufferHttpResponse.bodyAsJsonObject().mapTo(RevenuePushResponse.class);
            if (bufferHttpResponse.statusCode() != 200) {
              return Uni.createFrom().failure(new RuntimeException("Response status code from accounting server is not 200"));
            }
            if (Objects.isNull(response)) {
              return Uni.createFrom().failure(new RuntimeException("Response from accounting server is null"));
            }
            if (!response.getError()) {
              return Uni.createFrom().failure(new RuntimeException("Response from accounting server is error, message: " + response.getMessage()));
            }
            return Uni.createFrom().voidItem();
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("pushRevenueData_error : {}", throwable.getMessage(), throwable);
          });
    }

    private GeneralOrderRequest mapToGeneralOrderRequest(BillEvtpPayInDTO billEvtpPay, Map<String, String> serviceMap) {
      int recordType = 0;
      if (Objects.nonNull(serviceMap.get(billEvtpPay.getMProduct()))) {
        recordType = RevenueType.TEMPORARY_REVENUE.getValue(); // 4: Có trạng thái cuối
      }
      else {
        recordType = RevenueType.COMPLETED_REVENUE2.getValue(); // 5: Không có trạng thái cuối
      }

      ItemOrderDTO itemOrderDTO = ItemOrderDTO.builder()
          .orderId(null)
          .departureLocation(null)
          .arrivalLocation(null)
          .vehiclePlateNumber(null)
          .warehouseCode(null)
          .itemSelection(1)
          .itemCode(billEvtpPay.getBill())
          .itemName(billEvtpPay.getBill())
          .itemNote(null)
          .itemUnit("bill")
          .itemQuantity(1L)
          .itemPrice(billEvtpPay.getAmt())
          .itemWeight(billEvtpPay.getWeight())
          .itemAmountBeforeTax(billEvtpPay.getFreight())
          .itemTaxType(1)
          .itemTaxPercent(billEvtpPay.getTaxPercent())
          .itemTaxAmount(billEvtpPay.getAmtVat())
          .itemAmountAfterTax(billEvtpPay.getAmt())
          .attribute1(null)
          .attribute2(null)
          .attribute3(null)
          .build();

      return GeneralOrderRequest.builder()
          .orderId(billEvtpPay.getBill())
          .orderCode(billEvtpPay.getBill())
          .orderReference(null)
          .cashflowType("INCOME")
          .serviceCode(billEvtpPay.getMProduct())
          .orderCreatedAt(billEvtpPay.getDateBill())
          .orderDeliveredAt(billEvtpPay.getDateInsert())
          .employeeId(null)
          .employeeInfo(null)
          .unitLevel1Id(billEvtpPay.getOrgId())
          .unitLevel2Id(billEvtpPay.getPostId())
          .unitInfo(null)
          .companyCode("1000")
          .sellerId(null)
          .sellerCode(null)
          .sellerInfo(null)
          .buyerId(null)
          .buyerCode(null)
          .buyerInfo(null)
          .consigneeId(null)
          .consignee(null)
          .orderTotalQuantity(1L)
          .orderAmountBeforeTax(billEvtpPay.getFreight())
          .orderTaxAmount(billEvtpPay.getAmt())
          .orderAmountAfterTax(billEvtpPay.getAmt())
          .totalAmount(null)
          .paymentInfo(null)
          .paymentMethod(null)
          .paymentTermId(billEvtpPay.getPaymentTeamId())
          .invoicePartner(null)
          .currency("VND")
          .invoiceInfo(null)
          .itemOrderList(Collections.singletonList(itemOrderDTO))
          .recordType(recordType)
          .orderSource(revenueConfigPartner)
          .requestType(null)
          .domainType(revenueConfigPartner)
          .picType(1)
          .tenantId(1)
          .build();
    }

    @Override
    public Uni<Void> pusRevenueToAccountingSap() {
      long currentTime = System.currentTimeMillis();
      return gloExpRevenueRepository.findRevenuePeriodControlBy("P")
          .collect().asList()
          .flatMap(periods -> {
            log.info("revenue_periods_size: {}", periods.size());
            if (periods.isEmpty()) {
              log.info("revenue_periods_is_empty");
              return Uni.createFrom().voidItem();
            }
            return pushAccountingRevenueBy(RevenueType.TEMPORARY_REVENUE)
                .flatMap(unused -> pushAccountingRevenueBy(RevenueType.COMPLETED_REVENUE2))
                .flatMap(unused -> pushAccountingRevenueBy(RevenueType.COMPLETED_REVENUE3))
                .onFailure()
                .invoke(throwable -> {
                  log.error("pusRevenueToAccountingSap_fail: {}", throwable.getMessage(), throwable);
                });
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("pusRevenueToAccountingSap_executed: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }

    @Override
    public Uni<Void> accountingUnfinishedRevenue() {
      return pushAccountingRevenueBy(RevenueType.TEMPORARY_REVENUE);
    }

    @Override
    public Uni<Void> accountingCompletedRevenueNoEnding() {
      return pushAccountingRevenueBy(RevenueType.COMPLETED_REVENUE2);
    }

    @Override
    public Uni<Void> accountingCompletedRevenueWithEnding() {
      return pushAccountingRevenueBy(RevenueType.COMPLETED_REVENUE3);
    }

//    @Override
//    public Uni<Void> accountingInternalRevenue() {
//      return pushAccountingRevenueBy(RevenueAccountingType.DTNB);
//    }
//    @Override
//    public Uni<Void> accountingUnfinishedDiscountRevenue() {
//      return pushAccountingRevenueBy(RevenueAccountingType.DTCKCHT);
//    }
//
//    @Override
//    public Uni<Void> accountingCompletedDiscountRevenueNoEnding() {
//      return pushAccountingRevenueBy(RevenueAccountingType.DTCKHT_KTTC);
//    }
//
//    @Override
//    public Uni<Void> accountingCompletedDiscountRevenueWithEnding() {
//      return pushAccountingRevenueBy(RevenueAccountingType.DTCKHT_CTTC);
//    }

    public Uni<Void> pushAccountingRevenueBy(RevenueType revenueType) {
      long currentTime = System.currentTimeMillis();
      return gloExpRevenueRepository.findRevenuePeriodControlBy("P")
          .collect().asList()
          .flatMap(periods -> {
            log.info("revenue_periods_size: {}", periods.size());
            if (periods.isEmpty()) {
              log.info("revenue_periods_is_empty");
              return Uni.createFrom().voidItem();
            }
            RevenuePeriodControlEntity revenuePeriod = periods.getFirst();
            LocalDate endOfMonth = DateUtils.getLocalDateBy(revenuePeriod.getEndDate());
            return processPushAcctToSap(revenuePeriod.getPeriodId(), revenueType, endOfMonth)
                .flatMap(unuse -> {  // chot ky doanh thu
                  return gloExpRevenueRepository.updateRevenuePeriodControl(revenuePeriod.getPeriodId(), "P", null, null, null)
                      .flatMap(unused -> {
                        log.info("updateRevenuePeriodControl: {}", unused);
                        return Uni.createFrom().voidItem();
                      })
                      .onFailure()
                      .invoke(throwable -> {
                        log.error("updateRevenuePeriodControl_fail: {}", throwable.getMessage(), throwable);
                      });
                })
                .onFailure()
                .invoke(throwable -> {
                  log.error("findPeriodIdBy_error: {}", throwable.getMessage(), throwable);
                });
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("processRevenueEveryMonth_executed: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }

    private Uni<Void> processPushAcctToSap(BigDecimal periodId, RevenueType revenueType, LocalDate endOfMonth) {
      long currentTime = System.currentTimeMillis();

      Uni<Integer> countUni = gloExpRevenueRepository.findAllRevenueStatementCount(periodId, revenueType, null);

      Multi<BmsServiceCategoryMappingEntity> serviceCategoryMappingMulti = calculationRevenueRepository.findAllServiceCategoryMapping();

      Multi<BgDichvuEntity> bgDichvuMulti = calculationRevenueRepository.findAllBgDichVu();

      return Uni.combine().all().unis(countUni, serviceCategoryMappingMulti.collect().asList(), bgDichvuMulti.collect().asList())
          .withUni((totalItems, revenueServiceGroupEntities, bgDichvuList) -> {
            log.info("findAllRevenueStatement_size: {}, periodId: {}",  totalItems, periodId);
            log.info("findAllServiceCategoryMapping_size: {}, periodId: {}",  revenueServiceGroupEntities.size(), periodId);

            Map<String, String> serviceMap = revenueServiceGroupEntities.stream()
                .collect(Collectors.toMap(
                    BmsServiceCategoryMappingEntity::getServiceCode,
                    BmsServiceCategoryMappingEntity::getProductCategory,
                    (oldValue, newValue) -> oldValue // nếu trùng thì giữ lại giá trị cũ
                ));

            Map<String, Integer> dichVuMap = bgDichvuList.stream()
                .collect(Collectors.toMap(
                    BgDichvuEntity::getMaDichVu,
                    BgDichvuEntity::getVat,
                    (oldValue, newValue) -> oldValue // nếu trùng thì giữ lại giá trị cũ
                ));

            int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
            List<Multi<RevenueStatementSapDTO>> multiList = new ArrayList<>();

            for (int i = 0; i < maxPage; i++) {
              multiList.add(gloExpRevenueRepository.findAllRevenueStatementBy(periodId, revenueType, i, batchBillHandleSize, null));
            }

            Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

            for (Multi<RevenueStatementSapDTO> multi : multiList) {
              uniChainProcess = uniChainProcess.chain(() ->
                      multi.collect().asList()
                          .flatMap(listBill -> pushingRevenueSapService.handlePushRawData(listBill, revenueType, null, serviceMap, dichVuMap, endOfMonth)))
                  .onFailure()
                  .recoverWithUni((throwable) -> {
                    log.error("handlePushRawData_sap_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().voidItem();
                  });
              }
              return uniChainProcess;
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("calculationAllBillToRevenue_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }
}
