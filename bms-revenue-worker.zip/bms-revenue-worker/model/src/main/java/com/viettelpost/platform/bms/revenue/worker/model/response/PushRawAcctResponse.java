package com.viettelpost.platform.bms.revenue.worker.model.response;

import java.util.List;
import lombok.Data;

@Data
public class PushRawAcctResponse {
    private int httpStatusCode;
    private String errorCode;
    private String detail;
    private List<Object> data;
}
