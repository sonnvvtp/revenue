package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceCustomerService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice-customer")
@Tag(name = "API quản lý khách hàng (xuất hóa đơn)")
@RequiredArgsConstructor
@Slf4j
public class InvoiceCustomerController {

    private final InvoiceCustomerService invoiceCustomerService;

    @GET
    @Path("/search")
    @Operation(summary = "Lấy thông tin khách hàng")
    public Uni<Response> search(
            @QueryParam("customerCode") String customerCode,
            @QueryParam("customerPhone") String customerPhone,
            @QueryParam("customerTax") String customerTax,
            @QueryParam("page") @DefaultValue("1") int page,
            @QueryParam("size") @DefaultValue("10") int size
    ) {
        return invoiceCustomerService.getAll(customerCode, customerPhone, customerTax, page, size)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Path("/{id}")
    @Operation(summary = "Lấy thông tin khách hàng")
    public Uni<Response> getInvoiceCustomerDetail(
            @PathParam("id") Long id
    ) {
        return invoiceCustomerService.getInvoiceCustomerDetailById(id)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }
}
