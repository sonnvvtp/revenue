package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BudgetDocumentSap {

    GHI_GIAM_NGAN_SACH_LOI(0, "Ghi giảm ngân sách lỗi"),
    GHI_GIAM_NGAN_SACH_THANH_CONG(1, "Ghi giảm ngân sách thành công");

    private final Integer code;
    private final String description;

    public static Integer fromStatus(BudgetDocumentSap status) {
        return status.getCode();
    }
}
