package com.viettelpost.platform.bms.revenue.worker.common.enums;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RevenueRecordStatus {
    SYNC_FAIL(-1, "Chưa gom bảng kê"),
    CHUA_GOM_BK(0, "Chưa gom bảng kê"),
    DONG_BO_THANH_CONG(1, "Đồng bộ thành công"),
    DONG_BO_THAT_BAI(2, "Đồng bộ thất bại"),
    DA_GOM_BK(3, "Đã gom bảng kê");

    private final Integer code;
    private final String description;

    public static RevenueRecordStatus fromCode(Integer code) {
        for (RevenueRecordStatus status : RevenueRecordStatus.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static Integer fromStatus(RevenueRecordStatus status) {
        return status.getCode();
    }
}
