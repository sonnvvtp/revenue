package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BmsPaymentPeriodHisMap {
    @JsonAlias("config_type_old")
    private Long configTypeOld;

    @JsonAlias("config_value_old")
    private JsonNode configValueOld;

    @JsonAlias("partner_id")
    private Long partnerId;

    @JsonAlias("partner_evtp")
    private String partnerEvtp;

    @JsonAlias("cus_id")
    private Long cusId;

    @JsonAlias("post_id")
    private Long postId;

    @JsonAlias("partner_group_id")
    private Long partnerGroupId;

    @JsonAlias("pay_category_config_id")
    private Long payCategoryConfigId;


    public List<Integer> getConfigValueOldAsList() {
        if (configValueOld == null || configValueOld.isNull()) {
            return Collections.emptyList();
        }

        ObjectMapper mapper = new ObjectMapper();

        try {
            if (configValueOld.isArray()) {
                return mapper.convertValue(configValueOld, new TypeReference<List<Integer>>() {});
            } else if (configValueOld.isTextual()) {
                String text = configValueOld.asText();
                if (text == null || text.trim().isEmpty() || "[]".equals(text.trim())) {
                    return Collections.emptyList();
                }
                return mapper.readValue(text, new TypeReference<List<Integer>>() {});
            } else {
                return Collections.emptyList();
            }
        } catch (Exception e) {
            // Log hoặc xử lý nếu parse lỗi
            return Collections.emptyList();
        }
    }
}
