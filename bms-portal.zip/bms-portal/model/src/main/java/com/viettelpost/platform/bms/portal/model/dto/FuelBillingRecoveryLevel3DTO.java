package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FuelBillingRecoveryLevel3DTO {

    Long id;
    @JsonAlias("receipt_number_excess")
    String excessNumber;
    @JsonAlias("receipt_number_reduction")
    String reductionNumber;
    @JsonAlias("synthesis_period")
    String synthesisPeriod;
    @JsonAlias("total_excess_amount")
    BigDecimal totalExcessAmount;
    @JsonAlias("total_budget_excess")
    BigDecimal totalExcessBudget;
    @JsonAlias("budget_reduction")
    BigDecimal budgetReduction;
    @JsonAlias("reduction_approved")
    String approved;
    @JsonAlias("reduction_status")
    Integer reductionStatus;
    @JsonAlias("created_at")
    LocalDateTime createdAt;
    @JsonAlias("approved_at")
    LocalDateTime approvedAt;
    @JsonAlias("is_active")
    Boolean isActive;
    @JsonAlias("excess_status")
    Integer excessStatus;
    @JsonAlias("excess_approved")
    String excessApproved;

}
