package com.viettelpost.platform.bms.revenue.worker.model.request.general;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.viettelpost.platform.bms.revenue.worker.model.request.InvoiceInfoDTO;
import com.viettelpost.platform.bms.revenue.worker.model.request.ItemOrderDTO;
import jakarta.validation.constraints.NotEmpty;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeneralOrderRequest {
  private String orderId;
  @NotEmpty(message = "vui lòng điền mã đơn")
  private String orderCode;
  private String orderParent;
  private String orderReference;
  private String orderName;
  private String cashflowType;
  private String serviceCode;
//  @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
//  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime orderCreatedAt;
//  @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
//  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime orderRevenueEntryAt;
//  @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
//  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime orderDeliveredAt;
  private Long employeeId;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> employeeInfo;
  private Long unitLevel1Id;
  private Long unitLevel2Id;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> unitInfo;
  private String companyCode;
  private Long sellerId;
  private String sellerCode;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> sellerInfo;
  private Long buyerId;
  private String buyerCode;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> buyerInfo;
  private Long consigneeId;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> consignee;
  private Long orderTotalQuantity;
  private BigDecimal orderAmountBeforeTax;
  private BigDecimal orderTaxAmount;
  private BigDecimal orderAmountAfterTax;
  private BigDecimal totalAmount;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> paymentInfo;
  private Integer paymentMethod;
  private Integer paymentTermId;
  private Integer paymentStatus;
  private String invoicePartner;
  private String currency;
  private InvoiceInfoDTO invoiceInfo;
  private List<ItemOrderDTO> itemOrderList;
  private String orderSource;
  private Integer recordType;
  private String domainType;
  private Integer picType;
  private Integer tenantId;
  private Integer[] requestType;
  private  Long periodId;
  private LocalDateTime recordRevenueEntryAt;
}

