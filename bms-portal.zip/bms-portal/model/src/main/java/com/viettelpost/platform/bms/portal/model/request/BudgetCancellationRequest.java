package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BudgetCancellationRequest {

    @JsonProperty("INPUT")
    private List<Input> INPUT;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    public static class Input {

        @JsonProperty("FMAREA")
        private String FMAREA;
        @JsonProperty("FISCAL_YEAR")
        private String FISCAL_YEAR;
        @JsonProperty("EXTERNAL_NUMBER")
        private String EXTERNAL_NUMBER;
        @JsonProperty("DOCUMENT_NUMBER")
        private Long DOCUMENT_NUMBER;
        @JsonProperty("HEADER_TEXT")
        private String HEADER_TEXT;

    }
}
