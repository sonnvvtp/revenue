package com.viettelpost.platform.bms.portal.common.config;

import lombok.extern.slf4j.Slf4j;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;
import java.util.stream.Collectors;
@Slf4j
public class VTManTokenHelper {
    private static String publicKeyText;
    private static String getKey(String filename, boolean isPrivateKey) throws Exception {
        try (InputStream is = VTManTokenHelper.class.getResourceAsStream(filename)) {
            String temp = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines()
                    .collect(Collectors.joining(""));
            String pem;
            if (isPrivateKey) {
                pem = temp.replace("-----BEGIN RSA PRIVATE KEY-----", "");
                pem = pem.replace("-----END RSA PRIVATE KEY-----", "");
            } else {
                pem = temp.replace("-----BEGIN PUBLIC KEY-----", "");
                pem = pem.replace("-----END PUBLIC KEY-----", "");
            }
            return pem;
        }catch (Exception ex){
            throw  new Exception(ex.getMessage());
        }
    }

    private static RSAPublicKey publicKey() {
        try {
            if (publicKeyText == null) {
                publicKeyText = getKey("/key/vtman.public", false);
            }
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] key = Base64.getDecoder().decode(publicKeyText);
            var x509 = new X509EncodedKeySpec(key);
            return (RSAPublicKey) keyFactory.generatePublic(x509);
        } catch (InvalidKeySpecException | IOException | NoSuchAlgorithmException e) {
            throw new RuntimeException();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static Map<String, Object> parse(String token) {
        try {
            var jwtConsumer = new JwtConsumerBuilder()
                    .setRelaxVerificationKeyValidation()
                    .setSkipAllValidators()
                    .setVerificationKey(publicKey()) // verify the signature with the public key
                    .setJwsAlgorithmConstraints( // only allow the expected signature algorithm(s) in the given context
                            AlgorithmConstraints.ConstraintType.PERMIT,
                            AlgorithmIdentifiers.RSA_USING_SHA256) // which is only RS256 here
                    .build();
            return jwtConsumer.process(token).getJwtClaims().getClaimsMap();
        } catch (InvalidJwtException e) {
            throw new RuntimeException();
        }
    }
}
