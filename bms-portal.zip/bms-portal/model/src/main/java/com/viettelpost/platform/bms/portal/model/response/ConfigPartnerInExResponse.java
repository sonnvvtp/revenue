package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ConfigPartnerInExResponse {
    private Long count;
    private List<Detail> details;


    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Detail {
        private Long partnerInternalLineId;
        private String partnerSource;
        private String merchantCode;
        private String serviceName;
        private String serviceCode;
        private String prefixCode;
        private List<String> bankCode;
        private Long status;
        private String updatedDate;
        private String updatedBy;

    }
}
