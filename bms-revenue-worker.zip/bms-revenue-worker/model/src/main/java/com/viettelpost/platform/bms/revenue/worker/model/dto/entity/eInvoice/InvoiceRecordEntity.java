package com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.viettelpost.platform.bms.revenue.worker.model.dto.InvoiceRecordDto;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RecordDto;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceRecordEntity {

  @JsonAlias("id")
  private BigDecimal id;

  @JsonAlias("tenant_id")
  private Integer tenantId;

  @JsonAlias("created_by")
  private Long createdBy;

  @JsonAlias("created_at")
  private LocalDateTime createdAt;

  @JsonAlias("updated_by")
  private Long updatedBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt;

  @JsonAlias("record_status")
  private Integer recordStatus;

  @JsonAlias("record_no")
  private String recordNo;

  @JsonAlias("unit_level1_id")
  private String unitLevel1Id;

  @JsonAlias("unit_level2_id")
  private String unitLevel2Id;

  @JsonAlias("buyer_id")
  private Long buyerId;

  @JsonAlias("buyer_code")
  private String buyerCode;

  @JsonAlias("accounting_date")
  private LocalDateTime accountingDate;

  @JsonAlias("accountant_id")
  private String accountantId;

  @JsonAlias("payment_method")
  private String paymentMethod;

  @JsonAlias("tax_percent")
  private Integer taxPercent;

  @JsonAlias("email")
  private String email;

  @JsonAlias("phone")
  private String phone;

  @JsonAlias("tax_code")
  private String taxCode;

  @JsonAlias("account_no")
  private String accountNo;

  @JsonAlias("customer_name")
  private String customerName;

  @JsonAlias("address")
  private String address;

  @JsonAlias("invoice_type")
  private String invoiceType;

  @JsonAlias("invoice_number")
  private String invoiceNumber;

  @JsonAlias("invoice_serial")
  private String invoiceSerial;

  @JsonAlias("invoice_form")
  private String invoiceForm;

  @JsonAlias("invoice_ref_id")
  private BigDecimal invoiceRefId;

  @JsonAlias("invoice_export_date")
  private LocalDateTime invoiceExportDate;

  @JsonAlias("record_type_id")
  private BigDecimal recordTypeId;

  @JsonAlias("amount_before_tax")
  private BigDecimal amountBeforeTax;

  @JsonAlias("amount_tax")
  private BigDecimal amountTax;

  @JsonAlias("amount_deduct")
  private BigDecimal amountDeduct;

  @JsonAlias("amount_total")
  private BigDecimal amountTotal;

  @JsonAlias("company_code")
  private String companyCode;

  @JsonAlias("record_type")
  private Integer recordType;

  @JsonAlias("record_source")
  private String recordSource;

  @JsonAlias("invoice_url")
  private LocalDateTime invoiceUrl;

  @JsonAlias("unit_name")
  private String unitName;

  @JsonAlias("from_date")
  private LocalDateTime fromDate;

  @JsonAlias("to_date")
  private LocalDateTime toDate;

  private List<InvoiceRecordDto> records;
}
