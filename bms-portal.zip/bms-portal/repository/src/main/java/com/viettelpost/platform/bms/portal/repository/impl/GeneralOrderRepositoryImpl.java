package com.viettelpost.platform.bms.portal.repository.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.viettelpost.platform.bms.portal.model.request.GeneralOrderRequest;
import com.viettelpost.platform.bms.portal.model.response.*;
import com.viettelpost.platform.bms.portal.repository.GeneralOrderRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
@RequiredArgsConstructor
public class GeneralOrderRepositoryImpl implements GeneralOrderRepository {

    private final PgPool client;

    @Override
    public Uni<GeneralOrderDetailResponse> getGeneralOrderDetailById(Long generalOrderId) {

        String sqlOrder = """
                    SELECT * FROM bms_payment.general_order WHERE id = $1
                """;

        String sqlInvoiceInfo = """
                    SELECT * FROM bms_payment.invoice_info WHERE general_order_id = $1 and domain_type = 'FMCG'
                """;

        String sqlItemOrder = """
                    SELECT * FROM bms_payment.item_order WHERE general_order_id = $1 order by item_code asc, item_selection asc
                """;
        ObjectMapper mapper = new ObjectMapper();

        Uni<GeneralOrderInfo> orderUni = client.preparedQuery(sqlOrder)
                .execute(Tuple.of(generalOrderId))
                .onItem().transform(rows -> {
                    if (!rows.iterator().hasNext()) {
                        throw new NotFoundException("Không tìm thấy đơn hàng với ID: " + generalOrderId);
                    }
                    Row row = rows.iterator().next();

                    EmployeeInfo employeeInfo = null;
                    UnitInfo unitInfo = null;

                    try {
                        JsonObject empJson = row.getJsonObject("employee_info");
                        if (empJson != null) {
                            employeeInfo = mapper.readValue(empJson.encode(), EmployeeInfo.class);
                        }

                        JsonObject unitJson = row.getJsonObject("unit_info");
                        if (unitJson != null) {
                            unitInfo = mapper.readValue(unitJson.encode(), UnitInfo.class);
                        }

                    } catch (JsonProcessingException e) {
                        throw new RuntimeException("Lỗi khi parse JSONB từ DB", e);
                    }
                    return GeneralOrderInfo.builder()
                            .id(row.getLong("id"))
                            .orderId(row.getString("order_id"))
                            .orderCode(row.getString("order_code"))
                            .buyerCode(row.getString("buyer_code"))
                            .orderSource(row.getString("order_source"))
                            .companyCode(row.getString("company_code"))
                            .unitInfo(unitInfo)
                            .createdAt(row.getLocalDateTime("created_at"))
                            .orderDeliveredAt(row.getLocalDateTime("order_delivered_at"))
                            .serviceCode(row.getString("service_code"))
                            .cashflowType(row.getString("cashflow_type"))
                            .employeeId(row.getLong("employee_id"))
                            .employeeInfo(employeeInfo)
                            .invoicePartner(row.getString("invoice_partner"))
                            .invoiceStatus(row.getInteger("invoice_status"))
                            .revenueSyncStatus(row.getInteger("revenue_sync_status"))
                            .paymentStatus(row.getInteger("payment_status"))
                            .paymentMethod(row.getInteger("payment_method"))
                            .paymentTermId(row.getLong("payment_term_id"))
                            .currency(row.getString("currency"))
                            .orderTotalQuantity(row.getInteger("order_total_quantity"))
                            .orderAmountBeforeTax(row.getBigDecimal("order_amount_before_tax"))
                            .orderTaxAmount(row.getBigDecimal("order_tax_amount"))
                            .orderAmountAfterTax(row.getBigDecimal("order_amount_after_tax"))
                            .build();

                });

        Uni<InvoiceBuyerInfo> invoiceUni = client.preparedQuery(sqlInvoiceInfo)
                .execute(Tuple.of(generalOrderId))
                .onItem().transform(rows -> {
                    if (!rows.iterator().hasNext()) return null;
                    Row row = rows.iterator().next();
                    return InvoiceBuyerInfo.builder()
                            .id(row.getLong("id"))
                            .buyerName(row.getString("buyer_name"))
                            .buyerType(row.getString("buyer_type"))
                            .buyerTaxCode(row.getString("buyer_tax_code"))
                            .buyerPhone(row.getString("buyer_phone"))
                            .buyerAddress(row.getString("buyer_address"))
                            .buyerEmail(row.getString("buyer_email"))
                            .partnerName(row.getString("partner_name"))
                            .build();
                });

        Uni<List<OrderItemInfo>> itemsUni = client.preparedQuery(sqlItemOrder)
                .execute(Tuple.of(generalOrderId))
                .onItem().transform(rows -> {
                    List<OrderItemInfo> list = new ArrayList<>();
                    for (Row row : rows) {
                        list.add(OrderItemInfo.builder()
                                .id(row.getLong("id"))
                                .itemCode(row.getString("item_code"))
                                .itemName(row.getString("item_name"))
                                .warehouseCode(row.getString("warehouse_code"))
                                .itemSelection(row.getInteger("item_selection"))
                                .departureLocation(row.getString("departure_location"))
                                .arrivalLocation(row.getString("arrival_location"))
                                .vehiclePlatenumber(row.getString("vehicle_platenumber"))
                                .itemUnit(row.getString("item_unit"))
                                .itemQuantity(row.getInteger("item_quantity"))
                                .itemWeight(row.getInteger("item_weight"))
                                .itemPrice(row.getBigDecimal("item_price"))
                                .itemAmountBeforeTax(row.getBigDecimal("item_amount_before_tax"))
                                .itemTaxPercent(row.getBigDecimal("item_tax_percent"))
                                .itemTaxType(row.getInteger("item_tax_type"))
                                .itemTaxAmount(row.getBigDecimal("item_tax_amount"))
                                .itemAmountAfterTax(row.getBigDecimal("item_amount_after_tax"))
                                .build());
                    }
                    return list;
                });

        return Uni.combine().all().unis(orderUni, invoiceUni, itemsUni)
                .asTuple()
                .onItem().transform(tuple -> GeneralOrderDetailResponse.builder()
                        .orderInfo(tuple.getItem1())
                        .invoiceInfo(tuple.getItem2())
                        .items(tuple.getItem3())
                        .build());
    }

    @Override
    public Multi<GeneralOrderResponse> getGeneralOrder(
            GeneralOrderRequest request) {
        String sql = """
                select * from bms_payment.general_order
                where 1=1 and invoice_status = 0
                """;

        String advancedFilter = request.getAdvancedFilter();
        String companyCode = request.getCompanyCode();
        List<Integer> status = request.getStatus();

        int page = Objects.nonNull(request.getPage()) ? request.getPage() : 1;
        int size = Objects.nonNull(request.getSize()) ? request.getSize() : 10;
        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and order_code = $%d ", counter++);
            params.add(advancedFilter.trim());
        }

        if (StringUtils.isNotEmpty(companyCode)) {
            sql += String.format(" and company_code = $%d ", counter++);
            params.add(companyCode.trim());
        }

        if (Objects.nonNull(status) && !status.isEmpty()) {
            sql += String.format(" and invoice_status = any($%d) ", counter++);
            params.add(status.toArray());
        }

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and created_at >= $%d and created_at <= $%d ", counter++, counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and created_at >= $%d ", counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and created_at <= $%d ", counter++);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }

        if (StringUtils.isNotEmpty(request.getSource())) {
            sql += String.format(" and order_source = $%d ", counter++);
            params.add(request.getSource());
        }

        sql += String.format(" order by created_at desc limit $%d offset $%d ", counter++, counter);
        params.add(size);
        params.add(size * (page - 1));

        return executeMulti(client, sql, Tuple.from(params), GeneralOrderResponse.class);
    }

    @Override
    public Uni<Integer> findInvoiceOrderCount(GeneralOrderRequest findInvoiceOrderRequest) {
        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        String companyCode = findInvoiceOrderRequest.getCompanyCode();
        List<Integer> status = findInvoiceOrderRequest.getStatus();
        LocalDate fromDate = findInvoiceOrderRequest.getFromDate();
        LocalDate toDate = findInvoiceOrderRequest.getToDate();

        String sql = """
        select count(1) as total from bms_payment.general_order
        where 1 = 1 and invoice_status = 0
        """;

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and order_code = $%d ", counter++);
            params.add(advancedFilter.trim());
        }

        if (StringUtils.isNotEmpty(companyCode)) {
            sql += String.format(" and company_code = $%d ", counter++);
            params.add(companyCode.trim());
        }

        if (Objects.nonNull(status) && !status.isEmpty()) {
            sql += String.format(" and invoice_status = any($%d) ", counter++);
            params.add(status.toArray());
        }

        if (StringUtils.isNotEmpty(findInvoiceOrderRequest.getSource())) {
            sql += String.format(" and order_source = $%d ", counter++);
            params.add(findInvoiceOrderRequest.getSource());
        }

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and created_at between $%d and $%d ", counter++, counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and created_at >= $%d ", counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and created_at <= $%d ", counter);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }

        return executeAndGetValue(client, sql, Tuple.from(params), "total", Integer.class);
    }


}
