package com.viettelpost.platform.bms.portal.common.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RoleType {

    ROLE_TCT("ROLE_TCT", "role tong cong ty"),
    ROLE_CN("ROLE_CN", "role chi nhanh"),
    ROLE_BC("ROLE_BC", "role buu cuc");

    private String code;
    private String name;
}
