package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.dto.KMCPDTO;
import com.viettelpost.platform.bms.portal.model.model.CarManagementSettingModel;
import com.viettelpost.platform.bms.portal.model.request.VehicleTypeGroupFilter;
import com.viettelpost.platform.bms.portal.model.request.VehicleTypeGroupRequest;
import com.viettelpost.platform.bms.portal.model.response.CarLicensePlateResponse;
import com.viettelpost.platform.bms.portal.service.handler.CarManagementService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;
import java.util.Map;
import reactor.core.publisher.Mono;

@Slf4j
@Path("/car-management")
@Tag(name = "Cars Management")
@RequiredArgsConstructor
public class CarManagementController {

    @Inject
    CarManagementService carManagementSettingService;

    @GET
    @Path("/units")
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<List<String>> getAllCarUnits(
            @QueryParam("search") String search,
            @QueryParam("page") int page,
            @QueryParam("size") int size
    ) {
        return carManagementSettingService.getCarUnits(search, page, size);
    }

    @GET
    @Path("/cars-by-unit")
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Map<String, Object>> getAllCarLicensePlatesByUnit(
            @QueryParam("unit") String unit,
            @QueryParam("search") String search,
            @QueryParam("page") Integer page,
            @QueryParam("size") Integer size
    ) {
        return carManagementSettingService.getCarLicensePlatesByUnit(unit, search, page, size);
    }

    @GET
    @Path("/all-cars")
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<List<CarManagementSettingModel>> getAllCarLicensePlates() {
        return carManagementSettingService.getAllCarLicensePlates();
    }

    @POST
    @Path("/upsert-car")
    public Uni<Boolean> upsertCar(CarManagementSettingModel request) {
        return carManagementSettingService.upsertCar(request);
    }

    @GET
    @Path("/license-plates-in-bill")
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<List<CarLicensePlateResponse>> getCarLicensePlatesInFuelBillLv3(
            @QueryParam("receiptId") Long receiptId) {
        return carManagementSettingService.getCarLicensePlatesInFuelBillLv3(receiptId);
    }

    @GET
    @Path("/vehicle-type")
    @Produces(MediaType.APPLICATION_JSON)
    public Uni<Map<String, Object>> getVehicleTypes(
            @QueryParam("notInGroup") boolean notInGroup
    ) {
        return carManagementSettingService.getVehicleTypes(notInGroup);
    }

    @POST
    @Path("/vehicle-type-group")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Uni<Map<String, Object>> getVehicleTypeGroups(VehicleTypeGroupFilter filter) {
        return carManagementSettingService.getVehicleTypeGroups(filter == null ? new VehicleTypeGroupFilter() : filter);
    }

    @POST
    @Path("/vehicle-type-group/create")
    @Operation(summary = "Create Vehicle Type Group")
    @APIResponse(responseCode = "200", description = "Vehicle Type Group created successfully")
    @APIResponse(responseCode = "400", description = "Failed to create")
    public Uni<Response> createVehicleTypeGroup(VehicleTypeGroupRequest request) {
        return carManagementSettingService.createVehicleTypeGroup(request)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Tạo nhóm loại xe thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Tạo không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }

    @PUT
    @Path("/vehicle-type-group/update/{id}")
    @Operation(summary = "Update Vehicle Type Group")
    @APIResponse(responseCode = "200", description = "Vehicle Type Group updated successfully")
    @APIResponse(responseCode = "400", description = "Failed to update")
    public Uni<Response> updateVehicleTypeGroup(Long id, VehicleTypeGroupRequest request) {
        return carManagementSettingService.updateVehicleTypeGroup(id, request)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Cập nhật nhóm loại xe thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Cập nhật không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }

    @DELETE
    @Path("/vehicle-type-group/delete/{id}")
    @Operation(summary = "Delete Vehicle Type Group")
    @APIResponse(responseCode = "200", description = "Vehicle Type Group deleted successfully")
    @APIResponse(responseCode = "400", description = "Failed to delete")
    public Uni<Response> deleteVehicleTypeGroup(Long id) {
        return carManagementSettingService.deleteVehicleTypeGroup(id)
                .onItem().transform(success -> {
                    if (success) {
                        return Response.ok("Xóa nhóm loại xe thành công").build();
                    } else {
                        return Response.status(Response.Status.BAD_REQUEST)
                                .entity("Xóa không thành công").build();
                    }
                })
                .onFailure()
                .recoverWithItem(th -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("Error occurred: " + th.getMessage()).build());
    }

    @GET
    @Path("/kmcp")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "getKMCPDetailsByCarLicensePlate")
    @APIResponse(responseCode = "200", description = "Returns a KMCPDTO")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<KMCPDTO> getKMCPDetailsByCarLicensePlate(@QueryParam("carLicensePlate") String carLicensePlate) {
        return ReactiveConverter.toUni(carManagementSettingService.fetchKMCPByCarLicensePlate(carLicensePlate));
    }

}
