package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BudgetDocumentRetrieveSap {

    HOAN_GIAM_NGAN_SACH_LOI(0, "Hoàn giảm ngân sách lỗi "),
    HOAN_GIAM_NGAN_SACH_THANH_CONG(1, "Hoàn giảm ngân sách thành công");

    private final Integer code;
    private final String description;

    public static Integer fromStatus(BudgetDocumentRetrieveSap status) {
        return status.getCode();
    }

}
