package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;
@AllArgsConstructor
@Getter
public enum EpacketTransactionType {
    DEPOSIT_MONEY(1, "DEPOSIT_MONEY", "Nạp tiền thật"),
    WITHDRAW_MONEY(2, "WITHDRAW_MONEY", "Rút tiền thật"),
    MINUS_MONEY_WALLET(3, "MINUS_MONEY_WALLET", "Trừ tiền ví"),
    PLUS_MONEY_WALLET(4, "PLUS_MONEY_WALLET", "Cộng tiền ví"),

    NA(-1, "N/A", "N/A");
    private int id;
    private String code;
    private String name;

    public static EpacketTransactionType get(String code) {
        return Arrays.stream(EpacketTransactionType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(NA);
    }
}
