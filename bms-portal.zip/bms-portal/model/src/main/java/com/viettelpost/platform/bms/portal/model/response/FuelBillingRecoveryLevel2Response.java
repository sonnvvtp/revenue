package com.viettelpost.platform.bms.portal.model.response;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FuelBillingRecoveryLevel2Response {

    private Long id;
    private String receiptNumber;
    private String synthesisPeriod;
    private String unit;
    private BigDecimal budgetExcess;
    private BigDecimal budgetReduction;
    private Integer status;
}
