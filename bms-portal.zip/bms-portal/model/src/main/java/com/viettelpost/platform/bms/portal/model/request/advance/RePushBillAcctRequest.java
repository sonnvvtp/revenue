package com.viettelpost.platform.bms.portal.model.request.advance;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class RePushBillAcctRequest {

    @NotBlank(message = "Vui lòng cung cấp refDocNo")
    private String refDocNo;

    @NotEmpty(message = "Vui lòng cung cấp danh sách bill")
    private List<String> billList;

    @NotNull(message = "Vui lòng cung cấp posting date")
    private LocalDate postingDate;
}
