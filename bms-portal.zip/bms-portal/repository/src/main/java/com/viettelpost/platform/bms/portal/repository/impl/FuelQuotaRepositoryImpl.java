package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.BudgetReductionDTO;
import com.viettelpost.platform.bms.portal.model.dto.FuelQuotaDTO;
import com.viettelpost.platform.bms.portal.model.response.FuelQuotaResponse;
import com.viettelpost.platform.bms.portal.repository.FuelQuotaRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.SqlResult;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import reactor.core.publisher.Mono;

@Singleton
@Slf4j
public class FuelQuotaRepositoryImpl implements FuelQuotaRepository {

    @Inject
    PgPool client;

    @Override
    public Uni<List<FuelQuotaResponse>> searchFuelQuotas(
            String carLicensePlate, String synthesisPeriod, String unit, int pageNo, int pageSize) {
        int offset = (pageNo - 1) * pageSize;
        StringBuilder sql = new StringBuilder("SELECT f.*, f3.reduction_status, f3.excess_status FROM bms_payment.fuel_quota f" +
                "   left join bms_payment.fuel_billing_recovery_level3 f3" +
                "   on f3.synthesis_period = f.synthesis_period and f3.is_active = true" +
                "   WHERE f.is_active = true");
        List<Object> params = new ArrayList<>();

        if (unit != null && !unit.isEmpty()) {
            sql.append(" AND f.unit = $").append(1);
            params.add(unit);
        }

        if (carLicensePlate != null && !carLicensePlate.isEmpty()) {
            sql.append(" AND f.car_license_plate = $").append(params.size() + 1);
            params.add(carLicensePlate);
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            sql.append(" AND f.synthesis_period = $").append(params.size() + 1);
            params.add(synthesisPeriod);
        }

        sql.append(" ORDER BY created_at DESC ");
        sql.append(" LIMIT $").append(params.size() + 1);
        params.add(pageSize);
        sql.append(" OFFSET $").append(params.size() + 1);
        params.add(offset);

        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<FuelQuotaResponse> responses = new ArrayList<>();
                    rows.forEach(row -> {
                        FuelQuotaResponse response = mapRowsToFuelQuotaResponse(row);
                        responses.add(response);
                    });
                    return responses;
                });
    }

    public Uni<Long> countFuelQuotas(String carLicensePlate, String synthesisPeriod, String unit) {
        StringBuilder countSql = new StringBuilder("SELECT COUNT(*) FROM bms_payment.fuel_quota f" +
                "   left join bms_payment.car_management_setting c on f.car_id = c.id WHERE f.is_active = true");
        List<Object> params = new ArrayList<>();

        if (unit != null && !unit.isEmpty()) {
            countSql.append(" AND f.unit = $").append(1);
            params.add(unit);
        }

        if (carLicensePlate != null && !carLicensePlate.isEmpty()) {
            countSql.append(" AND f.car_license_plate = $").append(params.size() + 1);
            params.add(carLicensePlate);
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            countSql.append(" AND f.synthesis_period = $").append(params.size() + 1);
            params.add(synthesisPeriod);
        }

        return client.preparedQuery(countSql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> rows.iterator().next().getLong(0));
    }

    @Override
    public Uni<String> showNewestMonthFuelQuota() {
        String sql = "SELECT synthesis_period FROM bms_payment.fuel_quota ORDER BY created_at DESC LIMIT 1";

        return client.query(sql)
                .execute()
                .onItem().transform(rowSet -> {
                    if (rowSet.size() > 0) {
                        Row row = rowSet.iterator().next();
                        return row.getString("synthesis_period");
                    } else {
                        return null;
                    }
                });
    }

    @Override
    public Uni<FuelQuotaResponse> getFuelQuotaByCarLicensePlateAndSynthesisPeriod(
            String carLicensePlate, String synthesisPeriod) {
        String sql = "SELECT f.*, f3.reduction_status, f3.excess_status FROM bms_payment.fuel_quota f" +
                " left join bms_payment.fuel_billing_recovery_level3 f3 on f3.synthesis_period = f.synthesis_period and f3.is_active = true" +
                " WHERE f.car_license_plate = $1 AND f.synthesis_period = $2 AND f.is_active = true";
        return client.preparedQuery(sql)
                .execute(Tuple.of(carLicensePlate, synthesisPeriod))
                .onItem().transform(rows -> {
                    if (rows.size() == 0) {
                        return null;
                    }
                    return mapRowsToFuelQuotaResponse(rows.iterator().next());
                });
    }

    private FuelQuotaResponse mapRowsToFuelQuotaResponse(Row row) {
        return FuelQuotaResponse.builder()
                .id(row.getLong("id"))
                .synthesisPeriod(row.getString("synthesis_period"))
                .carLicensePlate(row.getString("car_license_plate"))
                //.budget(row.getBigDecimal("budget"))
                .averageUnitPrice(row.getBigDecimal("average_unit_price"))
                //.quata(row.getBigDecimal("quata"))
                .actualMileage(row.getBigDecimal("actual_mileage"))
                .fuelConsumptionRate(row.getBigDecimal("fuel_consumption_rate"))
                .fuelConsumptionUnit(row.getBigDecimal("fuel_consumption_unit"))
                .expectedFuelConsumption(row.getBigDecimal("expected_fuel_consumption"))
                .invoiceFuelAmount(row.getBigDecimal("invoice_fuel_amount"))
                .invoiceAmount(row.getBigDecimal("invoice_amount"))
                //.budgetExcess(row.getBigDecimal("budget_excess").setScale(0, RoundingMode.HALF_UP))
                .fuelExcess(row.getBigDecimal("fuel_excess"))
                .totalExcessAmount(row.getBigDecimal("total_excess_amount"))
                //.budgetReduction(row.getBigDecimal("budget_reduction").setScale(0, RoundingMode.HALF_UP))
                .reductionStatus(row.getInteger("reduction_status"))
                .excessStatus(row.getInteger("excess_status"))
                .build();
    }

    @Override
    public Uni<List<String>> showListMonth() {
        return client.preparedQuery("SELECT DISTINCT synthesis_period FROM bms_payment.fuel_quota ")
                .execute()
                .onItem().transformToMulti(set -> Multi.createFrom().iterable(set))
                .onItem().transform(row -> row.getString("synthesis_period"))
                .collect().asList();
    }

    @Override
    public Mono<Integer> create(List<FuelQuotaDTO> list, SqlConnection sqlConnection) {
        if (CollectionUtils.isEmpty(list)) {
            return Mono.just(0);
        }
        var preparedQuery = sqlConnection.preparedQuery(
                "INSERT INTO bms_payment.fuel_quota (" +
                        "synthesis_period, car_license_plate, budget, average_unit_price, quata, actual_mileage, "
                        +
                        "fuel_consumption_rate, fuel_consumption_unit, expected_fuel_consumption, invoice_fuel_amount, "
                        +
                        "invoice_amount, budget_excess, fuel_excess, total_excess_amount, budget_reduction, created_at, car_id, unit, is_active"
                        +
                        ") VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19) "
        );
        return preparedQuery.executeBatch(
                        list.stream().map(fuelQuotaDTO -> Tuple.tuple()
                                .addString(fuelQuotaDTO.getSynthesisPeriod())
                                .addString(fuelQuotaDTO.getCarLicensePlate())
                                .addBigDecimal(fuelQuotaDTO.getBudget())
                                .addBigDecimal(fuelQuotaDTO.getAverageUnitPrice())
                                .addBigDecimal(fuelQuotaDTO.getQuata())
                                .addBigDecimal(fuelQuotaDTO.getActualMileage())
                                .addBigDecimal(fuelQuotaDTO.getFuelConsumptionRate())
                                .addBigDecimal(fuelQuotaDTO.getFuelConsumptionUnit())
                                .addBigDecimal(fuelQuotaDTO.getExpectedFuelConsumption())
                                .addBigDecimal(fuelQuotaDTO.getInvoiceFuelAmount())
                                .addBigDecimal(fuelQuotaDTO.getInvoiceAmount())
                                .addBigDecimal(fuelQuotaDTO.getBudgetExcess())
                                .addBigDecimal(fuelQuotaDTO.getFuelExcess())
                                .addBigDecimal(fuelQuotaDTO.getTotalExcessAmount())
                                .addBigDecimal(fuelQuotaDTO.getBudgetReduction())
                                .addLocalDateTime(fuelQuotaDTO.getCreatedAt())
                                .addLong(fuelQuotaDTO.getCarId())
                                .addString(fuelQuotaDTO.getUnit())
                                .addBoolean(fuelQuotaDTO.getIsActive())).collect(Collectors.toList()))
                .onItem().transform(SqlResult::rowCount)
                .convert().with(UniReactorConverters.toMono());

    }

    @Override
    public Mono<Integer> update(List<FuelQuotaDTO> updateItems, SqlConnection sqlConnection) {
        if (CollectionUtils.isEmpty(updateItems)) {
            return Mono.just(0);
        }
        updateItems.forEach(
                item -> log.debug("Preparing to update record with ID: {}", item.getId()));
        // SQL query for batch update
        var updateQuery = sqlConnection.preparedQuery(
                "UPDATE bms_payment.fuel_quota " +
                        "SET budget = $1, " +
                        "    average_unit_price = $2, " +
                        "    quata = $3, " +
                        "    actual_mileage = $4, " +
                        "    fuel_consumption_rate = $5, " +
                        "    fuel_consumption_unit = $6, " +
                        "    expected_fuel_consumption = $7, " +
                        "    invoice_fuel_amount = $8, " +
                        "    invoice_amount = $9, " +
                        "    budget_excess = $10, " +
                        "    fuel_excess = $11, " +
                        "    total_excess_amount = $12, " +
                        "    budget_reduction = $13, " +
                        "    unit = $14, " +
                        "    is_active = $15 " +
                        "WHERE id = $16"
        );
        return Mono.fromCompletionStage(updateQuery.executeBatch(
                        updateItems.stream().map(fuelQuotaDTO -> Tuple.tuple()
                                        .addBigDecimal(fuelQuotaDTO.getBudget())  // $1
                                        .addBigDecimal(fuelQuotaDTO.getAverageUnitPrice())  // $2
                                        .addBigDecimal(fuelQuotaDTO.getQuata())  // $3
                                        .addBigDecimal(fuelQuotaDTO.getActualMileage())  // $4
                                        .addBigDecimal(fuelQuotaDTO.getFuelConsumptionRate())  // $5
                                        .addBigDecimal(fuelQuotaDTO.getFuelConsumptionUnit())  // $6
                                        .addBigDecimal(fuelQuotaDTO.getExpectedFuelConsumption())  // $7
                                        .addBigDecimal(fuelQuotaDTO.getInvoiceFuelAmount())  // $8
                                        .addBigDecimal(fuelQuotaDTO.getInvoiceAmount())  // $9
                                        .addBigDecimal(fuelQuotaDTO.getBudgetExcess())  // $10
                                        .addBigDecimal(fuelQuotaDTO.getFuelExcess())  // $11
                                        .addBigDecimal(fuelQuotaDTO.getTotalExcessAmount())  // $12
                                        .addBigDecimal(fuelQuotaDTO.getBudgetReduction())  // $13
                                        .addString(fuelQuotaDTO.getUnit())  // $14
                                        .addBoolean(fuelQuotaDTO.getIsActive())  // $15
                                        .addLong(fuelQuotaDTO.getId()))  // $16
                                .collect(Collectors.toList()))
                .map(SqlResult::rowCount)
                .subscribeAsCompletionStage());
    }

    @Override
    public Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection sqlConnection) {
        String query = "UPDATE bms_payment.fuel_quota SET is_active = false WHERE synthesis_period = $1";
        return sqlConnection.preparedQuery(query)
                .execute(Tuple.of(synthesisPeriod))
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(rows -> log.info("Deactivated records for synthesis period: {}",
                        synthesisPeriod))
                .doOnError(ex -> log.error("Error deactivating records for synthesis period {}: {}",
                        synthesisPeriod, ex.getMessage()))
                .then();
    }


}


