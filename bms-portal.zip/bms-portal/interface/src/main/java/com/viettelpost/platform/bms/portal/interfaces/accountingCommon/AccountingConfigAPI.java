package com.viettelpost.platform.bms.portal.interfaces.accountingCommon;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.service.handler.AccountingSapCfService;
import com.viettelpost.platform.model.request.accountingConfig.ConfigAccountAcctReq;
import com.viettelpost.platform.model.request.accountingConfig.GlAccountMapReq;
import com.viettelpost.platform.model.response.accountingConfig.AcctConfigReq;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/accounting-cf")
@Tag(name = "API config accounting SAP Common")
@RequiredArgsConstructor
@ApplicationScoped
public class AccountingConfigAPI {
    private final AccountingSapCfService accountingSapCfService;

    @Inject
    AuthenticationContext authCtx;

    /**
     * CONFIG
     * */

    @GET
    @Path("/list-business")
    @Operation(summary = "Danh sách cấu hình hạch toán")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListBusiness(@QueryParam("businessId") Integer businessId,
                                         @QueryParam("paramSearch") String paramSearch,
                                         @QueryParam("page") Integer page,
                                         @QueryParam("size") Integer size) {
        return accountingSapCfService.getListBusiness(businessId, paramSearch, page, size);
    }

    @POST
    @Path("/add-config")
    @Operation(summary = "Thêm mới cấu hình hạch toán")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> configBusinessSalary(@RequestBody @Valid AcctConfigReq req) {
        CustomUser infoUser = authCtx.getCurrentUser();

        return accountingSapCfService.addConfigAcctBusiness(req, infoUser);
    }

    @POST
    @Path("/delete-business")
    @Operation(summary = "xóa cấu hình hạch toán")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> deleteBusiness(@QueryParam("salaryBusinessConfigId") Integer salaryBusinessConfigId) {
        return accountingSapCfService.deleteBusiness(salaryBusinessConfigId);
    }

    @POST
    @Path("/update-config")
    @Operation(summary = "Cập nhật cấu hình hạch toán")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> updateConfigBusiness(@RequestBody @Valid AcctConfigReq req) {
        CustomUser infoUser = authCtx.getCurrentUser();

        return accountingSapCfService.updateConfigBusiness(req, infoUser);
    }

    /**
     * DETAIL CONFIG
     * */

    @GET
    @Path("/list-account-accounting")
    @Operation(summary = "Danh sách GL account")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListAccountAcct(@QueryParam("bmsAccountingConfigId") Integer bmsAccountingConfigId) {
        return accountingSapCfService.getListAccountAcct(bmsAccountingConfigId);
    }

    @POST
    @Path("/config-account-accounting")
    @Operation(summary = "Cấu hình chi tiết")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> configAccountAcct(@RequestBody @Valid ConfigAccountAcctReq reqConfig) {
        CustomUser infoUser = authCtx.getCurrentUser();

        return accountingSapCfService.configAccountAcctSalary(reqConfig, infoUser);
    }

    @POST
    @Path("/update-business-account")
    @Operation(summary = "Cập nhật cấu hình tai khoản hạch toán")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> updateConfigBusinessAccount(@RequestBody @Valid ConfigAccountAcctReq reqUpdate) {
        CustomUser infoUser = authCtx.getCurrentUser();

        return accountingSapCfService.updateConfigBusinessAccount(reqUpdate, infoUser);
    }

    @POST
    @Path("/delete-business-account")
    @Operation(summary = "xóa cấu hình tk hach toan")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> deleteConfigAccount(@QueryParam("bmsGlAccountConfigId") Integer salaryBusinessConfigId) {
        return accountingSapCfService.deleteBusinessAccount(salaryBusinessConfigId);
    }

    /**
     * List hardcode config
     * */

    @GET
    @Path("/list-channel")
    @Operation(summary = "Danh sách kênh")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListChannel() {
        return accountingSapCfService.getListChannelConfig();
    }

    @GET
    @Path("/list-object")
    @Operation(summary = "Danh sách đối tượng")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListObject() {
        return accountingSapCfService.getListObject();
    }

    @GET
    @Path("/company-code")
    @Operation(summary = "Danh sách đối tượng")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListCompanyCode() {
        return accountingSapCfService.getCompanyCodeConfig();
    }

    @GET
    @Path("/list-gl-account")
    @Operation(summary = "get list gl account from SAP SYNC")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListGlAccount() {
        return accountingSapCfService.getListGlAccount();
    }

    @GET
    @Path("/business-config")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getBusinessConfig() {
        return accountingSapCfService.getBusinessConfig();
    }

    @GET
    @Path("/contract-type")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getContractTypeConfig() {
        return accountingSapCfService.getContractTypeConfig();
    }


    @GET
    @Path("/list-column")
    @Operation(summary = "Danh sách cột config")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListColumn(@QueryParam("businessId") Integer businessId) {
        return accountingSapCfService.getListColumnNameViaBusiness(businessId);
    }

    @GET
    @Path("/list-column-no-co")
    @Operation(summary = "Danh sách đẩy thông tin nào theo tk nợ có")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListColumnNoCo() {
        return accountingSapCfService.getListColumnNameConfigViaBusiness();
    }

    @GET
    @Path("/list-config-type-group")
    @Operation(summary = "Danh sách loại gom")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getConfigTypeGroup() {
        return accountingSapCfService.getConfigTypeGroupList();
    }

    // list loại dữ liệu gom
    @GET
    @Path("/list-synthetic-type")
    @Operation(summary = "Loại dữ liệu gom")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getConfigTypeSynthetic(@QueryParam("businessId") Integer businessId) {
        return accountingSapCfService.getConfigTypeSynthetic(businessId);
    }

    @GET
    @Path("/insert-post-code-center")
    @Operation(summary = "Loại dữ liệu gom")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> insertPostCodeCenter(@QueryParam("page") Integer page, @QueryParam("pageSize") Integer pageSize) {
        return accountingSapCfService.insertPostCodeCenter(page, pageSize);
    }

    @GET
    @Path("/bms-get-post-code-center")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> bmsGetPostCodeCenter(@QueryParam("postId") Integer postId) {
        return accountingSapCfService.bmsGetPostCodeCenter(postId);
    }


    /*
     * bms_payment.gl_account_map
     */

    @GET
    @Path("/get-gl-account-map")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getGlAccountMap(@QueryParam("serviceCode") String serviceCode,
                                         @QueryParam("page") Integer page,
                                         @QueryParam("size") Integer size) {
        return accountingSapCfService.getGlAccountConfig(serviceCode, page, size);
    }

    @POST
    @Path("/update/get-gl-account")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> updateGlAccountMap(@RequestBody GlAccountMapReq req) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return accountingSapCfService.updateGlAccountMap(req, infoUser);
    }
}
