package com.viettelpost.platform.bms.portal.model.model;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

public class PartnerStatus {
    private static final StatementPayStatus BKConfig = StatementPayStatus.builder()
            .statementClear(51L)
            .statementCod(51L)
            .billPay(52L)
            .billTran(1002L)
            .sapCodeClear("BK17")
            .sapCodeClear_APPWEB("CUOCKH_BK")
            .sapCodeCod("BK18")
            .partnerCode("BAOKIM")
            .build();


    private static final StatementPayStatus VCBConfig = StatementPayStatus.builder()
            .statementClear(61L)
            .statementCod(61L)
            .billPay(62L)
            .billTran(1004L)
            .sapCodeClear_APPWEB("CUOCKH_VCB")
            .sapCodeClear("BK19")
            .sapCodeCod("BK20")
            .partnerCode("VCB")
            .build();

    private static final StatementPayStatus ViettelMoneyConfig = StatementPayStatus.builder()
            .statementClear(41L)
            .statementCod(71L)
            .billPay(2L)
            .billTran(2L)
            .sapCodeClear_APPWEB("CUOCKH_VDS")
            .sapCodeClear("TKLK_CPN")
            .sapCodeCod("TKLK_BT")
            .partnerCode("VTMONEY")
            .build();
    private static final StatementPayStatus OcbConfig = StatementPayStatus.builder()
            .billPay(88L) // trạng thái bill thanh toán thành công
            .billTran(1006L)
            .statementClear(87L)
            .statementCod(87L)
            .sapCodeClear("CUOC_OCB") // mã bảng kê đồng bộ SAP
            .sapCodeCod("COD_OCB") // mã bảng kê đồng bộ SAP
            .partnerCode("OCB")
            .sapCodeClear_APPWEB("CUOCKH_OCB")
            .build();

    private static final StatementPayStatus stbConfig = StatementPayStatus.builder()
            .billTran(1010L)
            .billPay(58L) // trạng thái bill thanh toán thành công
            .statementClear(57L)
            .statementCod(57L)
            .sapCodeClear("CUOC_STB") // mã bảng kê đồng bộ SAP
            .sapCodeCod("COD_STB") // mã bảng kê đồng bộ SAP
            .sapCodeClear_APPWEB("CUOCKH_STB")
            .partnerCode("STB")
            .build();

    private static final StatementPayStatus tpbConfig = StatementPayStatus.builder()
            .billPay(55L) // trạng thái bill thanh toán thành công
            .billTran(1012L)
            .statementClear(54L)
            .statementCod(54L)
            .sapCodeClear_APPWEB("CUOCKH_TPB")
            .sapCodeClear("CUOC_TPB") // mã bảng kê đồng bộ SAP
            .sapCodeCod("COD_TPB") // mã bảng kê đồng bộ SAP
            .partnerCode("TPB")
            .build();

    private static final StatementPayStatus bidvConfig = StatementPayStatus.builder()
            .billPay(92L) // trạng thái bill thanh toán thành công
            .billTran(1008L)
            .statementClear(91L)
            .statementCod(91L)
            .sapCodeClear("CUOC_BIDV") // mã bảng kê đồng bộ SAP
            .sapCodeCod("COD_BIDV") // mã bảng kê đồng bộ SAP
            .partnerCode("BIDV")
            .build();

    private static final StatementPayStatus VDS_MNT = StatementPayStatus.builder()
            .statementClear(3L)
            .statementCod(3L)
            .billPay(2L)
            .billTran(2L)
            .sapCodeClear("TKLK_CPN")
            .sapCodeCod("TKLK_BT")
            .partnerCode("VTMONEY")
            .build();

    private static final StatementPayStatus hdbConfig = StatementPayStatus.builder()
            .billPay(65L) // trạng thái bill thanh toán thành công
            .billTran(1014L)
            .statementClear(64L)
            .statementCod(64L)
            .sapCodeClear("CUOC_HDB") // mã bảng kê đồng bộ SAP
            .sapCodeCod("COD_HDB") // mã bảng kê đồng bộ SAP
            .partnerCode("HDB")
            .build();

    private static final StatementPayStatus hpayConfig = StatementPayStatus.builder()
            .billPay(98L) // trạng thái bill thanh toán thành công
            .billTran(1020L)
            .statementClear(97L)
            .statementCod(97L)
            .sapCodeClear_APPWEB("CUOCKH_HTP")
            .sapCodeClear("CUOC_HTP") // mã bảng kê đồng bộ SAP
            .sapCodeCod("COD_HTP") // mã bảng kê đồng bộ SAP
            .partnerCode("HPAY")
            .build();


    public static StatementPayStatus partnerStatusConfigByStatus(Integer status) {
        Map<Integer, StatementPayStatus> partnerStatusConfig = new LinkedHashMap<>();
        int partnerId = 0;
        if (Arrays.asList(51, 52).contains(status)) {
            partnerStatusConfig.put(2, BKConfig);
            partnerId = 2;
        } else if (Arrays.asList(61, 62).contains(status)) {
            partnerStatusConfig.put(3, VCBConfig);
            partnerId = 3;
        } else if (Arrays.asList(41, 42).contains(status)) {
            partnerStatusConfig.put(6, ViettelMoneyConfig);
            partnerId = 6;
        } else if (Arrays.asList(87, 88).contains(status)) {
            partnerStatusConfig.put(9, OcbConfig);
            partnerId = 9;
        } else if (Arrays.asList(57, 58).contains(status)) {
            partnerStatusConfig.put(8, stbConfig);
            partnerId = 8;
        } else if (Arrays.asList(91, 92).contains(status)) {
            partnerStatusConfig.put(4, bidvConfig);
            partnerId = 4;
        } else if (Arrays.asList(54, 55).contains(status)) {
            partnerStatusConfig.put(7, tpbConfig);
            partnerId = 7;
        } else if (Arrays.asList(64, 65).contains(status)) {
            partnerStatusConfig.put(16, hdbConfig);
            partnerId = 16;
        }else if(Arrays.asList(97, 98).contains(status)){
            partnerStatusConfig.put(26, hpayConfig);
            partnerId = 26;
        }
        return partnerStatusConfig.getOrDefault(partnerId, null);
    }
}
