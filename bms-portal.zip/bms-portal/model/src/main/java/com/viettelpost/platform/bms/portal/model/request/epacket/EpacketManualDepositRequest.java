package com.viettelpost.platform.bms.portal.model.request.epacket;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketManualDepositRequest {
    private String requestId;
    private String transactionCode;
    private BigDecimal amount;
    private String partnerSource;
    private String serviceType;
    private String merchantType;
    private String accountName;
    private Long cusId;
    private Long orgId;
    private String orgCode;
    private Long postId;
    private String postCode;
    private String reqPaymentTime;
    private List<ITEMS> items;

    @Data
    public static class ITEMS {
        private String billOriginal;
        private BigDecimal amountOriginal;
    }
}
