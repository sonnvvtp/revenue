package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.ApproverDTO;
import io.r2dbc.spi.Connection;
import reactor.core.publisher.Mono;

public interface ApproverRepository {

    Mono<ApproverDTO> getApproverByEmployeeCode(String employeeCode, Connection connection);

    Mono<Void> sendNotificationToApprover(ApproverDTO approver, String message,
            Connection connection);
}
