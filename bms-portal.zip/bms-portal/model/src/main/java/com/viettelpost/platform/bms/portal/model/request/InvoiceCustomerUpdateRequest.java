package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

import java.util.List;

@Data
public class InvoiceCustomerUpdateRequest {
    private String budgetUnitCode;
    private Integer customerType;
    private String invoiceConditionLv1;
    private String invoiceConditionLv2;
    private Boolean invoiceDetailByBill;
    private Integer fromDate;
    private Integer toDate;
    private Boolean autoMergeBill;
    private List<ServiceGroupRequest> serviceGroups;
}
