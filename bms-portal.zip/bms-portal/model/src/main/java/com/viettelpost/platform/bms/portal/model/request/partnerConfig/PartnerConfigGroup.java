package com.viettelpost.platform.bms.portal.model.request.partnerConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartnerConfigGroup {
    private String partnerSource;
    private String serviceType;
    private String merchantType;
    private String prefixCode;
    private int statusInternal;
    private Long partnerInternalId;
    private List<ConfigData> data;

    // getters and setters

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class ConfigData {
        private Long partnerExternalId;
        private int statusExternal;
        private String bankCode;
        private String logoPartnerExternal;
        private String partnerExternalName;
    }
}

