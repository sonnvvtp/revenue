package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.model.request.InvRecordUpdateRequest;
import com.viettelpost.platform.bms.portal.model.response.InvoiceRecordDetailResponse;
import com.viettelpost.platform.bms.portal.model.response.InvoiceRecordInfoResponse;
import com.viettelpost.platform.bms.portal.model.response.InvoiceRecordResponse;
import com.viettelpost.platform.bms.portal.repository.InvRecordRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@ApplicationScoped
@RequiredArgsConstructor
public class InvRecordRepositoryImpl implements InvRecordRepository {

    private final PgPool client;

    private final AuthenticationContext authCtx;

    @Override
    public Uni<Void> addOrdersToInvoice(Long recordId, List<Long> orderIds) {
        if (orderIds == null || orderIds.isEmpty()) {
            return Uni.createFrom().failure(new IllegalArgumentException("Danh sách đơn hàng trống"));
        }

        String inClause = orderIds.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));

        Uni<Void> voidUni = client.withTransaction(sqlConnection ->
                sqlConnection
                        .preparedQuery("""
                                    SELECT id FROM bms_payment.general_order
                                    WHERE id = ANY($1::bigint[]) AND invoice_status != 0
                                """)
                        .execute(Tuple.of(orderIds.toArray(new Long[0])))
                        .flatMap(rows -> {
                            if (rows.rowCount() > 0) {
                                return Uni.createFrom().failure(
                                        new IllegalArgumentException("Đơn hàng thêm vào không hợp lệ")
                                );
                            }
                            return Uni.createFrom().nullItem();
                        })

                        .flatMap(res -> sqlConnection
                                .preparedQuery("""
                                            SELECT id FROM bms_payment.invoice_record
                                            WHERE id = $1 AND record_status NOT IN (1, -1)
                                        """)
                                .execute(Tuple.of(recordId))
                                .flatMap(rows -> {
                                    if (rows.rowCount() > 0) {
                                        return Uni.createFrom().failure(
                                                new IllegalArgumentException("Trạng thái bảng kê không hợp lệ.")
                                        );
                                    }
                                    return Uni.createFrom().nullItem();
                                }))


                        .flatMap(res -> sqlConnection.preparedQuery("""
                                INSERT INTO bms_payment.invoice_record_line (created_by, updated_by, record_id, order_id, order_code, amount)
                                SELECT $1, $1, $2, o.id, o.order_code, o.order_amount_after_tax
                                FROM bms_payment.general_order o
                                WHERE o.id IN (""" + inClause + ")")
                                .execute(Tuple.of(authCtx.getCurrentUser().getUserId(), recordId))
                        )

                        .flatMap(res -> sqlConnection.preparedQuery("""
                                    UPDATE bms_payment.invoice_record r
                                    SET 
                                        amount_before_tax = sub.total_before_tax,
                                        amount_tax = sub.total_tax,
                                        amount_total = sub.total_amount - COALESCE(r.amount_deduct, 0),
                                        updated_by = $2
                                    FROM (
                                        SELECT 
                                            l.record_id,
                                            COALESCE(SUM(o.order_amount_before_tax), 0) AS total_before_tax,
                                            COALESCE(SUM(o.order_tax_amount), 0) AS total_tax,
                                            COALESCE(SUM(o.order_amount_after_tax), 0) AS total_amount
                                        FROM bms_payment.invoice_record_line l
                                        JOIN bms_payment.general_order o ON l.order_id = o.id
                                        WHERE l.record_id = $1
                                        GROUP BY l.record_id
                                    ) sub
                                    WHERE r.id = sub.record_id
                                """).execute(Tuple.of(recordId, authCtx.getCurrentUser().getUserId())))

                        .flatMap(res -> sqlConnection.preparedQuery("""
                                    UPDATE bms_payment.general_order o
                                    SET invoice_status = 1
                                    WHERE o.id IN (
                                        SELECT l.order_id
                                        FROM bms_payment.invoice_record_line l
                                        WHERE l.record_id = $1
                                    )
                                """).execute(Tuple.of(recordId)))

                        .flatMap(res -> sqlConnection.preparedQuery("""
                                            UPDATE bms_payment.invoice_record_item r
                                         SET
                                           unit_price = sub.amount_total,
                                           amount  = sub.amount_total * quantity
                                         FROM (
                                             SELECT
                                                ir.id, ir.amount_total
                                             FROM bms_payment.invoice_record ir
                                             WHERE ir.id = $1
                                         ) sub
                                         WHERE r.invoice_record_id = sub.id
                                """).execute(Tuple.of(recordId)))

        ).replaceWithVoid();
        return voidUni;
    }

    @Override
    public Multi<InvoiceRecordResponse> findListInvoiceRecordBy(List<BigDecimal> ids, List<Integer> status) {
        String sql = """
                select * from bms_payment.invoice_record
                where 1=1
                """;

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (!CollectionUtils.isEmpty(ids)) {
            sql += String.format(" and id = any($%d)", counter++);
            params.add(ids.toArray());
        }
        if (!CollectionUtils.isEmpty(status)) {
            sql += String.format(" and record_status = any($%d)", counter);
            params.add(status.toArray());
        }
        return executeMulti(client, sql, Tuple.from(params), InvoiceRecordResponse.class);
    }

    @Override
    public Uni<Boolean> updateStatusInvoiceRecord(List<BigDecimal> ids, Integer status, List<Integer> statusNeedUpd, Long userId, SqlConnection sqlConnection) {
        String sql = """
                update
                  bms_payment.invoice_record
                set
                    record_status = $1,
                    updated_at = current_timestamp,
                    updated_by = $2
                where 1 = 1
                """;

        List<Object> params = new ArrayList<>();
        params.add(status);
        params.add(userId);
        int counter = 3;

        if (!CollectionUtils.isEmpty(ids)) {
            sql += String.format(" and id = any($%d)", counter++);
            params.add(ids.toArray());
        }
        if (!CollectionUtils.isEmpty(statusNeedUpd)) {
            sql += String.format(" and record_status = any($%d)", counter);
            params.add(statusNeedUpd.toArray());
        }
        return executeOnly(client, sql, Tuple.from(params));
    }

    @Override
    public Uni<Void> deleteInvoiceRecord(Long recordId) {
        return client.withTransaction(conn ->
                conn.preparedQuery("""
                                    SELECT ir.amount_total,
                                           ARRAY_AGG(l.order_id) AS order_ids
                                    FROM bms_payment.invoice_record ir
                                    LEFT JOIN bms_payment.invoice_record_line l ON l.record_id = ir.id
                                    WHERE ir.id = $1 AND ir.record_status = 1
                                    GROUP BY ir.amount_total
                                """).execute(Tuple.of(recordId))

                        .flatMap(rows -> {
                            if (rows.rowCount() == 0) {
                                return Uni.createFrom().failure(
                                        new IllegalStateException("Chỉ được xóa bảng kê ở trạng thái tạo mới")
                                );
                            }

                            Row row = rows.iterator().next();
                            BigDecimal amountTotal = row.getBigDecimal("amount_total");

                            Long[] orderIdsArray = (Long[]) row.getValue("order_ids");


                            return conn.preparedQuery("DELETE FROM bms_payment.invoice_record_line WHERE record_id = $1")
                                    .execute(Tuple.of(recordId))

                                    .flatMap(_res1 -> conn.preparedQuery("DELETE FROM bms_payment.invoice_record_item WHERE invoice_record_id = $1")
                                            .execute(Tuple.of(recordId)))

                                    .flatMap(_res2 -> conn.preparedQuery("DELETE FROM bms_payment.invoice_record WHERE id = $1")
                                            .execute(Tuple.of(recordId)))

                                    .flatMap(_res3 -> conn.preparedQuery("""
                                                UPDATE bms_payment.general_order
                                                SET invoice_status = 0
                                                WHERE id = ANY($1::bigint[])
                                            """).execute(Tuple.of((Object) orderIdsArray)))

                                    .flatMap(_res4 -> conn.preparedQuery("""
                                                INSERT INTO bms_payment.invoice_record_delete_log
                                                (invoice_record_id, amount_total, order_ids, deleted_by)
                                                VALUES ($1, $2, $3, $4)
                                            """).execute(Tuple.of(recordId, amountTotal, (Object) orderIdsArray, authCtx.getCurrentUser().getUserId())));
                        })
        ).replaceWithVoid();
    }


    public Uni<Void> updateInvoiceRecordInfo(Long recordId, InvRecordUpdateRequest request) {
        return client.withTransaction(conn ->
                conn.preparedQuery("""
            SELECT 1 FROM bms_payment.invoice_record
            WHERE id = $1 AND record_status = 1
        """).execute(Tuple.of(recordId))
                        .flatMap(rows -> {
                            if (rows.rowCount() == 0) {
                                return Uni.createFrom().failure(
                                        new IllegalStateException("Chỉ được cập nhật bảng kê ở trạng thái tạo mới")
                                );
                            }

                            return conn.preparedQuery("""
                UPDATE bms_payment.invoice_record
                SET
                    email = $1,
                    address = $2,
                    customer_name = $3,
                    payment_method = $4,
                    updated_at = CURRENT_TIMESTAMP,
                    updated_by = $5
                WHERE id = $6
            """).execute(Tuple.of(request.getEmail(), request.getAddress(), request.getCustomerName(), request.getPaymentMethod(), authCtx.getCurrentUser().getUserId(), recordId));
                        })
        ).replaceWithVoid();
    }

    @Override
    public Uni<InvoiceRecordInfoResponse> getInvoiceRecordInfo(Long recordId) {
        return client.withConnection(conn ->
                conn.preparedQuery("""
                                    SELECT record_no, invoice_number, invoice_serial, invoice_form
                                    FROM bms_payment.invoice_record
                                    WHERE id = $1
                                """).execute(Tuple.of(recordId))
                        .flatMap(headerRows -> {
                            if (headerRows.rowCount() == 0) {
                                return Uni.createFrom().failure(new NotFoundException("Không tìm thấy bảng kê với ID: " + recordId));
                            }

                            Row header = headerRows.iterator().next();
                            InvoiceRecordInfoResponse dto = new InvoiceRecordInfoResponse();
                            dto.setRecordNo(header.getString("record_no"));
                            dto.setInvoiceForm(header.getString("invoice_number"));
                            dto.setInvoiceSerial(header.getString("invoice_serial"));
                            dto.setInvoiceForm(header.getString("invoice_form"));

                            return conn.preparedQuery("""
                                                SELECT 
                                                    go2.order_id, go2.order_code, go2.buyer_code, go2.order_created_at, 
                                                    io.item_code, io.item_name, io.item_unit, io.item_quantity, io.item_price, 
                                                    io.item_amount_before_tax, io.item_tax_percent, io.item_tax_amount,io.item_amount_after_tax, io.item_selection
                                                FROM bms_payment.general_order go2
                                                JOIN bms_payment.invoice_record_line irl ON irl.order_id = go2.id 
                                                JOIN bms_payment.invoice_record_item_order io ON io.order_id = go2.id
                                                WHERE irl.record_id = $1  order by item_code asc, item_selection asc
                                            """).execute(Tuple.of(recordId))
                                    .map(detailRows -> {
                                        List<InvoiceRecordDetailResponse> details = StreamSupport.stream(detailRows.spliterator(), false)
                                                .map(row -> {
                                                    InvoiceRecordDetailResponse detail = new InvoiceRecordDetailResponse();
                                                    detail.setOrderId(row.getString("order_id"));
                                                    detail.setOrderCode(row.getString("order_code"));
                                                    detail.setOrderCreatedAt(row.getLocalDateTime("order_created_at"));
                                                    detail.setItemCode(row.getString("buyer_code"));
                                                    detail.setItemCode(row.getString("item_code"));
                                                    detail.setItemName(row.getString("item_name"));
                                                    detail.setItemUnit(row.getString("item_unit"));
                                                    detail.setItemQuantity(row.getInteger("item_quantity"));
                                                    detail.setItemPrice(row.getBigDecimal("item_price"));
                                                    detail.setItemAmountBeforeTax(row.getBigDecimal("item_amount_before_tax"));
                                                    detail.setItemTaxPercent(row.getInteger("item_tax_percent"));
                                                    detail.setItemTaxAmount(row.getBigDecimal("item_tax_amount"));
                                                    detail.setItemAmountAfterTax(row.getBigDecimal("item_amount_after_tax"));
                                                    detail.setItemSelection(row.getInteger("item_selection"));
                                                    return detail;
                                                })
                                                .collect(Collectors.toList());

                                        dto.setDetails(details);
                                        return dto;
                                    });
                        })
        );
    }


}
