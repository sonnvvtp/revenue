package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class AdvanceReturnRecordDTO {
    @JsonAlias("ADVANCE_ACCT_ID")
    private Long advanceAcctId;

    @JsonAlias("ADVANCE_ACCT_NO")
    private String recordNo;

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_CODE")
    private String partnerCode;

    @JsonAlias("AMOUNT")
    private BigDecimal amount;

    @JsonAlias("CREATED_AT")
    private LocalDateTime createdAt;

    @JsonAlias("CREATED_BY")
    private String createdBy;
}
