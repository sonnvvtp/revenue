package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.request.GeneralOrderRequest;
import com.viettelpost.platform.bms.portal.service.handler.GeneralOrderService;
import io.smallrye.mutiny.Uni;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/general-order")
@Tag(name = "API hóa đơn")
@RequiredArgsConstructor
public class GeneralOrderController {
    private final GeneralOrderService generalOrderService;

    @GET
    @Path("/{id}")
    @Operation(summary = "Chi tiết hóa đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getGeneralOrderDetailById(@PathParam("id") Long id) {
        return generalOrderService.getGeneralOrderDetailById(id)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @POST
    @Path("get-invoice")
    @Operation(summary = "Danh sách hóa đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getGeneralOrder(@Valid GeneralOrderRequest request) {
        return generalOrderService.findInvoiceOrder(request)
                .map(querySearchResult -> BaseResponse.successApi(querySearchResult, "OK"));
    }
}
