package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PostgreClusterInfoResponse {

    @JsonAlias("node_id")
    private Long nodeId;

    @JsonAlias("hostname")
    private String hostname;

    @JsonAlias("port")
    private Integer port;

    @JsonAlias("status")
    private String status;

    @JsonAlias("role")
    private String role;

    @JsonAlias("select_cnt")
    private Integer selectCount;

    @JsonAlias("load_balance_node")
    private Boolean loadBalanceNode;

    @JsonAlias("replication_delay")
    private String replicationDelay;

    @JsonAlias("replication_state")
    private String replicationState;

    @JsonAlias("replication_sync_state")
    private String replicationSyncState;

    @JsonAlias("last_status_change")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", shape = JsonFormat.Shape.STRING)
    private Date lastStatusChange;
}
