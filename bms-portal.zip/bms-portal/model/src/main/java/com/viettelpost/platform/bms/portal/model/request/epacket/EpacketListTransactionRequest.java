package com.viettelpost.platform.bms.portal.model.request.epacket;

import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketListTransactionRequest {
    private Long cusId;
    private String transactionsCode;
    private Integer transactionType;
    private String fromDate;
    private String toDate;
    private Integer reconStatus;
    private  Integer accountingStatus;
    private  Integer walletType;
    private Integer page = 1;
    private Integer size = 10;
}
