package com.viettelpost.platform.bms.revenue.worker.repository.impl;

import com.viettelpost.platform.bms.common.utils.DataMappingUtils;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueAccountingType;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueStatementStatus;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueStatus;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueRecordDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueStatementDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.RevenueStatementSapDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.GeneralOrderEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueRecordEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLevel2Entity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLevel2LineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueStatementLineEntity;
import com.viettelpost.platform.bms.revenue.worker.repository.GloExpRevenueRepository;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class GloExpRevenueRepositoryImpl implements GloExpRevenueRepository {

    private final PgPool pgPool;

    private final ConnectionPool oraclePool;

    @ConfigProperty(name = "discount.cal.log.batchSize", defaultValue = "500")
    Integer batchSize;

    @Override
    public Uni<Boolean> checkExistedInvoiceOrder(String domainType, String orderCode, Integer orderType, Integer picType, String source) {
        List<Object> params = new ArrayList<>();
        String tableName;
        String sql = null;
        if (Objects.nonNull(domainType)) {
            tableName = "bms_payment." + domainType;
            sql = "select 1 as existed from " + tableName + " where record_code = $1 and record_source = $2 and record_type = $3 and pic_type = $4";
        }
        params.add(orderCode);
        params.add(source);
        params.add(orderType);
        params.add(picType);
        return executeAndGetValue(pgPool, sql, Tuple.from(params), "existed", Integer.class)
                .map(Objects::nonNull);
    }

    @Override
    public Multi<GeneralOrderEntity> saveBatchGeneralOrder(String domainType, List<GeneralOrderEntity> entities, SqlConnection sqlConnection) {

        String tableName = null;
        if (Objects.nonNull(domainType)) {
            tableName = "bms_payment." + domainType;
        }
        String sqlInsert = "insert into " + tableName +
            """
                (tenant_id
                ,created_by
                ,created_at
                ,updated_by
                ,updated_at
                ,record_id
                ,record_code
                ,record_reference
                ,cashflow_type
                ,service_code
                ,record_created_at
                ,record_delivered_at
                ,unit_level1_id
                ,unit_level2_id
                ,unit_info
                ,company_code
                ,seller_id
                ,seller_code
                ,seller_info
                ,buyer_id
                ,buyer_code
                ,buyer_info
                ,consignee_id
                ,consignee
                ,record_total_quantity
                ,record_amount_before_tax
                ,record_tax_amount
                ,record_amount_after_tax
                ,total_amount
                ,payment_status
                ,payment_info
                ,payment_method
                ,payment_term_id
                ,revenue_sync_status
                ,invoice_status
                ,invoice_partner
                ,currency
                ,record_source
                ,record_type
                ,pic_type
                ,pic_info
                ,pic_id
                ,request_type
                ,record_name
                ,record_parent
                ,employee_id
                ,employee_info)
                 values
            """;

        String sqlBindParams = """
            (
                 ?,
                 ?,
                 current_timestamp,
                 ?,
                 current_timestamp,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?,
                 ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            GeneralOrderEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt");
    }

    @Override
    public Multi<InvoiceInfoEntity> saveInvoiceInfo(String domainType, List<InvoiceInfoEntity> entities, SqlConnection sqlConnection) {

        if (CollectionUtils.isEmpty(entities)) {
            return Multi.createFrom().empty();
        }

        String tableName = null;
        if (Objects.nonNull(domainType)) {
            tableName = "bms_payment." + "invoice_info";
        }
        String sqlInsert = "insert into " + tableName +
        """
            (tenant_id
            ,created_by
            ,created_at
            ,updated_by
            ,updated_at
            ,general_order_id
            ,order_id
            ,buyer_id
            ,buyer_type
            ,buyer_name
            ,partner_name
            ,buyer_phone
            ,buyer_email
            ,buyer_tax_code
            ,buyer_address
            ,buyer_bank_account
            ,buyer_bank_name) values 
            """;

        String sqlBindParams = """
            (
                  ?,
                  ?,
                  current_timestamp,
                  ?,
                  current_timestamp,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?,
                  ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            InvoiceInfoEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt");
    }

    @Override
    public Multi<ItemOrderEntity> saveBatchItemOrder(String domainType, List<ItemOrderEntity> entities,
                                            SqlConnection sqlConnection) {

        if (CollectionUtils.isEmpty(entities)) {
            return Multi.createFrom().empty();
        }

        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment." + domainType + "_item_record";
        }
        String sqlInsert = "insert into " + tableName +
            """
                (tenant_id
                  ,created_by
                  ,created_at
                  ,updated_by
                  ,updated_at
                  ,record_id
                  ,departure_location
                  ,arrival_location
                  ,vehicle_plateNumber
                  ,warehouse_code
                  ,item_selection
                  ,item_code
                  ,item_name
                  ,item_note
                  ,item_unit
                  ,item_quantity
                  ,item_price
                  ,item_weight
                  ,item_amount_before_tax
                  ,item_tax_type
                  ,item_tax_percent
                  ,item_tax_amount
                  ,item_amount_after_tax
                  ,attribute1
                  ,attribute2
                  ,attribute3
                 ) values
                """;

        String sqlBindParams = """
            (
                   ?,
                   ?,
                   current_timestamp,
                   ?,
                   current_timestamp,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            ItemOrderEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt");
    }

    @Override
    public Uni<Integer> groupByBillRevenueCount(BigDecimal periodId, String domainType, RevenueType revenueType) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment." + domainType + "_record";
        }

        String sql = """
                        select
                          count(gr.*) total
                        from
                          (
                          select
                            unit_level2_id ,
                            buyer_code ,
                            service_code,
                            record_source
                          from
                    """
                    + tableName +
                    """
                        where
                            		record_source = $1
                            		and revenue_sync_status = $2
                            		and record_type = $3
                            		and period_id = $4
                            	group by
                            		unit_level2_id ,
                            		buyer_code ,
                            		service_code,
                            		record_source
                            ) gr
                    """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(revenueType.getValue());
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);

    }

    @Override
    public Multi<GroupRevenueRecordDTO> findGroupByRevenueRecord(BigDecimal periodId, String domainType,
        RevenueType revenueType, Integer page, Integer size) {
        String tableName = null;
        String tableItemName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment." + domainType + "_record rvr";
            tableItemName = "bms_payment." + domainType + "_item_record rvir";
        }

        String sql = """
                    select
                    gr.*
                      from
                      	(
                      	select
                      	  rvr.unit_level1_id,
                      		rvr.unit_level2_id,
                      		rvr.buyer_code ,
                      		rvr.service_code,
                      		rvr.record_source,
                      		count(1) total_bill,
                      		sum(rvr.record_amount_before_tax) amount_before_tax,
                      		sum(rvr.record_tax_amount) tax_amount,
                      		sum(rvir.item_amount_after_tax) discount_amount,
                      		sum(rvr.record_amount_after_tax) amount_after_tax,
                      		json_agg(
                            json_build_object(
                                'id', rvr.id,
                                'code', rvr.record_code,
                                'amount', rvr.record_amount_after_tax,
                                'company', rvr.company_code
                            )
                          ) as records
                      	from
                    """
            + tableName +
            """
                 left join
                
                """
            + tableItemName +
            """ 
                on rvir.record_id = rvr.id  and rvir.item_selection = 3
                where
                    rvr.record_source = $1
                    and rvr.revenue_sync_status = $2
                    and rvr.record_type = $3
                    and period_id = $4
                  group by
                    rvr.unit_level1_id,
                    rvr.unit_level2_id,
                    rvr.buyer_code ,
                    rvr.service_code,
                    rvr.record_source
                ) gr
                limit $5 offset $6
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(revenueType.getValue());
        params.add(periodId);
        params.add((size * page + size));
        params.add(size * page);

        return executeMulti(pgPool, sql, Tuple.from(params), GroupRevenueRecordDTO.class);
    }

    @Override
    public Uni<Integer> groupByBillRevenueCountV2(BigDecimal periodId, String domainType, RevenueType revenueType) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_record";
        }

        String sql = """
                        select
                          count(gr.*) total
                        from
                          (
                          select
                            post_id ,
                            buyer_code ,
                            service_code,
                            record_source
                          from
                    """
            + tableName +
            """
                where
                        record_source = $1
                        and revenue_sync_status = $2
                        and record_type = $3
                        and period_id = $4 and record_amount_after_tax >= 0
                      group by
                        post_id ,
                        buyer_code ,
                        service_code,
                        record_source
                    ) gr
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(revenueType.getValue());
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);

    }

    @Override
    public Multi<GroupRevenueRecordDTO> findGroupByRevenueRecordV2(BigDecimal periodId, String domainType,
        RevenueType revenueType, Integer page, Integer size) {
        String tableName = null;
        String tableItemName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_record rvr";
            tableItemName = "bms_payment.revenue_record_item rvir";
        }

        String sql = """
                    select
                    gr.*
                      from
                      	(
                      	select
                      	  rvr.org_id unit_level1_id,
                      		rvr.post_id unit_level2_id,
                      		rvr.buyer_code ,
                      		rvr.service_code,
                      		rvr.record_source,
                      		count(1) total_bill,
                      		sum(rvr.record_amount_before_tax) amount_before_tax,
                      		sum(rvr.record_tax_amount) tax_amount,
                      		sum(rvir.item_amount_after_tax) discount_amount,
                      		sum(rvr.record_amount_after_tax) amount_after_tax,
                      		(sum(rvr.record_amount_after_tax) - sum(coalesce(rvir.item_amount_after_tax, 0))) total_amount,
                      		sum(coalesce(rvir.item_amount_before_tax, 0)) amount_discount_before_tax,
                      		sum(coalesce(rvir.item_tax_amount, 0)) amount_discount_tax,
                      		sum(coalesce(rvir.item_amount_after_tax, 0)) amount_discount_after_tax,
                      		json_agg(
                            json_build_object(
                                'id', rvr.id,
                                'code', rvr.record_code,
                                'amount', rvr.record_amount_after_tax,
                                'postCode', rvr.post_code,
                                'postName', rvr.post_name,
                                'orgCode', rvr.org_code,
                                'orgName', rvr.org_name,
                                'company', rvr.company_code
                            )
                          ) as records
                      	from
                    """
            + tableName +
            """
                 left join
                
                """
            + tableItemName +
            """ 
                on rvir.record_id = rvr.order_id and rvir.item_selection = 3
                where
                    rvr.record_source = $1
                    and rvr.revenue_sync_status = $2
                    and rvr.record_type = $3
                    and period_id = $4 and record_amount_after_tax >= 0
                  group by
                    rvr.org_id,
                    rvr.post_id,
                    rvr.buyer_code ,
                    rvr.service_code,
                    rvr.record_source
                ) gr
                limit $5 offset $6
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(revenueType.getValue());
        params.add(periodId);
        params.add((size * page + size));
        params.add(size * page);

        return executeMulti(pgPool, sql, Tuple.from(params), GroupRevenueRecordDTO.class);
    }

    @Override
    public Multi<RevenueStatementEntity> saveBatchRevenueStatement(List<RevenueStatementEntity> entities,
        SqlConnection sqlConnection) {
        String tableName = "bms_payment.revenue_statement";

        String sqlInsert = "insert into " + tableName +
            """
                (   tenant_id
                     ,created_by
                     ,created_at
                     ,updated_by
                     ,updated_at
                     ,statement_code
                     ,description
                     ,service_code
                     ,unit_level1_id
                     ,unit_level1_code
                     ,unit_level1_name
                     ,unit_level2_id
                     ,unit_level2_code
                     ,unit_level2_name
                     ,company_code
                     ,customer_code
                     ,customer_name
                     ,statement_amount_before_tax
                     ,statement_tax_amount
                     ,statement_amount_after_tax
                     ,statement_amount_discount
                     ,total_amount
                     ,revenue_sync_status
                     ,revenue_accounting_status
                     ,currency
                     ,statement_source
                     ,record_size
                     ,record_type
                     ,period_id
                     ,statement_business_id
                     ,amount_discount_before_tax
                     ,amount_discount_tax
                 ) values
                """;

        String sqlBindParams = """
            (
                   ?,
                     ?,
                     current_timestamp,
                     ?,
                     current_timestamp,
                     bms_payment.gen_sequence_next(?, 6)::varchar,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?,
                     ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            RevenueStatementEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt", "records");
    }

    @Override
    public Multi<RevenueStatementLineEntity> saveBatchRevenueStatementLine(
        List<RevenueStatementLineEntity> entities, SqlConnection sqlConnection) {
        String tableName = "bms_payment.revenue_statement_line";

        String sqlInsert = "insert into " + tableName +
            """
                (tenant_id
                ,created_by
                ,created_at
                ,updated_by
                ,updated_at
                ,record_id
                ,record_code
                ,statement_id
                ,statement_code
                ,total_amount
                 ) values
                """;

        String sqlBindParams = """
            (
                  ?,
                   ?,
                   current_timestamp,
                   ?,
                   current_timestamp,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            RevenueStatementLineEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt");
    }

    @Override
    public Uni<RevenueStatementLevel2Entity> saveRevenueStatementLevel2(RevenueStatementLevel2Entity entity,
        SqlConnection sqlConnection) {
        String sql = """
                insert into bms_payment.revenue_statement_level2(
                                                    tenant_id
                                                   ,created_by
                                                   ,created_at
                                                   ,updated_by
                                                   ,updated_at
                                                   ,statement_code
                                                   ,description
                                                   ,unit_level1_id
                                                   ,unit_level1_code
                                                   ,unit_level1_name
                                                   ,unit_level2_id
                                                   ,unit_level2_code
                                                   ,unit_level2_name
                                                   ,company_code
                                                   ,statement_amount_before_tax
                                                   ,statement_tax_amount
                                                   ,statement_amount_discount
                                                   ,statement_amount_after_tax
                                                   ,total_amount
                                                   ,item_quantity
                                                   ,revenue_sync_status
                                                   ,revenue_accounting_status
                                                   ,currency
                                                   ,period_id
                                                   ,statement_source)
                values ($1
                      ,$2
                      ,current_timestamp
                      ,$3
                      ,current_timestamp
                      ,bms_payment.gen_sequence_next($4, 7)::varchar
                      ,$5
                      ,$6
                      ,$7
                      ,$8
                      ,$9
                      ,$10
                      ,$11
                      ,$12
                      ,$13
                      ,$14
                      ,$15
                      ,$16
                      ,$17
                      ,$18
                      ,$19
                      ,$20
                      ,$21
                      ,$22
                      ,$23
                )
                returning id,statement_code
                """;
        List<Object> params = new ArrayList<>();

        params.addAll(DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), RevenueStatementLevel2Entity.class);
        }

        return execute(pgPool, sql, Tuple.from(params), RevenueStatementLevel2Entity.class);
    }

    @Override
    public Uni<Integer> findGroupByRevenueStatementCount(BigDecimal periodId,
        SqlConnection sqlConnection) {

        String sql = """
                        select
                          count(1) total
                        from bms_payment.revenue_statement
                        where
                            period_id = $1
                            and revenue_sync_status = $2
                    """;

        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(RevenueStatementStatus.CHOT_BANG_KE.getCode());

        if (Objects.nonNull(sqlConnection)) {
            return executeAndGetValue(sqlConnection, sql, Tuple.from(params), "total", Integer.class);
        }

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<RevenueStatementEntity> findRevenueStatementBy(BigDecimal periodId, Integer page, Integer size,
        SqlConnection sqlConnection) {

        String sql = """
                        select *
                        from bms_payment.revenue_statement
                        where
                            period_id = $1
                            and revenue_sync_status = $2
                            limit $3 offset $4
                    """;

        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(RevenueStatementStatus.CHOT_BANG_KE.getCode());
        params.add((size * page + size));
        params.add(size * page);

        if (Objects.nonNull(sqlConnection)) {
            return executeMulti(sqlConnection, sql, Tuple.from(params), RevenueStatementEntity.class);
        }

        return executeMulti(pgPool, sql, Tuple.from(params), RevenueStatementEntity.class);
    }

    @Override
    public Multi<RevenueStatementLevel2LineEntity> saveBatchRevenueStatementLevel2Line(
        List<RevenueStatementLevel2LineEntity> entities, SqlConnection sqlConnection) {
        String tableName = "bms_payment.revenue_statement_level2_line";

        String sqlInsert = "insert into " + tableName +
            """
                (tenant_id
                ,created_by
                ,created_at
                ,updated_by
                ,updated_at
                ,statement_id
                ,statement_code
                ,statement_level2_id
                ,statement_level2_code
                ,total_amount
                 ) values
                """;

        String sqlBindParams = """
            (
                  ?,
                   ?,
                   current_timestamp,
                   ?,
                   current_timestamp,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            RevenueStatementLevel2LineEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt");
    }

    @Override
    public Uni<GroupRevenueStatementDTO> findGroupByRevenueStatement(BigDecimal periodId,
        SqlConnection sqlConnection) {

        String sql = """
                        select
                          count(1) total_bill,
                          sum(statement_amount_before_tax) total_fee_shipping,
                          sum(statement_amount_discount) total_amt_deduct,
                          sum(statement_tax_amount) tax_amount,
                          sum(total_amount) total_amt
                        from bms_payment.revenue_statement
                        where
                            period_id = $1
                    """;

        List<Object> params = new ArrayList<>();
        params.add(periodId);

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), GroupRevenueStatementDTO.class);
        }

        return execute(pgPool, sql, Tuple.from(params), GroupRevenueStatementDTO.class);
    }

    @Override
    public Uni<Boolean> updateRevenueStatementLevel2By(BigDecimal statementId, GroupRevenueStatementDTO groupRevenueStatement,
        SqlConnection sqlConnection) {
        String sql = """
                update
                  bms_payment.revenue_statement_level2
                set
                    item_quantity = $1,
                    statement_amount_before_tax = $2,
                    statement_amount_discount = $3,
                    statement_tax_amount = $4,
                    total_amount = $5
                where
                  id = $6
                """;

        List<Object> params = new ArrayList<>();
        params.add(groupRevenueStatement.getTotalBill());
        params.add(groupRevenueStatement.getTotalFeeShipping());
        params.add(groupRevenueStatement.getTotalAmtDeduct());
        params.add(groupRevenueStatement.getTaxAmount());
        params.add(groupRevenueStatement.getTotalAmt());
        params.add(statementId);

        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.from(params));
        }

        return executeOnly(pgPool, sql, Tuple.from(params));
    }

    @Override
    public Uni<Integer> findAllRevenueStatementCount(BigDecimal periodId, RevenueType revenueType,
        SqlConnection sqlConnection) {
        String sql = """
                    select count(1) as total
                    from bms_payment.revenue_statement rs
                    """;
        sql = sql + """
                    where rs.period_id = $1 and revenue_sync_status = $2 
                    """;
        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(RevenueStatementStatus.CHOT_BANG_KE.getCode());
        switch (revenueType) {
            case TEMPORARY_REVENUE: //Doanh thu tạm tính
                sql = sql + """
                                 and rs.record_type = $3
                                """;
                params.add(RevenueType.TEMPORARY_REVENUE.getValue());
                break;
            case COMPLETED_REVENUE2: // Doanh thu hoàn thành - Bill ko có trạng thái cuối
                sql = sql + """
                                 and rs.record_type = $3
                                """;
                params.add(RevenueType.COMPLETED_REVENUE2.getValue());
                break;
            case COMPLETED_REVENUE3: // DTHT_CTTC - Doanh thu hoàn thành - có trạng thái cuối
                sql = sql + """
                                 and rs.record_type = $3
                                """;
                params.add(RevenueType.COMPLETED_REVENUE3.getValue());
                break;
            default :
                break;
        }

        if (Objects.nonNull(sqlConnection)) {
            return executeAndGetValue(sqlConnection, sql, Tuple.from(params), "total", Integer.class);
        }

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<RevenueStatementSapDTO> findAllRevenueStatementBy(BigDecimal periodId, RevenueType revenueType, Integer page, Integer size,
        SqlConnection sqlConnection) {

        String sql = """
                        select
                          rs.*,
                          rsl.statement_code statement_level2_code,
                          (select group_service from bms_payment.revenue_service_group rsg where rsg.service_code = rs.service_code limit 1) group_service,
                          (  select rr.record_revenue_entry_at \s
                             from bms_payment.revenue_record rr
                             join bms_payment.revenue_statement_line rsl  on rsl.record_id  = rr.id
                             join bms_payment.revenue_statement rssub on rssub.id = rsl.statement_id\s
                             where rssub.id = rs.id \s
                             LIMIT 1) record_revenue_entry_at
                        from
                          bms_payment.revenue_statement rs
                        join bms_payment.revenue_statement_level2_line rsll on
                          rsll.statement_id = rs.id
                        join bms_payment.revenue_statement_level2 rsl on
                          rsl.id = rsll.statement_level2_id
                        where
                          rs.period_id = $1 and rs.revenue_sync_status = $2
                    """;
        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(RevenueStatementStatus.CHOT_BANG_KE.getCode());
        switch (revenueType) {
            case TEMPORARY_REVENUE: //Doanh thu tạm tính
                sql = sql + """
                                 and rs.record_type = $3
                                """;
                params.add(RevenueType.TEMPORARY_REVENUE.getValue());
                break;
            case COMPLETED_REVENUE2: // Doanh thu hoàn thành - Bill ko có trạng thái cuối
                sql = sql + """
                                 and rs.record_type = $3
                                """;
                params.add(RevenueType.COMPLETED_REVENUE2.getValue());
                break;
            case COMPLETED_REVENUE3: // DTHT_CTTC - Doanh thu hoàn thành - có trạng thái cuối
                sql = sql + """
                                 and rs.record_type = $3
                                """;
                params.add(RevenueType.COMPLETED_REVENUE3.getValue());
                break;
            default :
                break;
        }

        sql = sql + """
                       limit $4 offset $5
                """;

        params.add((size * page + size));
        params.add(size * page);

        if (Objects.nonNull(sqlConnection)) {
            return executeMulti(sqlConnection, sql, Tuple.from(params), RevenueStatementSapDTO.class);
        }

        return executeMulti(pgPool, sql, Tuple.from(params), RevenueStatementSapDTO.class);
    }

    @Override
    public Uni<Boolean> updateRevenueStatementBy(List<BigDecimal> ids, int status, SqlConnection sqlConnection) {
        String tableName = "bms_payment.revenue_statement";

        String sql = """
                update 
                """
                + tableName +
                """
                 set
                    revenue_sync_status = $1,
                    statement_accounting_date = current_timestamp
                where
                  id = any($2)
                """;

        List<Object> params = new ArrayList<>();
        params.add(status);
        params.add(ids.toArray());

        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.from(params));
        }

        return executeOnly(pgPool, sql, Tuple.from(params));
    }

    @Override
    public Uni<Boolean> updateRevenueRecordBy(List<BigDecimal> ids, int status, SqlConnection sqlConnection) {
        String tableName = "bms_payment.revenue_vtp_record";

        String sql = """
                update 
                """
            + tableName +
            """
             set
                revenue_sync_status = $1
            where
              id = any($2)
            """;

        List<Object> params = new ArrayList<>();
        params.add(status);
        params.add(ids.toArray());

        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.from(params));
        }

        return executeOnly(pgPool, sql, Tuple.from(params));
    }

    @Override
    public Uni<Void> updateBatchRevenueRecord(List<RevenueRecordEntity> statementLineEntityList,
        SqlConnection sqlConnection) {

        Uni<Void> uniProcess = Uni.createFrom().voidItem();
        String updateSql = """
                    update bms_payment.revenue_record
                    set
                        revenue_sync_status = $1,
                        statement_id = $2,
                        statement_code = $3,
                        updated_at = current_timestamp,
                        updated_by = $4
                    where id = $5
                    """;

        uniProcess = uniProcess.chain(() -> executeOnlyUpdatePostgreBatch(
            sqlConnection,
            updateSql,
            statementLineEntityList,
            "id",
            batchSize,
            "id", "updated_at"

        ).replaceWithVoid());
        return uniProcess;
    }

    @Override
    public Multi<RevenuePeriodControlEntity> findRevenuePeriodControlBy(String status) {
        String sql = """
                        select
                        *
                       from
                        bms_payment.revenue_period_control
                       where
                        period_status = $1 and active = $2
                    """;
        List<Object> params = new ArrayList<>();
        params.add(status);
        params.add("Y");

        return executeMulti(pgPool, sql, Tuple.from(params), RevenuePeriodControlEntity.class);
    }

    @Override
    public Uni<Long> findAllRevenueVtpRecordCount(BigDecimal periodId, String domainType) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment." + domainType + "_record";
        }

        String sql = """
                        select
                            count(1) total
                        from
                    """
            + tableName +
            """
                        where
                            record_source = $1
                            and period_id = $2
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Long.class);
    }

    @Override
    public Uni<Long> findAllRevenueRecordCount(BigDecimal periodId, String domainType) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_record";
        }

        String sql = """
                        select
                            count(1) total
                        from
                    """
            + tableName +
            """
                        where
                            record_source = $1
                            and period_id = $2
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Long.class);
    }

    @Override
    public Uni<Boolean> updateRevenuePeriodControl(BigDecimal id, String status, LocalDateTime startDate, LocalDateTime endDate, SqlConnection sqlConnection) {

        List<Object> params = new ArrayList<>();
        int counter = 1;

        String updateSql = """
                    update bms_payment.revenue_period_control
                    set
                        updated_at = current_timestamp
                        """;
        updateSql += String.format(", updated_by = $%d, period_status = $%d ", counter++, counter++);
        params.add(-1);
        params.add(status);

        if (Objects.nonNull(startDate) && Objects.nonNull(endDate)) {
            updateSql += String.format(", start_date = $%d, end_date = $%d ", counter++, counter++);
            params.add(startDate);
            params.add(endDate);
        }
        updateSql += String.format(" where id = $%d ", counter);
        params.add(id);

        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, updateSql, Tuple.from(params));
        }
        return executeOnly(pgPool, updateSql, Tuple.from(params));
    }

    @Override
    public Uni<Integer> checkRevenuePeriodControlIsExists(BigDecimal periodId) {
        String sql = """
                        select
                        count(1) total
                       from
                        bms_payment.revenue_period_control
                       where
                        period_id = $1
                    """;
        List<Object> params = new ArrayList<>();
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Uni<RevenuePeriodControlEntity> save(RevenuePeriodControlEntity entity, SqlConnection sqlConnection) {

        String sql = """
            insert into bms_payment.revenue_period_control
            (
                tenant_id
                ,created_by
                ,created_at
                ,updated_by
                ,updated_at
                ,period_id
                ,period_status
                ,start_date
                ,end_date
            )
            values (
                   $1
                  ,$2
                  ,current_timestamp
                  ,$3
                  ,current_timestamp
                  ,$4
                  ,$5
                  ,$6
                  ,$7
            )
            returning *
            """;
        List<Object> params = new ArrayList<>();
        params.addAll(DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt", "doctypeId", "active"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), RevenuePeriodControlEntity.class);
        }

        return execute(pgPool, sql, Tuple.from(params), RevenuePeriodControlEntity.class);
    }

    @Override
    public Uni<Integer> groupByRevenueBillEditCount(BigDecimal periodId, String domainType,
        RevenueType revenueType) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_record";
        }

        String sql = """
                        select
                          count(gr.*) total
                        from
                          (
                          select
                            record_reference,
                            post_id ,
                            buyer_code ,
                            service_code,
                            record_source
                          from
                    """
            + tableName +
            """
                where
                        record_source = $1
                        and revenue_sync_status = $2
                        and record_type = $3
                        and period_id = $4 and record_amount_after_tax < 0
                      group by
                        record_reference,
                        post_id ,
                        buyer_code ,
                        service_code,
                        record_source
                    ) gr
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(revenueType.getValue());
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<GroupRevenueRecordDTO> findGroupByRevenueBillEdit(BigDecimal periodId,
        String domainType, RevenueType revenueType, Integer page, Integer size) {
        String tableName = null;
        String tableItemName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_record rvr";
            tableItemName = "bms_payment.revenue_record_item rvir";
        }

        String sql = """
                    select
                    gr.*
                      from
                      	(
                      	select
                      	  rvr.record_reference,
                      	  rvr.org_id unit_level1_id,
                      		rvr.post_id unit_level2_id,
                      		rvr.buyer_code ,
                      		rvr.service_code,
                      		rvr.record_source,
                      		count(1) total_bill,
                      		sum(rvr.record_amount_before_tax) amount_before_tax,
                      		sum(rvr.record_tax_amount) tax_amount,
                      		sum(rvir.item_amount_after_tax) discount_amount,
                      		sum(rvr.record_amount_after_tax) amount_after_tax,
                      		(sum(rvr.record_amount_after_tax) - sum(coalesce(rvir.item_amount_after_tax, 0))) total_amount,
                      		sum(coalesce(rvir.item_amount_before_tax, 0)) amount_discount_before_tax,
                      		sum(coalesce(rvir.item_tax_amount, 0)) amount_discount_tax,
                      		sum(coalesce(rvir.item_amount_after_tax, 0)) amount_discount_after_tax,
                      		json_agg(
                            json_build_object(
                                'id', rvr.id,
                                'code', rvr.record_code,
                                'amount', rvr.record_amount_after_tax,
                                'postCode', rvr.post_code,
                                'postName', rvr.post_name,
                                'orgCode', rvr.org_code,
                                'orgName', rvr.org_name,
                                'company', rvr.company_code
                            )
                          ) as records
                      	from
                    """
            + tableName +
            """
                 left join
                
                """
            + tableItemName +
            """ 
                on rvir.record_id = rvr.order_id and rvir.item_selection = 3
                where
                    rvr.record_source = $1
                    and rvr.revenue_sync_status = $2
                    and rvr.record_type = $3
                    and period_id = $4 and record_amount_after_tax < 0
                  group by
                    rvr.record_reference,
                    rvr.org_id,
                    rvr.post_id,
                    rvr.buyer_code ,
                    rvr.service_code,
                    rvr.record_source
                ) gr
                limit $5 offset $6
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(revenueType.getValue());
        params.add(periodId);
        params.add((size * page + size));
        params.add(size * page);

        return executeMulti(pgPool, sql, Tuple.from(params), GroupRevenueRecordDTO.class);
    }
}
