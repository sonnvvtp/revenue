package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.VehicleTypeGroupDTO;
import com.viettelpost.platform.bms.portal.model.model.CarManagementSettingModel;
import com.viettelpost.platform.bms.portal.model.model.VehicleTypeGroupModel;
import com.viettelpost.platform.bms.portal.model.request.VehicleTypeGroupFilter;
import com.viettelpost.platform.bms.portal.model.response.CarLicensePlateResponse;
import com.viettelpost.platform.bms.portal.model.response.VehicleTypeGroupResponse;
import com.viettelpost.platform.bms.portal.model.response.VehicleTypeResponse;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.util.List;
import java.util.Map;
import reactor.core.publisher.Mono;

public interface CarManagementRepository {

    Uni<List<String>> findAllCarUnits(String search, int page, int size);

    Uni<List<String>> findAllCarLicensePlatesByUnit(String unit, String search, Integer page,
            Integer size);

    Uni<List<CarLicensePlateResponse>> findAllCarLicensePlatesInWaitingApprove(Long receiptId);

    Uni<List<String>> getCarLicensePlateByReceiptId(Long receiptId);

    Uni<Integer> countBillDetailLv3ByReceiptId(Long receiptId);

    Uni<List<CarLicensePlateResponse>> getListBillDetailLv3ByCarLicensePlate(
            List<String> carLicensePlates);

    Uni<List<VehicleTypeResponse>> getVehicleTypes();

    Uni<List<VehicleTypeResponse>> getVehicleTypesNotInGroup();

    Uni<List<VehicleTypeGroupResponse>> getVehicleTypeGroups(VehicleTypeGroupFilter filter);

    Uni<Long> countVehicleTypeGroups(VehicleTypeGroupFilter filter);

    Uni<VehicleTypeGroupDTO> findVehicleTypeGroupById(Long id);

    Uni<Long> createVehicleTypeGroup(String name, String vehicleTypeCodes,
            Boolean isSyncInvoice);

    Uni<Boolean> updateVehicleTypeGroup(Long id, String name, String vehicleTypeCodes,
            Boolean isSyncInvoice);

    Uni<Boolean> deleteVehicleTypeGroup(Long id);

    Mono<Map<String, String>> getKmcpIdByCarLicensePlates(List<String> carLicensePlates);

    Mono<List<String>> getVehicleTypesForSyncInvoice();

    Mono<List<String>> getValidCarLicensePlatesInTypes(List<String> types);

    Mono<String> getKMCPId(String carLicensePlate);

    Uni<Boolean> updateTypeGroupByType(List<String> vehicleTypes, Long vehicleTypeGroupId);
}
