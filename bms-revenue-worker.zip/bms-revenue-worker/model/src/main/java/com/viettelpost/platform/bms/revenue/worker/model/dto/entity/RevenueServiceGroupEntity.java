package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevenueServiceGroupEntity {
    @JsonAlias("id")
    private Long id;

    @JsonAlias("service_code")
    private String serviceCode;

    @JsonAlias("service_name")
    private Long serviceName;

    @JsonAlias("apply_status")
    private Integer applyStatus;
}
