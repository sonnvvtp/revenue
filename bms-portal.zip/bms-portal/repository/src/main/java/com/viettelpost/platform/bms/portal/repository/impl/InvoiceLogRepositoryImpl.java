package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.request.InvoiceLogRequest;
import com.viettelpost.platform.bms.portal.model.response.InvoiceLogResponse;
import com.viettelpost.platform.bms.portal.model.response.InvoiceLogResponse.InvoiceLogItem;
import com.viettelpost.platform.bms.portal.repository.InvoiceLogRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import io.smallrye.mutiny.Uni;
import reactor.core.publisher.Mono;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class InvoiceLogRepositoryImpl implements InvoiceLogRepository {

    @Inject
    PgPool client;

    private InvoiceLogItem mapRowToInvoiceLogItem(Row row) {
        String requestAt = "";
        try {
            if (row.getLocalDateTime("request_at") != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
                requestAt = row.getLocalDateTime("request_at").format(formatter);
            }
        } catch (Exception e) {
            log.warn("Column request_at not found or invalid format", e);
        }

        return new InvoiceLogItem()
                .setId(getLongValue(row, "id"))
                .setInvoiceRecordId(getLongValue(row, "invoice_record_id"))
                .setRequestAt(requestAt)
                .setLogRequest(getStringValue(row, "log_request"))
                .setLogResponse(getStringValue(row, "log_response"))
                .setLogStatus(getIntegerValue(row, "log_status"))
                .setErrCode(getIntegerValue(row, "err_code"))
                .setErrMsg(getStringValue(row, "err_msg"))
                .setRecordNo(getStringValue(row, "record_no"));
    }

    private String getStringValue(Row row, String columnName) {
        try {
            return row.getString(columnName) != null ? row.getString(columnName) : "";
        } catch (Exception e) {
            log.warn("Column {} not found or invalid format", columnName);
            return "";
        }
    }

    private Long getLongValue(Row row, String columnName) {
        try {
            return row.getLong(columnName);
        } catch (Exception e) {
            log.warn("Column {} not found or invalid format", columnName);
            return 0L;
        }
    }

    private Integer getIntegerValue(Row row, String columnName) {
        try {
            return row.getInteger(columnName);
        } catch (Exception e) {
            log.warn("Column {} not found or invalid format", columnName);
            return 0;
        }
    }

    @Override
    public Mono<InvoiceLogResponse> getInvoiceLog(InvoiceLogRequest request) {
        log.debug("Executing getInvoiceLog query for record_no: {}", request.getRecordNo());
        final String sql = buildInvoiceLogSql(request);
        log.debug("SQL query: {}", sql);

        Uni<List<InvoiceLogItem>> dataUni = client.preparedQuery(sql)
                .execute(Tuple.of(request.getRecordNo()))
                .map(rows -> {
                    List<InvoiceLogItem> items = new ArrayList<>();
                    for (Row row : rows) {
                        items.add(mapRowToInvoiceLogItem(row));
                    }
                    log.debug("Found {} log entries for record_no: {}", items.size(), request.getRecordNo());
                    return items;
                })
                .onFailure().invoke(e -> {
                    log.error("Error executing query for record_no: {}", request.getRecordNo(), e);
                });

        Mono<List<InvoiceLogItem>> dataMono = Mono.fromFuture(dataUni.subscribeAsCompletionStage());

        return dataMono.map(data -> {
            long totalItems = data.size();
            log.debug("Returning {} log entries for record_no: {}", totalItems, request.getRecordNo());
            return new InvoiceLogResponse()
                    .setData(data)
                    .setTotalRecords(totalItems)
                    .setTotalPage(1)
                    .setCurrentPage(1);
        });
    }

    private String buildInvoiceLogSql(InvoiceLogRequest request) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT l.*, r.record_no FROM bms_payment.invoice_log_request l ");
        sql.append("JOIN bms_payment.invoice_record r ON l.invoice_record_id = r.id ");
        sql.append("WHERE r.record_no = $1 ");
        sql.append("ORDER BY l.request_at DESC");
        
        return sql.toString();
    }
} 