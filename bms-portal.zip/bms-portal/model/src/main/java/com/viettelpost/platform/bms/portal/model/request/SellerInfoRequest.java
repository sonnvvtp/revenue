package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

@Data
public class SellerInfoRequest {
    private String sellerName;
    private String taxCode;
    private String address;
    private String phone;
    private String email;
    private String bankName;
    private String bankAccount;
    private String companyCode;
}
