package com.viettelpost.platform.bms.portal.interfaces.accountingCommon;
import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.service.handler.AccountingSapService;
import com.viettelpost.platform.model.request.accounting.callbackSap.callbackAccounting.DataWrapAccounting;
import com.viettelpost.platform.model.request.accounting.callbackSap.callbackBp.DataWrapCallbackBp;
import com.viettelpost.platform.model.request.accounting.callbackSap.callbackConfiguration.DataWrapCallbackConfiguration;
import com.viettelpost.platform.model.request.accounting.callbackSap.callbackGlAccount.DataWrapCallbackGlAccount;
import com.viettelpost.platform.model.request.accounting.funcResolve.PayBatchUpdatePostIdReq;
import com.viettelpost.platform.model.request.accounting.funcResolve.ReqDeleteBathOption;
import com.viettelpost.platform.model.request.accounting.funcResolve.TraceStatusRawReq;
import com.viettelpost.platform.model.request.accounting.funcResolve.UpdateDataSecretReq;
import com.viettelpost.platform.model.request.accounting.funcResolve.UpdateDateRawReq;
import com.viettelpost.platform.model.request.accounting.reqSyntheticData.SyntheticDataReq;
import com.viettelpost.platform.model.request.func.UpdateForControlLineReq;
import com.viettelpost.platform.model.response.accounting.BmsPushAcctResponse;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/accounting")
@Tag(name = "API Accounting SAP Common")
@RequiredArgsConstructor
@ApplicationScoped
public class AccountingAPI {
    private final AccountingSapService accountingSapService;

    @ConfigProperty(name = "bms-key-search")
    String bmsKeySearch;

    @POST
    @Path("/push-accounting-raw")
    @Operation(summary = "Tiếp nhận thông tin vào bảng RAW DATA")
    public Uni<BmsPushAcctResponse> insertRawTable(@RequestBody @Valid SyntheticDataReq batch) {
        return accountingSapService.acctReceptionDataRaw(batch);
    }

    @GET
    @Path("/data-raw")
    @Operation(summary = "Tiếp nhận thông tin vào bảng RAW DATA")
    public Uni<Response> insertRawTable(@QueryParam("businessId") Long businessId,
                                        @QueryParam("refNumber") String refNumber,
                                        @QueryParam("bkC1") String bkC1,
                                        @QueryParam("bkC2") String bkC2,
                                        @QueryParam("bkC3") String bkC3){
        return accountingSapService.getRawData(businessId, refNumber, bkC1, bkC2, bkC3);
    }

    /*
     * LEVEL 1: BATCH
     */
    @GET
    @Path("/get-acct-batch")
    @Operation(summary = "get batch group by param")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getPayBatchGroupList(
            @QueryParam("batchId") List<Long> batchId,
            @QueryParam("batchName") String batchName,
            @QueryParam("businessId") Integer businessId,
            @QueryParam("status") Integer status,
            @QueryParam("fromDate") String fromDate,
            @QueryParam("toDate") String toDate,
            @QueryParam("page") Integer page,
            @QueryParam("size") Integer size) {
        return accountingSapService.getAcctBatchInfo(batchId, batchName, businessId, status, fromDate, toDate, page, size);
    }

    /*
     * LEVEL 2: HEADER
     */
    @GET
    @Path("/get-sub-business")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSubBusiness(@QueryParam("acctBatchId") Long acctBatchId,
                                 @QueryParam("status") Integer status,
                                 @QueryParam("page") Integer page,
                                 @QueryParam("size") Integer size,
                                 @QueryParam("fromDate") String fromDate,
                                 @QueryParam("toDate") String toDate) {
        return accountingSapService.getSubBusiness(acctBatchId, status, fromDate, toDate, page, size);
    }

    /*
     * LEVEL 3: ITEM
     */
    @GET
    @Path("/get-sub-business-detail")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSubBusinessDetail(@QueryParam("acctBatchId") Long acctBatchId,
                                       @QueryParam("acctSubBusinessId") Long acctSubBusinessId,
                                       @QueryParam("page") Integer page,
                                       @QueryParam("size") Integer size,
                                       @QueryParam("fromDate") String fromDate,
                                       @QueryParam("toDate") String toDate) {
        return accountingSapService.getSubBusinessDetail(acctBatchId, acctSubBusinessId, fromDate, toDate, page, size);
    }

    /*
     * DETAIL ITEM IN LEVEL 3
     */
    @GET
    @Path("/detail-item-in-group")
    @Operation(summary = "chi tiết raw trong business detail")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> detailItemInGroup(@QueryParam("acctSubBusinessId") Long acctSubBusinessId,
                                    @QueryParam("acctSubBusinessDetailId") Long acctSubBusinessDetailId) {
        return accountingSapService.getDetailItemInGroup( acctSubBusinessId, acctSubBusinessDetailId);
    }

    /*
     * LIST RAW DATA
     */
    @GET
    @Path("/synthetic-raw-data")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSubBusiness(@QueryParam("businessId") Long businessId,
                                 @QueryParam("refNumber") String refNumber,
                                 @QueryParam("refNumberParent") String refNumberParent,
                                 @QueryParam("bkC1") String bkC1,
                                 @QueryParam("bkC2") String bkC2,
                                 @QueryParam("bkC3") String bkC3,
                                 @QueryParam("status") Integer status,
                                 @QueryParam("fromDate") String fromDate,
                                 @QueryParam("toDate") String toDate,
                                 @QueryParam("fromPostDate") String fromPostDate,
                                 @QueryParam("toPostDate") String toPostDate,
                                 @QueryParam("page") Integer page,
                                 @QueryParam("size") Integer size) {
        return accountingSapService.getInfoRawData(businessId, refNumber, refNumberParent, bkC1, bkC2, bkC3, status, fromDate, toDate, page, size, fromPostDate, toPostDate);
    }

    /*
     * DETAIL RAW DATA -> RAW ĐÃ ĐƯỢC GOM TRONG BATCH LÀO
     */
    @GET
    @Path("/detail-business-grouped")
    @Operation(summary = "tổng hợp nghiệp vụ đã gom theo 1 raw theo acctSyntheticId")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> detailBusinessGrouped(@QueryParam("businessId") Long businessId,
                                        @QueryParam("acctSyntheticId") Long acctSyntheticId) {
        return accountingSapService.getDetailBusinessGrouped(businessId, acctSyntheticId);
    }

    @GET
    @Path("/search-result")
    @Operation(summary = "cho đối tác - tổng hợp nghiệp vụ đã gom theo 1 raw theo refNumber, refNumberParent")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> searchResultAccounting(@QueryParam("businessId") Long businessId,
                                         @QueryParam("refNumber") String refNumber,
                                         @QueryParam("refNumberParent") String refNumberParent,
                                         @QueryParam("bkC1") String bkC1,
                                         @QueryParam("bkC2") String bkC2,
                                         @QueryParam("bkC3") String bkC3
                                         ) {
        return accountingSapService.getResultAccounting(businessId, refNumber, refNumberParent, bkC1, bkC2, bkC3);
    }

    /**
     * DELETE
     */

    @POST
    @Path("/delete-batch-raw")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> detailItemInGroup(@RequestBody ReqDeleteBathOption req) throws Exception {
        return accountingSapService.deleteBatchRaw(req);
    }

    @POST
    @Path("/delete-raw-fail")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> deleteRawItem(@RequestBody ReqDeleteBathOption req) throws Exception {
        return accountingSapService.deleteRawItem(req.getListRawData());
    }

    /**
     * BP code
     */

    @GET
    @Path("/get-list-map-bp")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getListMapBp(@QueryParam("page") Integer page, @QueryParam("size") Integer size) {
        return accountingSapService.getListMapBpSap(page, size);
    }

    @GET
    @Path("/delete-map-bp")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> deleteMapBp(@QueryParam("isDeleteAll") Boolean isDeleteAll, @QueryParam("value") String value) {
        return accountingSapService.deleteMapBpSap(isDeleteAll, value);
    }
    /**
     * UPDATE STATUS, update đẩy lại hach toán
     */

    @POST
    @Path("/update-ready-sync")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updateBatchReadySync(@RequestBody List<Long> batchId) throws Exception {
        return accountingSapService.updateItemBatchReadyPush(batchId);
    }

    @POST
    @Path("/update-status-pending")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updateStatusPending(@RequestBody List<Long> batchId) throws Exception {
        return accountingSapService.updateStatusPendingSynthetic(batchId);
    }

    /**
     * CALLBACK DATA SAP
     */

    @POST
    @Path("/callback/data-bp-res")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> consumeDataBpSap(@RequestBody DataWrapCallbackBp reqBase) throws Exception {
        return accountingSapService.consumeDataBpSapFunc(reqBase);
    }

    @POST
    @Path("/callback/accounting-res")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> sapCallbackResult(@RequestBody DataWrapAccounting req) throws Exception {
        return accountingSapService.sapCallbackResultFunc(req);
    }

    @POST
    @Path("/callback/gl-account-callback-result")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> glAccountCallbackResult(@RequestBody DataWrapCallbackGlAccount reqData) throws Exception {
        return accountingSapService.glAccountCallbackResultFunc(reqData);
    }

    @POST
    @Path("/callback/sap-bms-configuration-consumer")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> sapBmsConfigurationConsumer(@RequestBody DataWrapCallbackConfiguration reqData) throws Exception {
        return accountingSapService.sapBmsConfigurationConsumerFunc(reqData);
    }

    /**
     * update create -> delete bp map -> rePush data create bp
     *
     */
    @POST
    @Path("/callback/update-create-bp")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updateCreateBp(@RequestBody List<Long> listAcctSyntheticId) throws Exception {
        return accountingSapService.updateCreateBpRaw(listAcctSyntheticId);
    }

    @POST
    @Path("/get-list-acct-batch")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getListAcctBatchViaRawId(@RequestBody List<Long> listAcctSyntheticId) throws Exception {
        return accountingSapService.getListAcctBatchViaRawId(listAcctSyntheticId);
    }

    /**
     * FUNC RESOLVE
     */
    @POST
    @Path("/update-date-raw")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updateDateRaw(@RequestBody UpdateDateRawReq reqBody) throws Exception {
        return accountingSapService.updateDateRaw(reqBody);
    }

    /**
     * salary update postId fico_pay_batch
     */

    @POST
    @Path("/update-post-id-pay-batch")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updatePostIdPayBatch(@RequestBody PayBatchUpdatePostIdReq reqBody) throws Exception {
        return accountingSapService.updatePostIdPayBatch(reqBody);
    }

    /**
     * update another field in raw table
     */

    @POST
    @Path("/update-another-field-raw")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updateAnotherFieldRaw(@RequestBody UpdateDataSecretReq stringSql) throws Exception {
        if(bmsKeySearch.equals(stringSql.getKeySecret())){
            return accountingSapService.updateAnotherFieldRaw(stringSql);
        }
        return null;
    }

    @GET
    @Path("/detail-accounting-record")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> detailAccountingRecord(@QueryParam("recordId") Long recordId) throws Exception {
        return accountingSapService.getDetailAccountingByRecord(recordId);
    }

    @POST
    @Path("/get-data")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getData(@RequestBody String dataReq) throws Exception {
        return accountingSapService.getData(dataReq);
    }
    /**
     * VIPO
     */

    @GET
    @Path("/cash-advance/vipo/list")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> cashAdcanceAccountingList(@QueryParam("status") Integer status,
                                            @QueryParam("bkCode") String bkCode,
                                            @QueryParam("orgID") Long orgId,
                                            @QueryParam("postId") Long postId,
                                            @QueryParam("fromDate") String fromDate,
                                            @QueryParam("toDate") String toDate,
                                            @QueryParam("page") Integer page,
                                            @QueryParam("size") Integer size) {
        return accountingSapService.getDataCashAdvanceVipoAccounting(status, bkCode, orgId, postId, fromDate, toDate, page, size)
                .flatMap(data -> Uni.createFrom().item(BaseResponse.successApi(data, "OK")));
    }

    @GET
    @Path("/cash-advance/vipo/list-detail")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> cashAdcanceAccountingListDetail(@QueryParam("bkCode") String bkCode) {
        return accountingSapService.getDataCashAdvanceVipoAccountingDetail(bkCode);
    }
    /**
     * OS
     */

    @POST
    @Path("/trace-status-raw")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> traceStatusRaw(@RequestBody TraceStatusRawReq dataReq) throws Exception {
        return accountingSapService.traceStatusRaw(dataReq);
    }

    @GET
    @Path("/sap-service-config")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSapServiceConfig() throws Exception {
        return accountingSapService.getSapServiceConfig();
    }

    @GET
    @Path("/sap-project-config")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> getSapProjectConfig(@QueryParam("companyCode") String companyCode) throws Exception {
        return accountingSapService.getSapProjectConfig(companyCode);
    }

    /**
     * FUNC
     */

    @POST
    @Path("/func/delete-comparison-internal")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> deleteComparisonInternal(List<String> reqVtpOrderIds) throws Exception {
        return accountingSapService.deleteComparisonInternal(reqVtpOrderIds);
    }

    @POST
    @Path("/func/delete-comparison-externals")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> deleteComparisonExternal(List<String> reqVtpOrderIds) throws Exception {
        return accountingSapService.deleteComparisonExternal(reqVtpOrderIds);
    }

    @POST
    @Path("/func/update-for-control-line/time")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<?> updateForControlLine(@RequestBody UpdateForControlLineReq req) throws Exception {
        return accountingSapService.forControlLineUpdateTime(req);
    }
}
