package com.viettelpost.platform.bms.portal.model.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ConfigCallbackModel {
    @JsonAlias("source_type")
    private String sourceType;

    @JsonAlias("service_type")
    private String serviceType;

    @JsonAlias("statement_token_partner")
    private StatementTokenPartner token;

    @JsonAlias("authen_type")
    private int authenType;

    private Endpoint  endpoint;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Endpoint {
        @JsonAlias("url-login")
        private String urlLogin;

        @JsonAlias("url-noti")
        private String urlNoti;

        @JsonAlias("url-noti-record")
        private String urlNotiRecordSmg;

        @JsonAlias("url-noti-vipo")
        private String urlNotiVipo;

        @JsonAlias("url-noti-fmcg")
        private String urlNotiFmcg;

        @JsonAlias("url-noti-qtcv")
        private String urlNotiQtcv;

    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class StatementTokenPartner {
        @JsonAlias("client_id")
        private String client_id;

        @JsonAlias("username")
        private String username;

        @JsonAlias("password")
        private String password;

        @JsonAlias("grant_type")
        private String grant_type;

        @JsonProperty("x-access-token")
        private String xAccessToken;

    }

}
