package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

@Data
public class FicoConfigJobDTO {

    @JsonAlias("CONFIG_ID")
    private Long configId;

    @JsonAlias("CONFIG_VAL")
    private String configVal;

    @JsonAlias("CONFIG_STATUS")
    private Integer configStatus;

    @JsonAlias("CONFIG_TYPE")
    private Integer configType;

    @JsonAlias("CONFIG_HOUR")
    private Integer configHour;
}
