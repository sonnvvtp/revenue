package com.viettelpost.platform.bms.portal.model.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PayBatchModel {
    private Long batchId;
    private String batchNo;
    private String statementNo;
    private String summaryNo;
    private Long partnerId;
    private String partnerCode;
    private Date createdAt;
    private Date accountingDate;
    private Long orgId;
    private String orgCode;
    private Long postId;
    private String postCode;
    private String postName;
    private Long recordType;
    private String serviceCode;
    private String profitCenter;
    private String costCenter;
    private BigDecimal codAmount;
    private BigDecimal feeAmount;
    private BigDecimal payAmount;
    private Long uncCreatedBy;
    private Long bthCreatedBy;
    private String accountingNo;
    private String bankAccountNo;
    private String ftCode;
    private String reqCode;
}
