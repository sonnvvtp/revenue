package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.model.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.portal.model.request.BillRevenueRequest;
import com.viettelpost.platform.bms.portal.model.request.ReportRevenueRequest;
import com.viettelpost.platform.bms.portal.model.request.RevenuePeriodControlRequest;
import com.viettelpost.platform.bms.portal.service.handler.BillRevenueService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/bill-revenue")
@Tag(name = "API Bill Revenue")
@RequiredArgsConstructor
@ApplicationScoped
public class BillRevenueController {

    private final BillRevenueService billRevenueService;

    @POST
    @Path("/find-list")
    @Operation(summary = "Lấy danh sách báo cáo doanh thu")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findList(@Valid BillRevenueRequest request) {
        return billRevenueService.findListBillRevenue(request)
                .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/export")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON})
    @Operation(summary = "Xuất excel báo cáo doanh thu")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Response exportExcel(@Valid BillRevenueRequest request) {
        return billRevenueService.exportBillRevenue(request);
    }

    @GET
    @Path("/list-period")
    @Operation(summary = "Lấy danh sách kỳ đối soát")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findListPeriod() {
        return billRevenueService.findListPeriod()
            .collect().asList()
            .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/report-revenue")
    @Operation(summary = "Báo cáo doanh thu")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> reportRevenue(@Valid ReportRevenueRequest request) {
        return billRevenueService.reportRevenue(request)
            .collect().asList()
            .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/report-revenue/export")
    @Operation(summary = "Báo cáo doanh thu")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Response exportReportRevenue(@Valid ReportRevenueRequest request) {
        return billRevenueService.exportReportRevenue(request);
    }

    @GET
    @Path("/list-period-control")
    @Operation(summary = "Lấy danh sách kỳ đối soát")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> findListPeriodControl() {
        return billRevenueService.findListPeriodControl()
            .collect().asList()
            .map(result -> BaseResponse.successApi(result, "OK"));
    }

    @POST
    @Path("/save-period-control")
    @Operation(summary = "Lấy danh sách kỳ đối soát")
    @APIResponse(responseCode = "200", description = "Return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> savePeriodControl(RevenuePeriodControlRequest request) {
        return billRevenueService.savePeriodControl(request).map(result -> BaseResponse.successApi(result, "OK"));
    }
}
