package com.viettelpost.platform.bms.revenue.worker.common.annotation;

import java.lang.annotation.*;

/**
 * Annotation used to define a condition in Drools rules.
 * It specifies the name, comparison operator, and data type of the fact field.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
@Documented
public @interface ConditionDrool {
    String name();

    /**
     * Defines the comparison operator used in the Drools rule.
     *
     * <p>Example:</p>
     * <pre>
     * BELONG_TO -> Operator: in
     * NOT_BELONG_TO -> Operator: not in
     * ... // For more operator info please read in Enum: OperatorDrool
     * </pre>
     *
     * @return the comparison operator
     */
    /**
     * Specifies the data type of the fact field.
     *
     * @return the class type of the fact field
     */
    Class<?> clazz();
}
