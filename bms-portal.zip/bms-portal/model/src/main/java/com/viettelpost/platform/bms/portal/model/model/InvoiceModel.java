package com.viettelpost.platform.bms.portal.model.model;

import java.sql.Timestamp;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@ToString
public class InvoiceModel {

    private String id;
    private String serial;
    private String invType;
    private String invNo;
    private String from;
    private Timestamp idt;
    private String sName;
    private String sTax;
    private Long amount;
    private Long subFee;
    private Long vat;
    private Long total;
    private Integer status;
    private String bpCode;
    private Timestamp createDate;
    private String postOfficeCreateInv;
    private Integer typePay;
    private Timestamp updateDate;
    private String linkImg;
    private String bpSale;
    private String bpSaleDebt;
    private String sAddress;
    private Long createdBy;
    private List<InvItemModel> itemsInv;
    private String taxCode;
    private String supplierName;
    private String supplierAddress;
    private String carLicensePlate;
    private FileInvoiceModel file;
    private boolean success;
    private String course;

    @Getter
    @Setter
    @Accessors(chain = true)
    @ToString
    public static class FileInvoiceModel {

        private Long id;
        private String idInvoice;
        private String fileName;
        private Long fileSize;
        private String fileType;
        private String urlFile;
        private String pathFile;
    }

    @Getter
    @Setter
    @Accessors(chain = true)
    @ToString
    public static class InvItemModel {

        private String id;
        private String invoiceId;
        private String userCreate;
        private Timestamp createDate;
        private Long subFee;
        private String nameHH;
        private String idTypeCp;
        private String typeCp;
        private Long vat;
        private Double vatRate;
        private Long total;
        private Double price;
        private Long amount;
        private Double quantity;
        private Integer status;
        private String bpCode;
        private String stk;

    }

}