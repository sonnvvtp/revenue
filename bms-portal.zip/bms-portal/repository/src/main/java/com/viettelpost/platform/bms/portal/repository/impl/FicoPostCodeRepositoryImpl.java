package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.PostCodeDTO;
import com.viettelpost.platform.bms.portal.repository.FicoPostCodeRepository;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Flux;

@ApplicationScoped
@RequiredArgsConstructor
public class FicoPostCodeRepositoryImpl implements FicoPostCodeRepository {

    @Override
    public Uni<PostCodeDTO> getPostCodeFromCode(String postCode, Connection connection) {
        String sql =
                "SELECT fspcc.COMPANY_CODE, hp.POSTCODE, fspcc.COST_CENTER, hp.POST_NAME, hp.POST_ID, " +
                "fspcc.PROFIT_CENTER, hp.ORGANIZATION_ID " +
                "FROM ERP_AC.FICO_SAP_POST_CODE_CENTER fspcc " +
                "JOIN ERP_AC.HR_POSTCODE hp ON fspcc.POST_ID = hp.POST_ID " +
                "WHERE hp.POSTCODE = ?";

        var statement = connection.createStatement(sql)
                .bind(0, postCode);

        return Uni.createFrom().completionStage(
                Flux.from(statement.execute())
                        .flatMap(result -> result.map((row, metadata) -> {
                            PostCodeDTO dto = new PostCodeDTO();
                            dto.setCompanyCode(row.get("COMPANY_CODE", String.class));
                            dto.setPostCode(row.get("POSTCODE", String.class));
                            dto.setCostCenter(row.get("COST_CENTER", String.class));
                            dto.setPostName(row.get("POST_NAME", String.class));
                            dto.setPostId(row.get("POST_ID", Long.class));
                            dto.setProfitCenter(row.get("PROFIT_CENTER", String.class));
                            dto.setOrgId(row.get("ORGANIZATION_ID", Long.class));
                            return dto;
                        }))
                        .next()
                        .toFuture()
        );
    }
}
