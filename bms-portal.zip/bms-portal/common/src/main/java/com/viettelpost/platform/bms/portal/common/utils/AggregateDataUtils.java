package com.viettelpost.platform.bms.portal.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Utility class for aggregating and grouping raw data.
 */
public class AggregateDataUtils {

    private static final Logger log = LoggerFactory.getLogger(AggregateDataUtils.class);

    /**
     * Groups a list of input objects based on specified fields and aggregates each group into a result object using a provided function.
     *
     * @param inputList The list of input objects to group and aggregate.
     * @param clazzResult The class of the result object type.
     * @param clazzInput The class of the input object type.
     * @param functionGroup A function that takes a grouped list of input objects and returns an aggregated result object.
     * @param fieldGroupList The names of the fields to group by. These fields must have standard getter methods (e.g., getFieldName).
     * @param <R> The type of the result objects.
     * @param <I> The type of the input objects.
     * @return A list of result objects, one for each group.
     * @throws IllegalArgumentException if input list or fieldGroupList is null or empty.
     */
    public static <R, I> List<R> aggregateGroupRawData(List<I> inputList, Class<R> clazzResult, Class<I> clazzInput, Function<List<I>, R> functionGroup, String... fieldGroupList) {

        if (Objects.isNull(inputList)) {
            throw new IllegalArgumentException("[AggregateDataUtils] Input list cannot be null.");
        }
        if (Objects.isNull(fieldGroupList) || fieldGroupList.length == 0) {
            throw new IllegalArgumentException("[AggregateDataUtils] Field group list cannot be null or empty.");
        }

        List<R> resultList = new ArrayList<>();
        Map<String, List<I>> groupedListMap = inputList.stream()
                .collect(Collectors.groupingBy(item -> buildGroupKey(item, clazzInput, fieldGroupList)));

        for (String groupKey : groupedListMap.keySet()) {
            List<I> groupedList = groupedListMap.get(groupKey);
            R result = functionGroup.apply(groupedList);
            resultList.add(result);
        }

        return resultList;

    }

    /**
     * Builds a unique key string for grouping by concatenating the values of specified fields from the given object.
     *
     * @param item The object from which to extract field values.
     * @param clazz The class of the object.
     * @param fieldGroupList The list of field names to use in the key. Corresponding getters must exist (e.g., getFieldName).
     * @param <T> The type of the object.
     * @return A comma-separated string of field values representing the group key.
     */
    private static <T> String buildGroupKey(T item, Class<T> clazz, String... fieldGroupList) {
        List<Object> keyValue = new ArrayList<>();
        for (String fieldName : fieldGroupList) {
            try {
                Method method = clazz.getMethod("get" + StringUtils.capitalize(fieldName));
                Object value = method.invoke(item);
                if(Objects.nonNull(value)) {
                    keyValue.add(value);
                }
            } catch (Exception ex) {
                log.warn("[AggregateDataUtils] Error while getting field value for {}, exception: {}", fieldName, ex.getMessage(), ex);
            }
        }

        return keyValue.stream().map(Object::toString).collect(Collectors.joining(","));
    }
}
