package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

@Data
public class AccountingVipoRequest {
    private Integer type;
    private String fromDate;
    private String toDate;
    private String transactionCode;
}
