package com.viettelpost.platform.bms.portal.repository;


import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.request.GeneralOrderRequest;
import com.viettelpost.platform.bms.portal.model.response.GeneralOrderDetailResponse;
import com.viettelpost.platform.bms.portal.model.response.GeneralOrderResponse;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

public interface GeneralOrderRepository extends BaseRepository {
    Uni<GeneralOrderDetailResponse> getGeneralOrderDetailById(Long generalOrderId);

    Multi<GeneralOrderResponse> getGeneralOrder(GeneralOrderRequest request);

    Uni<Integer> findInvoiceOrderCount(GeneralOrderRequest findInvoiceOrderRequest);
}
