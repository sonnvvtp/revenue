package com.viettelpost.platform.bms.portal.model.request.partnerConfig;

import lombok.Data;

import java.util.List;

@Data
public class ConfigReceiveRequest {
    Long partnerInternalLineId;
    List<Integer> listBankExId;
}
