package com.viettelpost.platform.bms.revenue.worker.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueAccountingType;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueRecordStatus;
import com.viettelpost.platform.bms.revenue.worker.common.utils.OracleUtils;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BillEvtpPayInDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.BmsBillRevenueEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.RevenueServiceGroupEntity;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.mapper.BillRevenueMapper;
import com.viettelpost.platform.bms.revenue.worker.model.request.general.CreateBatchOrderRequest;
import com.viettelpost.platform.bms.revenue.worker.model.response.CreateBatchResponse;
import com.viettelpost.platform.bms.revenue.worker.repository.CalculationRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.service.CalculationRevenueService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.ext.web.client.WebClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Mono;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class CalculationRevenueServiceImpl implements CalculationRevenueService {

    private final CalculationRevenueRepository calculationRevenueRepository;

    private final ConnectionPool oraclePool;

    @ConfigProperty(name = "job.calculation.discount.batch.handle.size", defaultValue = "10000")
    Integer batchBillHandleSize;

    @ConfigProperty(name = "config.concurrency.process.call.api", defaultValue = "10")
    Integer concurrencyProcess;

    private final WebClient webClient;

    @ConfigProperty(name = "push.create.batch.url", defaultValue = "https://dev-mm-bms.viettelpost.vn/invoice/api/v1/invoice-order/create-batch")
    String pushCreateBatchUrl;

    @ConfigProperty(name = "config.batch.create", defaultValue = "200")
    Integer maxChunkSize;

    @ConfigProperty(name = "revenue.client-id", defaultValue = "BMS_FMCG")
    String revenueClientId;

    @ConfigProperty(name = "revenue.secret-key", defaultValue = "Abc123456")
    String revenueClientKey;

    @ConfigProperty(name = "revenue.config.domain.type", defaultValue = "REVENUE_VTP")
    String revenueDomainType;

    @Inject
    ObjectMapper objectMapper;

    @Override
    public Uni<Void> calculationAllBillToRevenue() {
        long currentTime = System.currentTimeMillis();
        // Lấy ngày hiện tại
//        LocalDate today = LocalDate.now().minusMonths(1);
        LocalDate today = LocalDate.now();

        // Lấy ngày bắt đầu của tháng hiện tại (ngày 1)
        LocalDate startOfMonth = today.with(TemporalAdjusters.firstDayOfMonth());

        return calculationRevenueRepository.findPeriodBy(startOfMonth)
            .flatMap(periodEntity -> {
              log.info("calculationAllBillToRevenue_periodEntity: {}", periodEntity);
              if (Objects.isNull(periodEntity)) {
                return Uni.createFrom().voidItem();
              }
              LocalDate endOfMonth = periodEntity.getEndDate().toLocalDate();
              Uni<Integer> countUni = calculationRevenueRepository.findAllEvtpPayInCount(startOfMonth, endOfMonth);

              Multi<RevenueServiceGroupEntity> revenueServiceGroupMulti = calculationRevenueRepository.findRevenueServiceGroupBy();
              return Uni.combine().all().unis(countUni, revenueServiceGroupMulti.collect().asList())
                  .withUni((totalItems, revenueServiceGroupEntities) -> {
                  /*
                  return Uni.createFrom().voidItem();
                  */
//                    /*
                  log.info("calculationAllBillToRevenue_size: {}, startOfMonth: {}, endOfMonth: {}",  totalItems,  startOfMonth, endOfMonth);
                  int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
                  List<Multi<BillEvtpPayInDTO>> multiList = new ArrayList<>();
                  Map<String, String> serviceMap = revenueServiceGroupEntities.stream()
                      .collect(Collectors.toMap(
                          RevenueServiceGroupEntity::getServiceCode,
                          RevenueServiceGroupEntity::getServiceCode,
                          (oldValue, newValue) -> oldValue // nếu trùng thì giữ lại giá trị cũ
                      ));

                  for (int i = 0; i < maxPage; i++) {
                    multiList.add(
                        calculationRevenueRepository.findAllEvtpPayIn(startOfMonth, endOfMonth, i, batchBillHandleSize));
                  }

                  Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

                  for (Multi<BillEvtpPayInDTO> multi : multiList) {
                    uniChainProcess = uniChainProcess.chain(() -> multi.collect().asList()
                            .flatMap(listBill -> processSaveBatch(listBill, serviceMap, periodEntity.getPeriodId())))
                        .onFailure()
                        .recoverWithUni((throwable) -> {
                          log.error("saveBatch_fail: {}", throwable.getMessage(), throwable);
                          return Uni.createFrom().voidItem();
                        });
                  }
                  return uniChainProcess;
//                  */
                })
                // tong hop bill hoan thanh
                .flatMap(unused -> processBillDeliveriesToRevenue(periodEntity.getPeriodId(), startOfMonth, endOfMonth))
                .flatMap(unused -> pushBillRevenueToGeneralRecord(periodEntity.getPeriodId(), RevenueType.TEMPORARY_REVENUE))
                .flatMap(unused -> pushBillRevenueToGeneralRecord(periodEntity.getPeriodId(), RevenueType.COMPLETED_REVENUE2))
                .flatMap(unused -> pushBillRevenueToGeneralRecord(periodEntity.getPeriodId(), RevenueType.COMPLETED_REVENUE3))
                /*
                // Bảng kê cấp 2
                .flatMap(rs -> calculationRevenueRepository.saveBmsDebt(toDebtEntities(periodIdFinal.get(), startOfMonth), null)
                    // ghi nhận doanh thu tạm tính
                        .flatMap(debtId -> {
                              return groupByBillRevenueBy(debtId, periodIdFinal.get(), RevenueType.TEMPORARY_REVENUE, startOfMonth)
                                  .flatMap(unused -> groupByBillRevenueBy(debtId, periodIdFinal.get(), RevenueType.COMPLETED_REVENUE2, startOfMonth)
                                    .flatMap(unused2 -> groupByBillRevenueBy(debtId, periodIdFinal.get(), RevenueType.COMPLETED_REVENUE3, startOfMonth)
                                      // sum tong
                                      .flatMap(unuse -> calculationRevenueRepository.findGroupByBmsDebtBy(debtId, periodIdFinal.get(), null)
                                          // Cập nhật lại số tiền
                                        .flatMap(groupDebtItem -> calculationRevenueRepository.updateBmsDebtBy(debtId, groupDebtItem, null))
                                          .flatMap(rsUpd -> {
                                            if (rsUpd) {
                                              log.info("updateBmsDebtBy_success: {}", debtId);
                                            }
                                            return Uni.createFrom().voidItem();
                                          }
                                        ))));
                        })
                )
                */
                .onFailure()
                .recoverWithUni(throwable -> {
                  log.info("calculationAllBillToRevenue_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
                  return Uni.createFrom().voidItem();
                });
            })
            .onFailure()
            .recoverWithUni(throwable -> {
              log.error("calculationAllBillToRevenue_findPeriodBy: {}", throwable.getMessage(), throwable);
              log.info("calculationAllBillToRevenue_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
              return Uni.createFrom().voidItem();
            });
    }

    private Uni<Void> processBillDeliveriesToRevenue(BigDecimal periodId, LocalDate startOfMonth, LocalDate endOfMonth) {
      /*
      return Uni.createFrom().voidItem();
      */
//      /*
      Uni<Integer> countUni = calculationRevenueRepository.findAllBillSucessCount(startOfMonth, endOfMonth);
      return countUni
          .flatMap(count -> {
            log.info("processBillDeliveriesToRevenue_size: {}, startOfMonth: {}, endOfMonth: {}",  count,  startOfMonth, endOfMonth);
            int maxPage = (int) Math.ceil((double) count / batchBillHandleSize);
            List<Multi<BillEvtpPayInDTO>> multiList = new ArrayList<>();

            for (int i = 0; i < maxPage; i++) {
              multiList.add(
                  calculationRevenueRepository.findAllBillSucess(startOfMonth, endOfMonth, i, batchBillHandleSize));
            }

            Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

            for (Multi<BillEvtpPayInDTO> multi : multiList) {
              uniChainProcess = uniChainProcess.chain(() -> multi.collect().asList()
                      .flatMap(listBill -> processSaveBatch(listBill, null, periodId)))
                  .onFailure()
                  .recoverWithUni((throwable) -> {
                    log.error("saveBatch_BillDeliveries_success_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().voidItem();
                  });
            }
            return uniChainProcess;
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("findAllBillSucessCount_fail: {}", throwable.getMessage(), throwable);
          });
//      */
    }

    private List<BmsBillRevenueEntity> toItemOrderEntities(List<BillEvtpPayInDTO> billEvtpPayInList, Map<String, String> serviceMap, BigDecimal periodId) {

        List<BmsBillRevenueEntity> entities = new ArrayList<>();
        for (BillEvtpPayInDTO evtpPayInDTO : billEvtpPayInList) {
            int orderType = 0;
            if (Objects.isNull(serviceMap)) {
              orderType = 3;
            }
            else {
              if (Objects.nonNull(serviceMap.get(evtpPayInDTO.getMProduct()))) {
                orderType = 1; // 1: tam tinh, 2: hoàn thành
              } else {
                orderType = 2; // 1: tam tinh, 2: hoàn thành
              }
            }

            entities.add(
                BmsBillRevenueEntity.builder()
                    .createdBy(-1L)
                    .updatedBy(-1L)
                    .orgId(evtpPayInDTO.getOrgId())
                    .postId(evtpPayInDTO.getPostId())
                    .payInId(evtpPayInDTO.getPayInId())
                    .bill(evtpPayInDTO.getBill())
                    .type(evtpPayInDTO.getType())
                    .billId(evtpPayInDTO.getBillId())
                    .billId(evtpPayInDTO.getBillId())
                    .billStatus(evtpPayInDTO.getBillStatus())
                    .dateBill(evtpPayInDTO.getDateBill())
                    .dateInsert(evtpPayInDTO.getDateInsert())
                    .partnerEvtp(evtpPayInDTO.getPartnerEvtp())
                    .mProduct(evtpPayInDTO.getMProduct())
                    .cityFrom(evtpPayInDTO.getCityFrom())
                    .cityTo(evtpPayInDTO.getCityTo())
                    .paymentTeamId(evtpPayInDTO.getPaymentTeamId())
                    .isPaid(evtpPayInDTO.getIsPaid())
                    .weight(evtpPayInDTO.getWeight())
                    .amt(evtpPayInDTO.getAmt())
                    .amtDeduct(BigDecimal.ZERO)
                    .amtDeductOther(BigDecimal.ZERO)
                    .fee(evtpPayInDTO.getFee())
                    .freight(evtpPayInDTO.getAmt().subtract(evtpPayInDTO.getAmtVat()))
                    .feeOther(BigDecimal.ZERO)
                    .amtVat(evtpPayInDTO.getAmtVat())
                    .amtPay(evtpPayInDTO.getAmtPay())
                    .billRevenueType(orderType)
                    .revenueSource("VTP")
                    .isSync(0)
                    .periodId(periodId)
                    .vat(evtpPayInDTO.getTaxPercent())
                    .companyCode(evtpPayInDTO.getCompanyCode())
                    .build());
        }
        return entities;
    }

    @Override
    public Uni<Void> postInspectionEveryDayJob() {
      long currentTime = System.currentTimeMillis();

      return calculationRevenueRepository.findG2bVanDonBy()
          .collect().asList()
          .flatMap(bmsBillJourneyEntities -> {
            log.info("findG2bVanDonBy_size: {}", bmsBillJourneyEntities.size());
            return calculationRevenueRepository.saveBatchBmsBillJourney(bmsBillJourneyEntities, null)
                .flatMap(aBoolean -> {
                  log.info("findG2bVanDonBy_success");
                  return Uni.createFrom().voidItem();
                })
                .onFailure()
                .invoke(throwable -> {
                  log.error("saveBatchBmsBillJourney_failure: {}", throwable.getMessage(), throwable);
                });
          }).onFailure()
          .invoke(throwable -> {
            log.error("findG2bVanDonBy_failure: {}", throwable.getMessage(), throwable);
          });
    }

    public Uni<Void> pushBillRevenueToGeneralRecord(BigDecimal periodId, RevenueType revenueType) {
      long currentTime = System.currentTimeMillis();
      log.info("pushBillRevenueToGeneralRecord: {}, periodId: {}",  periodId,  revenueType.getValue());

      Uni<Integer> countUni = calculationRevenueRepository.findBillRevenueCount(periodId, revenueType);

      return countUni
          .flatMap((totalItems) -> {
            log.info("groupByBillRevenueBy_size: {}, periodId: {}",  totalItems,  periodId);
            int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
            List<Multi<BmsBillRevenueDTO>> multiList = new ArrayList<>();

            for (int i = 0; i < maxPage; i++) {
              multiList.add(
                  calculationRevenueRepository.findBillRevenueBy(periodId, revenueType, i, batchBillHandleSize));
            }

            Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

            for (Multi<BmsBillRevenueDTO> multi : multiList) {
              uniChainProcess = uniChainProcess.chain(() -> multi.collect().asList()
                      .flatMap(listGroup -> pushBatchBillRevenueToGeneralRecord(listGroup, periodId)))
                  .onFailure()
                  .recoverWithUni((throwable) -> {
                    log.error("saveBatchGroupBillRevenue_fail: {}", throwable.getMessage(), throwable);
                    return Uni.createFrom().voidItem();
                  });
            }
            return uniChainProcess;
          })
          .onFailure()
          .recoverWithUni(throwable -> {
            log.info("groupByBillRevenueBy_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
            return Uni.createFrom().voidItem();
          });
    }

    private Uni<Void> pushBatchBillRevenueToGeneralRecord(List<BmsBillRevenueDTO> billRevenueDTOList, BigDecimal periodId) {

      log.info("billRevenueDTOList_size: {}", billRevenueDTOList.size());
      if(CollectionUtils.isEmpty(billRevenueDTOList)) {
        return Uni.createFrom().voidItem();
      }

      int size = billRevenueDTOList.size();
      int numChunks = (size + maxChunkSize - 1) / maxChunkSize; // Tính số chunk (làm tròn lên)

      List<List<BmsBillRevenueDTO>> chunks = IntStream.range(0, numChunks)
          .mapToObj(i -> billRevenueDTOList.subList(i * maxChunkSize, Math.min((i + 1) * maxChunkSize, size)))
          .toList();

      List<Uni<Boolean>> uniList = new ArrayList<>();
      for (List<BmsBillRevenueDTO> chunk : chunks) {
        uniList.add(callApiCreateBatch(chunk));
      }
      return Uni.join().all(uniList).usingConcurrencyOf(concurrencyProcess).andCollectFailures()
          .onFailure()
          .recoverWithItem(throwable -> {
            log.error("callApiCreateBatch_error_pre: {}", throwable.getMessage(), throwable);
            return new ArrayList<>();
          })
          .replaceWithVoid();
    }

    public Uni<Boolean> callApiCreateBatch(List<BmsBillRevenueDTO> billRevenueDTOList) {
      CreateBatchOrderRequest createBatchOrderRequest = CreateBatchOrderRequest.builder()
          .domainType(revenueDomainType)
          .orders(BillRevenueMapper.toGeneralOrderRequests(billRevenueDTOList, objectMapper))
          .orderSource(revenueDomainType)
          .tenantId(1)
          .build();

//      log.debug("Request push raw data accounting: {}", Json.encode(createBatchOrderRequest));
      return webClient.postAbs(pushCreateBatchUrl)
          .putHeader("Content-Type", "application/json")
          .putHeader("client-id", revenueClientId)
          .putHeader("secret-key", revenueClientKey)
          .sendJson(createBatchOrderRequest)
          .flatMap(bufferHttpResponse -> {
            boolean isError= false;
            if (bufferHttpResponse.statusCode() != 200) {
              isError =true;
              log.info("callApiCreateBatch_fail_not_200: {}", bufferHttpResponse.bodyAsString());
            }

            CreateBatchResponse response = bufferHttpResponse.bodyAsJsonObject().mapTo(CreateBatchResponse.class);
            if (Objects.isNull(response)) {
              return Uni.createFrom().failure(new RuntimeException("Response from accounting server is null"));
            }

            if (!"00".equals(response.getErrorCode())) {
              isError =true;
              log.error("callApiCreateBatch_fail: {}", response.getMessage());
            }
            else {
              if (Objects.nonNull(response.getData()) && CollectionUtils.isNotEmpty(response.getData().getIds())) {
                  isError = false;
                  return calculationRevenueRepository.updateStatusBillRevenueBy(response.getData().getIds(),
                          !isError ? RevenueRecordStatus.DONG_BO_THANH_CONG.getCode() : RevenueRecordStatus.SYNC_FAIL.getCode())
                      .flatMap(unuse -> {
                        log.info("updateStatusBillRevenueBy: {}", unuse);
                        return Uni.createFrom().item(true);
                      })
                      .onFailure()
                      .invoke(throwable -> {
                        log.error("updateStatusBillRevenueBy_error : {}", throwable.getMessage(), throwable);
                      });
              }
            }

            return Uni.createFrom().item(true);
          })
          .onFailure()
          .invoke(throwable -> {
            log.error("callApiCreateBatch_err: {}", throwable.getMessage(), throwable);
          });
    }

    private Uni<Void> pushKafkaBatchBillRevenueToGeneralRecord(List<BmsBillRevenueDTO> billRevenueDTOList, BigDecimal periodId) {

    log.info("billRevenueDTOList_size: {}", billRevenueDTOList.size());
    if(CollectionUtils.isEmpty(billRevenueDTOList)) {
      return Uni.createFrom().voidItem();
    }

    List<Uni<Void>> uniList = new ArrayList<>();
    for (BmsBillRevenueDTO billRevenueDTO : billRevenueDTOList) {
//        uniList.add(revenueConsumerService.produceBillRevenue(billRevenueDTO));
//        uniList.add(revenueConsumerService.produceBillRevenue(billRevenueDTO));
    }
    return Uni.join().all(uniList).usingConcurrencyOf(concurrencyProcess).andCollectFailures()
        .onFailure()
        .recoverWithItem(throwable -> {
          log.error("callApiCreateBatch_error_pre: {}", throwable.getMessage(), throwable);
          return new ArrayList<>();
        })
        .replaceWithVoid();
  }

    private Uni<Void> processSaveBatch(List<BillEvtpPayInDTO> billEvtpPayInList, Map<String, String> serviceMap, BigDecimal periodId) {

    return ReactiveConverter.toUni(OracleUtils.withTransaction(oraclePool, sqlConnection -> {
      List<BmsBillRevenueEntity> entities = toItemOrderEntities(billEvtpPayInList, serviceMap, periodId);
      return ReactiveConverter.toMono(
          calculationRevenueRepository.saveBatchBmsBillRevenue(entities, sqlConnection)
              .flatMap(aBoolean -> {
                if (aBoolean) {
                  log.info("processSaveBatch_success_size: {}, periodId: {}", billEvtpPayInList.size(), periodId);
                }
                return Uni.createFrom().voidItem();
              }));
    }).onErrorResume(throwable -> {
      log.error("processSaveBatch_error: {}", throwable.getMessage(), throwable);
      return Mono.error(throwable);
    }));
  }

}
