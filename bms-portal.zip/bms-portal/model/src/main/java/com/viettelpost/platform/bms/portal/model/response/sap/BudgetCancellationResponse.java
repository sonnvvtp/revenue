package com.viettelpost.platform.bms.portal.model.response.sap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BudgetCancellationResponse {

    @JsonProperty("RESULT")
    private List<Result> RESULT;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Result {

        @JsonProperty("EXTERNAL_NUMBER")
        private String EXTERNAL_NUMBER;
        @JsonProperty("DOCUMENT_NUMBER")
        private long DOCUMENT_NUMBER;
        @JsonProperty("EV_ERROR")
        private int EV_ERROR;
        @JsonProperty("MESSAGES")
        private List<Message> MESSAGES;

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors(chain = true)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Message {
        @JsonProperty("MESSAGE")
        private String MESSAGE;

    }
}
