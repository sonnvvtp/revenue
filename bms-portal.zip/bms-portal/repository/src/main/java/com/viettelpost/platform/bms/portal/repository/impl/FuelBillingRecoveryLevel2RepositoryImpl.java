package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryLevel2DTO;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import com.viettelpost.platform.bms.portal.repository.FuelBillingRecoveryLevel2Repository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class FuelBillingRecoveryLevel2RepositoryImpl implements
        FuelBillingRecoveryLevel2Repository {

    @Inject
    PgPool client;

    @Override
    public Mono<Void> persist(FuelBillingRecoveryLevel2DTO level2DTO, SqlConnection connection) {
        String query = "INSERT INTO bms_payment.fuel_billing_recovery_level2 (" +
                "receipt_number_excess,receipt_number_reduction, synthesis_period, unit, total_excess_amount," +
                " total_budget_excess, budget_reduction, reduction_status, created_at, excess_status, is_active"
                +
                ") VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)";

        Tuple tuple = Tuple.tuple()
                .addString(level2DTO.getNumberExcess())
                .addString(level2DTO.getNumberReduction())
                .addString(level2DTO.getSynthesisPeriod())
                .addString(level2DTO.getUnit())
                .addBigDecimal(level2DTO.getTotalExcessAmount())
                .addBigDecimal(level2DTO.getTotalExcessBudget())
                .addBigDecimal(level2DTO.getBudgetReduction())
                .addInteger(level2DTO.getReductionStatus())
                .addLocalDateTime(level2DTO.getCreatedAt())
                .addInteger(level2DTO.getExcessStatus())
                .addBoolean(level2DTO.getIsActive());

        return connection.preparedQuery(query)
                .execute(tuple)
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(rows -> log.info(
                        "[DB] Inserted fuel billing recovery level 2 with receipt number: {}",
                        level2DTO.getNumberExcess()))
                .doOnError(ex -> log.error(
                        "[DB] Error inserting fuel billing recovery level 2 with receipt number: {}",
                        level2DTO.getNumberExcess(), ex))
                .then();
    }

@Override
public Mono<Void> updateStatus(List<String> receiptNumbers, BillingStatus status, SqlConnection connection) {
    if (receiptNumbers.isEmpty()) {
        return Mono.empty();
    }

    String placeholders = IntStream.range(0, receiptNumbers.size())
            .mapToObj(i -> "$" + (i + 3))
            .collect(Collectors.joining(", "));

    String query = "UPDATE bms_payment.fuel_billing_recovery_level2 SET " +
            "reduction_status = CASE WHEN budget_reduction = 0 THEN 0 ELSE $1 END, " +
            "excess_status = CASE WHEN total_budget_excess = 0 THEN 0 ELSE $2 END " +
            "WHERE receipt_number_reduction IN (" + placeholders + ") " +
            "AND is_active = true";

    List<Object> params = new ArrayList<>();
    params.add(status.getCode());
    params.add(status.getCode());
    params.addAll(receiptNumbers);

    return connection.preparedQuery(query)
            .execute(Tuple.from(params))
            .convert().with(UniReactorConverters.toMono())
            .doOnSuccess(rows -> log.info("Updated status to {} for {} receipt numbers in level 2", status, receiptNumbers.size()))
            .doOnError(ex -> log.error("Error updating status for receipt numbers in level 2: {}", ex.getMessage()))
            .then();
}

    @Override
    public Mono<Void> updateStatusFuelBillingRecoveryLevel2(String unit, String synthesisPeriod,
            Integer status) {
        String query = "UPDATE bms_payment.fuel_billing_recovery_level2 SET reduction_status = $1 " +
                "WHERE unit = $2 AND synthesis_period = $3";

        return client.preparedQuery(query)
                .execute(Tuple.of(status, unit, synthesisPeriod))
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(rows -> log.info(
                        "Updated FuelBillingRecoveryLevel2DTO for unit: {} and synthesisPeriod: {}",
                        unit, synthesisPeriod))
                .doOnError(ex -> log.error(
                        "Error updating FuelBillingRecoveryLevel2DTO for unit: {} and synthesisPeriod: {}",
                        unit, synthesisPeriod, ex))
                .then();
    }

    @Override
    public Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection sqlConnection) {
        String query = "UPDATE bms_payment.fuel_billing_recovery_level2 SET is_active = false WHERE synthesis_period = $1";
        return sqlConnection.preparedQuery(query)
                .execute(Tuple.of(synthesisPeriod))
                .convert().with(UniReactorConverters.toMono())
                .doOnSuccess(rows -> log.info("Deactivated records for synthesis period: {}",
                        synthesisPeriod))
                .doOnError(ex -> log.error("Error deactivating records for synthesis period {}: {}",
                        synthesisPeriod, ex.getMessage()))
                .then();
    }

}
