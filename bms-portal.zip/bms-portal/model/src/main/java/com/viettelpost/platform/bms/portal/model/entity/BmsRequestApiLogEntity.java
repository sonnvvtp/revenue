package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BmsRequestApiLogEntity {

    @JsonAlias("request_log_id")
    private Long requestLogId;

    @JsonAlias("request_id")
    private String requestId;

    @JsonAlias("parrent_id")
    private String parrentId;

    @JsonAlias("request_value")
    private String requestValue;

    @JsonAlias("response_value")
    private String responseValue;

    @JsonAlias("request_key")
    private String requestKey;

    @JsonAlias("request_source")
    private String requestSource;

    @JsonAlias("request_at")
    private LocalDateTime requestAt;

    @JsonAlias("request_by")
    private String requestBy;

    @JsonAlias("tenant_id")
    private Integer tenantId;
}
