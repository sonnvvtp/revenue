package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceBuyerInfo {
    private Long id;
    private String buyerName;
    private String buyerType;
    private String buyerTaxCode;
    private String buyerPhone;
    private String buyerAddress;
    private String buyerEmail;
    private String partnerName;
}
