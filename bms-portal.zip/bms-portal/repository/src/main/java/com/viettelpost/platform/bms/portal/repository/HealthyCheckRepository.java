package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.response.PostgreClusterInfoResponse;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import reactor.core.publisher.Mono;

public interface HealthyCheckRepository extends BaseRepository {
    Mono<Integer> checkDatabasePostgres();

    Multi<PostgreClusterInfoResponse> getClusterInfo();

}
