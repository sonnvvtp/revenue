package com.viettelpost.platform.bms.revenue.worker.model.kafka;

import com.viettelpost.platform.bms.revenue.worker.model.dto.BmsBillRevenueDTO;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class BillRevenueKafka {

    private List<BmsBillRevenueDTO> billRevenueDTOs;
}
