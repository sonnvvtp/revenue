package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceRecordItemEntity {

  @JsonAlias("id")
  private Long id;

  @JsonAlias("tenant_id")
  private Integer tenantId;

  @JsonAlias("created_by")
  private Long createdBy;

  @JsonAlias("created_at")
  private LocalDateTime createdAt = LocalDateTime.now();

  @JsonAlias("updated_by")
  private Long updatedBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt = LocalDateTime.now();

  @JsonAlias("unit_level1_id")
  private String unitLevel1Id;

  @JsonAlias("unit_level2_id")
  private String unitLevel2Id;

  @JsonAlias("invoice_record_id")
  private BigDecimal invoiceRecordId;

  @JsonAlias("isactive")
  private String isActive = "y";

  @JsonAlias("rn")
  private Integer rn;

  @JsonAlias("is_note")
  private String isNote = "n";

  @JsonAlias("product_type")
  private String productType;

  @JsonAlias("note")
  private String note;

  @JsonAlias("unit")
  private String unit;

  @JsonAlias("quantity")
  private Integer quantity = 1;

  @JsonAlias("unit_price")
  private BigDecimal unitPrice = BigDecimal.ZERO;

  @JsonAlias("amount")
  private BigDecimal amount = BigDecimal.ZERO;

  @JsonAlias("invoice_item_ref_id")
  private Long invoiceItemRefId;

  @JsonAlias("invoice_adjust_id")
  private Long invoiceAdjustId;
}
