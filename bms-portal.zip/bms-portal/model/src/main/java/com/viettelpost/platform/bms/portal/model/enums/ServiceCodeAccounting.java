package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ServiceCodeAccounting {

    COD_SERVICE("COD", "COD"),
    CPN_SERVICE("CPN", "CPN"),
    LOG_SERVICE("LOG", "LOG"),
    CVPO_SERVICE("CVPO", "CVPO"),
    SVPO_SERVICE("SVPO", "SVPO"),
    FCWT_SERVICE("FCWT", "FCWT"),
    OTHER_SERVICE("KHAC", "N/A");

    private final String code;
    private final String description;

    public static ServiceCodeAccounting fromCode(Integer code) {
        for (ServiceCodeAccounting status : ServiceCodeAccounting.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("ServiceCodeAccounting Invalid status code: " + code);
    }
}
