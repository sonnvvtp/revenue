package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.common.utils.ThreadUtils;
import com.viettelpost.platform.bms.portal.model.request.AccountingFloorRequest;
import com.viettelpost.platform.bms.portal.service.handler.ChiCodFloorService;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/accounting-cod")
@RequiredArgsConstructor
@ApplicationScoped
public class AccountingCodController {

    @Inject
    ChiCodFloorService chiCodFloorService;

    @PUT
    @Path("/floor")
    @Operation(summary = "accounting cod batch id")
    public Uni<Response> updateClickCountLink(@RequestBody AccountingFloorRequest request) {
        // Trả response ngay lập tức
        Uni<Response> responseUni = Uni.createFrom().item(
                Response.status(Response.Status.OK)
                        .entity(new BaseResponse(true, "Accounting cod batch triggered successfully!", null))
                        .build()
        );

        // Xử lý chính chạy nền
        ThreadUtils.runInOtherThread(() -> {
            try {
                chiCodFloorService.pushAccountingRawChiCodFloor(request, false).block();
            } catch (Exception ex) {
                log.info("ERROR_ACCOUNTING_FLOOR : {}", ex.getMessage());
            }
        });

        return responseUni;
    }

    @PUT
    @Path("/vpo")
    @Operation(summary = "accounting cod vpo batch id")
    public Uni<Response> accountingVPO(@RequestBody AccountingFloorRequest request) {
        // Trả response ngay lập tức
        Uni<Response> responseUni = Uni.createFrom().item(
                Response.status(Response.Status.OK)
                        .entity(new BaseResponse(true, "Accounting cod batch triggered successfully!", null))
                        .build()
        );

        // Xử lý chính chạy nền
        ThreadUtils.runInOtherThread(() -> {
            try {
                chiCodFloorService.pushAccountingRawChiCodFloor(request, true).block();
            } catch (Exception ex) {
                log.info("ERROR_ACCOUNTING_VPO : {}", ex.getMessage());
            }
        });

        return responseUni;
    }
}
