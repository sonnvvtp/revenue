package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.repository.HrPostCodeDAO;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@ApplicationScoped
@RequiredArgsConstructor
public class HrPostCodeDAOImpl implements HrPostCodeDAO {

    private final ConnectionPool oracleClient;

    @Override
    public Uni<Long> getPostIdByPostCode(String postCode) {

        String sql = """
                select POST_ID
                from ERP_AC.HR_POSTCODE
                where POSTCODE = :postCode
                """;

        return executeAndGetValue(oracleClient, sql, Map.of("postCode", postCode), "POST_ID", Long.class);
    }
}
