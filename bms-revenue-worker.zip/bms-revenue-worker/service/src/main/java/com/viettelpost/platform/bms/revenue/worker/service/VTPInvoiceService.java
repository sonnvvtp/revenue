package com.viettelpost.platform.bms.revenue.worker.service;

import io.smallrye.mutiny.Uni;

public interface VTPInvoiceService {
    Uni<Void> processInvoiceRecordEveryMonth();
}
