package com.viettelpost.platform.bms.portal.model.response;

import lombok.Data;

@Data
public class UnitInfo {
    private UnitLevel unitLevel1;
    private UnitLevel unitLevel2;

    @Data
    public static class UnitLevel {
        private Long id;
        private String code;
        private String name;
    }
}
