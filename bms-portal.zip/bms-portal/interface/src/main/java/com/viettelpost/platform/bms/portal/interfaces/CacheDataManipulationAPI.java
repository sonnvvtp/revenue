package com.viettelpost.platform.bms.portal.interfaces;

import static com.viettelpost.platform.bms.common.core.uri.ReportAPI.GET_HASH;
import static com.viettelpost.platform.bms.common.core.uri.ReportAPI.PUT_HASH;
import static com.viettelpost.platform.bms.common.core.uri.ReportAPI.ROOT_CACHE;

import com.viettelpost.platform.bms.common.dto.HashGetReqDto;
import com.viettelpost.platform.bms.common.dto.HashPatchReqDto;
import com.viettelpost.platform.bms.portal.service.handler.CacheDataManipulationService;
import com.viettelpost.platform.root.common.utils.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path(ROOT_CACHE)
@Tag(name = "cache data")
@RequiredArgsConstructor
@Slf4j
public class CacheDataManipulationAPI {

    private final CacheDataManipulationService cacheDataManipulationService;

    @GET
    @Path(GET_HASH)
    @Operation(summary = "get hash")
    @APIResponse(responseCode = "200", description = "OK")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Map<String, String>> getHashApi(@Valid @BeanParam HashGetReqDto hashGetReqDto) {
        return ReactiveConverter.toUni(cacheDataManipulationService.getHash(hashGetReqDto));
    }

    @PATCH
    @Path(PUT_HASH)
    @Operation(summary = "put hash")
    @APIResponse(responseCode = "200", description = "OK")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Void> putHashApi(@Valid @RequestBody HashPatchReqDto hashPatchReqDto) {
        return ReactiveConverter.toUni(cacheDataManipulationService.putHash(hashPatchReqDto));
    }
}
