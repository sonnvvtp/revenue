package com.viettelpost.platform.bms.portal.model.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FuelQuotaDTO {

    Long id;
    String synthesisPeriod;
    String carLicensePlate;
    BigDecimal budget;
    BigDecimal averageUnitPrice;
    BigDecimal quata;
    BigDecimal actualMileage;
    BigDecimal fuelConsumptionRate;
    BigDecimal fuelConsumptionUnit;
    BigDecimal expectedFuelConsumption;
    BigDecimal invoiceFuelAmount;
    BigDecimal invoiceAmount;
    BigDecimal budgetExcess;
    BigDecimal fuelExcess;
    BigDecimal totalExcessAmount;
    BigDecimal budgetReduction;
    LocalDateTime createdAt;
    Long carId;
    String unit;
    Boolean isActive;
}
