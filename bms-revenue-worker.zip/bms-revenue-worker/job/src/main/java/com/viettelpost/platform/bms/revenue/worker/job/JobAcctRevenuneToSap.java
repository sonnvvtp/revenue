package com.viettelpost.platform.bms.revenue.worker.job;

import com.viettelpost.platform.bms.revenue.worker.service.GloExpRevenueService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.job.JobAbs;
import io.quarkus.scheduler.Scheduled;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Mono;

@ApplicationScoped
@Slf4j
@Named("JobAcctRevenuneToSap")
@RequiredArgsConstructor
public class JobAcctRevenuneToSap extends JobAbs<Void> {

    @ConfigProperty(name = "config.cron.acct.revenue.sap", defaultValue = "0 0/1 * * * ?")
    String cronJobAcctRevenuneToSap;

    private final GloExpRevenueService gloExpRevenueService;

    // Job chạy theo cron timeJobRun
    @Scheduled(cron = "${config.cron.acct.revenue.sap}")
    public Uni<Void> acctRevenuneToSap() {
        return ReactiveConverter.toUni(super.executeTask("acctRevenuneToSap", cronJobAcctRevenuneToSap));
    }

    @Override
    protected Mono<Void> taskAction() {
        log.debug("=====start_JobAcctRevenuneToSap======");
        return ReactiveConverter.toMono(gloExpRevenueService.pusRevenueToAccountingSap());
    }
}
