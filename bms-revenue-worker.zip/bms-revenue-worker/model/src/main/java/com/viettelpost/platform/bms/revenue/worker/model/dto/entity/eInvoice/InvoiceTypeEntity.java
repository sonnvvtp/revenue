package com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceTypeEntity {

  @JsonAlias("invoice_type_id")
  private BigDecimal id;

  @JsonAlias("type_code")
  private String typeCode;

  @JsonAlias("template_code")
  private String templateCode;

  @JsonAlias("is_active")
  private Boolean isActive = true;

  @JsonAlias("company_code")
  private String companyCode;

  @JsonAlias("created_at")
  private LocalDateTime createdAt = LocalDateTime.now();

  @JsonAlias("created_by")
  private String createdBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt = LocalDateTime.now();

  @JsonAlias("updated_by")
  private String updatedBy;

  @JsonAlias("tenant_id")
  private Short tenantId = 1;

  @JsonAlias("created_name")
  private String createdName;

  @JsonAlias("updated_name")
  private String updatedName;
}
