package com.viettelpost.platform.bms.portal.model.response.forControl;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BmsDebtComparisonExternalDTO {
    @JsonAlias("debtcomparisonid")
    public Long debtComparisonId;

    @JsonAlias("reqpaymentid")
    public Long reqPaymentId;

    @JsonAlias("reqvtpoderid")
    public String reqVtpOderId;

    @JsonAlias("partnertransid")
    public String partnerTransId;

    @JsonAlias("reqcollectamount")
    public BigDecimal reqCollectAmount;

    @JsonAlias("reqpaymentdate")
    public String reqPaymentDate;

    @JsonAlias("reqdocstatus")
    public Long reqDocStatus;

    @JsonAlias("rescollectamount")
    public BigDecimal resCollectAmount;

    @JsonAlias("respaymentdate")
    public String resPaymentDate;

    @JsonAlias("resdocstatus")
    public Long resDocStatus;

    @JsonAlias("paycode")
    public String payCode;

    @JsonAlias("checkedamount")
    public BigDecimal checkedAmount;

    @JsonAlias("checkedstatus")
    public Long checkedStatus;

    @JsonAlias("created")
    public String created;

    @JsonAlias("createdby")
    public Long createdBy;

    @JsonAlias("docstatus")
    public Long docStatus;

    @JsonAlias("doctype")
    public Long docType;

    @JsonAlias("postid")
    public Long postId;

    @JsonAlias("postcode")
    public String postCode;

    @JsonAlias("orgid")
    public Long orgId;

    @JsonAlias("orgcode")
    public String orgCode;

    @JsonAlias("merchanttype")
    public String merchantType;

    @JsonAlias("servicetype")
    public String serviceType;

    @JsonAlias("partnersource")
    public String partnerSource;

    @JsonAlias("partnerid")
    public Long partnerId;

    @JsonAlias("updated")
    public String updated;

    @JsonAlias("updateby")
    public Long updateBy;

    @JsonAlias("ischecked")
    public Long isChecked;

    @JsonAlias("partnertransferid")
    public String partnerTransferId;

    @JsonAlias("transactionfee")
    public BigDecimal transactionFee;

    final Integer groupType = 2;

}
