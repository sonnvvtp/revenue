package com.viettelpost.platform.bms.portal.model.request.epacket;

import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import com.viettelpost.platform.bms.portal.model.enums.EpacketTransactionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketCallbackRequest {
    private String transactionCode;
    private Long cusId;
    private PartnerSource partnerSource;
    private ServiceType serviceType;
    private MerchantType merchantType;
    private EpacketTransactionType epacketTransactionType;
}
