package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum StatusPaidQrCodeClearPayIn {

    BAO_KIM_PAID(2,51, 52, "Đã thu BK"),
    VCB_PAID(3,61, 62, "Đã thu VCB"),
    VIETTEL_MONEY_PAID(6,41, 42, "Đã thu TKLK"),
    OCB_PAID(9,87, 88, "Đã thu OCB"),
    BIDV_PAID(4,91, 92, "Đã thu BIDV"),
    STB_PAID(8,57, 58, "Đã thu SacomBank"),
    TPB_PAID(7,54, 55, "Đã thu TPBank"),
    HDB_PAID(16,64, 65, "Đã thu HDBank"),
    HPAY_PAID(26,97, 98, "Đã thu HPAY"),
    NA(-1,-1,-1,"NA");

    private int partnerId;
    private int record;
    private int bill;
    private String description;

    public static StatusPaidQrCodeClearPayIn get(int bill) {
        return Arrays.stream(StatusPaidQrCodeClearPayIn.values())
                .filter(e -> Objects.equals(e.getBill(), bill)).findFirst().orElse(NA);
    }
}

