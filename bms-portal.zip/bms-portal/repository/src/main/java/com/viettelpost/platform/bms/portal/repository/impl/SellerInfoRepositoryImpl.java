package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.model.entity.SellerInfoEntity;
import com.viettelpost.platform.bms.portal.model.request.SellerAccountRequest;
import com.viettelpost.platform.bms.portal.model.request.SellerInfoRequest;
import com.viettelpost.platform.bms.portal.model.response.PageResponse;
import com.viettelpost.platform.bms.portal.repository.SellerInfoRepository;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
@RequiredArgsConstructor
public class SellerInfoRepositoryImpl implements SellerInfoRepository {
    private final PgPool client;

    private final AuthenticationContext authCtx;


    @Override
    public Uni<SellerInfoEntity> create(SellerInfoRequest request) {
        String checkSql = """
                    SELECT 1 FROM bms_payment.seller_info WHERE company_code = $1
                """;

        String insertSql = """
                    INSERT INTO bms_payment.seller_info (
                        seller_name,
                        tax_code,
                        address,
                        phone,
                        email,
                        bank_name,
                        bank_account,
                        company_code,
                        created_at,
                        created_by,
                        updated_at,
                        updated_by,
                        tenant_id
                    ) VALUES (
                        $1, $2, $3, $4, $5, $6, $7, $8,
                        CURRENT_TIMESTAMP, $9,
                        CURRENT_TIMESTAMP, $9, 1
                    ) RETURNING *
                """;

        String currentUser = Optional.ofNullable(authCtx.getCurrentUser())
                .map(u -> u.getName())
                .orElse("system");

        return client.preparedQuery(checkSql)
                .execute(Tuple.of(request.getCompanyCode()))
                .onItem().transformToUni(rows -> {
                    if (rows.iterator().hasNext()) {
                        return Uni.createFrom().failure(
                                new IllegalArgumentException("Thông tin người bán cho company_code '" +
                                                             request.getCompanyCode() + "' đã tồn tại.")
                        );
                    }

                    Tuple params = Tuple.tuple()
                            .addValue(request.getSellerName())
                            .addValue(request.getTaxCode())
                            .addValue(request.getAddress())
                            .addValue(request.getPhone())
                            .addValue(request.getEmail())
                            .addValue(request.getBankName())
                            .addValue(request.getBankAccount())
                            .addValue(request.getCompanyCode())
                            .addValue(currentUser);

                    return client.preparedQuery(insertSql)
                            .execute(params)
                            .onItem().transform(rowSet -> {
                                Row row = rowSet.iterator().next();
                                return SellerInfoEntity.builder()
                                        .sellerId(row.getLong("seller_id"))
                                        .sellerName(row.getString("seller_name"))
                                        .taxCode(row.getString("tax_code"))
                                        .address(row.getString("address"))
                                        .phone(row.getString("phone"))
                                        .email(row.getString("email"))
                                        .bankName(row.getString("bank_name"))
                                        .bankAccount(row.getString("bank_account"))
                                        .companyCode(row.getString("company_code"))
                                        .createdAt(row.getLocalDateTime("created_at"))
                                        .createdBy(row.getString("created_by"))
                                        .updatedAt(row.getLocalDateTime("updated_at"))
                                        .updatedBy(row.getString("updated_by"))
                                        .tenantId(row.getShort("tenant_id"))
                                        .build();
                            });
                });
    }

    @Override
    public Uni<PageResponse<SellerInfoEntity>> getAll(int page, int size) {
        int safePage = Math.max(page, 1);
        int offset = (safePage - 1) * size;

        String dataSql = """
                    SELECT *
                    FROM bms_payment.seller_info
                    ORDER BY seller_id
                    OFFSET $1 LIMIT $2
                """;

        String countSql = """
                    SELECT COUNT(*) FROM bms_payment.seller_info
                """;

        Tuple dataParams = Tuple.of(offset, size);

        Uni<List<SellerInfoEntity>> dataUni = client.preparedQuery(dataSql)
                .execute(dataParams)
                .onItem()
                .transform(rowSet -> {
                    List<SellerInfoEntity> list = new ArrayList<>();
                    for (Row row : rowSet) {
                        list.add(SellerInfoEntity.builder()
                                .sellerId(row.getLong("seller_id"))
                                .sellerName(row.getString("seller_name"))
                                .taxCode(row.getString("tax_code"))
                                .address(row.getString("address"))
                                .phone(row.getString("phone"))
                                .email(row.getString("email"))
                                .bankName(row.getString("bank_name"))
                                .bankAccount(row.getString("bank_account"))
                                .companyCode(row.getString("company_code"))
                                .createdAt(row.getLocalDateTime("created_at"))
                                .createdBy(row.getString("created_by"))
                                .updatedAt(row.getLocalDateTime("updated_at"))
                                .updatedBy(row.getString("updated_by"))
                                .tenantId(row.getShort("tenant_id"))
                                .build());
                    }
                    return list;
                });

        Uni<Long> countUni = client.preparedQuery(countSql)
                .execute()
                .onItem()
                .transform(rowSet -> rowSet.iterator().next().getLong(0));

        return Uni.combine().all().unis(dataUni, countUni)
                .asTuple()
                .onItem()
                .transform(tuple -> new PageResponse<>(tuple.getItem1(), tuple.getItem2()));
    }

    @Override
    public Uni<SellerInfoEntity> update(Long id, SellerInfoRequest request) {
        String checkSql = """
                    SELECT 1 FROM bms_payment.seller_info
                    WHERE company_code = $1 AND seller_id <> $2
                """;

        String updateSql = """
                    UPDATE bms_payment.seller_info
                    SET
                        seller_name = $1,
                        tax_code = $2,
                        address = $3,
                        phone = $4,
                        email = $5,
                        bank_name = $6,
                        bank_account = $7,
                        company_code = $8,
                        updated_at = CURRENT_TIMESTAMP,
                        updated_by = $9
                    WHERE seller_id = $10
                    RETURNING *
                """;

        String currentUser = Optional.ofNullable(authCtx.getCurrentUser())
                .map(u -> u.getName())
                .orElse("system");

        return client.preparedQuery(checkSql)
                .execute(Tuple.of(request.getCompanyCode(), id))
                .onItem().transformToUni(rows -> {
                    if (rows.iterator().hasNext()) {
                        return Uni.createFrom().failure(
                                new IllegalArgumentException("Đã tồn tại thông tin người bán với company_code: " + request.getCompanyCode())
                        );
                    }


                    Tuple params = Tuple.tuple()
                            .addValue(request.getSellerName())
                            .addValue(request.getTaxCode())
                            .addValue(request.getAddress())
                            .addValue(request.getPhone())
                            .addValue(request.getEmail())
                            .addValue(request.getBankName())
                            .addValue(request.getBankAccount())
                            .addValue(request.getCompanyCode())
                            .addValue(currentUser)
                            .addValue(id);

                    return client.preparedQuery(updateSql)
                            .execute(params)
                            .onItem().transform(rowSet -> {
                                if (!rowSet.iterator().hasNext()) {
                                    throw new NotFoundException("Không tìm thấy seller_id: " + id);
                                }

                                Row row = rowSet.iterator().next();
                                return SellerInfoEntity.builder()
                                        .sellerId(row.getLong("seller_id"))
                                        .sellerName(row.getString("seller_name"))
                                        .taxCode(row.getString("tax_code"))
                                        .address(row.getString("address"))
                                        .phone(row.getString("phone"))
                                        .email(row.getString("email"))
                                        .bankName(row.getString("bank_name"))
                                        .bankAccount(row.getString("bank_account"))
                                        .companyCode(row.getString("company_code"))
                                        .createdAt(row.getLocalDateTime("created_at"))
                                        .createdBy(row.getString("created_by"))
                                        .updatedAt(row.getLocalDateTime("updated_at"))
                                        .updatedBy(row.getString("updated_by"))
                                        .tenantId(row.getShort("tenant_id"))
                                        .build();
                            });
                });
    }

    @Override
    public Uni<Void> updateAccountInfo(Long sellerId, SellerAccountRequest request) {
        String checkSql = """
                    SELECT 1 FROM bms_payment.seller_info WHERE seller_id = $1
                """;

        String updateSql = """
                    UPDATE bms_payment.seller_info
                    SET
                        username = $1,
                        password = $2,
                        updated_at = CURRENT_TIMESTAMP,
                        updated_by = $3
                    WHERE seller_id = $4
                """;

        String currentUser = Optional.ofNullable(authCtx.getCurrentUser())
                .map(u -> u.getName())
                .orElse("system");

        return client.preparedQuery(checkSql)
                .execute(Tuple.of(sellerId))
                .onItem().transformToUni(rows -> {
                    if (!rows.iterator().hasNext()) {
                        return Uni.createFrom().failure(
                                new NotFoundException("Không tìm thấy seller_id: " + sellerId)
                        );
                    }

                    Tuple params = Tuple.of(request.getUsername(), request.getPassword(), currentUser, sellerId);

                    return client.preparedQuery(updateSql)
                            .execute(params)
                            .onItem().transformToUni(result -> {
                                if (result.rowCount() == 0) {
                                    return Uni.createFrom().failure(
                                            new IllegalStateException("Không thể cập nhật tài khoản người bán.")
                                    );
                                }
                                return Uni.createFrom().voidItem();
                            });
                });
    }


}
