package com.viettelpost.platform.bms.portal.interfaces;


import com.viettelpost.platform.bms.portal.model.response.BillPetroFailDataResponse;
import com.viettelpost.platform.bms.portal.model.response.BillPetroSuccessDataResponse;
import com.viettelpost.platform.bms.portal.model.response.ReSyncBillOnPetrol;
import com.viettelpost.platform.bms.portal.service.handler.BillPetroService;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import javax.inject.Inject;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


@Path("/bill")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Bill Operations")
public class BillController {

    private final BillPetroService billService;

    private final InvoiceService invoiceService;

    @Inject
    public BillController(BillPetroService billService, InvoiceService invoiceService) {
        this.billService = billService;
        this.invoiceService = invoiceService;
    }

    @GET
    @Path("/resync-petrol")
    @Operation(summary = "Mock ReSync Bill API")
    @APIResponse(responseCode = "200", description = "Returns a mock response of resync bills")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<ReSyncBillOnPetrol> getMockReSyncBill(
            @QueryParam("fromTime") String fromTime,
            @QueryParam("toTime") String toTime) {
        return ReactiveConverter.toUni(
                invoiceService.processInvoices(fromTime, toTime, System.currentTimeMillis()));
    }

    @POST
    @Path("/export-fail")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON})
    @Operation(summary = "Export fail bills to Excel")
    @APIResponse(responseCode = "200", description = "Returns an Excel file containing failed bill data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportToExcel(List<BillPetroFailDataResponse> dataFail) {
        return Uni.createFrom().item(() -> {
            try {
                byte[] excelData = billService.exportToExcel(dataFail);
                String fileName = billService.generateFileName("fail");
                return Response.ok(new ByteArrayInputStream(excelData))
                        .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                        .build();
            } catch (IOException e) {
                return Response.serverError().entity("Failed to generate Excel file").build();
            }
        });
    }

    @POST
    @Path("/export-success")
    @Produces({MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON})
    @Operation(summary = "Export success bills to Excel")
    @APIResponse(responseCode = "200", description = "Returns an Excel file success bill data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportToExcelSuccessBill(List<BillPetroSuccessDataResponse> dataSuccess) {
        return Uni.createFrom().item(() -> {
            try {
                byte[] excelData = billService.exportToExcelSuccessBill(dataSuccess);
                String fileName = billService.generateFileName("success");
                return Response.ok(new ByteArrayInputStream(excelData))
                        .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                        .build();
            } catch (IOException e) {
                return Response.serverError().entity("Failed to generate Excel file").build();
            }
        });
    }
}