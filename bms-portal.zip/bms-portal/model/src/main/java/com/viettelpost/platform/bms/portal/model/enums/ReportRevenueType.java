package com.viettelpost.platform.bms.portal.model.enums;

import lombok.Getter;

@Getter
public enum ReportRevenueType {
    TEMPORARY_REVENUE(1, "Doanh thu chưa thực hiện"),
    COMPLETED_REVENUE(2, "Doanh thu hoàn thành");

    private final int code;
    private final String name;

    ReportRevenueType(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ReportRevenueType fromCode(int code) {
        for (ReportRevenueType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Loại báo cáo doanh thu không hợp lệ");
    }
}
