package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EpacketTransactionEntity {

    @JsonAlias("req_transaction_id")
    private Long reqTransactionId;

    @JsonAlias("cust_id")
    private Long custId;

    @JsonAlias("created_date")
    private LocalDateTime createdDate;

    @JsonAlias("is_checked")
    private Integer isChecked;

    @JsonAlias("org_code")
    private String orgCode;

    @JsonAlias("org_id")
    private Long orgId;

    @JsonAlias("partner_internal_id")
    private Long partnerInternalId;

    @JsonAlias("post_code")
    private String postCode;

    @JsonAlias("post_id")
    private Long postId;

    @JsonAlias("req_acc_name")
    private String reqAccName;

    @JsonAlias("req_acc_no")
    private String reqAccNo;

    @JsonAlias("req_collect_amount")
    private BigDecimal reqCollectAmount;

    @JsonAlias("req_expire_date")
    private LocalDateTime reqExpireDate;

    @JsonAlias("req_memo")
    private String reqMemo;

    @JsonAlias("req_operation")
    private String reqOperation;

    @JsonAlias("req_partner_code")
    private String reqPartnerCode;

    @JsonAlias("req_partner_id")
    private Long reqPartnerId;

    @JsonAlias("req_payment_code")
    private String reqPaymentCode;

    @JsonAlias("req_payment_time")
    private LocalDateTime reqPaymentTime;

    @JsonAlias("req_request_type")
    private Long reqRequestType;

    @JsonAlias("res_qr_path")
    private String resQrPath;

    @JsonAlias("res_qr_string")
    private String resQrString;

    @JsonAlias("status")
    private Integer status;

    @JsonAlias("transaction_type")
    private Integer transactionType;

    @JsonAlias("transaction_code")
    private String transactionCode;

    @JsonAlias("updated_by")
    private Long updatedBy;

    @JsonAlias("updated_date")
    private LocalDateTime updatedDate;

    @JsonAlias("request_id")
    private String requestId;

    @JsonAlias("partner_internal_line_id")
    private Long partnerInternalLineId;

    @JsonAlias("recon_status")
    private Integer reconStatus;

    @JsonAlias("transaction_source")
    private Integer transactionSource;


}
