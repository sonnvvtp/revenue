package com.viettelpost.platform.bms.portal.common.model;

import lombok.Builder;
import lombok.Data;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;

@Data
@Builder
public class HeaderCell {
    private String name;

    private HorizontalAlignment headerHorizontalAlignment;

    private HorizontalAlignment cellHorizontalAlignment;

    private VerticalAlignment headerVerticalAlignment;

    private VerticalAlignment cellVerticalAlignment;

    @Builder.Default
    private boolean isBold = true;

    private IndexedColors foregroundHeaderColor;

    private String fieldName;

    private boolean isSerialNumber;
}

