package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UploadFileApiResponse {
    private boolean error;
    private String message;
    private UploadFileResponse data;
}