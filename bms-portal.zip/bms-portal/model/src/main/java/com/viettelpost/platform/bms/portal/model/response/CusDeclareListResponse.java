package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CusDeclareListResponse {
    @JsonAlias("cus_id")
    private Long cusId;

    @JsonAlias("phone")
    private String phone;

    @JsonAlias("full_name")
    private String fullName;

    @JsonAlias("email")
    private String email;

    @JsonAlias("payment_period")
    private String periodPayment;

    @JsonAlias("created_by")
    private String createdBy;

    @JsonAlias("created_declare")
    private String createdDeclare;

    @JsonAlias("updated_declare")
    private String updatedDeclare;

    @JsonAlias("payment_type")
    private Integer paymentType;

    @JsonAlias("active")
    private Integer active;


    public String getPaymentTypeLabel() {
        if (paymentType == null) {
            return null;
        }
        return switch (paymentType) {
            case -1 ->  "Chưa cấu hình";
            case 0 ->  "Tiền mặt";
            case 1 -> "Ngân hàng ";
            case 2 -> "Viettel pay";
            case 3 -> "E-VTP";
            default -> "Khác";
        };
    }

    public String getPaymentPeriodLabel() {
        if (periodPayment == null) {
            return null;
        }
        return switch (periodPayment) {
            case "0" ->  "Hằng ngày";
            default -> "Thứ " + periodPayment;
        };
    }
}
