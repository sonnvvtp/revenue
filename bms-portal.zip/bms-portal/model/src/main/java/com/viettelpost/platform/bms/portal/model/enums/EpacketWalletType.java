package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;
@AllArgsConstructor
@Getter
public enum EpacketWalletType {
    CUS_WALLET(1, "CUS_WALLET", "Ví khách hàng"),
    VTP_WALLET(2, "VTP_WALLET", "Ví VTP"),

    NA(-1, "N/A", "N/A");
    private int id;
    private String code;
    private String name;

    public static EpacketWalletType get(String code) {
        return Arrays.stream(EpacketWalletType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(NA);
    }
}
