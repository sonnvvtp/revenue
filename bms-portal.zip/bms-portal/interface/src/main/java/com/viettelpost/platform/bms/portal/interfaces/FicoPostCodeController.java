package com.viettelpost.platform.bms.portal.interfaces;


import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.service.handler.FicoPostCodeService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/postcodes")
@Tag(name = "API cấu hình đơn vị tính (xuất hóa đơn)")
@RequiredArgsConstructor
public class FicoPostCodeController {
    private final FicoPostCodeService ficoPostCodeService;

    @GET
    @Path("/{postcode}")
    @Operation(summary = "Lấy thông tin đăng nhập theo postcode")
    @APIResponse(responseCode = "200", description = "Trả về thông tin postcode")
    @APIResponse(responseCode = "400", description = "Yêu cầu không hợp lệ")
    public Uni<Response> getPostCode(@PathParam("postcode") String postCode) {
        return ficoPostCodeService.getPostCodeFromCode(postCode)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }
}
