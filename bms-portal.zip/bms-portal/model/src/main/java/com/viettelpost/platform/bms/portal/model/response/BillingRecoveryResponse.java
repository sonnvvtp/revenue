package com.viettelpost.platform.bms.portal.model.response;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingRecoveryResponse {

    private Long id;
    private String receiptNumber;
    private String synthesisPeriod;
    private BigDecimal budgetReduction;
    private BigDecimal budgetExcess;
    private String approved;
    private Integer status;
    private String causeReason;
}

