package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.viettelpost.platform.bms.portal.common.config.CustomLocalDateTimeDeserializer;
import jakarta.validation.constraints.NotEmpty;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class GeneralOrderRequest {
  private String orderId;
  @NotEmpty(message = "vui lòng điền mã đơn")
  private String orderCode;
  private String orderReference;
  private String cashflowType;
  private String serviceCode;
  @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime orderCreatedAt;
  @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime orderDeliveredAt;
  private Long employeeId;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> employeeInfo;
  private Long unitLevel1Id;
  private Long unitLevel2Id;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> unitInfo;
  private String companyCode;
  private Long sellerId;
  private String sellerCode;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> sellerInfo;
  private Long buyerId;
  private String buyerCode;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> buyerInfo;
  private Long consigneeId;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> consignee;
  private Long orderTotalQuantity;
  private BigDecimal orderAmountBeforeTax;
  private BigDecimal orderTaxAmount;
  private BigDecimal orderAmountAfterTax;
  private BigDecimal totalAmount;
  @JsonDeserialize(as = LinkedHashMap.class)
  private Map<String, Object> paymentInfo;
  private Integer paymentMethod;
  private Integer paymentTermId;
  private String invoicePartner;
  private String currency;
  private InvoiceInfoDTO invoiceInfo;
  private List<ItemOrderDTO> itemOrderList;
  @NotEmpty(message = "vui lòng điền nguồn đẩy đơn")
  private String orderSource;
  private Integer recordType;
  private String domainType;
  private Integer picType;
  private Integer tenantId;
}

