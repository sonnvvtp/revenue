package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.model.VehicleTypeGroupKmcpModel;
import com.viettelpost.platform.bms.portal.model.model.VehicleTypeGroupModel;
import java.util.List;
import reactor.core.publisher.Mono;

public interface FuelBillingRecoveryConfig {

    Mono<List<VehicleTypeGroupModel>> getAllVehicleTypeGroup();

    Mono<List<VehicleTypeGroupKmcpModel>> getAllVehicleTypeGroupKmcpConfig();
}
