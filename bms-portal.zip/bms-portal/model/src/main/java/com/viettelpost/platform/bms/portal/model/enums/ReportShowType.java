package com.viettelpost.platform.bms.portal.model.enums;

import lombok.Getter;

@Getter
public enum ReportShowType {
    SHOW_CUS(1, "Hiển thị theo khách hàng"),
    SHOW_POST(2, "Hiển thị theo bưu cục"),
    SHOW_SERVICE(3, "Hiển thị theo dịch vụ");

    private final int code;
    private final String name;

    ReportShowType(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ReportShowType fromCode(int code) {
        for (ReportShowType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Loại báo cáo doanh thu không hợp lệ");
    }
}
