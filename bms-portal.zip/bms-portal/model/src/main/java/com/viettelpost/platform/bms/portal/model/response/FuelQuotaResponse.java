package com.viettelpost.platform.bms.portal.model.response;

import java.math.BigDecimal;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FuelQuotaResponse {

    private Long id;
    private String synthesisPeriod;
    private String carLicensePlate;
    private BigDecimal budget;
    private BigDecimal averageUnitPrice;
    private BigDecimal quata;
    private BigDecimal actualMileage;
    private BigDecimal fuelConsumptionRate;
    private BigDecimal fuelConsumptionUnit;
    private BigDecimal expectedFuelConsumption;
    private BigDecimal invoiceFuelAmount;
    private BigDecimal invoiceAmount;
    private BigDecimal budgetExcess;
    private BigDecimal fuelExcess;
    private BigDecimal totalExcessAmount;
    private BigDecimal budgetReduction;
    private Integer excessStatus;
    private Integer reductionStatus;
}
