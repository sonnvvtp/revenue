package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceItemInfoEntity {

    @JsonAlias("id")
    private Long id;

    @JsonAlias("tenant_id")
    private Integer tenantId;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("created_at")
    private LocalDateTime createdAt;

    @JsonAlias("updated_by")
    private Long updatedBy;

    @JsonAlias("updated_at")
    private LocalDateTime updatedAt;

    @JsonAlias("invoice_customer_id")
    private BigDecimal invoiceCustomerId;

    @JsonAlias("customer_item_code")
    private String customerItemCode;

    @JsonAlias("customer_item_type")
    private Short customerItemType;

    @JsonAlias("customer_item_name")
    private String customerItemName;

    @JsonAlias("customer_item_phone")
    private String customerItemPhone;

    @JsonAlias("customer_item_email")
    private String customerItemEmail;

    @JsonAlias("customer_item_address")
    private String customerItemAddress;

    @JsonAlias("customer_item_tax")
    private String customerItemTax;

    @JsonAlias("invoice_condition_lv1")
    private String invoiceConditionLv1;

    @JsonAlias("invoice_condition_lv2")
    private String invoiceConditionLv2;

    @JsonAlias("from_date")
    private Integer fromDate;

    @JsonAlias("to_date")
    private Integer toDate;

    @JsonAlias("auto_merge_bill")
    private Boolean autoMergeBill = false;

    @JsonAlias("bank_name")
    private String bankName;

    @JsonAlias("bank_account_number")
    private String bankAccountNumber;

    @JsonAlias("bank_account_name")
    private String bankAccountName;

    @JsonAlias("payment_date")
    private LocalDateTime paymentDate;
}
