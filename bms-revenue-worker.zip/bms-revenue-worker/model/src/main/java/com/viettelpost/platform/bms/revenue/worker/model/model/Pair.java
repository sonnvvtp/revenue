package com.viettelpost.platform.bms.revenue.worker.model.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Pair<T, R> {
    private T first;
    private R second;
}
