package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;
@Getter
@AllArgsConstructor
public enum MerchantType {
    VTP_POSTMAN(1, "VTP_POSTMAN", "VTMan"),
    VTP_CUSTOMER(2, "VTP_POSTMAN", "App/web"),
    EGL(3, "EGL", "EGL"),
    ADELA(4, "ADELA", "ADELA"),
    VIPO(5, "VIPO", "VIPO"),
    ABBOTT(6, "ABBOTT", "ABBOTT"),
    EGLSC(7, "EGLSC", "EGLSC"),
    FMCG(13, "FMCG", "FMCG"),
    QTCV(14, "QTCV", "QTCV"),
    HUBLOCK(15, "HUBLOCK","HUBLOCK"),
    LGT(16, "LGT", "LGT"),
    NA(-1, "N/A", "N/A");
    private int id;
    private String code;
    private String name;

    public static MerchantType get(String code) {
        return Arrays.stream(MerchantType.values())
                .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(NA);
    }
}
