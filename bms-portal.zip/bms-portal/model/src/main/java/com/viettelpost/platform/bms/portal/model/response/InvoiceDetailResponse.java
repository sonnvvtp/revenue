package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceDetailResponse {
    private String recordNo; // Mã bảng kê
    private String orderCode; // Đơn hàng
    private String invoiceDate; // Ngày hóa đơn
    private String invoiceNo; // Số
    private String invoiceSymbol; // Ký hiệu
    private String invoicePattern; // Mẫu số
    private String customerCode; // Mã khách hàng
    private Double totalAmountBeforeTax; // Tiền hàng trước thuế
    private Double totalTaxAmount; // Tiền thuế
    private Double totalDiscountAmount; // Chiết khấu
    private Double totalAmountAfterTax; // Tiền sau thuế
    private List<InvoiceDetailItem> items;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceDetailItem {
        private Integer index; // STT
        private String productName; // Tên hàng hóa
        private String unit; // Đơn vị tính
        private Integer quantity; // Số lượng
        private Double unitPrice; // Đơn giá
        private Double amountBeforeTax; // Tiền hàng trước thuế
        private Double taxRate; // Thuế suất
        private Double taxAmount; // Tiền thuế
        private Double discountAmount; // Chiết khấu
        private Double amountAfterTax; // Tiền sau thuế
    }
} 