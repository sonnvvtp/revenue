package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.Map;

@Data
public class AdvanceAcctDetailDTO {

    @JsonAlias("ADVANCE_ACCT_DETAIL_ID")
    private Long advanceAcctDetailId;

    @JsonAlias("ADVANCE_ACCT_ID")
    private Long advanceAcctId;

    @JsonAlias("REF_ID")
    private Long refId;

    private Map<String, Object> details;
}
