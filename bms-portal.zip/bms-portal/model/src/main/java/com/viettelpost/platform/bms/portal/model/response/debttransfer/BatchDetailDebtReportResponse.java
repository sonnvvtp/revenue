package com.viettelpost.platform.bms.portal.model.response.debttransfer;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class BatchDetailDebtReportResponse {

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("PARTNER_NAME")
    private String partnerName;

    @JsonAlias("BATCH_NO")
    private String batchNo;

    @JsonAlias("AMT")
    private BigDecimal amt;

    @JsonAlias("AMT_DEDUCT")
    private BigDecimal amtDeduct;

    @JsonAlias("AMT_DEDUCT_OTHER")
    private BigDecimal amtDeductOther;

    @JsonAlias("AMT_PAY")
    private BigDecimal amtPay;

    @JsonAlias("PERIOD_NAME")
    private String periodName;

    @JsonAlias("NOTE")
    private String note;

    @JsonAlias("DOCSTATUS")
    private Integer docStatus;

    @JsonAlias("DOCUMENTNO")
    private String documentNo;

    @JsonAlias("DOCTYPE_ID")
    private Long docTypeId;

    @JsonAlias("ACCOUNTING_DATE")
    private String accountingDate;

    @JsonAlias("TOTAL_AMT_PAY_STRING")
    private String totalAmtPayString;
}
