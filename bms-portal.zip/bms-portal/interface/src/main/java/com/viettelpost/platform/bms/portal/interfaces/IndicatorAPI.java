package com.viettelpost.platform.bms.portal.interfaces;

import static com.viettelpost.platform.bms.common.core.uri.ReportAPI.GET_INDICATOR;
import static com.viettelpost.platform.bms.common.core.uri.ReportAPI.ROOT_INDICATOR;

import com.viettelpost.platform.bms.portal.service.handler.IndicatorService;
import com.viettelpost.platform.root.common.utils.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Produces(MediaType.TEXT_PLAIN)
@Consumes(MediaType.TEXT_PLAIN)
@Path(ROOT_INDICATOR)
@Tag(name = "indicators")
@RequiredArgsConstructor
@Slf4j
public class IndicatorAPI {

    private final IndicatorService indicatorService;

    @GET
    @Path(GET_INDICATOR)
    @Operation(summary = "get indicators")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<String> indicatorsApi() {
        return ReactiveConverter.toUni(indicatorService.indicators());
    }
}
