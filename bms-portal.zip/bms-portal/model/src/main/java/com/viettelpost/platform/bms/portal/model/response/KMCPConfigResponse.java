package com.viettelpost.platform.bms.portal.model.response;

import com.viettelpost.platform.bms.portal.model.model.KMCPModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KMCPConfigResponse {
    private Long id;
    private Long vehicleTypeGroupId;
    private String vehicleTypeGroupName;
    private Integer orgType;
    private KMCPModel kmcp;
    private CommitmentItemResponse commitmentItem;
}
