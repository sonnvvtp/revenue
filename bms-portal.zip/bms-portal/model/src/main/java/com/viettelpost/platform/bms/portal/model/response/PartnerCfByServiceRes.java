package com.viettelpost.platform.bms.portal.model.response;

import com.viettelpost.platform.bms.portal.model.request.partnerConfig.PartnerConfigGroup;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartnerCfByServiceRes {
    private Long total;
    private List<PartnerConfigGroup> details;
}
