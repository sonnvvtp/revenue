package com.viettelpost.platform.bms.revenue.worker.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodeEnum {

    SUCCESS("00", "SUCCESS"),
    UNAUTHORIZED("01", "UNAUTHORIZED"),
    DATA_ERROR("02", "DATA_ERROR"),
    INTERNAL_SERVER_ERROR("99", "INTERNAL_SERVER_ERROR"),
    RECORD_COD_NOT_FOUND("03", "Không tìm thấy bảng kê"),
    CREATE_RECORD_ERROR("04", "Danh sách bill không cùng khách hàng hoặc loại bill"),
    ADD_BILL_RECORD_ERROR("05", "Bill với mã %d không hợp lệ"),
    BILL_NOT_FOUND("06", "Không tìm thấy bill"),
    CREATE_BATCH_ERROR("07", "Danh sách bảng kê không cùng khách hàng hoặc loại bill"),
    PAY_BATCH_NOT_FOUND("08", "Không tìm thấy bảng kê chi"),
    CUSTOMER_NOT_FOUND("09", "Không tìm thấy mã khách hàng"),
    CREATE_STATEMENT_ERROR("10", "Danh sách bảng kê không cùng ngân hàng chi"),
    PAY_BATCH_BANK_ERROR("11", "Bảng kê chưa có cấu hình thông tin ngân hàng"),
    STATEMENT_NOT_FOUND("12", "Không tìm thấy UNC"),
    SUMMARY_NOT_FOUND("13", "Không tìm thấy bảng THTT"),
    GROUP_EMPLOYEE_EXISTED("03", "Mã nhóm đã tồn tại!"),
    GROUP_EMPLOYEE_NOT_FOUND("04", "Nhóm nhân viên không tồn tại"),
    GROUP_EMPLOYEE_DELETE_ASSIGNED("05", "Không thể xóa nhóm nhân viên đã gán được gán vào chính sách"),
    THIRDPARTY_CONNECT_FAILED("17", "Kết nối thất bại, chi tiết lỗi: %s"),
    DISCOUNT_POLICY_NO_EXISTED("06", "Mã chính sách đã tồn tại"),
    DISCOUNT_POLICY_NOT_FOUND("07", "Chính sách chiết khấu không tồn tại"),
    DISCOUNT_POLICY_DELETE_PACKAGE("08", "Không thể xóa chính sách đã tạo gói chiết khấu"),
    DISCOUNT_POLICY_RULE_NOT_FOUND("09", "Cách tính chiết khấu không tồn tại"),
    DISCOUNT_PACKAGE_FORM_TYPE_VALIDATE_1("10", "Khách hàng đã có gói chiết khấu %s với hình thức %s áp dụng từ %s đến %s đã được phê duyệt, do đó không thể tạo gói chiết khấu mới cùng hình thức trong cùng thời gian. Vui lòng kiểm tra và thử lại."),
    DISCOUNT_PACKAGE_FORM_TYPE_VALIDATE_2("10", "Khách hàng đã có gói chiết khấu %s với hình thức %s áp dụng từ %s đến %s đã được phê duyệt, do đó không thể gửi phê duyệt gói chiết khấu mới cùng hình thức trong cùng thời gian. Vui lòng kiểm tra và thử lại."),
    DISCOUNT_PACKAGE_FORM_TYPE_VALIDATE_3("10", "Khách hàng đã có gói chiết khấu %s với hình thức %s áp dụng từ %s đến %s đã được phê duyệt, do đó không thể phê duyệt gói chiết khấu mới cùng hình thức trong cùng thời gian. Vui lòng kiểm tra và thử lại."),
    UNAUTHORIZED_APPROVAL_DISCOUNT("11", "Bạn không có quyền phê duyệt gói CK")
    ,;

    private final String code;
    private final String message;

    public String format(String value) {
        return String.format(this.message, value);
    }
}
