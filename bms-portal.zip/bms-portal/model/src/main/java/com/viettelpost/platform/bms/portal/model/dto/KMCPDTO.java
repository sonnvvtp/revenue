package com.viettelpost.platform.bms.portal.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
public class KMCPDTO {
    private String id;
    private String name;
    private String debitAcc;
    private Integer typePay;
    private Integer carLicensePlateIsRequire;

    public KMCPDTO(String id, String name, String debitAcc, Integer typePay,
            Integer carLicensePlateIsRequire) {
        this.id = id;
        this.name = name;
        this.debitAcc = debitAcc;
        this.typePay = typePay;
        this.carLicensePlateIsRequire = carLicensePlateIsRequire == null ? 0 : carLicensePlateIsRequire;
    }
}
