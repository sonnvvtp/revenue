package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.dto.InvoiceSymbolDTO;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceSymbolService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import static com.viettelpost.platform.bms.common.exception.BaseResponse.errorApiWithHttpStatusCodeVTP;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/invoice/config")
@Tag(name = "InvoiceConfigController")
@RequiredArgsConstructor
public class InvoiceConfigController {

    private final InvoiceSymbolService invoiceSymbolService;

    @Inject
    AuthenticationContext context;

    @GET
    @Path("/list-symbol")
    @Operation(summary = "API danh sách kí hiệu hóa đơn")
    @APIResponse(responseCode = "200", description = "return danh sách kí hiệu hóa đơn")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> listInvoiceSymbols() {
        return ReactiveConverter.toUni(invoiceSymbolService.listAll());
    }

    @POST
    @Operation(summary = "API thêm mới kí hiệu hóa đơn")
    @Path("/insert-symbol")
    public Uni<Response> insertInvoiceSymbol(InvoiceSymbolDTO dto) {
        String err = validateInput(dto, false);
        if (err != null) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, err, null));
        }
        CustomUser user = context.getCurrentUser();
        return ReactiveConverter.toUni(invoiceSymbolService.insert(user, dto));
    }

    @POST
    @Operation(summary = "API cập nhật kí hiệu hóa đơn")
    @Path("/update-symbol")
    public Uni<Response> updateInvoiceSymbol(InvoiceSymbolDTO dto) {
        String err = validateInput(dto, true);
        if (err != null) {
            return Uni.createFrom().item(errorApiWithHttpStatusCodeVTP(Response.Status.BAD_REQUEST, err, null));
        }
        CustomUser user = context.getCurrentUser();
        return ReactiveConverter.toUni(invoiceSymbolService.update(user, dto));
    }

    private String validateInput(InvoiceSymbolDTO dto, boolean isUpdate) {
        if (!isUpdate && (dto.getSymbolCode() == null || dto.getSymbolCode().trim().isEmpty())) {
            return "symbolCode is required";
        }
        if (dto.getSymbolCode() != null && dto.getSymbolCode().length() > 25) {
            return "symbolCode max length is 25";
        }
        if (dto.getInvoiceType() == null) {
            return "invoiceType is required";
        }
        if (dto.getMaxThreshold() == null || dto.getMaxThreshold() <= 0) {
            return "maxThreshold must be > 0";
        }
        if (dto.getIsActive() == null) {
            return "isActive is required";
        }
        return null;
    }
}
