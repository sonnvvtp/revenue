package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.viettelpost.platform.bms.portal.model.enums.IsPaidStatusEnum;
import com.viettelpost.platform.bms.portal.model.enums.SmbType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReportRevenueSmbDTO {

    private Long id;

    @JsonAlias("bill")
    private String bill;

    @JsonAlias("partner_evtp")
    private String partnerEvtp;

    @JsonAlias("service_code")
    private String serviceCode;

    @JsonAlias("type")
    private Integer type;

    private String typeCode;

    @JsonAlias("amount")
    private BigDecimal amount;

    @JsonAlias("item_code")
    private String itemCode;

    @JsonAlias("date_insert")
    private String dateInsert;

    @JsonAlias("formatted_date_payment")
    private String datePayment;

    @JsonAlias("partner_id")
    private Integer partnerId;

    @JsonAlias("status")
    private Integer status;

    private String statusText;

    public String getStatusText() {
        return IsPaidStatusEnum.get(this.status).getDescription();
    }

    public String getTypeCode() {
        return SmbType.get(this.type).getCode();
    }
}
