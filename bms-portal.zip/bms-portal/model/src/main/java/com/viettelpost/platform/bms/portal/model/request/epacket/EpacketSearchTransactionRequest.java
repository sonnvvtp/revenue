package com.viettelpost.platform.bms.portal.model.request.epacket;

import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketSearchTransactionRequest {
    private PartnerSource partnerSource;
    private ServiceType serviceType;
    private MerchantType merchantType;
    private Long cusId;
    private String fromDate;
    private String toDate;
    private List<String> transactionsCode;

}
