package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryLevel2DTO;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.util.List;
import reactor.core.publisher.Mono;

public interface FuelBillingRecoveryLevel2Repository {

    Mono<Void> persist(FuelBillingRecoveryLevel2DTO recoveryDTO, SqlConnection connection);

    Mono<Void> updateStatus(List<String> receiptNumbers, BillingStatus status,
            SqlConnection connection);

    Mono<Void> updateStatusFuelBillingRecoveryLevel2(String unit, String synthesisPeriod, Integer status);

    Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection sqlConnection);
}
