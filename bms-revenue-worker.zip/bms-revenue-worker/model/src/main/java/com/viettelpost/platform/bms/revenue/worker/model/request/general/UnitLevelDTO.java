package com.viettelpost.platform.bms.revenue.worker.model.request.general;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UnitLevelDTO {
  private Long id;
  private String code;
  private String name;
}

