package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceItemsResponse {
    private Long recordId; // ID của hóa đơn
    private List<InvoiceItemDetail> items;
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceItemDetail {
        private Integer index; // STT
        private String productName; // Tên hàng hóa dịch vụ
        private String unit; // Đơn vị tính
        private Integer quantity; // Số lượng
        private Double unitPrice; // Đơn giá
        private Double amountBeforeTax; // Tiền hàng trước thuế
        private Double taxRate; // Thuế suất
        private Double taxAmount; // Tiền thuế
        private Double discountAmount; // Thành tiền sau thuế
        private String type; // Loại
    }
} 