package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartnerInternalConfigResponse {

    @JsonAlias("partner_internal_id")
    private Long partnerInternalId;

    @JsonAlias("partner_internal_line_id")
    private Long partnerInternalLineId;

    @JsonAlias("partner_source")
    private String partnerSource;

    @JsonAlias("endpoint")
    private Endpoint endpoint;

    @JsonAlias("authen_type")
    private Long authenType;

    @JsonAlias("statement_token_partner")
    private StatementTokenPartner statementTokenPartner;

    @JsonAlias("client_id")
    private String clientId;

    @JsonAlias("secret_id")
    private String secretId;

    @JsonAlias("service_type")
    private String serviceType;

    @JsonAlias("merchant_type")
    private String merchantType;

    @JsonAlias("active")
    private Long active;

    @JsonAlias("prefix")
    private String prefixCode;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("created_date")
    private Date createdDate;

    @JsonAlias("updated_by")
    private Long  updatedBy;

    @JsonAlias("updated_date")
    private Date updatedDate;

    @JsonAlias("transaction_type_id")
    private Long  transactionTypeId;

    @JsonAlias("transaction_type_code")
    private String transactionTypeCode;





    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Endpoint {

        @JsonAlias("url-noti")
        private String urlNoti;

        @JsonAlias("url-login")
        private String urlLogin;

        @JsonAlias("url-noti-record")
        private String urlNotiRecordSmg;

        @JsonAlias("url-noti-vipo")
        private String urlNotiVipo;

        @JsonAlias("url-noti-fmcg")
        private String urlNotiFmcg;

        @JsonAlias("url-noti-qtcv")
        private String urlNotiQtcv;

    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class StatementTokenPartner {

        @JsonAlias("username")
        private String username ;

        @JsonAlias("password")
        private String password;

        @JsonAlias("bms-access-token")
        private String bmsAccessToken;



    }
}
