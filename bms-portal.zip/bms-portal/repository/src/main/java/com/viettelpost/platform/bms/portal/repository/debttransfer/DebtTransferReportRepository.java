package com.viettelpost.platform.bms.portal.repository.debttransfer;

import com.viettelpost.platform.bms.portal.model.request.debttransfer.DebtTransferReportRequest;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.FindListBatchDebtDetailRequest;
import com.viettelpost.platform.bms.portal.model.request.debttransfer.FindListBatchDebtRequest;
import com.viettelpost.platform.bms.portal.model.response.debttransfer.*;
import com.viettelpost.platform.bms.portal.repository.BaseRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

public interface DebtTransferReportRepository extends BaseRepository {

    Multi<DebtTransferReportResponse> getReportDebtTransfer(DebtTransferReportRequest debtTransferReportRequest);

    Uni<Integer> findListBillDebtCount(FindListBatchDebtRequest findListBatchDebtRequest);

    Multi<FindListBatchDebtResponse> findListBillDebt(FindListBatchDebtRequest findListBatchDebtRequest);

    Uni<Integer> findListBillDebtDetailCount(FindListBatchDebtDetailRequest findListBillDebtRequest);

    Multi<FindListBatchDebtDetailResponse> findListBillDebtDetail(FindListBatchDebtDetailRequest findListBillDebtRequest);

    Multi<BatchDetailDebtReportResponse> getReportListBatchDetailDebt(FindListBatchDebtDetailRequest findListBillDebtRequest);

    Multi<DocTypeBatchResponse> findDocTypeBatchList();
}
