package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BmsMapPaymentTypeDTO {
    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("PARTNER_ID")
    private Long partnerId;


    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("CONFIG_TYPE_OLD")
    private Long configTypeOld;


    @JsonAlias("CONFIG_TYPE_NEW")
    private Long configTypeNew;
    @JsonAlias("POST_ID")
    private Long postId;
    @JsonAlias("UPDATED_BY")
    private Long userId;

}