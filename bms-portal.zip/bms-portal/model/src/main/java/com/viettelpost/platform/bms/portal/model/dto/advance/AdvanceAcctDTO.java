package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class AdvanceAcctDTO {
    @JsonAlias("ADVANCE_ACCT_ID")
    private Long advanceAcctId;

    @JsonAlias("DOCTYPE")
    private String doctype;

    @JsonAlias("ADVANCE_ACCT_NO")
    private String advanceAcctNo;

    @JsonAlias("RECORD_NO")
    private String recordNo;

    @JsonAlias("BATCH_NO")
    private String batchNo;

    @JsonAlias("ADVANCE_NO")
    private String advanceNo;

    @JsonAlias("PARTNER_CODE")
    private String partnerCode;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("CUS_POST_ID")
    private Long cusPostId;

    @JsonAlias("CUS_ORG_ID")
    private Long cusOrgId;

    @JsonAlias("AMOUNT")
    private BigDecimal amount;

    @JsonAlias("DISCOUNT")
    private BigDecimal discount;

    @JsonAlias("FEE_AMOUNT")
    private BigDecimal feeAmount;

    @JsonAlias("DEBT_DATE")
    private LocalDateTime debtDate;

    @JsonAlias("DOC_DATE")
    private LocalDateTime docDate;

    @JsonAlias("ACCOUNTING_DATE")
    private LocalDateTime accountingDate;

    @JsonAlias("SERVICE_CODE")
    private String serviceCode;

    @JsonAlias("BANK_ACCOUNT_NO")
    private String bankAccountNo;

    @JsonAlias("TRANSACTION_ID")
    private String transactionId;

    @JsonAlias("STATUS")
    private Integer status;

    @JsonAlias("DOC_STATUS")
    private Integer docStatus;

    @JsonAlias("CUS_ID")
    private Long cusId;

    @JsonAlias("CREATED_AT")
    private LocalDateTime createdAt;

    @JsonAlias("CREATED_BY")
    private Long createdBy;

    @JsonAlias("UPDATED_AT")
    private LocalDateTime updatedAt;

    @JsonAlias("UPDATED_BY")
    private Long updatedBy;
}
