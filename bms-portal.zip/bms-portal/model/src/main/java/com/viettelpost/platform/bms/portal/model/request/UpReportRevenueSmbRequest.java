package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

@Data
public class UpReportRevenueSmbRequest {
    private String bill;
}
