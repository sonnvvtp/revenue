package com.viettelpost.platform.bms.revenue.worker.common.enums;

import java.util.Arrays;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum TaxCodeType {
    TAX_O0(0,"O0", "Thuế VAT đầu ra 0%"),
    TAX_O5(5, "O5","Thuế VAT đầu ra 5%"),
    TAX_O8(8, "O1","Thuế VAT đầu ra 8%"),
    TAX_O1(10, "O1","Thuế VAT đầu ra 10%"),
    TAX_ON(-1, "ON","Không chịu thuế đầu ra");

    private final Integer id;
    private final String code;
    private final String description;

    public static TaxCodeType getId(String code) {
        return Arrays.stream(TaxCodeType.values())
            .filter(e -> Objects.equals(e.getCode(), code)).findFirst().orElse(null);
    }

    public static TaxCodeType getCode(Integer id) {
        return Arrays.stream(TaxCodeType.values())
            .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(TAX_O0);
    }
}
