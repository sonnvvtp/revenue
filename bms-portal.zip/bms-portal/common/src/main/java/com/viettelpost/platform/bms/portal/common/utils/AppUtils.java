package com.viettelpost.platform.bms.portal.common.utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.viettelpost.platform.bms.portal.common.model.RoleDTO;
import com.viettelpost.platform.bms.portal.common.model.enums.RoleType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Date;
import java.util.Objects;

@Slf4j
@Getter
@AllArgsConstructor
public class AppUtils {
    public static RoleDTO filterDataByRole(Long userId, String maCN, String maBuuCuc, String role, String secretKey) {
        RoleDTO roleDTO = new RoleDTO();

        if (isEmpty(role) || isEmpty(secretKey)) {
            return null;
        }
        String dataDecrypt = AESUtils.decrypt(role, secretKey);

        if (isEmpty(dataDecrypt)) {
            return null;
        }
        JsonObject jsonObject;
        try {
            jsonObject =new Gson().fromJson(dataDecrypt, JsonObject.class);
        }
        catch (Exception ex) {
            jsonObject = null;
        }

        if (Objects.isNull(jsonObject) || userId != jsonObject.get("userid").getAsLong()) {
            log.info("method filterDataByRole userId: [{}]", jsonObject);
            return null;
        }
        log.info("method filterDataByRole jsonObject: [{}]", jsonObject);
        if (RoleType.ROLE_TCT.getCode().equals(jsonObject.get("role").getAsString())) {
            return new RoleDTO();
        }
        if (RoleType.ROLE_CN.getCode().equals(jsonObject.get("role").getAsString()) && isNotEmpty(maCN)) {
            roleDTO.setRoleType(RoleType.ROLE_CN);
            roleDTO.setOrgCode(maCN);
            return roleDTO;
        }
        if (isNotEmpty(maBuuCuc)) {
            roleDTO.setRoleType(RoleType.ROLE_BC);
            roleDTO.setPostCode(maBuuCuc);
            return roleDTO;
        }
        return null;
    }

    public static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }

    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    public static boolean collectionIsEmpty(Collection<?> collection) {
        return collection == null || collection.isEmpty();
    }

    public static Date stringToDateByFormat(String formatStr, String date) {
        try {
            SimpleDateFormat format = new SimpleDateFormat(formatStr);
            return format.parse(date);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            return null;
        }
    }

    public static String safeDateFormatter(LocalDateTime date, DateTimeFormatter formatter) {
        if (Objects.isNull(date)) {
            return "";
        }

        return formatter.format(date);
    }

    public static String safeDateFormatter(LocalDate date, DateTimeFormatter formatter) {
        if (Objects.isNull(date)) {
            return "";
        }

        return formatter.format(date);
    }
}
