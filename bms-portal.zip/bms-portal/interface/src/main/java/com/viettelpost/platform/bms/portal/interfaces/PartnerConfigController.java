package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.partnerConfig.*;
import com.viettelpost.platform.bms.portal.service.handler.PartnerConfigService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.text.ParseException;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("partner")
@Tag(name = "Partner-config")
@RequiredArgsConstructor
public class PartnerConfigController {


    @Inject
    AuthenticationContext authenticationContext;

    private final PartnerConfigService partnerConfigService;

    @GET
    @Path("/list-partner-in-config")
    @Operation(summary = "get list danh sách cấu hình đối tác  nội bộ")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác nội bộ")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListConfigPartnerInternal() {
        return ReactiveConverter.toUni(partnerConfigService.getListPartnerConfigInternal());
    }

    @GET
    @Path("/list-partner-ex")
    @Operation(summary = "get list danh sách đối tác thanh toán bank")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListConfigPartnerExternal(@QueryParam(value = "active") Long active,
                                                      @QueryParam(value = "activeAllArea") Long activeAllArea,
                                                      @QueryParam(value = "partnerCode") String partnerCode) {
        return ReactiveConverter.toUni(partnerConfigService.getListPartnerConfigExternal(partnerCode,active,activeAllArea));
    }


    @POST
    @Path("/update-partner-external-config")
    @Operation(summary = "update partner-config")
    @APIResponse(responseCode = "200", description = "update partner config")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updatePartnerExternalConfig(@RequestBody PartnerConfigRequest req) throws ParseException {
        CustomUser customUser = authenticationContext.getCurrentUser();
        return ReactiveConverter.toUni(partnerConfigService.updatePartnerExternalConfig(req, customUser.getUserId()));
    }

    @GET
    @Path("/list-partner-config-qrCode")
    @Operation(summary = "get list danh sách cấu hình đối tác  bank theo đối tác nội bộ")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác nội bộ")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListConfigQrCode(@QueryParam(value = "partnerSource") String partnerSource,
                                             @QueryParam(value = "merchant") String merchant,
                                             @QueryParam(value = "transactionType") String transactionType,
                                             @QueryParam(value = "page") Integer page,
                                             @QueryParam(value = "size") Integer size,
                                             @QueryParam(value = "serviceType") String serviceType) {
        return ReactiveConverter.toUni(partnerConfigService.getListPartnerConfigQrCodeBank(partnerSource,merchant,transactionType,page,size,serviceType));
    }

    @POST
    @Path("/insert-partner-external-config")
    @Operation(summary = "insert partner-config")
    @APIResponse(responseCode = "200", description = "update partner config")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> insertPartnerExternalConfig(@RequestBody PartnerConfigRequest req) throws ParseException {
        CustomUser customUser = authenticationContext.getCurrentUser();
        return ReactiveConverter.toUni(partnerConfigService.insertPartnerExternalConfig(req, customUser.getUserId()));
    }

    @GET
    @Path("/list-partner-by-service")
    @Operation(summary = "get list danh sách cấu hình đối tác thanh toán theo từng dịch vụ")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListConfigPartnerByService(@QueryParam(value = "partnerSource") String partnerSource,
                                                       @QueryParam(value = "merchantType") String merchantType,
                                                       @QueryParam(value = "serviceType") String serviceType,
                                                       @QueryParam(value = "page") int page,
                                                       @QueryParam(value = "size") int size) throws ParseException {

        return ReactiveConverter.toUni(partnerConfigService.getListPartnerConfigByService(partnerSource,serviceType,merchantType,page,size));
    }

    @PUT
    @Path("/update-status-partner-in-line")
    @Operation(summary = "update trạng thái bật tắt của dịch vụ")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateStatusPartnerInternalLine(@RequestBody PartnerInternalStatusReq req)  {
        CustomUser customUser = authenticationContext.getCurrentUser();
        return ReactiveConverter.toUni(partnerConfigService.updateStatusPartnerInternalLineConfig(req,customUser.getUserId()));
    }

    @DELETE
    @Path("/delete-partner-in-line/{id}")
    @Operation(summary = "delete cấu hình đối tác theo merchant")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> deletePartnerInternalLine(@PathParam("id") Long id)  {
        return ReactiveConverter.toUni(partnerConfigService.deletePartnerInternalByMerchant(id));
    }

    @GET
    @Path("/list-partner-source")
    @Operation(summary = "get list danh sách cấu hình đối tác thanh toán")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListConfigPartnerSourceExternal(@QueryParam(value = "serviceType") String serviceType,
                                                            @QueryParam(value = "merchantType") String merchantType,
                                                            @QueryParam(value = "prefixCode") String prefixCode) {
        return ReactiveConverter.toUni(partnerConfigService.getListPartnerSourceConfigExternal(serviceType,merchantType,prefixCode));
    }

    @GET
    @Path("/list-service-type")
    @Operation(summary = "get list danh sách cấu hình đối tác thanh toán")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListServiceTypeConfigExternal(@QueryParam(value = "partnerSource") String partnerSource,
                                                          @QueryParam(value = "merchantType") String merchantType,
                                                          @QueryParam(value = "prefixCode") String prefixCode) {
        return ReactiveConverter.toUni(partnerConfigService.getListServiceTypeConfig(partnerSource,merchantType,prefixCode));
    }

    @GET
    @Path("/list-merchant-type")
    @Operation(summary = "get list danh sách cấu hình đối tác thanh toán")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListMerchantTypeConfigExternal(@QueryParam(value = "partnerSource") String partnerSource,
                                                           @QueryParam(value = "serviceType") String serviceType,
                                                           @QueryParam(value = "prefixCode") String prefixCode) {
        return ReactiveConverter.toUni(partnerConfigService.getListMerchantTypeConfigExternal(partnerSource,serviceType,prefixCode));
    }

    @GET
    @Path("/list-prefix-code")
    @Operation(summary = "get list danh sách cấu hình đối tác thanh toán")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListPrefixCodeConfigExternal(@QueryParam(value = "partnerSource") String partnerSource,
                                                           @QueryParam(value = "serviceType") String serviceType,
                                                           @QueryParam(value = "merchantType") String merchantType) {
        return ReactiveConverter.toUni(partnerConfigService.getListPrefixCodeConfigExternal(partnerSource,serviceType,merchantType));
    }

    @GET
    @Path("/list-transaction-type")
    @Operation(summary = "get list danh sách dịch vụ theo đối tác")
    @APIResponse(responseCode = "200", description = "return danh sách cấu hình đối tác")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getListTransactionType(@QueryParam(value = "partnerSource") String partnerSource,
                                                         @QueryParam(value = "serviceType") String serviceType,
                                                         @QueryParam(value = "merchantType") String merchantType) {
        return ReactiveConverter.toUni(partnerConfigService.getListTransactionType(partnerSource,serviceType,merchantType));
    }


    @POST
    @Path("/insert-partner-config-qrCode")
    @Operation(summary = "update partner-config")
    @APIResponse(responseCode = "200", description = "update partner config")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> insertPartnerQrBankConfig(@RequestBody ConfigPartnerInExRequest req) throws ParseException {
        CustomUser customUser = authenticationContext.getCurrentUser();
        return ReactiveConverter.toUni(partnerConfigService.insertPartnerConfigQrCodeByBank(req, customUser.getUserId()));
    }


    @PUT
    @Path("/update-partner-config-qrCode")
    @Operation(summary = "update partner-config")
    @APIResponse(responseCode = "200", description = "update partner config")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updatePartnerQrBankConfig(@RequestBody ConfigReceiveRequest req) throws ParseException {
        CustomUser customUser = authenticationContext.getCurrentUser();
        return ReactiveConverter.toUni(partnerConfigService.updatePartnerConfigQrCodeByBank(req, customUser.getUserId()));
    }


    @PUT
    @Path("/update-config-bank-qrcode")
    @Operation(summary = "update partner-config")
    @APIResponse(responseCode = "200", description = "update partner config")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateConfigBankQrCode(@RequestBody PartnerReceiveConfigRequest request) throws ParseException {
        CustomUser customUser = authenticationContext.getCurrentUser();
        return ReactiveConverter.toUni(partnerConfigService.updateConfigBankQrCode(request, customUser.getUserId()));
    }

}
