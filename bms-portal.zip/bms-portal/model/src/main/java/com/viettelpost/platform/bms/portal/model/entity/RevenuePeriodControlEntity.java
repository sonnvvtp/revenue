package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevenuePeriodControlEntity {
  @JsonAlias("id")
  public Long id;

  @JsonAlias("tenant_id")
  public Integer tenantId;

  @JsonAlias("created_by")
  public Long createdBy;

  @JsonAlias("created_at")
  public LocalDateTime createdAt;

  @JsonAlias("updated_by")
  public Long updatedBy;

  @JsonAlias("updated_at")
  public LocalDateTime updatedAt;

  @JsonAlias("period_id")
  public BigDecimal periodId;

  @JsonAlias("period_status")
  public String periodStatus;

  @JsonAlias("doctype_id")
  public Long doctypeId;

  @JsonAlias("active")
  public String active;

  @JsonAlias("start_date")
  public LocalDateTime startDate;

  @JsonAlias("end_date")
  public LocalDateTime endDate;
}
