package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrgPostDTO {
    @JsonAlias({"ORG_ID","org_id"})
    private Long orgId;

    @JsonAlias({"ORG_CODE","org_code"})
    private String orgCode;

    @JsonAlias({"POST_ID","post_id"})
    private Long postId;

    @JsonAlias({"POST_CODE","post_code"})
    private String postCode;

    @JsonAlias("cus_id")
    private Long cusId;
}

