package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryConfigDTO;
import com.viettelpost.platform.bms.portal.model.dto.VehicleTypeGroupKMCPConfigDTO;
import com.viettelpost.platform.bms.portal.model.request.KMCPConfigFilter;
import com.viettelpost.platform.bms.portal.model.request.KMCPConfigRequest;
import com.viettelpost.platform.bms.portal.model.response.BillingRecoveryConfigResponse;
import com.viettelpost.platform.bms.portal.model.response.CommitmentItemResponse;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;
import reactor.core.publisher.Mono;

import java.util.List;

public interface FuelBillingRecoveryConfigRepository {

    Mono<Boolean> changeConfigManage(int type, String value, String modifier);

    Mono<Boolean> createConfigManage(int type, String value, String modifier);

    Mono<Boolean> findConfigManageByType(int type);

    Uni<BillingRecoveryConfigResponse> configManageDetail(Integer type);

    Mono<FuelBillingRecoveryConfigDTO> findByType(Integer type);

    Mono<List<CommitmentItemResponse>> getCommitmentItems(String search, Connection connection, int page, int size);

    Mono<List<CommitmentItemResponse>> getCommitmentItemsByItems(Connection connection, List<String> commitmentItem);

    Mono<List<VehicleTypeGroupKMCPConfigDTO>> getKMCPConfigs(KMCPConfigFilter filter);

    Mono<Long> countKMCPConfigs(KMCPConfigFilter filter);

    Uni<Boolean> updateKMCPConfig(KMCPConfigRequest request);

    Uni<Boolean> createKMCPConfig(KMCPConfigRequest request);

    Uni<Boolean> findKMCPConfigByVehicleTypeGroupIdAndOrgType(Long vehicleTypeGroupId, Integer orgType);

    Uni<Boolean> findKMCPConfigByVehicleTypeGroupIdAndOrgTypeAndNotById(Long vehicleTypeGroupId, Integer orgType, Long id);

    Uni<Boolean> findKMCPConfigById(Long id);

    Uni<Boolean> deleteKMCPConfig(Long id);

    Uni<Boolean> deleteKMCPConfigByVehicleTypeGroupId(Long vehicleTypeGroupId);
}
