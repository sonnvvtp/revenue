package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.common.utils.DataMappingUtils;
import com.viettelpost.platform.bms.portal.model.dto.BillRevenueDTO;
import com.viettelpost.platform.bms.portal.model.dto.ReportRevenueDTO;
import com.viettelpost.platform.bms.portal.model.entity.ErpPeriodEntity;
import com.viettelpost.platform.bms.portal.model.entity.RevenuePeriodControlEntity;
import com.viettelpost.platform.bms.portal.model.enums.BillRevenueType;
import com.viettelpost.platform.bms.portal.model.enums.ReportDebtType;
import com.viettelpost.platform.bms.portal.model.enums.ReportRevenueType;
import com.viettelpost.platform.bms.portal.model.enums.ReportShowType;
import com.viettelpost.platform.bms.portal.model.enums.RevenueType;
import com.viettelpost.platform.bms.portal.model.request.BillRevenueRequest;
import com.viettelpost.platform.bms.portal.model.request.ReportRevenueRequest;
import com.viettelpost.platform.bms.portal.repository.BillRevenueRepository;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

@ApplicationScoped
@RequiredArgsConstructor
public class BillRevenueRepositoryImpl implements BillRevenueRepository {

    private final ConnectionPool oracleClient;
    private final PgPool pgClient;


    @Override
    public Uni<Integer> getBillRevenueCount(BillRevenueRequest request) {
        String sql = "SELECT count(1) as total " +
                     "FROM ERP_AC.BMS_BILL_REVENUE bbr " +
                     "WHERE 1 = 1 ";

        Map<String, Object> params = new HashMap<>();
        sql += buildWhereClause(request, params);
        return executeAndGetValue(oracleClient, sql, params, "total", Integer.class)
                .onFailure().invoke(throwable -> {
                    throw new RuntimeException("Failed to fetch count bill revenue: " + throwable);
                });
    }

    @Override
    public Multi<BillRevenueDTO> getBillRevenueList(BillRevenueRequest request) {
        String sql = "SELECT " +
                     " bbr.BILL_REVENUE_ID , " +
                     " bbr.BILL , " +
                     " bbr.PARTNER_EVTP, " +
                     " bbr.M_PRODUCT, " +
                     " TO_CHAR(bbr.DATEBILL, 'dd/MM/yyyy') AS DATE_BILL, " +
                     " TO_CHAR(bbr.DATEINSERT, 'dd/MM/yyyy') AS DATE_INSERT, " +
                     " bbr.\"TYPE\", " +
                     " bbr.BILL_REVENUE_TYPE, " +
                     " bbr.CITY_FROM , " +
                     " bbr.CITY_TO , " +
                     " (VTP.GET_TEN_TINH(bbr.CITY_FROM)) AS CITY_FROM_NAME, " +
                     " (VTP.GET_TEN_TINH(bbr.CITY_TO)) AS CITY_TO_NAME, " +
                     " NVL((SELECT ORDER_STATUS FROM ERP_CUS.CUS_ORDER WHERE ORDER_NUMBER = bbr.BILL AND ROWNUM = 1), 200) AS BILL_STATUS, " +
                     " bbr.WEIGHT , " +
                     " bbr.FREIGHT AS AMT, " +
                     " bbr.FEE AS AMT_DEDUCT, " +
                     " bbr.AMT_VAT , " +
                     " (bbr.AMT - bbr.FEE) AS AMOUNT, " +
                     " bbr.ORG_ID, " +
                     " bbr.POST_ID, " +
                     " TO_CHAR(bbr.CREATED, 'dd/MM/yyyy') AS CREATED_DATE, " +
                     " ROW_NUMBER() OVER ( ORDER BY bbr.CREATED DESC) AS rowNumber " +
                     "FROM ERP_AC.BMS_BILL_REVENUE bbr " +
                     "WHERE 1 = 1 ";

        Map<String, Object> params = new HashMap<>();

        String whereClause = buildWhereClause(request, params);

        int page = Objects.isNull(request.getPage()) ? 1 : request.getPage();
        int size = Objects.isNull(request.getSize()) ? 10 : request.getSize();

        int startIndex = (page - 1) * size + 1;
        int endIndex = startIndex - 1 + size;

        String finalSql = """
                SELECT * FROM (%s %s) a
                WHERE rowNumber BETWEEN :startIndex AND :endIndex ORDER BY BILL_REVENUE_ID DESC
                """.formatted(sql, whereClause);

        params.put("startIndex", startIndex);
        params.put("endIndex", endIndex);

        return executeMulti(oracleClient, finalSql, params, BillRevenueDTO.class)
                .onFailure().invoke(throwable -> {
                    throw new RuntimeException("Failed to fetch bill revenue list: " + throwable);
                });
    }

    @Override
    public Multi<BillRevenueDTO> getBillRevenueStream(BillRevenueRequest request, Long lastId, int batchSize) {
        StringBuilder innerQuery = new StringBuilder();
        innerQuery.append("SELECT bbr.* FROM ERP_AC.BMS_BILL_REVENUE bbr WHERE 1 = 1 ");

        Map<String, Object> params = new HashMap<>();
        String whereClause = buildWhereClause(request, params);
        innerQuery.append(whereClause);

        if (lastId != null && lastId > 0) {
            innerQuery.append(" AND bbr.BILL_REVENUE_ID > :lastId ");
            params.put("lastId", lastId);
        }

        innerQuery.append(" ORDER BY bbr.BILL_REVENUE_ID ASC ");

        String finalSql =
                "SELECT  " +
                "  BILL_REVENUE_ID,  " +
                "  BILL,  " +
                "  PARTNER_EVTP,  " +
                "  M_PRODUCT,  " +
                "  TO_CHAR(DATEBILL, 'dd/MM/yyyy') AS DATE_BILL,  " +
                "  TO_CHAR(DATEINSERT, 'dd/MM/yyyy') AS DATE_INSERT,  " +
                "  \"TYPE\",  " +
                "  CITY_FROM,  " +
                "  CITY_TO,  " +
                "  (VTP.GET_TEN_TINH(CITY_FROM)) AS CITY_FROM_NAME,  " +
                "  (VTP.GET_TEN_TINH(CITY_TO)) AS CITY_TO_NAME,  " +
                "  NVL((SELECT ORDER_STATUS FROM ERP_CUS.CUS_ORDER co WHERE co.ORDER_NUMBER = BILL AND ROWNUM = 1), 200) AS BILL_STATUS,  " +
                "  WEIGHT,  " +
                "  FREIGHT AS AMT,  " +
                "  FEE AS AMT_DEDUCT,  " +
                "  AMT_VAT,  " +
                "  (AMT - FEE) AS AMOUNT  " +
                "FROM ( " + innerQuery.toString() + " ) " +
                "WHERE ROWNUM <= :batchSize";

        params.put("batchSize", batchSize);

        return executeMulti(oracleClient, finalSql, params, BillRevenueDTO.class)
                .onFailure().invoke(throwable -> {
                    throw new RuntimeException("Failed to fetch bill revenue stream: " + throwable.getMessage());
                });
    }

    @Override
    public Multi<ErpPeriodEntity> findAllPeriod() {
        String sql = """
                        SELECT *
                         FROM ERP_AC.ERP_PERIOD
                        WHERE ISACTIVE = ?
                """;

        List<Object> params = new ArrayList<>();
        params.add("Y");
        return executeMulti(oracleClient, sql, params,  ErpPeriodEntity .class);
    }

    @Override
    public Multi<ReportRevenueDTO> reportRevenue(ReportRevenueRequest request, Long postID) {

        String sql = "";
        switch (request.getReportShowType()) {
            case ReportShowType.SHOW_CUS:
                sql = """
                          SELECT BBR.ORG_ID,
                                 ERP_AC.GET_ORGCODE (BBR.POST_ID)
                                     ORG_CODE,
                                 BBR.POST_ID,
                                 ERP_AC.GET_POSTCODE (BBR.POST_ID)
                                     POST_CODE,
                                 ERP_AC.GET_POSTNAME (BBR.POST_ID)
                                     POST_NAME,
                                 BBR.PARTNER_EVTP
                                     CUSTOMER_CODE,
                                 (SELECT FULLNAME
                                    FROM ERP_AC.ERP_PARTNER
                                   WHERE VALUE = BBR.PARTNER_EVTP AND ROWNUM = 1)
                                     CUSTOMER_NAME,
                                 COUNT(1) QUANTITY,
                                 SUM (ROUND (BBR.AMT - BBR.AMT_VAT))
                                     AMOUNT_BEFORE_TAX,
                                 SUM (BBR.AMT_VAT)
                                     AMOUNT_TAX,
                                 SUM (BBR.AMT)
                                     AMOUNT_AFTER_TAX,
                                 SUM (BBR.FEE)
                                     AMOUNT_DEDUCT,
                                 SUM (BBR.AMT - BBR.FEE)
                                     AMOUNT_AFTER_DEDUCT
                            FROM ERP_AC.BMS_BILL_REVENUE BBR
                           WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE IN (%s)
                      """;
                if (Objects.nonNull(request.getReportDebtType())) {
                    switch (request.getReportDebtType()) {
                        case ReportDebtType.DEBT_CPN:
                            sql += " AND BBR.M_PRODUCT NOT IN ('VNB') AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_LOG:
                            sql += " AND EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_VNB:
                            sql += " AND BBR.M_PRODUCT = 'VNB' ";
                            break;
                        default:
                            break;
                    }
                }
                sql += " AND BBR.ORG_ID IN (SELECT ORGANIZATION_ID FROM HR_POSTCODE WHERE POST_ID = ?) ";
                sql += " GROUP BY BBR.ORG_ID, BBR.POST_ID, BBR.PARTNER_EVTP ";
                break;
            case ReportShowType.SHOW_POST:
                sql = """
                            SELECT BBR.ORG_ID,
                                 ERP_AC.GET_ORGCODE (BBR.POST_ID)
                                     ORG_CODE,
                                 BBR.POST_ID,
                                 ERP_AC.GET_POSTCODE (BBR.POST_ID)
                                     POST_CODE,
                                 ERP_AC.GET_POSTNAME (BBR.POST_ID)
                                     POST_NAME,
                                 BBR.M_PRODUCT
                                     SERVICE_CODE,
                                 (SELECT TEN_DICHVU
                                    FROM VTP.BG_DICHVU
                                   WHERE MA_DICHVU = BBR.M_PRODUCT AND ROWNUM = 1)
                                     SERVICE_NAME,
                                 COUNT(1) QUANTITY,
                                 SUM (ROUND (BBR.AMT - BBR.AMT_VAT))
                                     AMOUNT_BEFORE_TAX,
                                 SUM (BBR.AMT_VAT)
                                     AMOUNT_TAX,
                                 SUM (BBR.AMT)
                                     AMOUNT_AFTER_TAX,
                                 SUM (BBR.FEE)
                                     AMOUNT_DEDUCT,
                                 SUM (BBR.AMT - BBR.FEE)
                                     AMOUNT_AFTER_DEDUCT
                            FROM ERP_AC.BMS_BILL_REVENUE BBR
                           WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE IN (%s)
                      """;
                if (Objects.nonNull(request.getReportDebtType())) {
                    switch (request.getReportDebtType()) {
                        case ReportDebtType.DEBT_CPN:
                            sql += " AND BBR.M_PRODUCT NOT IN ('VNB') AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_LOG:
                            sql += " AND EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_VNB:
                            sql += " AND BBR.M_PRODUCT = 'VNB' ";
                            break;
                        default:
                            break;
                    }
                }
                sql += " AND BBR.ORG_ID IN (SELECT ORGANIZATION_ID FROM HR_POSTCODE WHERE POST_ID = ?) ";
                sql += " GROUP BY BBR.ORG_ID, BBR.POST_ID, BBR.M_PRODUCT ";
                break;
            case ReportShowType.SHOW_SERVICE:
                sql = """
                          SELECT BBR.ORG_ID,
                                 (SELECT UPPER(TRIM(ORGCODE)) FROM ERP_AC.HR_ORGANIZATION WHERE ORG_ID = BBR.ORG_ID)
                                     ORG_CODE,
                                 BBR.M_PRODUCT
                                     SERVICE_CODE,
                                 (SELECT TEN_DICHVU
                                    FROM VTP.BG_DICHVU
                                   WHERE MA_DICHVU = BBR.M_PRODUCT AND ROWNUM = 1)
                                     SERVICE_NAME,
                                 COUNT(1) QUANTITY,
                                 SUM (ROUND (BBR.AMT - BBR.AMT_VAT))
                                     AMOUNT_BEFORE_TAX,
                                 SUM (BBR.AMT_VAT)
                                     AMOUNT_TAX,
                                 SUM (BBR.AMT)
                                     AMOUNT_AFTER_TAX,
                                 SUM (BBR.FEE)
                                     AMOUNT_DEDUCT,
                                 SUM (BBR.AMT - BBR.FEE)
                                     AMOUNT_AFTER_DEDUCT
                            FROM ERP_AC.BMS_BILL_REVENUE BBR
                           WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE IN (%s)
                      """;
                if (Objects.nonNull(request.getReportDebtType())) {
                    switch (request.getReportDebtType()) {
                        case ReportDebtType.DEBT_CPN:
                            sql += " AND BBR.M_PRODUCT NOT IN ('VNB') AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_LOG:
                            sql += " AND EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_VNB:
                            sql += " AND BBR.M_PRODUCT = 'VNB' ";
                            break;
                        default:
                            break;
                    }
                }
                sql += " AND BBR.ORG_ID IN (SELECT ORGANIZATION_ID FROM HR_POSTCODE WHERE POST_ID = ?) ";
                sql += " GROUP BY BBR.ORG_ID, BBR.M_PRODUCT ";
                break;
            default:
                break;
        }

        List<Integer> reportTypeStatus = new ArrayList<>();
        if (ReportRevenueType.TEMPORARY_REVENUE.equals(request.getReportRevenueType())) {
            reportTypeStatus.add(BillRevenueType.TEMPORARY_REVENUE.getValue());
        } else if (ReportRevenueType.COMPLETED_REVENUE.equals(request.getReportRevenueType())) {
            reportTypeStatus.add(BillRevenueType.COMPLETED_REVENUE2.getValue());
            reportTypeStatus.add(BillRevenueType.COMPLETED_REVENUE3.getValue());
        }

        String placeholder = IntStream.range(0, reportTypeStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));
        sql = sql.formatted(placeholder);

        List<Object> params = new ArrayList<>();
        params.add(request.getPeriodId());
        params.addAll(reportTypeStatus);
        params.add(postID);

        return executeMulti(oracleClient, sql, params, ReportRevenueDTO.class);
    }

    @Override
    public Multi<ReportRevenueDTO> reportRevenueStream(ReportRevenueRequest request, BigDecimal lastId,
        int batchSize, Long postId) {
        String sql = "";
        switch (request.getReportShowType()) {
            case ReportShowType.SHOW_CUS:
                sql = """
                        SELECT gr.*, (SELECT NAME FROM ERP_AC.ERP_PERIOD WHERE PERIOD_ID = ? AND ROWNUM = 1) PERIOD_NAME FROM (
                    """;
                sql += """
                          SELECT BBR.ORG_ID,
                                 ERP_AC.GET_ORGCODE (BBR.POST_ID)
                                     ORG_CODE,
                                 BBR.POST_ID,
                                 ERP_AC.GET_POSTCODE (BBR.POST_ID)
                                     POST_CODE,
                                 ERP_AC.GET_POSTNAME (BBR.POST_ID)
                                     POST_NAME,
                                 BBR.PARTNER_EVTP
                                     CUSTOMER_CODE,
                                 (SELECT FULLNAME
                                    FROM ERP_AC.ERP_PARTNER
                                   WHERE VALUE = BBR.PARTNER_EVTP AND ROWNUM = 1)
                                     CUSTOMER_NAME,
                                 COUNT(1) QUANTITY,
                                 SUM (ROUND (BBR.AMT - BBR.AMT_VAT))
                                     AMOUNT_BEFORE_TAX,
                                 SUM (BBR.AMT_VAT)
                                     AMOUNT_TAX,
                                 SUM (BBR.AMT)
                                     AMOUNT_AFTER_TAX,
                                 SUM (BBR.FEE)
                                     AMOUNT_DEDUCT,
                                 SUM (BBR.AMT - BBR.FEE)
                                     AMOUNT_AFTER_DEDUCT
                            FROM ERP_AC.BMS_BILL_REVENUE BBR
                           WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE IN (%s)
                      """;
                if (Objects.nonNull(request.getReportDebtType())) {
                    switch (request.getReportDebtType()) {
                        case ReportDebtType.DEBT_CPN:
                            sql += " AND BBR.M_PRODUCT NOT IN ('VNB') AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_LOG:
                            sql += " AND EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_VNB:
                            sql += " AND BBR.M_PRODUCT = 'VNB' ";
                            break;
                        default:
                            break;
                    }
                }
                sql += " AND BBR.ORG_ID IN (SELECT ORGANIZATION_ID FROM HR_POSTCODE WHERE POST_ID = ?) ";

                sql += " GROUP BY BBR.ORG_ID, BBR.POST_ID, BBR.PARTNER_EVTP ";
                if (Objects.nonNull(lastId) && lastId.compareTo(BigDecimal.ZERO) > 0) {
                    sql += " ) gr WHERE gr.AMOUNT_AFTER_TAX > ? AND ROWNUM <= ? ";
                }
                else {
                    sql += " ) gr WHERE ROWNUM <= ? ";
                }
                break;
            case ReportShowType.SHOW_POST:
                sql = """
                        SELECT gr.*, (SELECT NAME FROM ERP_AC.ERP_PERIOD WHERE PERIOD_ID = ? AND ROWNUM = 1) PERIOD_NAME FROM (
                    """;
                sql += """
                            SELECT BBR.ORG_ID,
                                 ERP_AC.GET_ORGCODE (BBR.POST_ID)
                                     ORG_CODE,
                                 BBR.POST_ID,
                                 ERP_AC.GET_POSTCODE (BBR.POST_ID)
                                     POST_CODE,
                                 ERP_AC.GET_POSTNAME (BBR.POST_ID)
                                     POST_NAME,
                                 BBR.M_PRODUCT
                                     SERVICE_CODE,
                                 (SELECT TEN_DICHVU
                                    FROM VTP.BG_DICHVU
                                   WHERE MA_DICHVU = BBR.M_PRODUCT AND ROWNUM = 1)
                                     SERVICE_NAME,
                                 COUNT(1) QUANTITY,
                                 SUM (ROUND (BBR.AMT - BBR.AMT_VAT))
                                     AMOUNT_BEFORE_TAX,
                                 SUM (BBR.AMT_VAT)
                                     AMOUNT_TAX,
                                 SUM (BBR.AMT)
                                     AMOUNT_AFTER_TAX,
                                 SUM (BBR.FEE)
                                     AMOUNT_DEDUCT,
                                 SUM (BBR.AMT - BBR.FEE)
                                     AMOUNT_AFTER_DEDUCT
                            FROM ERP_AC.BMS_BILL_REVENUE BBR
                           WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE IN (%s)
                      """;
                if (Objects.nonNull(request.getReportDebtType())) {
                    switch (request.getReportDebtType()) {
                        case ReportDebtType.DEBT_CPN:
                            sql += " AND BBR.M_PRODUCT NOT IN ('VNB') AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_LOG:
                            sql += " AND EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_VNB:
                            sql += " AND BBR.M_PRODUCT = 'VNB' ";
                            break;
                        default:
                            break;
                    }
                }
                sql += " AND BBR.ORG_ID IN (SELECT ORGANIZATION_ID FROM HR_POSTCODE WHERE POST_ID = ?) ";
                sql += " GROUP BY BBR.ORG_ID, BBR.POST_ID, BBR.M_PRODUCT ";
                if (Objects.nonNull(lastId) && lastId.compareTo(BigDecimal.ZERO) > 0) {
                    sql += " ) gr WHERE gr.AMOUNT_AFTER_TAX > ? AND ROWNUM <= ? ";
                }
                else {
                    sql += " ) gr WHERE ROWNUM <= ? ";
                }
                break;
            case ReportShowType.SHOW_SERVICE:
                sql = """
                        SELECT gr.*, (SELECT NAME FROM ERP_AC.ERP_PERIOD WHERE PERIOD_ID = ? AND ROWNUM = 1) PERIOD_NAME FROM (
                    """;
                sql += """
                            SELECT BBR.ORG_ID,
                                 (SELECT UPPER(TRIM(ORGCODE)) FROM ERP_AC.HR_ORGANIZATION WHERE ORG_ID = BBR.ORG_ID)
                                     ORG_CODE,
                                 BBR.M_PRODUCT
                                     SERVICE_CODE,
                                 (SELECT TEN_DICHVU
                                    FROM VTP.BG_DICHVU
                                   WHERE MA_DICHVU = BBR.M_PRODUCT AND ROWNUM = 1)
                                     SERVICE_NAME,
                                 COUNT(1) QUANTITY,
                                 SUM (ROUND (BBR.AMT - BBR.AMT_VAT))
                                     AMOUNT_BEFORE_TAX,
                                 SUM (BBR.AMT_VAT)
                                     AMOUNT_TAX,
                                 SUM (BBR.AMT)
                                     AMOUNT_AFTER_TAX,
                                 SUM (BBR.FEE)
                                     AMOUNT_DEDUCT,
                                 SUM (BBR.AMT - BBR.FEE)
                                     AMOUNT_AFTER_DEDUCT
                            FROM ERP_AC.BMS_BILL_REVENUE BBR
                           WHERE BBR.PERIOD_ID = ? AND BBR.BILL_REVENUE_TYPE IN (%s)
                      """;
                if (Objects.nonNull(request.getReportDebtType())) {
                    switch (request.getReportDebtType()) {
                        case ReportDebtType.DEBT_CPN:
                            sql += " AND BBR.M_PRODUCT NOT IN ('VNB') AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_LOG:
                            sql += " AND EXISTS (SELECT 1 FROM ERP_AC.BMS_SERVICE_CATEGORY_MAPPING WHERE SERVICE_CODE = BBR.M_PRODUCT AND PRODUCT_CATEGORY = 'LOG') ";
                            break;
                        case ReportDebtType.DEBT_VNB:
                            sql += " AND BBR.M_PRODUCT = 'VNB' ";
                            break;
                        default:
                            break;
                    }
                }
                sql += " AND BBR.ORG_ID IN (SELECT ORGANIZATION_ID FROM HR_POSTCODE WHERE POST_ID = ?) ";
                sql += " GROUP BY BBR.ORG_ID, BBR.M_PRODUCT ";
                if (Objects.nonNull(lastId) && lastId.compareTo(BigDecimal.ZERO) > 0) {
                    sql += " ) gr WHERE gr.AMOUNT_AFTER_TAX > ? AND ROWNUM <= ? ";
                }
                else {
                    sql += " ) gr WHERE ROWNUM <= ? ";
                }
                break;
            default:
                break;
        }

        List<Integer> reportTypeStatus = new ArrayList<>();
        if (ReportRevenueType.TEMPORARY_REVENUE.equals(request.getReportRevenueType())) {
            reportTypeStatus.add(BillRevenueType.TEMPORARY_REVENUE.getValue());
        } else if (ReportRevenueType.COMPLETED_REVENUE.equals(request.getReportRevenueType())) {
            reportTypeStatus.add(BillRevenueType.COMPLETED_REVENUE2.getValue());
            reportTypeStatus.add(BillRevenueType.COMPLETED_REVENUE3.getValue());
        }

        String placeholder = IntStream.range(0, reportTypeStatus.size())
            .mapToObj(i -> "?")
            .collect(Collectors.joining(","));
        sql = sql.formatted(placeholder);

        List<Object> params = new ArrayList<>();
        params.add(request.getPeriodId());
        params.add(request.getPeriodId());
        params.addAll(reportTypeStatus);
        params.add(postId);

        if (Objects.nonNull(lastId) && lastId.compareTo(BigDecimal.ZERO) > 0) {
            params.add(lastId);
            params.add(batchSize);
        }
        else {
            params.add(batchSize);
        }

        return executeMulti(oracleClient, sql, params, ReportRevenueDTO.class);
    }

    private String buildWhereClause(BillRevenueRequest request, Map<String, Object> params) {
        StringBuilder where = new StringBuilder();

        LocalDate fromDate = request.getFromDate();
        LocalDate toDate = request.getToDate();

        RevenueType type = RevenueType.fromCode(request.getType());

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            if (RevenueType.COMPLETED == type) {
                where.append(" AND bbr.DATEINSERT >= :fromDate AND bbr.DATEINSERT <= :toDate ");
                params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
                params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
            }
            else {
                where.append(" AND bbr.DATEBILL >= :fromDate AND bbr.DATEBILL <= :toDate ");
                params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
                params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
            }
        } else if (Objects.nonNull(fromDate)) {
            if (RevenueType.COMPLETED == type) {
                where.append(" AND bbr.DATEINSERT >= :fromDate ");
                params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            }
            else {
                where.append(" AND bbr.DATEBILL >= :fromDate ");
                params.put("fromDate", LocalDateTime.of(fromDate, LocalTime.MIN));
            }
        } else if (Objects.nonNull(toDate)) {
            if (RevenueType.COMPLETED == type) {
                where.append(" AND bbr.DATEINSERT <= :toDate ");
                params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
            }
            else {
                where.append(" AND bbr.DATEBILL <= :toDate ");
                params.put("toDate", LocalDateTime.of(toDate, LocalTime.MAX));
            }
        }

        switch (type) {
            case TOTAL:
                where.append(" AND BBR.BILL_REVENUE_TYPE = 1 ");
                break;
            case COMPLETED:
                where.append(" AND BBR.BILL_REVENUE_TYPE IN (2, 3) ");
                break;
            case TEMPORARY:
                where.append(" AND BBR.BILL_REVENUE_TYPE = 1 ");
                where.append(" AND NOT EXISTS (SELECT 1 FROM ERP_AC.BMS_BILL_JOURNEY WHERE ORDER_NUMBER = BBR.BILL AND ORDER_STATUS IN (501, 503,504,517)) ");
                break;
            default:
                throw new IllegalArgumentException("Loại báo cáo không hợp lệ: " + request.getType());
        }

        if (Objects.nonNull(request.getPostId())) {
            where.append(" AND bbr.POST_ID = :postId ");
            params.put("postId", request.getPostId());
        }

        if (Objects.nonNull(request.getOrgId())) {
            where.append(" AND bbr.ORG_ID = :orgId ");
            params.put("orgId", request.getOrgId());
        }

        if (Objects.nonNull(request.getPartnerEvtp())){
            where.append(" AND bbr.PARTNER_EVTP = :partnerEvtp ");
            params.put("partnerEvtp", request.getPartnerEvtp().trim());
        }

        if (request.getBills() != null && !request.getBills().isEmpty()) {
            List<String> billParams = new ArrayList<>();
            for (int i = 0; i < request.getBills().size(); i++) {
                String paramName = "bill_" + i;
                billParams.add(":" + paramName);
                params.put(paramName, request.getBills().get(i));
            }
            where.append(" AND bbr.BILL IN (").append(String.join(", ", billParams)).append(") ");
        }
        return where.toString();
    }

    @Override
    public Multi<RevenuePeriodControlEntity> findAllPerioControl() {
        String sql = """
                select
                	*
                from
                	bms_payment.revenue_period_control
                where active = $1
            """;
        return executeMulti(pgClient, sql, Tuple.of("Y"), RevenuePeriodControlEntity.class);
    }

    @Override
    public Uni<RevenuePeriodControlEntity> save(RevenuePeriodControlEntity entity, SqlConnection sqlConnection) {
        boolean isInsert = Objects.isNull(entity.getId());

        String sql;

        List<Object> params = new ArrayList<>();

        if (isInsert) {
            sql = """
            insert into bms_payment.revenue_period_control
            (
               tenant_id
              ,created_by
              ,created_at
              ,updated_by
              ,updated_at
              ,period_id
              ,period_status
              ,doctype_id
              ,active
              ,start_date
              ,end_date
            )
            values (
                $1,
                $2,
                current_timestamp,
                $3,
                current_timestamp,
                $4,
                $5,
                $6,
                $7,
                $8,
                $9
            )
            returning *
            """;
            params.addAll(
                DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));
        } else {
            sql = """
            update bms_payment.revenue_period_control
            set
                tenant_id = $1,
                updated_by = $2,
                updated_at = current_timestamp,
                period_id = $3,
                period_status = $4,
                doctype_id = $5,
                active = $6,
                start_date = $7,
                end_date = $8
            where id = $9
            returning *
            """;
            params.addAll(DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "createdBy", "updatedAt"));
            params.add(entity.getId());
        }

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), RevenuePeriodControlEntity.class);
        }

        return execute(pgClient, sql, Tuple.from(params), RevenuePeriodControlEntity.class);
    }
}
