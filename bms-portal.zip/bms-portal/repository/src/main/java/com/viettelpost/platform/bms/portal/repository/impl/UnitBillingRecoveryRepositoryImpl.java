package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.enums.BillingType;
import com.viettelpost.platform.bms.portal.model.response.FuelBillingRecoveryLevel2Response;
import com.viettelpost.platform.bms.portal.repository.UnitBillingRecoveryRepository;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class UnitBillingRecoveryRepositoryImpl implements UnitBillingRecoveryRepository {

    @Inject
    PgPool client;

    @Override
    public Uni<List<FuelBillingRecoveryLevel2Response>> searchUnitBills(
            String receiptNumber, String synthesisPeriod, String unit, int pageNo, int pageSize, int type) {
        int offset = (pageNo - 1) * pageSize;
        String sqlTemplate = """
               SELECT *
               FROM bms_payment.fuel_billing_recovery_level2
               WHERE is_active = true
               %s %s %s %s
               ORDER BY created_at DESC
               LIMIT $%d OFFSET $%d
        """;
        List<Object> params = new ArrayList<>();

        String unitCondition = "";
        String receiptNumberCondition = "";
        String synthesisPeriodCondition = "";
        String budgetCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                " AND total_budget_excess > 0" : " AND budget_reduction > 0";

        if (unit != null && !unit.isEmpty()) {
            unitCondition = "AND unit = $1";
            params.add(unit);
        }

        if (receiptNumber != null && !receiptNumber.isEmpty()) {
            receiptNumberCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND receipt_number_excess like $" + (params.size() + 1) :
                    " AND receipt_number_reduction like $" + (params.size() + 1) ;
            params.add("%" + receiptNumber.toUpperCase().trim() + "%");
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            synthesisPeriodCondition = "AND synthesis_period = $" + (params.size() + 1);
            params.add(synthesisPeriod);
        }

        params.add(pageSize);
        params.add(offset);

        String finalSql = String.format(sqlTemplate,unitCondition, budgetCondition,
                receiptNumberCondition, synthesisPeriodCondition, params.size() - 1, params.size());
        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<FuelBillingRecoveryLevel2Response> responses = new ArrayList<>();
                    rows.forEach(row -> {
                        FuelBillingRecoveryLevel2Response response = mapRowToFuelBillingRecoveryLevel2Response(row, type);
                        responses.add(response);
                    });
                    return responses;
                });
    }

    @Override
    public Uni<Long> countUnitBills(String receiptNumber, String synthesisPeriod, String unit, int type) {
        String sqlTemplate = """
               SELECT COUNT(*) FROM bms_payment.fuel_billing_recovery_level2
               WHERE is_active = true
               %s %s %s %s
        """;
        List<Object> params = new ArrayList<>();

        String unitCondition = "";
        String receiptNumberCondition = "";
        String synthesisPeriodCondition = "";
        String budgetCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                " AND total_budget_excess > 0" : " AND budget_reduction > 0";

        if (unit != null && !unit.isEmpty()) {
            unitCondition = "AND unit = $1";
            params.add(unit);
        }

        if (receiptNumber != null && !receiptNumber.isEmpty()) {
            receiptNumber = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND receipt_number_excess like $" + (params.size() + 1) :
                    " AND receipt_number_reduction like $" + (params.size() + 1) ;
            params.add("%" + receiptNumber.toUpperCase().trim() + "%");
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            synthesisPeriodCondition = "AND synthesis_period = $" + (params.size() + 1);
            params.add(synthesisPeriod);
        }

        String finalSql = String.format(sqlTemplate,unitCondition, budgetCondition,
                receiptNumberCondition, synthesisPeriodCondition);

        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> rows.iterator().next().getLong(0));
    }

    @Override
    public Uni<FuelBillingRecoveryLevel2Response> getUnitBillById(Long id) {
        return client.preparedQuery("SELECT * FROM bms_payment.fuel_billing_recovery_level2 WHERE id = $1")
                .execute(Tuple.of(id))
                .onItem().transform(rows -> {
                    if (rows.size() == 0) {
                        return null;
                    }
                    return mapRowToFuelBillingRecoveryLevel2Response(rows.iterator().next(), 1);
                });
    }

    @Override
    public Uni<String> showNewestMonthUnitBillingRecovery() {
        String sql = "SELECT MAX(synthesis_period) FROM bms_payment.fuel_billing_recovery_level2";

        return client.query(sql)
                .execute()
                .onItem().transform(rowSet -> {
                    if (rowSet.size() > 0) {
                        Row row = rowSet.iterator().next();
                        return row.getString("max");
                    } else {
                        return null;
                    }
                });
    }

    @Override
    public Uni<Boolean> updateStatus(String synthesisPeriod, Integer status, int type) {
        String sql = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                "UPDATE bms_payment.fuel_billing_recovery_level2 SET excess_status = $1 " +
                        "WHERE synthesis_period = $2 AND is_active = true AND total_budget_excess > 0" :
                "UPDATE bms_payment.fuel_billing_recovery_level2 SET reduction_status = $1 " +
                        "WHERE synthesis_period = $2 AND is_active = true AND budget_reduction > 0";

        return client.preparedQuery(sql)
                .execute(Tuple.of(status, synthesisPeriod))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0);
    }

    private FuelBillingRecoveryLevel2Response mapRowToFuelBillingRecoveryLevel2Response(Row row, int type) {
        return FuelBillingRecoveryLevel2Response.builder()
                .id(row.getLong("id"))
                .receiptNumber(
                        (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                                row.getString("receipt_number_excess") :
                                row.getString("receipt_number_reduction")
                )
                .synthesisPeriod(row.getString("synthesis_period"))
                .unit(row.getString("unit"))
                .budgetExcess(row.getBigDecimal("total_budget_excess")
                        .setScale(0, RoundingMode.HALF_UP))
                .budgetReduction(row.getBigDecimal("budget_reduction")
                        .setScale(0, RoundingMode.HALF_UP))
                .status(
                        (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                                row.getInteger("excess_status") :
                                row.getInteger("reduction_status")
                )
                .build();
    }
}
