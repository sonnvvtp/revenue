package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.common.config.BaseRepositoryConfig;
import com.viettelpost.platform.bms.portal.common.model.enums.ErrorCodeEnum;
import com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils;
import com.viettelpost.platform.bms.portal.common.exception.BusinessException;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.R2dbcBadGrammarException;
import io.r2dbc.spi.R2dbcTimeoutException;
import io.r2dbc.spi.Statement;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.TimeoutException;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import io.vertx.mutiny.sqlclient.RowSet;
import io.vertx.mutiny.sqlclient.SqlClient;
import io.vertx.mutiny.sqlclient.Tuple;
import io.vertx.pgclient.PgException;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public interface BaseRepository {

    Logger log = LoggerFactory.getLogger("BaseRepository");

    Pattern PARAM_PATTERN = Pattern.compile(":(\\w+)");

    default <T> Uni<T> execute(SqlClient sqlConnection, String sql, Tuple params, Class<T> clazz) {
        doInfoLog(sql);
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return sqlConnection.preparedQuery(sql)
                .mapping(DataMapping.map(clazz))
                .execute(params)
                .map(rows -> rows.iterator().hasNext() ? rows.iterator().next() : null)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> execute(ConnectionPool sqlConnection, String sql, Map<String, Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .map(result -> result.map(DataMappingUtils.map(clazz)))
                                    .flatMap(Mono::from);
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> execute(ConnectionPool sqlConnection, String sql, List<Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .map(result -> result.map(DataMappingUtils.map(clazz)))
                                    .flatMap(Mono::from);
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeAndGetValue(SqlClient sqlConnection, String sql, Tuple params, String columnName, Class<T> clazz) {
        doInfoLog(sql);
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return sqlConnection.preparedQuery(sql)
                .execute(params)
                .map(rows -> rows.iterator().hasNext() ? rows.iterator().next().get(clazz, columnName) : null)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeAndGetValue(SqlClient sqlConnection, String sql, String columnName, Class<T> clazz) {
        doInfoLog(sql);
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return sqlConnection.preparedQuery(sql)
                .execute()
                .map(rows -> rows.iterator().hasNext() ? rows.iterator().next().get(clazz, columnName) : null)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeAndGetValue(ConnectionPool sqlConnection, String sql, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = connection.createStatement(sql);

                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .flatMap(result -> Mono.from(result.map((row, metadata) -> row.get(columnName, clazz))));
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeAndGetValue(ConnectionPool sqlConnection, String sql, Map<String, Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .flatMap(result -> Mono.from(result.map((row, metadata) -> row.get(columnName, clazz))));
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeAndGetValue(ConnectionPool sqlConnection, String sql, List<Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .flatMap(result -> Mono.from(result.map((row, metadata) -> row.get(columnName, clazz))));
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeAndGetValue(Connection connection, String sql, Map<String, Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
        doInfoLog(sql);
        return ReactiveConverter.toUni(Mono.from(statement.execute())
                        .flatMap(result -> Mono.from(result.map((row, metadata) -> row.get(columnName, clazz)))))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default Uni<Boolean> executeOnly(SqlClient sqlConnection, String sql, Tuple params) {
        doInfoLog(sql);
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return sqlConnection.preparedQuery(sql)
                .execute(params)
                .map(Objects::nonNull)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default Uni<Boolean> executeOnly(ConnectionPool sqlConnection, String sql, List<Object> params) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);

                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .map(Objects::nonNull);
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default Uni<Boolean> executeOnly(Connection sqlConnection, String sql, List<Object> params) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];

        Statement statement = preparedOracleStatementAndBindParams(sqlConnection, sql, params);

        doInfoLog(sql);
        return ReactiveConverter.toUni(Mono.from(statement.execute())
                        .map(Objects::nonNull))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMulti(SqlClient sqlConnection, String sql, Tuple params, Class<T> clazz) {
        doInfoLog(sql);
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return sqlConnection.preparedQuery(sql)
                .mapping(DataMapping.map(clazz))
                .execute(params)
                .onItem()
                .transformToMulti(RowSet::toMulti)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMulti(ConnectionPool sqlConnection, String sql, Map<String, Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toMulti(Flux.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Flux.from(statement.execute())
                                    .flatMap(result -> result.map(DataMappingUtils.map(clazz)));
                        },
                        Connection::close
                ))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMulti(ConnectionPool sqlConnection, String sql, List<Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toMulti(Flux.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Flux.from(statement.execute())
                                    .flatMap(result -> result.map(DataMappingUtils.map(clazz)));
                        },
                        Connection::close
                ))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMulti(Connection sqlConnection, String sql, List<Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];

        Statement statement = preparedOracleStatementAndBindParams(sqlConnection, sql, params);
        doInfoLog(sql);
        Flux<T> resultMono = Flux.from(statement.execute())
                .flatMap(result -> result.map(DataMappingUtils.map(clazz)));

        return ReactiveConverter.toMulti(resultMono).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMultiAndGetValue(SqlClient sqlConnection, String sql, Tuple tuple, String columnName, Class<T> clazz) {
        doInfoLog(sql);
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return sqlConnection.preparedQuery(sql)
                .execute(tuple)
                .onItem()
                .transformToMulti(RowSet::toMulti)
                .map(rows -> rows.get(clazz, columnName))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMultiAndGetValue(ConnectionPool sqlConnection, String sql, Map<String, Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toMulti(Flux.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Flux.from(statement.execute())
                                    .flatMap(result -> Flux.from(result.map((row, metadata) -> row.get(columnName, clazz))));
                        },
                        Connection::close
                ))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeMultiAndGetValue(ConnectionPool sqlConnection, String sql, List<Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toMulti(Flux.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Flux.from(statement.execute())
                                    .flatMap(result -> Flux.from(result.map((row, metadata) -> row.get(columnName, clazz))));
                        },
                        Connection::close
                ))
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeInsertOrUpdateAndGetRow(ConnectionPool sqlConnection, String sql, List<Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        if (!sql.toLowerCase().contains("insert into") && !sql.toLowerCase().contains("update")) {
            return Uni.createFrom().failure(new BusinessException("SQL is not insert or update statement"));
        }
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);

                            try {
                                T form = clazz.getConstructor().newInstance();
                                List<String> columns = JsonObject.mapFrom(form).stream().map(Map.Entry::getKey).toList();
                                statement.returnGeneratedValues(columns.toArray(new String[0]));
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .map(result -> result.map(DataMappingUtils.map(clazz)))
                                    .flatMap(Mono::from);
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeInsertOrUpdateAndGetRow(Connection sqlConnection, String sql, List<Object> params, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        if (!sql.toLowerCase().contains("insert into") && !sql.toLowerCase().contains("update")) {
            return Uni.createFrom().failure(new BusinessException("SQL is not insert or update statement"));
        }

        Statement statement = preparedOracleStatementAndBindParams(sqlConnection, sql, params);
        try {
            T form = clazz.getConstructor().newInstance();
            List<String> columns = JsonObject.mapFrom(form).stream().map(Map.Entry::getKey).toList();
            statement.returnGeneratedValues(columns.toArray(new String[0]));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        doInfoLog(sql);
        Mono<T> resultMono = Mono.from(statement.execute())
                .flatMap(result -> Mono.from(result.map(DataMappingUtils.map(clazz))));

        return ReactiveConverter.toUni(resultMono).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeInsertOrUpdateAndGetRow(ConnectionPool sqlConnection, String sql, List<Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        if (!sql.toLowerCase().contains("insert into") && !sql.toLowerCase().contains("update")) {
            return Uni.createFrom().failure(new BusinessException("SQL is not insert or update statement"));
        }
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            statement.returnGeneratedValues(columnName);
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .map(result -> result.map((row, metadata) -> row.get(columnName, clazz)))
                                    .flatMap(Mono::from);
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<Boolean> executeOracleBatch(Connection sqlConnection, String sql, List<T> entities, BiConsumer<T, List<Object>> handleAddParams, Integer maxBatchSize) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        List<Multi<Boolean>> batchExecute = new ArrayList<>();
        oracleCreateBatchBulkBoolean(sqlConnection, sql, entities, batchExecute, maxBatchSize, (entity, statement) -> {
            List<Object> params = new ArrayList<>();
            handleAddParams.accept(entity, params);
            oracleBindParams(params, statement);
        });
        doInfoLog(sql);
        return Multi.createBy().concatenating().streams(batchExecute)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement))
                .collect().asList().replaceWith(true);
    }

    default <T> Uni<Boolean> executeOracleBatch(ConnectionPool sqlConnection, String sql, List<T> entities, BiConsumer<T, List<Object>> handleAddParams, Integer maxBatchSize) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];

        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            List<Multi<Boolean>> batchExecute = new ArrayList<>();
                            oracleCreateBatchBulkBoolean(connection, sql, entities, batchExecute, maxBatchSize, (entity, statement) -> {
                                List<Object> params = new ArrayList<>();
                                handleAddParams.accept(entity, params);
                                oracleBindParams(params, statement);
                            });

                            doInfoLog(sql);
                            return ReactiveConverter.toMono(Multi.createBy().concatenating().streams(batchExecute)
                                    .collect()
                                    .asList()
                                    .replaceWith(true)
                            );
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<Boolean> executeOracleBatchRaw(Connection sqlConnection, String sql, List<T> entities, BiConsumer<T, Statement> handleBindParam, Integer maxBatchSize) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        List<Multi<Boolean>> batchExecute = new ArrayList<>();
        oracleCreateBatchBulkBoolean(sqlConnection, sql, entities, batchExecute, maxBatchSize, handleBindParam);
        doInfoLog(sql);
        return Multi.createBy().concatenating().streams(batchExecute)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement))
                .collect().asList().replaceWith(true);
    }

    default <T> Uni<Boolean> executeOracleBatchRaw(ConnectionPool sqlConnection, String sql, List<T> entities, BiConsumer<T, Statement> handleBindParam, Integer maxBatchSize) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];

        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            List<Multi<Boolean>> batchExecute = new ArrayList<>();
                            oracleCreateBatchBulkBoolean(connection, sql, entities, batchExecute, maxBatchSize, handleBindParam);

                            doInfoLog(sql);
                            return ReactiveConverter.toMono(Multi.createBy().concatenating().streams(batchExecute)
                                    .collect()
                                    .asList()
                                    .replaceWith(true)
                            );
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<Boolean> executeOnlyInsertOracleBatch(Connection connection, String sql, List<T> entities, Integer maxBatchSize, String... propertiesExcepts) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];

        List<Multi<Boolean>> bulkInsert = new ArrayList<>();

        oracleCreateBatchBulkBoolean(connection, sql, entities, bulkInsert, maxBatchSize, propertiesExcepts);

        doInfoLog(sql);
        return Multi.createBy().concatenating().streams(bulkInsert)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement))
                .collect().asList().replaceWith(true);
    }

    default <T> Uni<Boolean> executeOnlyInsertOracleBatch(ConnectionPool sqlConnection, String sql, List<T> entities, Integer maxBatchSize, String... propertiesExcepts) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];

        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            List<Multi<Boolean>> bulkInsert = new ArrayList<>();

                            oracleCreateBatchBulkBoolean(connection, sql, entities, bulkInsert, maxBatchSize, propertiesExcepts);
                            doInfoLog(sql);
                            return ReactiveConverter.toMono(Multi.createBy().concatenating().streams(bulkInsert)
                                    .collect().asList().replaceWith(true));
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Multi<T> executeInsertPostgreBatch(SqlClient sqlConnection, String sql, String sqlParamBind, List<T> listEntity, Class<T> clazz, Integer maxBatchSize, String... propertiesExcepts) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        List<Multi<T>> bulkInsert = new ArrayList<>();
        for (int i = 0; i < listEntity.size(); i+= maxBatchSize) {
            List<Object> params = new ArrayList<>();
            String INSERT_STATEMENT = preparedPostgreBatchStatementAndBindParams(i, sql, sqlParamBind, params, listEntity, maxBatchSize, propertiesExcepts);
            INSERT_STATEMENT += " returning *";
            doInfoLog(INSERT_STATEMENT);
            bulkInsert.add(sqlConnection.preparedQuery(INSERT_STATEMENT)
                    .mapping(DataMapping.map(clazz))
                    .execute(Tuple.from(params))
                    .onItem()
                    .transformToMulti(RowSet::toMulti)
                    .onFailure()
                    .transform(throwable -> doErrorLog(throwable, currentElement)));
        }

        return Multi.createBy().concatenating().streams(bulkInsert);
    }

    default <T> Uni<Boolean> executeOnlyInsertPostgreBatch(SqlClient sqlConnection, String sql, String sqlParamBind, List<T> listEntity, Integer maxBatchSize, String... propertiesExcepts) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        List<Multi<Boolean>> bulkInsert = new ArrayList<>();
        for (int i = 0; i < listEntity.size(); i+= maxBatchSize) {
            List<Object> params = new ArrayList<>();
            String INSERT_STATEMENT = preparedPostgreBatchStatementAndBindParams(i, sql, sqlParamBind, params, listEntity, maxBatchSize, propertiesExcepts);

            doInfoLog(INSERT_STATEMENT);
            bulkInsert.add(sqlConnection.preparedQuery(INSERT_STATEMENT)
                    .execute(Tuple.from(params))
                    .map(Objects::nonNull)
                    .toMulti()
                    .onFailure()
                    .transform(throwable -> doErrorLog(throwable, currentElement)));
        }

        return Multi.createBy()
                .concatenating().streams(bulkInsert)
                .collect().asList()
                .replaceWith(true);
    }

    default <T> Uni<Boolean> executeOnlyUpdatePostgreBatch(SqlClient sqlConnection, String sql, List<T> listEntity, String primaryKey, Integer maxBatchSize, String... propertiesExcepts) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        List<Tuple> batchParams = new ArrayList<>();
        for (int i = 0; i < listEntity.size(); i+= maxBatchSize) {
            int end = Math.min(i + maxBatchSize, listEntity.size());
            List<T> chunk = listEntity.subList(i, end);
            for (T entity : chunk) {
                List<Object> params = new ArrayList<>(DataMappingUtils.getAllPropertyValuesExcept(entity, propertiesExcepts));
                params.add(DataMappingUtils.getPropertyValue(entity, primaryKey));
                batchParams.add(Tuple.from(params));
            }
        }
        doInfoLog(sql);
        return sqlConnection.preparedQuery(sql)
                .executeBatch(batchParams)
                .map(Objects::nonNull)
                .onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    default <T> Uni<T> executeFunctionOrProcedureAndGetValue(ConnectionPool sqlConnection, String sql, Map<String, Object> params, String columnName, Class<T> clazz) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StackTraceElement currentElement = stackTrace[2];
        return ReactiveConverter.toUni(Mono.usingWhen(
                        sqlConnection.create(),
                        connection -> {
                            Statement statement = preparedOracleStatementAndBindParams(connection, sql, params);
                            doInfoLog(sql);
                            return Mono.from(statement.execute())
                                    .flatMap(result -> Mono.from(result.map(outParameter -> outParameter.get(columnName, clazz))));
                        },
                        Connection::close
                )).onFailure()
                .transform(throwable -> doErrorLog(throwable, currentElement));
    }

    private Statement preparedOracleBatchStatementAndBindParams(Connection connection, String sql, List<List<Object>> batchParams) {
        Statement statement = connection.createStatement(sql);
        for (List<Object> params : batchParams) {
            oracleBindParams(params, statement);
            statement.add();
        }

        return statement;
    }

    private Statement preparedOracleStatementAndBindParams(Connection connection, String sql, List<Object> params) {
        Statement statement = connection.createStatement(sql);
        oracleBindParams(params, statement);
        return statement;
    }

    private Statement preparedOracleStatementAndBindParams(Connection connection, String sql, Map<String, Object> params) {


        Map<String, Object> finalParams = new HashMap<>();
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof Collection<?> collectionValue) {
                String placeholder = IntStream.range(0, collectionValue.size())
                        .mapToObj(i -> ":" + i)
                        .collect(Collectors.joining(", "));
                sql = sql.replaceAll(":" + key, placeholder);
                Object[] values = collectionValue.toArray();
                for (int i = 0; i < values.length; i++) {
                    finalParams.put(i+"", values[i]);
                }
            }
            else {
                finalParams.put(key, value);
            }
        }

        Statement statement = connection.createStatement(sql);
        for (Map.Entry<String, Object> entry : finalParams.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (Objects.isNull(value)) {
                statement.bindNull(key, String.class);
            } else {
                statement.bind(key, value);
            }
        }

        return statement;
    }

    private <T> String preparedPostgreBatchStatementAndBindParams(int i, String sql, String sqlParamBind, List<Object> params, List<T> listEntity, Integer maxBatchSize, String... propertiesExcepts) {
        int end = Math.min(i + maxBatchSize, listEntity.size());
        List<T> chunk = listEntity.subList(i, end);
        String INSERT_STATEMENT = sql;
        StringBuilder insertValuesBuilder = new StringBuilder();

        for (T entity : chunk) {
            insertValuesBuilder.append(sqlParamBind).append(",\n");
            params.addAll(DataMappingUtils.getAllPropertyValuesExcept(entity, propertiesExcepts));
        }

        String insertParameters = StringUtils.removeEnd(insertValuesBuilder.toString(), ",\n");

        insertParameters = DataMappingUtils.convertPlaceholder(insertParameters);

        INSERT_STATEMENT += insertParameters;

        return INSERT_STATEMENT;
    }

    private <T> void oracleCreateBatchBulkBoolean(Connection connection, String sql, List<T> entities, List<Multi<Boolean>> bulkInsert, Integer maxBatchSize, String... propertiesExcepts) {
        oracleCreateBatchBulkBoolean(
                connection,
                sql,
                entities,
                bulkInsert,
                maxBatchSize,
                (entity, statement) -> {
                    List<Object> params = new ArrayList<>(DataMappingUtils.getAllPropertyValuesExcept(entity, propertiesExcepts));
                    oracleBindParams(params, statement);
                }
        );
    }

    private <T> void oracleCreateBatchBulkBoolean(
            Connection connection, String sql, List<T> entities,
            List<Multi<Boolean>> bulkInsert, Integer maxBatchSize,
            BiConsumer<T, Statement> handleBindParams
    ) {
        for (int i = 0; i < entities.size(); i += maxBatchSize) {
            int end = Math.min(i + maxBatchSize, entities.size());
            List<T> chunk = entities.subList(i, end);

            Statement statement = connection.createStatement(sql);
            for (T entity : chunk) {
                handleBindParams.accept(entity, statement);
                statement.add();
            }

            Multi<Boolean> insert = ReactiveConverter.toUni(Mono.from(statement.execute())
                            .flatMap(result -> Mono.from(result.getRowsUpdated()))
                            .map(Objects::nonNull))
                    .toMulti();

            bulkInsert.add(insert);
        }
    }

    private void oracleBindParams(List<Object> params, Statement statement) {
        for (int i = 0; i < params.size(); i++) {
            Object value = params.get(i);

            if (Objects.isNull(value)) {
                statement.bindNull(i, String.class);
            } else {
                statement.bind(i, value);
            }
        }
    }

    private Throwable doErrorLog(Throwable throwable, StackTraceElement stackTraceElement) {
        if (throwable instanceof TimeoutException || throwable instanceof SQLTimeoutException || throwable instanceof R2dbcTimeoutException) {
            log.error("EXECUTE SQL FAILED - TIMEOUT EXCEPTION: ", throwable);
        } else if (throwable instanceof SQLException || throwable instanceof R2dbcBadGrammarException || throwable instanceof PgException) {
            log.error("EXECUTE SQL FAILED - SQL EXCEPTION: ", throwable);
        } else {
            log.error("EXECUTE SQL FAILED: ", throwable);
        }
        log.error("\n\tat {}", stackTraceElement);
        return new BusinessException(HttpStatus.SC_INTERNAL_SERVER_ERROR, ErrorCodeEnum.DATA_ERROR.getCode(), throwable.getMessage());
    }

    private void doInfoLog(String sql) {
        if (BaseRepositoryConfig.showSql()) {
            log.info("SQL STATEMENT EXECUTE:\n{}", sql);
        }

    }
}

