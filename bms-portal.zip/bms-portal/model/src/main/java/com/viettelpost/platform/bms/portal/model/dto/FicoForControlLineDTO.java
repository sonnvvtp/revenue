package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FicoForControlLineDTO {
    @JsonAlias("REQ_VTP_ORDER_ID")
    private String transactionCode;

    @JsonAlias("PARTNER_TRANSFER_ID")
    private String transactionIdBk;
}