package com.viettelpost.platform.bms.portal.model.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static com.viettelpost.platform.bms.portal.model.enums.BusinessAdvanceAcctType.*;

@RequiredArgsConstructor
@Getter
public enum DocTypeAdvanceAcct {

    BK_UT(1, "Bảng kê ứng tiền", List.of(U0, U1, U7, Y0)),
    PC_COD_RT(2, "Phiếu chi COD/rút tiền", List.of(U3)),
    BK_QR(3, "Bảng kê QR", List.of(U4)),
    BK_DON_UNG_PTC(4, "Bảng kê đơn ứng PTC", List.of(U2)),
    BK_DON_HOAN(5, "Bảng kê đơn hoàn", List.of(U5)),
    BK_CT_DT(6, "Bảng kê chuyển trả đối tác", List.of(U6)),
    NA(-99, "N/A", null);

    private final Integer code;

    private final String name;

    /** Danh sách loại nghiệp vụ hạch toán */
    private final List<BusinessAdvanceAcctType> types;

    public static DocTypeAdvanceAcct getDocTypeAdvanceAcct(Integer code) {
        return Arrays.stream(DocTypeAdvanceAcct.values())
                .filter(docTypeAdvanceAcct -> Objects.equals(docTypeAdvanceAcct.getCode(), code))
                .findFirst()
                .orElse(NA);
    }
}
