package com.viettelpost.platform.bms.portal.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QueryInvoiceOrderResponse {
    @JsonAlias("record_id")
    private BigDecimal recordId;
    @JsonAlias("order_code")
    private String orderCode;
    @JsonAlias("invoice_status")
    private int invoiceStatus;
    private int errorStatus;
    @JsonAlias("err_msg")
    private String errorMessage;
    @JsonAlias("invoice_form")
    private String invoiceNo;
    @JsonAlias("invoice_number")
    private String invoiceNumber;
    @JsonAlias("invoice_export_date")
//    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    private LocalDateTime invoiceDate;
    @JsonAlias("invoice_url")
    private String pdfUrl;
    private String xmlUrl;
    private Integer syncAttemptCount;
    @JsonAlias("created_at")
    private LocalDateTime createdAt;
    @JsonAlias("updated_at")
//    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss")
    private LocalDateTime lastUpdatedTime;
}
