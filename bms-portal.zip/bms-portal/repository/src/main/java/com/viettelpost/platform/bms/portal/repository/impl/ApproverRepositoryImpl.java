package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.ApproverDTO;
import com.viettelpost.platform.bms.portal.repository.ApproverRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.Parameters;
import io.r2dbc.spi.R2dbcType;
import io.r2dbc.spi.Row;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class ApproverRepositoryImpl implements ApproverRepository {

    @Override
    public Mono<ApproverDTO> getApproverByEmployeeCode(String employeeCode, Connection connection) {
        String sql = "SELECT u.MANHANVIEN, u.TELEPHONE, u.FULLNAME " +
                "    FROM ( " +
                "        SELECT DISTINCT MANHANVIEN, TELEPHONE, concat(FIRSTNAME, concat(' ', LASTNAME)) AS FULLNAME "
                +
                "        FROM VTP.SUSERS " +
                "    ) u " +
                "    WHERE u.MANHANVIEN = :maNhanVien";

        log.info("Executing query: {} with parameters: employeeCode = {}", sql, employeeCode);

        return Mono.from(connection
                        .createStatement(sql)
                        .bind("maNhanVien", Parameters.in(R2dbcType.VARCHAR, employeeCode))
                        .execute())
                .flatMapMany(result -> result.map((row, metadata) -> mapRowToDTO(row)))
                .singleOrEmpty()
                .switchIfEmpty(Mono.error(new RuntimeException(
                        "Approver not found for employeeCode: " + employeeCode)))
                .doOnSuccess(dto -> log.info("[DB] Successfully found approver by employeeCode: {}",
                        employeeCode))
                .doOnError(ex -> log.error("[DB] Error finding approver by employeeCode: {}",
                        employeeCode, ex));
    }

    @Override
    public Mono<Void> sendNotificationToApprover(ApproverDTO approver, String message,
            Connection connection) {
        String sql =
                "INSERT INTO VTP.SMS_MSG2SEND (SMS_MSG_ID, CONTENT, MOBIFONE, TYPE, STATUS, CREATEBY, CREATEDATE,SENDDATE, ISSMSVIETNAM) "
                        +
                        "VALUES (VTP.SMS_MSG_ID_SEQ.NEXTVAL, :content, :mobifone, :type, :status, :createBy, SYSDATE, SYSDATE, :isSmsVietnam)";

        log.info("Executing query: {}. Inserting SMS notification for approver: {}", sql,
                approver.getMaNhanVien());

        return Mono.from(connection
                        .createStatement(sql)
                        .bind("content", Parameters.in(R2dbcType.NVARCHAR, message))
                        .bind("mobifone", Parameters.in(R2dbcType.VARCHAR, approver.getTelephone()))
                        .bind("type", Parameters.in(R2dbcType.VARCHAR, "DL2"))
                        .bind("status", Parameters.in(R2dbcType.NUMERIC, 0))
                        .bind("createBy", Parameters.in(R2dbcType.NUMERIC, 312))
                        .bind("isSmsVietnam", Parameters.in(R2dbcType.NUMERIC, 0))
                        .execute())
                .then()
                .doOnSuccess(v -> log.info("[DB] Successfully sent notification to approver: {}",
                        approver.getMaNhanVien()))
                .doOnError(ex -> log.error("[DB] Error sending notification to approver: {}",
                        approver.getMaNhanVien(), ex));
    }

    private ApproverDTO mapRowToDTO(Row row) {
        return ApproverDTO.builder()
                .maNhanVien(row.get("MANHANVIEN", String.class))
                .fullName(row.get("FULLNAME", String.class))
                .telephone(row.get("TELEPHONE", String.class))
                .build();
    }
}
