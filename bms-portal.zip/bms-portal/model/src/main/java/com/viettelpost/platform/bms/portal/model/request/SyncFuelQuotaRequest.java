package com.viettelpost.platform.bms.portal.model.request;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SyncFuelQuotaRequest {

    private Long year;
    private Long month;
    private List<String> licensePlates;// If null or empty mean sync all
    private String unit;
    private String receiptNumber;
}
