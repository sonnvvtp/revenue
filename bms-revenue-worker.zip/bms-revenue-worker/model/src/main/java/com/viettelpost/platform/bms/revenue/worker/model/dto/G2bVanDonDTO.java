package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.time.LocalDateTime;
import lombok.Data;

@Data
public class G2bVanDonDTO {

    @JsonAlias("NOTE")
    private String note;

    @JsonAlias("MA_VANDON")
    private String maVanDon;

    @JsonAlias("TRANG_THAI")
    private Long trangThai;

    @JsonAlias("MA_BUUCUC")
    private String maBuuCuc;

    @JsonAlias("NGAY_HE_THONG")
    private LocalDateTime ngayHeThong;
}
