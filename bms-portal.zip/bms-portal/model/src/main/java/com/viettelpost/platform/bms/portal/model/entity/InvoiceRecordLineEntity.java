package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceRecordLineEntity {

  @JsonAlias("id")
  private Long id;

  @JsonAlias("tenant_id")
  private Integer tenantId;

  @JsonAlias("created_by")
  private Long createdBy;

  @JsonAlias("created_at")
  private LocalDateTime createdAt;

  @JsonAlias("updated_by")
  private Long updatedBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt;

  @JsonAlias("record_id")
  private BigDecimal recordId;

  @JsonAlias("order_id")
  private BigDecimal orderId;

  @JsonAlias("order_code")
  private String orderCode;

  @JsonAlias("amount")
  private BigDecimal amount;
}
