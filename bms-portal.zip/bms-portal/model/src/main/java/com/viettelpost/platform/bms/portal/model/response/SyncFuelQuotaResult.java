package com.viettelpost.platform.bms.portal.model.response;

public class SyncFuelQuotaResult {

}
