package com.viettelpost.platform.bms.portal.model.request.epacket;

import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class EpacketReconciliationEpacketRequest {
    private Integer cusId;
    private Integer reconStatus; // 0 cân khớp, 1 lệch tiền, 2 VTP có - đối tác không có, 3 VTP không có.
    private String fromDate;
    private String toDate;
    private  Integer walletType;
    private Integer page = 1;
    private Integer size = 10;
}
