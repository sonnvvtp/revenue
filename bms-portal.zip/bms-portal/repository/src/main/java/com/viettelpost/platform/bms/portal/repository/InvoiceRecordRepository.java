package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceDoctypeEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordItemEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordItemOrderEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceRecordLineEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceSellerInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceStatusJourneyEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceSymbolEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceTypeEntity;
import com.viettelpost.platform.bms.portal.model.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.CreateInvoiceRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.DetailRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceOrderRequest;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceRecordRequest;
import com.viettelpost.platform.bms.portal.model.response.einvoice.InvoiceRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.ItemRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.OrderRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.FindInvoiceOrderResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.FindInvoiceRecordResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.QuerySearchItemRecord;
import com.viettelpost.platform.bms.portal.model.response.einvoice.QuerySearchRecordOrder;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.math.BigDecimal;
import java.util.List;

public interface InvoiceRecordRepository extends BaseRepository {
    Multi<FindInvoiceOrderResponse> findInvoiceOrderBy(CreateInvoiceRecordRequest request);

    Uni<InvoiceRecordEntity> save(InvoiceRecordEntity entity, SqlConnection sqlConnection);

    Uni<InvoiceRecordItemEntity> save(InvoiceRecordItemEntity entity, SqlConnection sqlConnection);

    Multi<InvoiceRecordLineEntity> saveBatch(List<InvoiceRecordLineEntity> entities, SqlConnection sqlConnection);

    Uni<Boolean> updateInvoiceStatusBy(List<BigDecimal> ids, Integer status, SqlConnection sqlConnection);

    Uni<Boolean> updateTotalAmountRecord(InvoiceRecordEntity entity, SqlConnection sqlConnection);

    Uni<Long> getNextSequenceBy(String schemaName, String seqName, SqlConnection sqlConnection);

    Uni<Integer> findInvoiceRecordCount(FindInvoiceRecordRequest findInvoiceOrderRequest, List<String> companyCodes);

    Multi<FindInvoiceRecordResponse> findInvoiceRecord(FindInvoiceRecordRequest findInvoiceOrderRequest, List<String> companyCodes);

    Uni<InvoiceRecordResponse> findInvoiceRecordById(BigDecimal recordId);

    Uni<QuerySearchRecordOrder> findListOrderCount(BigDecimal recordId, DetailRecordRequest request);

    Multi<OrderRecordResponse> findListOrder(BigDecimal recordId, DetailRecordRequest request);

    Uni<QuerySearchItemRecord> findListItemCount(BigDecimal recordId);

    Multi<ItemRecordResponse> findListItem(BigDecimal recordId);

    Multi<InvoiceRecordResponse> findListInvoiceRecordBy(List<BigDecimal> ids, List<Integer> status);

    Uni<Boolean> updateStatusInvoiceRecord(List<BigDecimal> ids, Integer status, List<Integer> statusNeedUpd, Long userId, SqlConnection sqlConnection);

    Multi<OrderRecordResponse> findListOrderBy(List<BigDecimal> recordIds, SqlConnection sqlConnection);

    Uni<Boolean> save(InvoiceStatusJourneyEntity entity, SqlConnection sqlConnection);

    Multi<InvoiceStatusJourneyEntity> saveBatchJourney(List<InvoiceStatusJourneyEntity> entities, SqlConnection sqlConnection);

    Uni<InvoiceDoctypeEntity> finErpDoctypeBy(Long doctypeId, SqlConnection sqlConnection);

    Uni<InvoiceTypeEntity> findInvoiceTypeBy(String companyCode, SqlConnection sqlConnection);

    Uni<InvoiceSymbolEntity> findInvoiceSymbolBy(String companyCode, SqlConnection sqlConnection);

    Multi<ItemOrderEntity> findItemOrderBy(BigDecimal orderId, SqlConnection sqlConnection);

    Multi<InvoiceRecordItemOrderEntity> saveBatchItemOrder(List<InvoiceRecordItemOrderEntity> entities, SqlConnection sqlConnection);

    Uni<Integer> findOrderByRecordIdCount(BigDecimal recordId, FindInvoiceOrderRequest findInvoiceOrderRequest);

    Multi<FindInvoiceOrderResponse> findOrderByRecordId(BigDecimal recordId, FindInvoiceOrderRequest findInvoiceOrderRequest);

    Uni<InvoiceSellerInfoEntity> findInvoiceSellerInfoBy(BigDecimal recordId, SqlConnection sqlConnection);

    Multi<InvoiceInfoEntity> findInvoiceInfoBy(BigDecimal recordId, SqlConnection sqlConnection);

    Uni<ItemRecordResponse> findInvoiceRecordItemOrder(BigDecimal itemOrderId, BigDecimal recordId);

    Uni<Boolean> updateTaxAmount(BigDecimal recordId, BigDecimal itemOrderId, BigDecimal taxAmountUpdate, Long userId, SqlConnection sqlConnection);

    Uni<Boolean> updateRecordAmount(BigDecimal recordId, Long userId, SqlConnection sqlConnection);

    Multi<ItemOrderEntity> findItemOrderBy(BigDecimal itemOrderId, BigDecimal recordId, SqlConnection sqlConnection);
}
