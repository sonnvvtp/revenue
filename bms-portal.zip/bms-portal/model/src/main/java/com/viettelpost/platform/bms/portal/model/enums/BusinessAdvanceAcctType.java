package com.viettelpost.platform.bms.portal.model.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Objects;

/**
 * Nghiệp vụ hạch toán ứng tiền
 */
@RequiredArgsConstructor
@Getter
public enum BusinessAdvanceAcctType {
    U0("Hạch toán chi ứng tiền"),
    U1("Cấn trừ tiền cước"),
    U7("Cấn trừ tiền phí"),
    Y0("Hoạch toán doanh thu ứng tiền"),
    U3("Hạch toán thu nợ ứng qua chi/rút COD"),
    U4("Hạch toán thu qua QR"),
    U5("Đơn hàng phải thu khách hàng"),
    U2("Hạch toán chuyển nợ khi đơn PTC"),
    U6("Hạch toán chi tiền trả đối tác"),
    NA("N/A");

    private final String businessName;

    public static BusinessAdvanceAcctType getBusinessType(String value) {
        return Arrays.stream(BusinessAdvanceAcctType.values())
                .filter(businessAdvanceAcctType -> Objects.equals(businessAdvanceAcctType.name(), value))
                .findFirst()
                .orElse(NA);
    }
}
