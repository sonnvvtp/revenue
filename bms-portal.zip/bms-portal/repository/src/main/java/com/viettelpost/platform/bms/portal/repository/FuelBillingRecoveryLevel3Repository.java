package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryLevel3DTO;
import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryStatus;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import io.vertx.mutiny.sqlclient.SqlConnection;
import java.util.List;
import reactor.core.publisher.Mono;

public interface FuelBillingRecoveryLevel3Repository {

    Mono<Void> persist(FuelBillingRecoveryLevel3DTO recoveryDTO, SqlConnection connection);

    Mono<Void> updateStatus(List<String> receiptNumbers, BillingStatus status,
            SqlConnection connection);

    Mono<Void> updateStatusFuelBillingRecoveryLevel3(String synthesisPeriod, Integer status);

    Mono<Void> deactivateBySynthesisPeriod(String synthesisPeriod, SqlConnection sqlConnection);

    Mono<FuelBillingRecoveryStatus> getStatusLevel3(String synthesisPeriod, String receiptNumber);
}
