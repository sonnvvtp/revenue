package com.viettelpost.platform.bms.portal.model.request.advance;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AdvanceRecordByBillRequest {

    public String advancedFilter;

    @NotNull(message = "Vui lòng cung cấp docType")
    private String docType;

    private Integer page;

    private Integer size;
}
