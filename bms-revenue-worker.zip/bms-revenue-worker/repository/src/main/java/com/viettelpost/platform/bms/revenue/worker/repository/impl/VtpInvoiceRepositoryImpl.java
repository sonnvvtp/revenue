package com.viettelpost.platform.bms.revenue.worker.repository.impl;

import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueStatus;
import com.viettelpost.platform.bms.revenue.worker.common.enums.RevenueType;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupCustomeCodeDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueInvoiceDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceDoctypeEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceRecordEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceRecordLineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceSymbolEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceTypeEntity;
import com.viettelpost.platform.bms.revenue.worker.model.response.einvoice.FindRevenueRecordResponse;
import com.viettelpost.platform.bms.revenue.worker.repository.VtpInvoiceRepository;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.cache.annotation.CacheResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class VtpInvoiceRepositoryImpl implements VtpInvoiceRepository {

    private final PgPool pgPool;

    @ConfigProperty(name = "discount.cal.log.batchSize", defaultValue = "500")
    Integer batchSize;

    @Override
    public Uni<Integer> findCustomerCodeToInvoiceCount(BigDecimal periodId, String domainType) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_vtp_record" ;
        }

        String sql = """
                        select
                          count(gr.*) total
                        from
                          (
                          select
                                unit_level2_id,
                                buyer_code,
                                record_source
                          from
                    """
                    + tableName +
                    """
                        where
                            		record_source = $1
                            		and invoice_status = $2
                            		and record_type = any($3)
                            		and period_id = $4
                            	group by
                            		unit_level2_id,
                                buyer_code,
                                record_source
                            ) gr
                    """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(Arrays.asList(RevenueType.TEMPORARY_REVENUE.getValue(), RevenueType.COMPLETED_REVENUE2.getValue()).toArray());
        params.add(periodId);

        return executeAndGetValue(pgPool, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<GroupCustomeCodeDTO> findCustomerCodeToInvoice(BigDecimal periodId,
        String domainType, Integer page, Integer size) {
        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_vtp_record";
        }

        String sql = """
                    select
                    gr.*
                      from
                      	(
                      	select
                      		  unit_level2_id,
                            buyer_code,
                            record_source
                      	from
                    """
            + tableName +
            """
                where
                    record_source = $1
                    and invoice_status = $2
                    and record_type = any($3)
                    and period_id = $4
                  group by
                    unit_level2_id,
                    buyer_code,
                    record_source
                ) gr
                limit $5 offset $6
            """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(Arrays.asList(RevenueType.TEMPORARY_REVENUE.getValue(), RevenueType.COMPLETED_REVENUE2.getValue()).toArray());
        params.add(periodId);
        params.add((size * page + size));
        params.add(size * page);

        return executeMulti(pgPool, sql, Tuple.from(params), GroupCustomeCodeDTO.class);
    }

    @Override
    @CacheResult(cacheName = "partner-cache")
    public Uni<Boolean> checkPartnerExists(String partnerCode) {
        log.debug("Checking partner existence in database for code: {}", partnerCode);
        String sql = "SELECT EXISTS(SELECT 1 FROM bms_payment.partner_integration_config WHERE partner_code = $1 AND status = true)";
        return pgPool.preparedQuery(sql)
            .execute(Tuple.of(partnerCode))
            .map(rowSet -> {
                Row row = rowSet.iterator().next();
                boolean exists = row.getBoolean(0);
                log.debug("Partner with code {} exists: {}", partnerCode, exists);
                return exists;
            })
            .onFailure().invoke(e -> {
                log.error("Error checking partner existence for code: {}", partnerCode, e);
            });
    }

    @Override
    public Multi<FindRevenueRecordResponse> findRevenueRecordBy(BigDecimal periodId,  String domainType, List<GroupCustomeCodeDTO> customerCodes) {
        List<String> buyerCodes = customerCodes.stream()
            .map(GroupCustomeCodeDTO::getBuyerCode)
            .toList();

        String sql = """
                      select 
                          ger.id,
                          ger.record_code,
                          ger.invoice_status,
                          ger.record_created_at,
                          ger.buyer_id,
                          ger.buyer_code,
                          ger.company_code,
                          ger.unit_level1_id,
                          ger.unit_level2_id,
                          ger.payment_method,
                          ger.record_source,
                          ger.record_amount_before_tax as order_amount_before_tax,
                          ger.record_tax_amount as order_tax_amount,
                          ger.record_amount_after_tax as order_amount_after_tax,
                          ger.created_at as order_delivered_at,
                          ii.id as invoice_buyer_id,
                          ii.buyer_type,
                          ii.buyer_name,
                          ii.partner_name,
                          ii.buyer_phone,
                          ii.buyer_email,
                          ii.buyer_tax_code,
                          ii.buyer_address,
                          ii.buyer_bank_account,
                          ii.buyer_bank_name,
                          ii.doctype_id,
                          ii.group_order_id
                         from bms_payment.glo_exp_record ger
                         left join bms_payment.invoice_info ii on ii.general_order_id = ger.id
                         where 1 = 1
                            record_source = $1
                            and invoice_status = $2
                            and record_type = any($3)
                            and period_id = $4
                            and buyer_code = any($5)
                """;

        List<Object> params = new ArrayList<>();
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(Arrays.asList(RevenueType.TEMPORARY_REVENUE.getValue(), RevenueType.COMPLETED_REVENUE2.getValue()).toArray());
        params.add(periodId);
        params.add(buyerCodes.toArray());

        return executeMulti(pgPool, sql, Tuple.from(params), FindRevenueRecordResponse.class);
    }

    @Override
    public Uni<InvoiceDoctypeEntity> finErpDoctypeBy(Long doctypeId, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.erp_doctype
                where doctype_id = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(doctypeId), InvoiceDoctypeEntity.class);
        }

        return execute(pgPool, sql, Tuple.of(doctypeId), InvoiceDoctypeEntity.class);
    }

    @Override
    public Uni<InvoiceTypeEntity> findInvoiceTypeBy(String companyCode, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.invoice_type
                where company_code = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(companyCode), InvoiceTypeEntity.class);
        }

        return execute(pgPool, sql, Tuple.of(companyCode), InvoiceTypeEntity.class);
    }

    @Override
    public Uni<InvoiceSymbolEntity> findInvoiceSymbolBy(String companyCode, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.invoice_symbol
                where company_code = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.of(companyCode), InvoiceSymbolEntity.class);
        }

        return execute(pgPool, sql, Tuple.of(companyCode), InvoiceSymbolEntity.class);
    }

    @Override
    public Multi<ItemOrderEntity> findItemOrderBy(BigDecimal orderId, SqlConnection sqlConnection) {
        String sql = """
                 select * from bms_payment.item_order
                where general_order_id = $1
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeMulti(sqlConnection, sql, Tuple.of(orderId), ItemOrderEntity.class);
        }

        return executeMulti(pgPool, sql, Tuple.of(orderId), ItemOrderEntity.class);
    }

    @Override
    public Multi<GroupRevenueInvoiceDTO> findGroupByRevenueRecord(String domainType, BigDecimal periodId, List<GroupCustomeCodeDTO> customeCodeDTOList) {

        List<String> buyerCodes = customeCodeDTOList.stream()
            .map(GroupCustomeCodeDTO::getBuyerCode)
            .toList();

        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_vtp_record";
        }

        String sql = """
                    select
                      gr.*
                    from
                      (
                      select
                        rvr.unit_level1_id,
                        rvr.unit_level2_id,
                        rvr.buyer_code ,
                        rvr.record_source,
                        count(1) total_bill,
                        sum(rvr.record_amount_before_tax) amount_before_tax,
                        sum(rvr.record_tax_amount) tax_amount,
                        sum(rvr.record_amount_after_tax) amount_after_tax,
                        json_agg(
                            json_build_object(
                                'id', rvr.id,
                                'code', rvr.record_code,
                                'amount', rvr.record_amount_after_tax,
                                'buyerId',ii.id,
                                 'buyerName',ii.buyer_name,
                                 'buyerPhone',ii.buyer_phone,
                                 'buyerEmail',ii.buyer_email,
                                 'buyerTaxCode',ii.buyer_tax_code,
                                 'buyerAddress',ii.buyer_address
                            )
                          ) as records
                    from
                        bms_payment.revenue_vtp_record rvr
                    left join bms_payment.revenue_vtp_invoice_info ii on
                        ii.general_order_id = rvr.id
                    where
                        period_id = $1
                        and record_source = $2
                        and invoice_status = $3
                        and record_type = any($4)
                      group by
                        rvr.unit_level1_id,
                        rvr.unit_level2_id,
                        rvr.buyer_code ,
                        rvr.record_source
                    ) gr
            """;

        List<Object> params = new ArrayList<>();
        params.add(periodId);
        params.add(domainType);
        params.add(RevenueStatus.TAO_MOI.getCode());
        params.add(Arrays.asList(RevenueType.TEMPORARY_REVENUE.getValue(), RevenueType.COMPLETED_REVENUE2.getValue()).toArray());

        return executeMulti(pgPool, sql, Tuple.from(params), GroupRevenueInvoiceDTO.class);
    }

    @Override
    public Multi<InvoiceRecordEntity> saveBatchInvoiceRecord(List<InvoiceRecordEntity> entities,
        SqlConnection sqlConnection) {
        String tableName = "bms_payment.invoice_record";

        String sqlInsert = "insert into " + tableName +
            """
                (   tenant_id
                     ,created_by
                     ,created_at
                     ,updated_by
                     ,updated_at
                     ,record_status
                     ,record_no
                     ,unit_level1_id
                     ,unit_level2_id
                     ,buyer_id
                     ,buyer_code
                     ,accounting_date
                     ,accountant_id
                     ,payment_method
                     ,tax_percent
                     ,email
                     ,phone
                     ,tax_code
                     ,account_no
                     ,customer_name
                     ,address
                     ,invoice_type
                     ,invoice_number
                     ,invoice_serial
                     ,invoice_form
                     ,invoice_ref_id
                     ,invoice_export_date
                     ,record_type_id
                     ,amount_before_tax
                     ,amount_tax
                     ,amount_deduct
                     ,amount_total
                     ,company_code
                     ,record_type
                     ,record_source
                     ,unit_name
                     ,from_date
                     ,to_date
                 ) values
                """;

        String sqlBindParams = """
            (
                   ?,
                   ?,
                   current_timestamp,
                   ?,
                   current_timestamp,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?,
                   ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            InvoiceRecordEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt", "records");
    }

    @Override
    public Multi<InvoiceRecordLineEntity> saveBatchInvoiceRecordLine(
        List<InvoiceRecordLineEntity> entities, SqlConnection sqlConnection) {
        String tableName = "bms_payment.invoice_record_item";

        String sqlInsert = "insert into " + tableName +
            """
                (   tenant_id
                    ,created_by
                    ,created_at
                    ,updated_by
                    ,updated_at
                    ,record_id
                    ,order_id
                    ,order_code
                    ,amount
                 ) values
                """;

        String sqlBindParams = """
            (
                   ?,
                  ?,
                  current_timestamp,
                  ?,
                  current_timestamp,
                  ?,
                  ?,
                  ?,
                  ?
            )
            """;

        return executeInsertPostgreBatch(
            sqlConnection,
            sqlInsert,
            sqlBindParams,
            entities,
            InvoiceRecordLineEntity.class,
            batchSize,
            "id", "createdAt", "updatedAt");
    }

    @Override
    public Uni<Boolean> updateInvoiceStatusBy(String domainType, List<BigDecimal> ids, Integer status,
        SqlConnection sqlConnection) {

        String tableName = null;
        if (StringUtils.isNotEmpty(domainType)) {
            tableName = "bms_payment.revenue_vtp_record";
        }
        String sql = """
                update
                """
        + tableName +
                """       
                set
                    invoice_status = $1
                where
                  id = any($2)
                """;
        if (Objects.nonNull(sqlConnection)) {
            return executeOnly(sqlConnection, sql, Tuple.of(status, ids.toArray()));
        }

        return executeOnly(pgPool, sql, Tuple.of(status, ids.toArray()));
    }
}
