package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EpacketCallbackTransactionDTO {
    @JsonProperty("SendMessageResponse")
    private SendMessageResponse sendMessageResponse;

    @JsonProperty("ErrorResponse")
    private ErrorResponse errorResponse;

    // ---- THÊM TRẠNG THÁI NỘI BỘ ----
    @JsonIgnore
    private boolean error; // true nếu ErrorResponse != null
    @JsonIgnore
    private String message; // message nội bộ hoặc lỗi parse
    @JsonIgnore
    private String transactionCode; // để truyền xuyên suốt

    // ==== Success Structure ====
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class SendMessageResponse {
        @JsonProperty("ResponseMetadata")
        private ResponseMetadata responseMetadata;
        @JsonProperty("SendMessageResult")
        private SendMessageResult sendMessageResult;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class ResponseMetadata {
        @JsonProperty("RequestId")
        private String requestId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class SendMessageResult {
        @JsonProperty("MD5OfMessageAttributes")
        private String md5OfMessageAttributes;
        @JsonProperty("MD5OfMessageBody")
        private String md5OfMessageBody;
        @JsonProperty("MD5OfMessageSystemAttributes")
        private String md5OfMessageSystemAttributes;
        @JsonProperty("MessageId")
        private String messageId;
        @JsonProperty("SequenceNumber")
        private String sequenceNumber;
    }

    // ==== Error Structure ====
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class ErrorResponse {
        @JsonProperty("Error")
        private ErrorDetail error;
        @JsonProperty("RequestId")
        private String requestId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class ErrorDetail {
        @JsonProperty("Type")
        private String type;
        @JsonProperty("Code")
        private String code;
        @JsonProperty("Message")
        private String message;
    }
}


