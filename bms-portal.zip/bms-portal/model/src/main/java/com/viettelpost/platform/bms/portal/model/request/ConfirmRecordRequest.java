package com.viettelpost.platform.bms.portal.model.request;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ConfirmRecordRequest {
    @NotNull(message = "vui lòng điền Ids đơn")
    private List<BigDecimal> listRecordIds;
}
