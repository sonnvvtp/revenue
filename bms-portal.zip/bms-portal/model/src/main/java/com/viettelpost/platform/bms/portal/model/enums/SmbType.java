package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum SmbType {
    SBTT(7,"Bill thuê tủ"),
    SBQH(11,"Bill quá hạn"),
    GBOX(14,"Bill cước"),
    NA(-1,"N/A");

    private int id;
    private String code;

    public static SmbType get(int id) {
        return Arrays.stream(SmbType.values())
                .filter(e -> Objects.equals(e.getId(), id)).findFirst().orElse(NA);
    }
}
