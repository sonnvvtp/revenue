package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.dto.*;
import com.viettelpost.platform.bms.portal.model.request.AddPaymentPeriodCusRequest;
import com.viettelpost.platform.bms.portal.model.request.CusManagementRequest;
import com.viettelpost.platform.bms.portal.model.response.*;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.sqlclient.SqlConnection;

import java.util.List;

public interface CustomerManagementRepository extends BaseRepository {
    Uni<Long> getCountManagementCus(CusManagementRequest request);
    Multi<CusManagementListResponse> getListManagementCus(CusManagementRequest request);
    Uni<Long> getCountEvtpByCus(Long cusId);
    Multi<PartnerEvtpListByCusResponse> getListPartnerByCus(Long cusId);
    Uni<CusManagementListResponse> getInfoPaymentByCus(Long cusId);
    Uni<Long> getCountManagementCusDeclare(CusManagementRequest request);
    Multi<CusDeclareListResponse> getListManagementCusDeclare(CusManagementRequest request);
    Uni<Boolean> insertManagementCusDeclare(CusManagementListResponse request, SqlConnection sqlConnection,Long userId);
    Uni<Void> updateFicoEContractIfExits(CusManagementListResponse requests, Connection connection);
    Uni<Void> insertPaymentPeriod(List<PartnerCusDTO> partnerCusDTOList, Connection connection);
    Multi<PartnerCusDTO> getListPartnerByCusId(CusManagementListResponse request,Connection connection);
    Uni<Void>inActivePeriodPayment(List<PartnerCusDTO> partnerCusDTOList,Connection connection);
    Multi<AddPaymentPeriodCusRequest> getListInfoPaymentByCusExcel(List<AddPaymentPeriodCusRequest> requests);
    Multi<CusDeclareListResponse> getListManagementCusDeclareExcel(CusManagementRequest request);
   // Uni<Long> checkCusIdExitsConfigAuto(Long cusId, Connection connection);
    Multi<FicoPayPeriodHisDTO> getConfigTypeHis(Connection connection, Long cusId);
    Uni<Boolean> insertFicoPayPeriodHis(Connection connection, List<FicoPayPeriodHisDTO> ficoPayPeriodHisDTOList);
    Multi<FicoPayPeriodHisDTO>getListEditPeriodHis(Long cusId);
    Uni<Boolean> saveLogFileExcel(UploadFileResponse response,Long userId,String note,Long totalRecord,int status);
    Uni<Long> getCountFileUploadHis();
    Multi<DeclareUploadHisResponse> getListFileUploadHis(Integer page, Integer size);
    Uni<Integer> checkCusPaymentEveryDay(Long cusId);
    Multi<PaymentPeriodDTO> getListPaymentPeriodByEvtp(List<PartnerCusDTO> evtps,Connection connection);
    Uni<Boolean> saveLogPaymentPeriodBms(List<BmsPaymentPeriodHis> result,SqlConnection sqlConnection);
    Multi<BmsPaymentPeriodHisMap> getListBmsPaymentPeriodHis(Long cusId,SqlConnection sqlConnection);
    Uni<Void> updateLogCusBmsPeriod(SqlConnection sqlConnection,Long cusId);
    Uni<Boolean> updateFicoEContractCancel(String paramCus,Long paymentPeriod,Long cusId,Connection connection);
    Uni<Boolean> updateBmsDeclareCusPayment(SqlConnection sqlConnection,Long cusId,Long userId);
    Multi<AddPaymentPeriodCusRequest> getListCusInfoPayment(List<AddPaymentPeriodCusRequest> requests);
    Uni<Integer> checkCusHDDT(Long cusId);
}
