package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BillingRecoveryConfigResponse {
    private Long id;
    private Integer type;
    private String value;
    private String createAt;
    private String updateAt;
    private String creator;
    private String updater;
}
