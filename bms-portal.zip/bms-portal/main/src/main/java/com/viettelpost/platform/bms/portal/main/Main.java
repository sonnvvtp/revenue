package com.viettelpost.platform.bms.portal.main;

import io.quarkus.runtime.Quarkus;
import io.quarkus.runtime.annotations.QuarkusMain;

/**
 * Created by BinhNH on 12/01/2023
 */
@QuarkusMain
public class Main {

    public static void main(String[] args) {
        Quarkus.run(args);
    }
}
