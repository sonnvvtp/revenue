//package com.viettelpost.platform.bms.revenue.worker.job.kafka.consumer.impl;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.viettelpost.platform.bms.revenue.worker.service.consumer.kafka.RevenueConsumerService;
//import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
//import io.smallrye.mutiny.Multi;
//import io.smallrye.mutiny.Uni;
//import io.vertx.core.json.JsonObject;
//import jakarta.enterprise.context.ApplicationScoped;
//import java.time.Duration;
//import java.time.temporal.ChronoUnit;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.apache.kafka.common.errors.RebalanceInProgressException;
//import org.eclipse.microprofile.config.inject.ConfigProperty;
//import org.eclipse.microprofile.faulttolerance.Fallback;
//import org.eclipse.microprofile.faulttolerance.Retry;
//import org.eclipse.microprofile.reactive.messaging.Incoming;
//import org.eclipse.microprofile.reactive.messaging.Message;
//import reactor.core.publisher.Mono;
//
//@Slf4j
//@ApplicationScoped
//@RequiredArgsConstructor
//public class RevenueConsumerImpl implements RevenueConsumerService {
//
//    private final ObjectMapper objectMapper = new ObjectMapper();
//    private final JourneyBillService journeyBillService;
//
//    @ConfigProperty(name = "bms.timeout.minutes", defaultValue = "1")
//    Long configTimeout;
//
//    @Override
//    @Incoming("bms-message-bill-journey-in")
//    @Retry(delay = 5, delayUnit = ChronoUnit.SECONDS, retryOn = {java.util.concurrent.TimeoutException.class, io.smallrye.mutiny.TimeoutException.class})
//    @Fallback(applyOn = {Exception.class}, value = ReceiveFallbackHandler.class)
//    public Uni<Void> consumerJourneyBillIn(Message<ConsumerRecords<String, String>> recordsMessage) {
//        log.info("----------receive_consumerJourneyBillIn_records_size: [{}]", recordsMessage.getPayload().count());
//        // Process each record in the batch
//        ConsumerRecords<String, String> records = recordsMessage.getPayload();
//        return Multi.createFrom().iterable(records)
//            .onItem().transformToUniAndMerge(record -> {
//                JourneyBillTopic journeyBillTopic;
//                String payload;
//                try {
//                    log.info("----------record.value(): [{}]", record.value());
//                    journeyBillTopic = objectMapper.convertValue(record.value(), JourneyBillTopic.class);
//                    payload = JsonObject.mapFrom(record.value()).toString();
//                } catch (Exception e) {
//                    log.error("convert_payload_consumerJourneyBillIn_error: ex: [{}]", e.getLocalizedMessage(), e);
//                    return Uni.createFrom().voidItem();
//                }
//
//                Mono<Void> consumeKafka = journeyBillService.receiveKafkaJourneyBill(payload, journeyBillTopic)
//                    .timeout(Duration.ofMinutes(configTimeout));
//                return ReactiveConverter.toUni(consumeKafka);
//            })
//            .collect().asList()
//            .replaceWithVoid()
//            .call(() -> {
//                log.info("Successfully process batch of records!");
//                return Uni.createFrom().completionStage(recordsMessage.ack());
//            })
//            .onFailure(Exception.class).recoverWithUni(error -> handleGeneralException(recordsMessage, error))
//            .onFailure(RebalanceInProgressException.class).recoverWithUni(error -> {
//              log.warn("Rebalanced_in_progress: {}", error.getMessage());
//              return Uni.createFrom().completionStage(recordsMessage.ack());
//            });
//    }
//
//    private static Uni<Void> handleGeneralException(Message<ConsumerRecords<String, String>> recordsMessage, Throwable  error) {
//      log.error("consumerJourney_error: [{}]", error.getLocalizedMessage(), error);
//      return Uni.createFrom().completionStage(recordsMessage.ack());
//    }
//}
