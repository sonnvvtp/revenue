package com.viettelpost.platform.bms.revenue.worker.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceRecordDto {
    private BigDecimal id;
    private String code;
    private BigDecimal amount;
    private Long buyerId;
    private String buyerCode;
    public String buyerName;
    public String buyerPhone;
    public String buyerEmail;
    public String buyerTaxCode;
    public String buyerAddress;
}
