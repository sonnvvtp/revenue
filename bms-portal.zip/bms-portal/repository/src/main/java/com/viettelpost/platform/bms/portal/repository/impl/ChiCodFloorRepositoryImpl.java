package com.viettelpost.platform.bms.portal.repository.impl;

import com.google.common.collect.Lists;
import com.viettelpost.platform.bms.portal.common.utils.AppUtils;
import com.viettelpost.platform.bms.portal.model.model.BillModel;
import com.viettelpost.platform.bms.portal.model.model.PayBatchModel;
import com.viettelpost.platform.bms.portal.model.request.AccountingFloorRequest;
import com.viettelpost.platform.bms.portal.repository.ChiCodFloorRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.converters.multi.MultiReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class ChiCodFloorRepositoryImpl implements ChiCodFloorRepository {

    @Inject
    PgPool client;

    @ConfigProperty(name = "accounting.chi.cod.floor.config.day")
    Integer chiCodFloorConfigDay;

    @ConfigProperty(name = "accounting.chi.cod.vpo.post.code.config")
    private String accountingChiCodVPOPostCodeConfigId;

    @Override
    public Mono<String> getBusinessConfigById(Integer businessConfigId) {
        String sql = "SELECT business_code FROM bms_payment.acct_business_config WHERE business_id = $1 and is_active = 1";

        List<Object> params = new ArrayList<>();
        params.add(businessConfigId);
        Tuple tuple = Tuple.from(params);

        return Mono.from(client.preparedQuery(sql)
                .execute(tuple)
                .onItem().transformToMulti(rowSet ->
                        Multi.createFrom().iterable(rowSet)
                                .map(row -> row.getString("business_code"))
                )
                .convert().with(MultiReactorConverters.toFlux())
                .doOnError(error -> {
                    log.error("JOB_TRANSFER_REQ_SAP getBusinessConfigById : {}", error.getMessage());
                }));
    }

    @Override
    public Flux<Long> getRefNumberByBusinessConfigId(Integer businessConfigId, List<Long> payCostIdList) {
        StringBuilder sql = new StringBuilder();
        sql.append("select ref_number_parent from bms_payment.accounting_synthetic where business_id = $1");

        List<Object> params = new ArrayList<>();
        params.add(businessConfigId);

        List<List<Long>> batches = Lists.partition(payCostIdList, 1000);
        for (int i = 0; i < batches.size(); i++) {
            List<Long> batch = batches.get(i);

            if (i == 0) {
                sql.append(" and (ref_number_parent = any($2)");
            } else {
                sql.append(" or ref_number_parent = any($").append(i + 2).append(")");
            }
            String[] stringBatch = batch.stream()
                    .map(String::valueOf) // Chuyển Long -> String
                    .toArray(String[]::new);
            params.add(stringBatch); // Thêm vào tham số
        }
        sql.append(")");

        Tuple tuple = Tuple.from(params);

        return client.preparedQuery(sql.toString())
                .execute(tuple)
                .onItem().transformToMulti(rowSet ->
                        Multi.createFrom().iterable(rowSet)
                                .map(row -> Long.valueOf(row.getString("ref_number_parent")))
                )
                .convert().with(MultiReactorConverters.toFlux())
                .doOnError(error -> {
                    log.error("JOB_ACCOUNTING_COD_FLOOR_getRefNumberByBusinessConfigId_doOnError : {}", error.getMessage(), error);
                });
    }

    @Override
    public Flux<PayBatchModel> getPayBatch(Connection connection, Integer reqTypeFloor, Integer status, Integer configDay, AccountingFloorRequest request, boolean isVP) {
        StringBuilder sql = new StringBuilder("""
                SELECT PB.PAY_BATCH_ID    AS payBatchId,
                       PB.BATCH_NO        AS batchNo,
                       PB.COD_AMOUNT      AS codAmount,
                       PB.FEE_AMOUNT      AS feeAmount,
                       PB.PAY_AMOUNT      AS payAmount,
                       PB.CUS_PO_ID       AS partnerId,
                       PB.CUS_PO_CODE     AS partnerCode,
                       PB.CREATED_AT      AS createdAt,
                       PB.ACCOUNTING_DATE AS accountingDate,
                       PB.POST_ID         AS postId,
                       PC.POSTCODE        AS postCode,
                       PC.POST_NAME       AS postName,
                       PB.ORG_ID          AS orgId,
                       O.ORGCODE          AS orgCode,
                       BAI.BANK_ACCOUNT_NO  AS bankAccountNo,
                       BAI.ACCOUNTING_NO  AS accountingNo,
                       fps.CREATED_BY     AS uncCreatedBy,
                       (select SU.MANHANVIEN from VTP.SUSERS SU where SU.USERID = SM.CREATED_BY)  AS bthCreatedBy,
                       SAP.PROFIT_CENTER  AS profitCenter,
                       SAP.COST_CENTER    AS costCenter,
                       fps.STATEMENT_NO   AS statementNo,
                       SM.SUMMARY_NO      AS summaryNo,
                       tran.RES_TRANSACTION_ID AS ftCode,
                       tran.REQ_REQUEST_ID     AS reqCode
                FROM ERP_AC.FICO_PAY_BATCH PB
                         JOIN ERP_AC.HR_POSTCODE PC ON PB.POST_ID = PC.POST_ID
                         JOIN ERP_AC.HR_ORGANIZATION O ON O.ORG_ID = PB.ORG_ID
                         LEFT JOIN ERP_AC.FICO_BANK_ACCOUNT_INFO BAI ON BAI.BANK_ACCOUNT_INFO_ID = PB.BANK_FROM_ID
                         LEFT JOIN (SELECT DISTINCT fpsl.PAY_BATCH_ID, fps.CREATED_BY, fps.STATEMENT_NO , fps.PAY_STATEMENT_ID
                                    FROM ERP_AC.FICO_PAY_STATEMENT fps
                                             JOIN ERP_AC.FICO_PAY_STATEMENT_LINE fpsl ON fps.PAY_STATEMENT_ID = fpsl.PAY_STATEMENT_ID
                                    WHERE fpsl.PAY_BATCH_ID IS NOT NULL) fps ON fps.PAY_BATCH_ID = PB.PAY_BATCH_ID
                         LEFT JOIN ERP_AC.FICO_SAP_POST_CODE_CENTER SAP ON SAP.POST_ID = PB.POST_ID
                         LEFT JOIN ERP_AC.FICO_PAY_SUMMARY_LINE SML ON SML.PAY_STATEMENT_ID = fps.PAY_STATEMENT_ID
                         LEFT JOIN ERP_AC.FICO_PAY_SUMMARY SM ON SM.PAY_SUMMARY_ID = SML.PAY_SUMMARY_ID
                         LEFT JOIN (SELECT tran.*, ROW_NUMBER() OVER (PARTITION BY tran.PAYMENT_BATCH_ID ORDER BY tran.REQ_SEND_DATE DESC) AS rn
                                             FROM ERP_AC.FICO_BANK_TRANSFER tran) tran ON tran.PAYMENT_BATCH_ID = PB.PAY_BATCH_ID AND tran.rn = 1
                WHERE PB.REQ_TYPE = ? AND PB.BATCH_STATUS = ?
                """);

        // Danh sách tham số bind
        List<Object> params = new ArrayList<>();
        params.add(reqTypeFloor);
        params.add(status);

        // Thêm điều kiện batchId nếu có
        if (request.getBatchId() != 0L) {
            sql.append(" AND PB.PAY_BATCH_ID = ?");
            params.add(request.getBatchId());
        }

        List<String> cusPoCodeList = Arrays.stream(accountingChiCodVPOPostCodeConfigId.split(","))
                .map(String::trim)
                .collect(Collectors.toList());
        if (!cusPoCodeList.isEmpty()) {
            String inSql = cusPoCodeList.stream()
                    .map(c -> "?")
                    .collect(Collectors.joining(", "));
            sql.append(" AND PB.CUS_PO_CODE ")
                    .append(isVP ? "IN" : "NOT IN")
                    .append(" (").append(inSql).append(")");
            params.addAll(cusPoCodeList);
        }

        // Thêm điều kiện từ ngày - đến ngày nếu có
        if (request.getFromDate() != null && request.getToDate() != null) {
            sql.append(" AND PB.ACCOUNTING_DATE BETWEEN TRUNC(?) AND TRUNC(?) + 1 - 0.00001");
            params.add(new java.sql.Timestamp(Objects.requireNonNull(AppUtils.stringToDateByFormat("dd/MM/yyyy", request.getFromDate())).getTime()));
            params.add(new java.sql.Timestamp(Objects.requireNonNull(AppUtils.stringToDateByFormat("dd/MM/yyyy", request.getToDate())).getTime()));
        }

        // Chuẩn bị statement và bind các tham số
        var statement = connection.createStatement(sql.toString());
        for (int i = 0; i < params.size(); i++) {
            statement.bind(i, params.get(i));
        }

        return Flux.from(statement.execute())
                .flatMap(result -> result.map(row -> {
                    PayBatchModel batch = new PayBatchModel();
                    batch.setBatchId(row.get("payBatchId", Long.class));
                    batch.setBatchNo(row.get("batchNo", String.class));
                    batch.setCodAmount(row.get("codAmount", BigDecimal.class));
                    batch.setFeeAmount(row.get("feeAmount", BigDecimal.class));
                    batch.setPayAmount(row.get("payAmount", BigDecimal.class));
                    batch.setPartnerId(row.get("partnerId", Long.class));
                    batch.setPartnerCode(row.get("partnerCode", String.class));
                    batch.setCreatedAt(row.get("createdAt", Date.class));
                    batch.setAccountingDate(row.get("accountingDate", Date.class));
                    batch.setPostId(row.get("postId", Long.class));
                    batch.setPostCode(row.get("postCode", String.class));
                    batch.setOrgId(row.get("orgId", Long.class));
                    batch.setOrgCode(row.get("orgCode", String.class));
                    batch.setPostName(row.get("postName", String.class));
                    batch.setAccountingNo(row.get("accountingNo", String.class));
                    batch.setBankAccountNo(row.get("bankAccountNo", String.class));
                    batch.setUncCreatedBy(row.get("uncCreatedBy", Long.class));
                    batch.setBthCreatedBy(row.get("bthCreatedBy", Long.class));
                    batch.setProfitCenter(row.get("profitCenter", String.class));
                    batch.setCostCenter(row.get("costCenter", String.class));
                    batch.setStatementNo(row.get("statementNo", String.class));
                    batch.setSummaryNo(row.get("summaryNo", String.class));
                    batch.setFtCode(row.get("ftCode", String.class));
                    batch.setReqCode(row.get("reqCode", String.class));
                    return batch;
                }));
    }

    @Override
    public Mono<Boolean> checkConfig(Connection connection, Long configId) {
        String sql = "SELECT COUNT(1) AS SO_LUONG FROM ERP_AC.FICO_FEATURE_CONFIG WHERE CONFIG_ID = ? AND IS_ACTIVE = 1";
        log.info("JOB_ACCOUNTING_COD_FLOOR_checkConfig().");
        return Mono.from(connection.createStatement(sql)
                        .bind(0, configId)
                        .execute())
                .flatMap(result -> {
                            return Mono.from(result.map((row, metadata) -> row.get("SO_LUONG", Long.class)))
                                    .defaultIfEmpty(0L);
                        }
                )
                .map(count -> count > 0);
    }

    @Override
    public Flux<BillModel> getBillInPayBatch(Connection connection, Long batchId, boolean isVP) {
        String joinCus = "";
        String selectCus = "-1 AS cusId";

        if (isVP) {
            joinCus = "JOIN ERP_CUS.CUS_CUSTOMER_CODE cc ON cc.EVTPCODE = BT.PARTNER_EVTP";
            selectCus = "cc.CUS_ID AS cusId";
        }

        String joinCus2 = "";
        String selectCus2 = "-1 AS cusId";

        if (isVP) {
            joinCus2 = "JOIN ERP_CUS.CUS_CUSTOMER_CODE cc ON cc.EVTPCODE = PI.PARTNER_EVTP";
            selectCus2 = "cc.CUS_ID AS cusId";
        }

        String sql = String.format("""
                SELECT BT.PARTNER_ID                                                                           AS partnerId,
                       BT.PARTNER_EVTP                                                                         AS partnerCode,
                       BT.ORG_ID                                                                               AS orgId,
                       O.ORGCODE                                                                               AS orgCode,
                       BT.POST_ID                                                                              AS postId,
                       PC.POSTCODE                                                                             AS postCode,
                       PC.POST_NAME                                                                            AS postName,
                       (SELECT PROFIT_CENTER FROM ERP_AC.FICO_SAP_POST_CODE_CENTER WHERE POST_ID = BT.POST_ID) AS pc,
                       (SELECT COST_CENTER FROM ERP_AC.FICO_SAP_POST_CODE_CENTER WHERE POST_ID = BT.POST_ID)   AS cc,
                       CASE
                           WHEN BT.M_PRODUCT NOT IN ('VLC','VLF','VLK','VNB','VLG','VKO','VVT','VKU','VKD','G_PHH','G_VC','TQN','G_MIC','VLLS','VLOC','VLTU','VLTN','VLFA','VLTT','VLFP','VLFS','VLBK','VLAF','VLEU','VVTM','VNVL','VNVL5','VNVL8','VNVL10', 'CVPO')
                               THEN 'CPN'
                           WHEN BT.M_PRODUCT IN ('VLC','VLF','VLK','VLG','VKO','VVT','TQN')
                               THEN 'LOG'
                           WHEN BT.M_PRODUCT IN ('VKU','VKD')
                               THEN 'TH'
                           WHEN BT.M_PRODUCT IN ('G_PHH','G_VC')
                               THEN 'KHA'
                           WHEN BT.M_PRODUCT IN ('VNB')
                               THEN 'NB'
                           WHEN BT.M_PRODUCT IN ('G_MIC')
                               THEN 'TCS'
                           WHEN BT.M_PRODUCT IN ('VLLS','VLOC','VLTU','VLTN','VLFA','VLTT','VLFP','VLFS','VLBK','VLAF','VLEU')
                               THEN 'GPT'
                           WHEN BT.M_PRODUCT IN ('VVTM','VNVL','VNVL5','VNVL8','VNVL10')
                               THEN 'DVT'
                           WHEN BT.M_PRODUCT IN ('CVPO')
                               THEN 'CVPO'
                           ELSE 'KHAC'
                           END AS serviceCode,
                       AMT_COD                                                                                 AS amount,
                       BT.PERIOD_ID                                                                            AS periodId,
                       (select ENDDATE from ERP_AC.ERP_PERIOD where PERIOD_ID = BT.PERIOD_ID)                  AS endDate,
                       BT.DATEINSERT                                                                           AS completedDate,
                       20                                                                                      AS type,
                       rc.PAY_RECORD_COD_ID                                                                    AS recordId,
                       rc.RECORD_NO                                                                            AS recordNo,
                       %s
                FROM ERP_AC.EVTP_BILL_TRAN BT
                         JOIN ERP_AC.HR_POSTCODE PC ON BT.POST_ID = PC.POST_ID
                         JOIN ERP_AC.HR_ORGANIZATION O ON O.ORG_ID = BT.ORG_ID
                         JOIN ERP_AC.FICO_PAY_RECORD_COD_LINE rcl ON BT.BILL = rcl.BILL
                         JOIN ERP_AC.FICO_PAY_RECORD_COD rc ON rcl.PAY_RECORD_COD_ID = rc.PAY_RECORD_COD_ID
                         %s
                WHERE TYPE = 1
                  AND rc.PAY_RECORD_COD_ID IN (SELECT PAY_RECORD_ID
                                               FROM ERP_AC.FICO_PAY_BATCH_LINE
                                               WHERE PAY_BATCH_ID = ?
                                                 AND RECORD_TYPE = 20)
                UNION ALL
                SELECT PI.PARTNER_ID                                                                           AS partnerId,
                       PI.PARTNER_EVTP                                                                         AS partnerCode,
                       PI.ORG_ID                                                                               AS orgId,
                       O.ORGCODE                                                                               AS orgCode,
                       PI.POST_ID                                                                              AS postId,
                       PC.POSTCODE                                                                             AS postCode,
                       PC.POST_NAME                                                                            AS postName,
                       (SELECT PROFIT_CENTER FROM ERP_AC.FICO_SAP_POST_CODE_CENTER WHERE POST_ID = PI.POST_ID) AS pc,
                       (SELECT COST_CENTER FROM ERP_AC.FICO_SAP_POST_CODE_CENTER WHERE POST_ID = PI.POST_ID)   AS cc,
                       CASE
                           WHEN PI.M_PRODUCT NOT IN ('VLC','VLF','VLK','VNB','VLG','VKO','VVT','VKU','VKD','G_PHH','G_VC','TQN','G_MIC','VLLS','VLOC','VLTU','VLTN','VLFA','VLTT','VLFP','VLFS','VLBK','VLAF','VLEU','VVTM','VNVL','VNVL5','VNVL8','VNVL10', 'SVPO', 'FCWT')
                               THEN 'CPN'
                           WHEN PI.M_PRODUCT IN ('VLC','VLF','VLK','VLG','VKO','VVT','TQN')
                               THEN 'LOG'
                           WHEN PI.M_PRODUCT IN ('VKU','VKD')
                               THEN 'TH'
                           WHEN PI.M_PRODUCT IN ('G_PHH','G_VC')
                               THEN 'KHA'
                           WHEN PI.M_PRODUCT IN ('VNB')
                               THEN 'NB'
                           WHEN PI.M_PRODUCT IN ('G_MIC')
                               THEN 'TCS'
                           WHEN PI.M_PRODUCT IN ('VLLS','VLOC','VLTU','VLTN','VLFA','VLTT','VLFP','VLFS','VLBK','VLAF','VLEU')
                               THEN 'GPT'
                           WHEN PI.M_PRODUCT IN ('VVTM','VNVL','VNVL5','VNVL8','VNVL10')
                               THEN 'DVT'
                           WHEN PI.M_PRODUCT IN ('SVPO')
                               THEN 'SVPO'
                           WHEN PI.M_PRODUCT IN ('FCWT')
                               THEN 'FCWT'
                           ELSE 'KHAC'
                           END AS serviceCode,
                       CASE WHEN rcl.PAY_AMOUNT IS NOT NULL THEN NVL(rcl.PAY_AMOUNT,0) ELSE NVL(rcl.AMOUNT,0) - NVL(rcl.DEDUCT_AMOUNT,0) END AS amount,
                       PI.PERIOD_ID                                                                            AS periodId,
                       (select ENDDATE from ERP_AC.ERP_PERIOD where PERIOD_ID = PI.PERIOD_ID)                  AS endDate,
                       PI.DATEINSERT                                                                           AS completedDate,
                       10                                                                                      AS type,
                       rc.PAY_RECORD_CLEAR_ID                                                                  AS recordId,
                       rc.RECORD_NO                                                                            AS recordNo,
                       %s
                FROM ERP_AC.EVTP_PAY_IN PI
                         JOIN ERP_AC.HR_POSTCODE PC ON PI.POST_ID = PC.POST_ID
                         JOIN ERP_AC.HR_ORGANIZATION O ON O.ORG_ID = PI.ORG_ID
                         JOIN ERP_AC.FICO_PAY_RECORD_CLEAR_LINE rcl ON PI.PAY_IN_ID = rcl.PAY_IN_ID
                         JOIN ERP_AC.FICO_PAY_RECORD_CLEAR rc ON rcl.PAY_RECORD_CLEAR_ID = rc.PAY_RECORD_CLEAR_ID
                         %s
                WHERE rc.PAY_RECORD_CLEAR_ID IN (SELECT PAY_RECORD_ID
                                                 FROM ERP_AC.FICO_PAY_BATCH_LINE
                                                 WHERE PAY_BATCH_ID = ?
                                                   AND RECORD_TYPE = 10)
                """, selectCus, joinCus, selectCus2, joinCus2);

        return Flux.from(connection.createStatement(sql)
                        .bind(0, batchId)
                        .bind(1, batchId)
                        .execute())
                .flatMap(result -> result.map(row -> {
                    BillModel batch = new BillModel();
                    batch.setPartnerId(row.get("partnerId", Long.class));
                    batch.setPartnerCode(row.get("partnerCode", String.class));
                    batch.setOrgId(row.get("orgId", Long.class));
                    batch.setOrgCode(row.get("orgCode", String.class));
                    batch.setPostId(row.get("postId", Long.class));
                    batch.setPostCode(row.get("postCode", String.class));
                    batch.setPostName(row.get("postName", String.class));
                    batch.setProfitCenter(row.get("pc", String.class));
                    batch.setCostCenter(row.get("cc", String.class));
                    batch.setServiceCode(row.get("serviceCode", String.class));
                    batch.setAmount(row.get("amount", Long.class));
                    batch.setPeriodId(row.get("periodId", Long.class));
                    batch.setEndDate(row.get("endDate", Date.class));
                    batch.setCompletedDate(row.get("completedDate", Date.class));
                    batch.setType(row.get("type", Long.class));
                    batch.setRecordId(row.get("recordId", Long.class));
                    batch.setRecordNo(row.get("recordNo", String.class));
                    batch.setCusId(row.get("cusId", Long.class));
                    return batch;
                }));
    }

    @Override
    public Mono<Long> countBillsInPayBatch(Connection connection, Long batchId, boolean isVP) {
        // join ERP_CUS.CUS_CUSTOMER_CODE nếu isVP = true
        String joinCus1 = isVP ? "JOIN ERP_CUS.CUS_CUSTOMER_CODE cc ON cc.EVTPCODE = BT.PARTNER_EVTP" : "";
        String joinCus2 = isVP ? "JOIN ERP_CUS.CUS_CUSTOMER_CODE cc ON cc.EVTPCODE = PI.PARTNER_EVTP" : "";

        String sql = String.format("""
                SELECT COUNT(*) AS total
                FROM (
                    SELECT rc.PAY_RECORD_COD_ID AS recordId
                    FROM ERP_AC.EVTP_BILL_TRAN BT
                             JOIN ERP_AC.HR_POSTCODE PC ON BT.POST_ID = PC.POST_ID
                             JOIN ERP_AC.HR_ORGANIZATION O ON O.ORG_ID = BT.ORG_ID
                             JOIN ERP_AC.FICO_PAY_RECORD_COD_LINE rcl ON BT.BILL = rcl.BILL
                             JOIN ERP_AC.FICO_PAY_RECORD_COD rc ON rcl.PAY_RECORD_COD_ID = rc.PAY_RECORD_COD_ID
                             %s
                    WHERE BT.TYPE = 1
                      AND rc.PAY_RECORD_COD_ID IN (
                          SELECT PAY_RECORD_ID
                          FROM ERP_AC.FICO_PAY_BATCH_LINE
                          WHERE PAY_BATCH_ID = ?
                            AND RECORD_TYPE = 20
                      )
                    UNION ALL
                    SELECT rc.PAY_RECORD_CLEAR_ID AS recordId
                    FROM ERP_AC.EVTP_PAY_IN PI
                             JOIN ERP_AC.HR_POSTCODE PC ON PI.POST_ID = PC.POST_ID
                             JOIN ERP_AC.HR_ORGANIZATION O ON O.ORG_ID = PI.ORG_ID
                             JOIN ERP_AC.FICO_PAY_RECORD_CLEAR_LINE rcl ON PI.PAY_IN_ID = rcl.PAY_IN_ID
                             JOIN ERP_AC.FICO_PAY_RECORD_CLEAR rc ON rcl.PAY_RECORD_CLEAR_ID = rc.PAY_RECORD_CLEAR_ID
                             %s
                    WHERE rc.PAY_RECORD_CLEAR_ID IN (
                        SELECT PAY_RECORD_ID
                        FROM ERP_AC.FICO_PAY_BATCH_LINE
                        WHERE PAY_BATCH_ID = ?
                          AND RECORD_TYPE = 10
                    )
                )
                """, joinCus1, joinCus2);

        return Mono.from(connection.createStatement(sql)
                        .bind(0, batchId)
                        .bind(1, batchId)
                        .execute())
                .flatMap(result ->
                        Mono.from(result.map((row, metadata) -> row.get("total", Long.class)))
                                .defaultIfEmpty(0L)
                );
    }

}
