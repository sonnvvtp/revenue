package com.viettelpost.platform.bms.revenue.worker.service;

import io.smallrye.mutiny.Uni;

public interface RevenueVTPService {
    Uni<Void> processRevenueEveryMonth();
    Uni<Void> processCheckSyncBaseRevenue();
}
