package com.viettelpost.platform.bms.revenue.worker.model.dto.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevenueStatementLineEntity {
    
    @JsonAlias("id")
    private Long id;

    @JsonAlias("tenant_id")
    private Integer tenantId;

    @JsonAlias("created_by")
    private Long createdBy;

    @JsonAlias("created_at")
    private LocalDateTime createdAt;

    @JsonAlias("updated_by")
    private Long updatedBy;

    @JsonAlias("updated_at")
    private LocalDateTime updatedAt;

    @JsonAlias("record_id")
    private BigDecimal recordId;

    @JsonAlias("record_code")
    private String recordCode;

    @JsonAlias("statement_id")
    private BigDecimal statementId;

    @JsonAlias("statement_code")
    private String statementCode;

    @JsonAlias("total_amount")
    private BigDecimal totalAmount;
}
