package com.viettelpost.platform.bms.portal.model.response.epacket;
import com.viettelpost.platform.bms.portal.model.enums.MerchantType;
import com.viettelpost.platform.bms.portal.model.enums.PartnerSource;
import com.viettelpost.platform.bms.portal.model.enums.ServiceType;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class EpacketInsertMissingResponse {
    private Boolean error;
    private String errorMessage;
    private int totalRequested;
    private int insertedCount;
    private List<String> insertedCodes; // từ RETURNING
    private List<String> skippedCodes;  // requested - inserted
}
