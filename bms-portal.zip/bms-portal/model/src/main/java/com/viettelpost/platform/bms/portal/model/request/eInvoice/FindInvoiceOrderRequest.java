package com.viettelpost.platform.bms.portal.model.request.eInvoice;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import lombok.Data;

@Data
public class FindInvoiceOrderRequest {

    @Size(max = 100, message = "Từ khóa tìm kiếm quá dài")
    private String advancedFilter;

    private String companyCode;

    private List<Integer> status;

    private String source;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate fromDate;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    private Integer page;

    private Integer size;

}
