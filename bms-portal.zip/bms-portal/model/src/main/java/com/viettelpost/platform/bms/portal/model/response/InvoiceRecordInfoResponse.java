package com.viettelpost.platform.bms.portal.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceRecordInfoResponse {
    private String recordNo;
    private String invoiceNumber;
    private String invoiceSerial;
    private String invoiceForm;
    private List<InvoiceRecordDetailResponse> details;
}
