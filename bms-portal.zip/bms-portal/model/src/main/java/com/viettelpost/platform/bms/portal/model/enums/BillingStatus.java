package com.viettelpost.platform.bms.portal.model.enums;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BillingStatus {
    TAO_MOI(1, "Tạo mới"),
    GOM_CAP_2(2, "Gom bảng tổng hợp cấp 2"),
    GOM_TOAN_QUOC(3, "Gom bảng tổng hợp toàn quốc"),
    CHO_DUYET(4, "Chờ duyệt"),
    GUI_DUYET_LOI(5, "Gửi duyệt lỗi"),
    PHE_DUYET(6, "Phê duyệt"),
    TU_CHOI(7, "Từ chối"),
    HACH_TOAN_LOI(8, "Hạch toán lỗi"),
    HACH_TOAN_THANH_CONG(9, "Hạch toán thành công"),
    GHI_GIAM_NGAN_SACH_LOI(10, "Ghi giảm NS lỗi"),
    GHI_GIAM_NGAN_SACH_THANH_CONG(11, "Ghi giảm NS thành công"),
    HOAN_GIAM_NGAN_SACH_LOI(12, "Hoàn giảm NS lỗi "),
    HOAN_GIAM_NGAN_SACH_THANH_CONG(13, "Hoàn giảm NS thành công"),

    NA(0, "N/A");

    private final Integer code;
    private final String description;

    public static BillingStatus fromCode(Integer code) {
        for (BillingStatus status : BillingStatus.values()) {
            if (Objects.equals(status.getCode(), code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static Integer fromStatus(BillingStatus status) {
        return status.getCode();
    }
}
