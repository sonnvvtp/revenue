package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceRecordItemOrderEntity {
  @JsonAlias("id")
  public Long id;

  @JsonAlias("tenant_id")
  private Integer tenantId = 1;

  @JsonAlias("created_by")
  private Long createdBy;

  @JsonAlias("created_at")
  private LocalDateTime createdAt = LocalDateTime.now();

  @JsonAlias("updated_by")
  private Long updatedBy;

  @JsonAlias("updated_at")
  private LocalDateTime updatedAt = LocalDateTime.now();

  @JsonAlias("record_id")
  private BigDecimal recordId;

  @JsonAlias("order_id")
  private BigDecimal orderId;

  @JsonAlias("item_selection")
  private Integer itemSelection;

  @JsonAlias("item_code")
  private String itemCode;

  @JsonAlias("item_name")
  private String itemName;

  @JsonAlias("item_note")
  private String itemNote;

  @JsonAlias("item_unit")
  private String itemUnit;

  @JsonAlias("item_quantity")
  private Long itemQuantity;

  @JsonAlias("item_price")
  private BigDecimal itemPrice;

  @JsonAlias("item_weight")
  private Integer itemWeight;

  @JsonAlias("item_amount_before_tax")
  private BigDecimal itemAmountBeforeTax;

  @JsonAlias("item_tax_type")
  private Integer itemTaxType;

  @JsonAlias("item_tax_percent")
  private BigDecimal itemTaxPercent;

  @JsonAlias("item_tax_amount")
  private BigDecimal itemTaxAmount;

  @JsonAlias("item_amount_after_tax")
  private BigDecimal itemAmountAfterTax;

}
