package com.viettelpost.platform.bms.portal.model.request.partnerConfig;

import lombok.Data;

import java.util.List;

@Data
public class ConfigPartnerInExRequest {
    private String partnerSource;
    private String serviceType;
    private String merchantType;
    private String prefixCode;
    private List<Integer> partnerExternalId;
}
