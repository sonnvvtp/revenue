package com.viettelpost.platform.bms.portal.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BudgetDocumentDTO {

    private String carLicensePlate;
    private BigDecimal budgetReduction;
    private String unit;
    private String companyCode;
    private String costCenter;
    private String receiptNumber;
    private String ci;
}
