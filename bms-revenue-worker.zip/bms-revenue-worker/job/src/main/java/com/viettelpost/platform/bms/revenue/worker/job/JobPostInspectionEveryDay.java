package com.viettelpost.platform.bms.revenue.worker.job;

import com.viettelpost.platform.bms.revenue.worker.service.CalculationRevenueService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.job.JobAbs;
import io.quarkus.scheduler.Scheduled;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Mono;

@ApplicationScoped
@Slf4j
@Named("JobPostInspectionEveryDay")
public class JobPostInspectionEveryDay extends JobAbs<Void> {

  @ConfigProperty(name = "config.cron.inspection.everyday", defaultValue = "")
  String cronPostInspectionEveryDayJob;

  @Inject
  CalculationRevenueService calculationRevenueService;

  @Scheduled(cron = "${config.cron.inspection.everyday}")
  public Uni<Void> postInspectionEveryDayJob() {
    log.info("=====startJobAccountingChiFwd=====");
    return ReactiveConverter.toUni(super.executeTask("postInspectionEveryDayJob", cronPostInspectionEveryDayJob));
  }

  @Override
  protected Mono<Void> taskAction() {
    log.debug("=====start_JobCreateRevenueStatement======");
    return ReactiveConverter.toMono(calculationRevenueService.postInspectionEveryDayJob());
  }
}
