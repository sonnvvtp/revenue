package com.viettelpost.platform.bms.portal.model.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartnerEvtpListByCusResponse {
    @JsonAlias("ORG_ID")
    private String orgId;

    @JsonAlias("POST_ID")
    private String postId;

    @JsonAlias("CONFIG_VALUE")
    private String partnerEvtp;

    @JsonAlias("FULL_NAME")
    private String fullName;

    @JsonAlias("PAYMENT_TYPE")
    private Long paymentTypeId;

    @JsonAlias("PAYMENT_VALUE")
    private Long paymentValueNumber;

    @JsonAlias("PAYMENT_PERIOD_TYPE")
    private Long paymentPeriodType;

    @JsonAlias("PAYMENT_DATE")
    private Long payDate;

    private String paymentValueIds;
    private String paymentValue;



}
