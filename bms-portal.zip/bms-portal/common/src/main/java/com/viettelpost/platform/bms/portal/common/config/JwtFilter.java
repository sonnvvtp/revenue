package com.viettelpost.platform.bms.portal.common.config;

import com.viettelpost.platform.bms.portal.common.exception.BusinessException;
import com.viettelpost.platform.bms.portal.common.model.enums.ErrorCodeEnum;
import jakarta.inject.Inject;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.PreMatching;
import jakarta.ws.rs.ext.Provider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Provider
@PreMatching
public class JwtFilter implements ContainerRequestFilter {
    @Inject
    AuthenticationContextImpl authCtx;

    private final String HEADER = "Authorization";

    @ConfigProperty(name = "path.url.bypass")
    String bypassPaths;

    @ConfigProperty(name = "fw.client.id")
    String fwClientId;

    @ConfigProperty(name = "fw.client.secret")
    String fwClientSecret;

    @ConfigProperty(name = "fw.epacket.client.id")
    String fwEpacketClientId;

    @ConfigProperty(name = "fw.epacket.client.secret")
    String fwEpacketClientSecret;

    @Override
    public void filter(ContainerRequestContext req) throws IOException {
        // Danh sách các URL cần bypass
        List<String> bypassUrls =  new ArrayList<>();
        if (StringUtils.isNotEmpty(bypassPaths)) {
            bypassUrls = Arrays.stream(bypassPaths.split(";")).toList();
        }

        // Lấy đường dẫn của yêu cầu
        String path = req.getUriInfo().getPath();

        // Kiểm tra nếu URL nằm trong danh sách bypass
        if (bypassUrls.stream().anyMatch(path::startsWith)) {
            return; // Bypass không thực hiện xử lý tiếp theo
        }

        // DũngDA, check riêng cho epacket
        if(path.contains("/partner/epacket/")){
            String clientId = req.getHeaderString("client-id");
            String clientSecret = req.getHeaderString("client-secret");
            if((clientId != null && clientSecret != null) && (clientId.equals(fwEpacketClientId) && clientSecret.equals(fwEpacketClientSecret))){
                return;
            }
        }

        /**
         * check basic auth api fw
         */
        if(path.contains("/forwarding")){
            String clientId = req.getHeaderString("client-id");
            String clientSecret = req.getHeaderString("client-secret");
            if((clientId != null && clientSecret != null) && (clientId.equals(fwClientId) && clientSecret.equals(fwClientSecret))){
                return;
            }
        }

        String jwtToken = req.getHeaderString(HEADER);
        if (jwtToken == null) {
            throw new BusinessException(ErrorCodeEnum.UNAUTHORIZED.getCode(), "Token Fail!");
        }
        jwtToken = jwtToken.replace("Bearer ", "").replace("bearer ", "");
        var body = VTManTokenHelper.parse(jwtToken);
        Instant exp = Instant.ofEpochMilli(Long.parseLong(body.getOrDefault("exp", "0").toString()));
        if (exp.isBefore(Instant.now())) {
            throw new BusinessException(ErrorCodeEnum.UNAUTHORIZED.getCode(), "Expired token!");
        }

        authCtx.setToken(jwtToken);

        /* CÁC TRƯỜNG TRONG TOKEN TRÊN DEV KHÁC VỚI TRÊN PROD, CẦN CHECK LẠI CÁC TRƯỜNG KHI THÊM */
        authCtx.setCurrentUser(CustomUser.builder()
                .userId(convertStringToLongToken(body.get("userid")))
                .post((String) body.get("ma_buucuc"))
                .org((String) body.get("chi_nhanh"))
                .name((String) body.get("name"))
                .phone((String) body.get("phone"))
                .roleCode((String) body.get("ma_chucdanh"))
                .username((String) body.get("username"))
                .staffCode((String) body.get("manhanvien"))
                .dnUserId(convertStringToLongToken( body.get("dn_userid")))
                .employeeGroupId(convertStringToLongToken( body.get("employee_group_id")))
                .chiNhanh((String) body.get("chi_nhanh"))
                .maBuCuc((String) body.get("ma_buucuc"))
                .build());
    }


    private Long convertStringToLongToken(Object object) {
        if (object instanceof String) {
            return Long.parseLong((String) object);
        } else if (object instanceof Long) {
            return (Long) object;
        }
        return null;
    }
}
