package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryConfigDTO;
import com.viettelpost.platform.bms.portal.model.dto.VehicleTypeGroupKMCPConfigDTO;
import com.viettelpost.platform.bms.portal.model.request.KMCPConfigFilter;
import com.viettelpost.platform.bms.portal.model.request.KMCPConfigRequest;
import com.viettelpost.platform.bms.portal.model.response.BillingRecoveryConfigResponse;
import com.viettelpost.platform.bms.portal.model.response.CommitmentItemResponse;
import com.viettelpost.platform.bms.portal.repository.FuelBillingRecoveryConfigRepository;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.Parameters;
import io.r2dbc.spi.R2dbcType;
import io.r2dbc.spi.Statement;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class FuelBillingRecoveryConfigRepositoryImpl implements
        FuelBillingRecoveryConfigRepository {

    @Inject
    PgPool pgPool;

    @Override
    public Mono<Boolean> changeConfigManage(int type, String value, String modifier) {
        String sql = "UPDATE bms_payment.fuel_billing_recovery_config SET value = $2, update_at = CURRENT_TIMESTAMP, update_by = $3 WHERE type = $1;";

        return Mono.create(sink ->
                pgPool
                        .preparedQuery(sql)
                        .execute(Tuple.of(type, value, modifier))
                        .onItem().transform(pgRowSet -> pgRowSet.rowCount() > 0)
                        .onFailure().recoverWithItem(false)
                        .subscribe()
                        .with(
                                sink::success,
                                sink::error
                        ));
    }

    @Override
    public Mono<Boolean> createConfigManage(int type, String value, String modifier) {
        String sql = "INSERT INTO bms_payment.fuel_billing_recovery_config (type, value, create_at, create_by) " +
                "VALUES ($1, $2, CURRENT_TIMESTAMP, $3)";
        return Mono.create(sink ->
                pgPool
                        .preparedQuery(sql)
                        .execute(Tuple.of(type, value, modifier))
                        .onItem().transform(pgRowSet -> pgRowSet.rowCount() > 0)
                        .onFailure().recoverWithItem(false)
                        .subscribe()
                        .with(
                                sink::success,
                                sink::error
                        ));
    }

    @Override
    public Mono<Boolean> findConfigManageByType(int type){
        String sql = "SELECT EXISTS(SELECT 1 FROM bms_payment.fuel_billing_recovery_config WHERE type = $1)";

        return Mono.create(sink ->
                pgPool
                        .preparedQuery(sql)
                        .execute(Tuple.of(type))
                        .onItem()
                        .transform(rowSet -> rowSet.iterator().hasNext() && rowSet.iterator().next().getBoolean(0))
                        .onFailure().recoverWithItem(false)
                        .subscribe()
                        .with(
                                sink::success,
                                sink::error
                        ));
    }

    @Override
    public Uni<BillingRecoveryConfigResponse> configManageDetail(Integer type) {
        String sql = "SELECT id, type, value, TO_CHAR(create_at, 'HH24:MI:SS DD/MM/YYYY') AS create_at, " +
                "       TO_CHAR(update_at, 'HH24:MI:SS DD/MM/YYYY') AS update_at, create_by, update_by " +
                "       FROM bms_payment.fuel_billing_recovery_config WHERE type = $1";

        return pgPool.preparedQuery(sql)
                .execute(Tuple.of(type))
                .onItem().transform(rows -> {
                    if (rows.size() == 0) {
                        return null;
                    } else {
                        Row row = rows.iterator().next();
                        return mapRowToBillingRecoveryConfigResponse(row);
                    }
                });
    }

    private BillingRecoveryConfigResponse mapRowToBillingRecoveryConfigResponse(Row row) {
        return BillingRecoveryConfigResponse.builder()
                .id(row.getLong("id"))
                .type(row.getInteger("type"))
                .value(row.getString("value"))
                .createAt(row.getString("create_at"))
                .updateAt(row.getString("update_at"))
                .creator(row.getString("create_by"))
                .updater(row.getString("update_by"))
                .build();
    }

    @Override
    public Mono<FuelBillingRecoveryConfigDTO> findByType(Integer type) {
        String query = "SELECT id, type, value, create_at FROM bms_payment.fuel_billing_recovery_config WHERE type = $1";

        return pgPool.preparedQuery(query)
                .execute(Tuple.of(type))
                .convert().with(UniReactorConverters.toMono())
                .flatMap(rowSet -> {
                    if (!rowSet.iterator().hasNext()) {
                        return Mono.error(new RuntimeException());
                    }
                    Row row = rowSet.iterator().next();
                    FuelBillingRecoveryConfigDTO configDTO = mapRowToDTO(row);
                    return Mono.just(configDTO);
                })

                .doOnSuccess(dto -> log.info(
                        "[DB] Successfully found fuel billing recovery config by type: {}", type))
                .doOnError(ex -> log.error(
                        "[DB] Error finding fuel billing recovery config by type: {}", type, ex));
    }

    @Override
    public Mono<List<CommitmentItemResponse>> getCommitmentItems(String search, Connection connection, int page, int size) {
        if (StringUtils.isNotBlank(search)) {
            return getCommitmentItemsSearch(search, connection, page, size);
        }

        int startRow = (page - 1) * size + 1;
        int endRow = page * size;

        String sql = """
        SELECT DISTINCT COMMITMENT_ITEM, SHORT_TEXT, LONG_TEXT
        FROM (
            SELECT COMMITMENT_ITEM, SHORT_TEXT, LONG_TEXT,
                   ROW_NUMBER() OVER (ORDER BY COMMITMENT_ITEM) AS rn
            FROM ERP_AC.FICO_EXPENSE_ITEM
        )
        WHERE rn/2 BETWEEN :startRow AND :endRow
        """;

        log.info("Executing query: {} with parameters: search = {}", sql, search);

        return Mono.from(connection
                        .createStatement(sql)
                        .bind("startRow", Parameters.in(R2dbcType.INTEGER, startRow))
                        .bind("endRow", Parameters.in(R2dbcType.INTEGER, endRow))
                        .execute())
                .flatMapMany(result -> result.map((row, metadata) -> mapRowToCommitmentItemResponse(row)))
                .collectList();
    }

    public Mono<List<CommitmentItemResponse>> getCommitmentItemsSearch(String search, Connection connection, int page, int size) {
        int startRow = (page - 1) * size + 1;
        int endRow = page * size;

        String sql = """
        SELECT DISTINCT COMMITMENT_ITEM, SHORT_TEXT, LONG_TEXT
        FROM (
            SELECT COMMITMENT_ITEM, SHORT_TEXT, LONG_TEXT,
                   ROW_NUMBER() OVER (ORDER BY COMMITMENT_ITEM) AS rn
            FROM ERP_AC.FICO_EXPENSE_ITEM
            WHERE SHORT_TEXT like :search or LONG_TEXT like :search or COMMITMENT_ITEM like :search
        )
        WHERE rn/2 BETWEEN :startRow AND :endRow
        """;

        log.info("Executing query: {} with parameters: search = {}", sql, search);

        return Mono.from(connection
                        .createStatement(sql)
                        .bind("startRow", Parameters.in(R2dbcType.INTEGER, startRow))
                        .bind("endRow", Parameters.in(R2dbcType.INTEGER, endRow))
                        .bind("search", Parameters.in(R2dbcType.VARCHAR, "%" + search + "%"))
                        .execute())
                .flatMapMany(result -> result.map((row, metadata) -> mapRowToCommitmentItemResponse(row)))
                .collectList();
    }

    @Override
    public Mono<List<CommitmentItemResponse>> getCommitmentItemsByItems(Connection connection, List<String> commitmentItems) {
        String placeholders = String.join(",", commitmentItems.stream().map(commitmentItem -> "?").toArray(String[]::new));
        String query = "SELECT COMMITMENT_ITEM, SHORT_TEXT, LONG_TEXT FROM ERP_AC.FICO_EXPENSE_ITEM WHERE COMMITMENT_ITEM IN (" + placeholders + ")";
        Statement statement = connection.createStatement(query);
        for (int i = 0; i < commitmentItems.size(); i++) {
            statement.bind(i, commitmentItems.get(i));
        }
        return Mono.from(statement.execute())
                .flatMapMany(result ->
                        result.map((row, rowMetaData) ->
                                new CommitmentItemResponse(row.get("COMMITMENT_ITEM", String.class),
                                        row.get("SHORT_TEXT", String.class),
                                        row.get("LONG_TEXT", String.class))))
                .collectList()
                .switchIfEmpty(Mono.empty());
    }


    @Override
    public Mono<List<VehicleTypeGroupKMCPConfigDTO>> getKMCPConfigs(KMCPConfigFilter filter) {
        int offset = (filter.getPage() - 1) * filter.getSize();
        String sql = """
        SELECT c.*, s.name AS vehicle_type_group_name
        FROM bms_payment.vehicle_type_group_kmcp_config c
        LEFT JOIN bms_payment.vehicle_type_group_setting s ON c.vehicle_type_group_id = s.id
        %s
        ORDER BY c.vehicle_type_group_id DESC
        LIMIT $%d OFFSET $%d
        """;
        List<Object> params = new ArrayList<>();
        String vehicleTypeGroupCondition = "";

        if (filter.getVehicleTypeGroupId() != null && !filter.getVehicleTypeGroupId().isEmpty()) {
            AtomicInteger index = new AtomicInteger(1);
            String placeholders = filter.getVehicleTypeGroupId().stream()
                    .map(id -> "$" + index.getAndIncrement())
                    .collect(Collectors.joining(", "));
            vehicleTypeGroupCondition = " WHERE c.vehicle_type_group_id IN (" + placeholders + ")";
            params.addAll(filter.getVehicleTypeGroupId());
        }

        params.add(filter.getSize());
        params.add(offset);
        String finalSql = String.format(sql, vehicleTypeGroupCondition, params.size() - 1, params.size());

        return ReactiveConverter.toFlux(pgPool.preparedQuery(finalSql)
                        .mapping(DataMapping.map(VehicleTypeGroupKMCPConfigDTO.class))
                        .execute(Tuple.from(params))
                        .toMulti()
                        .flatMap(rows -> Multi.createFrom().iterable(rows)))
                .collectList();
    }

    @Override
    public Mono<Long> countKMCPConfigs(KMCPConfigFilter filter) {
        String sql = """
                SELECT count(*)
                FROM bms_payment.vehicle_type_group_kmcp_config
                %s
                """;
        List<Object> params = new ArrayList<>();
        String vehicleTypeGroupCondition = "";

        if (filter.getVehicleTypeGroupId() != null && !filter.getVehicleTypeGroupId().isEmpty()) {
            AtomicInteger index = new AtomicInteger(1);
            String placeholders = filter.getVehicleTypeGroupId().stream()
                    .map(id -> "$" + index.getAndIncrement())
                    .collect(Collectors.joining(", "));
            vehicleTypeGroupCondition = " WHERE vehicle_type_group_id IN (" + placeholders + ")";
            params.addAll(filter.getVehicleTypeGroupId());
        }
        String finalSql = String.format(sql, vehicleTypeGroupCondition);
        return Mono.create(sink ->
                pgPool
                        .preparedQuery(finalSql)
                        .execute(Tuple.from(params))
                        .onItem()
                        .transformToMulti(rowSet -> rowSet.iterator().hasNext()
                                ? Multi.createFrom().item(rowSet.iterator().next())
                                : Multi.createFrom().empty())
                        .collect().first()
                        .onItem().transform(row -> row.getLong(0))
                        .subscribe()
                        .with(sink::success, sink::error)
        );
    }

    @Override
    public Uni<Boolean> updateKMCPConfig(KMCPConfigRequest request) {
        String sql = "UPDATE bms_payment.vehicle_type_group_kmcp_config SET vehicle_type_group_id = $2, org_type = $3, kmcp_id = $4," +
                " update_date = CURRENT_TIMESTAMP, ci = $5 WHERE id = $1;";

        return pgPool
                .preparedQuery(sql)
                .execute(Tuple.of(
                        request.getId(),
                        request.getVehicleTypeGroupId(),
                        request.getOrgType(),
                        request.getKmcpId(),
                        request.getCommitmentItem()))
                .onItem().transform(pgRowSet -> pgRowSet.rowCount() > 0);
    }

    @Override
    public Uni<Boolean> createKMCPConfig(KMCPConfigRequest request) {
        String sql = "INSERT INTO bms_payment.vehicle_type_group_kmcp_config (vehicle_type_group_id, org_type, kmcp_id, update_date, ci) " +
                "VALUES ($1, $2, $3, CURRENT_TIMESTAMP, $4);";

        return pgPool
                .preparedQuery(sql)
                .execute(Tuple.of(
                        request.getVehicleTypeGroupId(),
                        request.getOrgType(),
                        request.getKmcpId(),
                        request.getCommitmentItem()
                ))
                .onItem().transform(pgRowSet -> pgRowSet.rowCount() > 0);
    }

    @Override
    public Uni<Boolean> findKMCPConfigByVehicleTypeGroupIdAndOrgType(Long vehicleTypeGroupId, Integer orgType) {
        String sql = "SELECT COUNT(*) FROM bms_payment.vehicle_type_group_kmcp_config WHERE vehicle_type_group_id = $1 AND org_type = $2";

        return pgPool.preparedQuery(sql)
                .execute(Tuple.of(vehicleTypeGroupId, orgType))
                .onItem().transform(rowSet -> {
                    int count = rowSet.iterator().hasNext() ? rowSet.iterator().next().getInteger(0) : 0;
                    return count > 0;
                })
                .onFailure().invoke(ex -> log.error("Error checking KMCPConfigExist: {}", ex.getMessage()));
    }

    @Override
    public Uni<Boolean> findKMCPConfigByVehicleTypeGroupIdAndOrgTypeAndNotById(Long vehicleTypeGroupId, Integer orgType, Long id) {
        String sql = "SELECT COUNT(*) FROM bms_payment.vehicle_type_group_kmcp_config WHERE vehicle_type_group_id = $1 AND org_type = $2 AND id != $3";

        return pgPool.preparedQuery(sql)
                .execute(Tuple.of(vehicleTypeGroupId, orgType, id))
                .onItem().transform(rowSet -> {
                    int count = rowSet.iterator().hasNext() ? rowSet.iterator().next().getInteger(0) : 0;
                    return count > 0;
                })
                .onFailure().invoke(ex -> log.error("Error checking KMCPConfigExist: {}", ex.getMessage()));
    }

    @Override
    public Uni<Boolean> findKMCPConfigById(Long id) {
        if (id == null || id <= 0) {
            return Uni.createFrom().failure(new IllegalArgumentException("ID không hợp lệ."));
        }

        String query = "SELECT EXISTS (SELECT 1 FROM bms_payment.vehicle_type_group_kmcp_config WHERE id = $1)";

        return pgPool.preparedQuery(query)
                .execute(Tuple.of(id))
                .onItem()
                .transform(rowSet -> rowSet.iterator().hasNext() && rowSet.iterator().next()
                        .getBoolean(0))
                .onFailure().invoke(ex -> log.error("Lỗi khi kiểm tra KMCPConfig tồn tại: {}",
                        ex.getMessage()))
                .onFailure().recoverWithItem(false);
    }

    @Override
    public Uni<Boolean> deleteKMCPConfig(Long id) {
        String query = "DELETE FROM bms_payment.vehicle_type_group_kmcp_config WHERE id = $1";

        return pgPool.preparedQuery(query)
                .execute(Tuple.of(id))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0)
                .onFailure()
                .invoke(ex -> log.error("Lỗi khi xóa KMCP: {}", ex.getMessage()))
                .onFailure().recoverWithItem(false);
    }

    @Override
    public Uni<Boolean> deleteKMCPConfigByVehicleTypeGroupId(Long vehicleTypeGroupId) {
        String query = "DELETE FROM bms_payment.vehicle_type_group_kmcp_config WHERE vehicle_type_group_id = $1";

        return pgPool.preparedQuery(query)
                .execute(Tuple.of(vehicleTypeGroupId))
                .onItem().transform(rowSet -> true)
                .onFailure()
                .invoke(ex -> log.error("Lỗi khi xóa KMCP: {}", ex.getMessage()))
                .onFailure().recoverWithItem(false);
    }

    private CommitmentItemResponse mapRowToCommitmentItemResponse(io.r2dbc.spi.Row row) {
        return CommitmentItemResponse.builder()
                .commitmentItems(row.get("commitment_item", String.class))
                .shortText(row.get("short_text", String.class))
                .longText(row.get("long_text", String.class))
                .build();
    }

    private FuelBillingRecoveryConfigDTO mapRowToDTO(Row row) {
        return FuelBillingRecoveryConfigDTO.builder()
                .id(row.getLong("id"))
                .type(row.getInteger("type"))
                .value(row.getString("value"))
                .build();
    }
}
