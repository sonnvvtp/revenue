package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.ApproverDTO;
import com.viettelpost.platform.bms.portal.model.dto.FuelBillingRecoveryLevel3DTO;
import com.viettelpost.platform.bms.portal.model.enums.BillingStatus;
import com.viettelpost.platform.bms.portal.model.enums.BillingType;
import com.viettelpost.platform.bms.portal.model.response.BillingRecoveryResponse;
import com.viettelpost.platform.bms.portal.model.response.FuelBillingRecoveryLevel3DetailResponse;
import com.viettelpost.platform.bms.portal.repository.BillingRecoveryRepository;
import com.viettelpost.platform.root.common.utils.DataMapping;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.Parameters;
import io.r2dbc.spi.R2dbcType;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import io.r2dbc.spi.Statement;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class BillingRecoveryRepositoryImpl implements BillingRecoveryRepository {

    @Inject
    PgPool client;

    @Override
    public Uni<List<BillingRecoveryResponse>> searchBills(
            String receiptNumber, String synthesisPeriod, List<Integer> status, int pageNo,
            int pageSize, int type) {
        int offset = (pageNo - 1) * pageSize;
        String sqlTemplate = """
           SELECT *
           FROM bms_payment.fuel_billing_recovery_level3
           WHERE is_active = true
           %s %s %s %s
           ORDER BY created_at DESC
           LIMIT $%d OFFSET $%d
        """;
        List<Object> params = new ArrayList<>();

        String receiptNumberCondition = "";
        String synthesisPeriodCondition = "";
        String statusCondition = "";
        String budgetCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                " AND total_budget_excess > 0" : " AND budget_reduction > 0";

        if (receiptNumber != null && !receiptNumber.isEmpty()) {
            receiptNumberCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND receipt_number_excess like $1" :
                    " AND receipt_number_reduction like $1";
            params.add("%" + receiptNumber.toUpperCase().trim() + "%");
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            synthesisPeriodCondition = "AND synthesis_period = $" + (params.size() + 1);
            params.add(synthesisPeriod);
        }

        if (status != null && !status.isEmpty()) {
            StringBuilder statusBuilder = new StringBuilder(
                    ((Objects.equals(type, BillingType.TRUY_THU.getCode())) ||
                    (Objects.equals(type, BillingType.DUYET_TRUY_THU.getCode()))) ?
                            "AND excess_status IN (" :
                            "AND reduction_status IN (");
            for (int i = 0; i < status.size(); i++) {
                if (i > 0) {
                    statusBuilder.append(", ");
                }
                statusBuilder.append("$").append(params.size() + 1);
                params.add(status.get(i));
            }
            statusBuilder.append(")");
            statusCondition = statusBuilder.toString();
        }

        params.add(pageSize);
        params.add(offset);

        String finalSql = String.format(sqlTemplate,budgetCondition, receiptNumberCondition,
                synthesisPeriodCondition, statusCondition, params.size() - 1, params.size());
        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<BillingRecoveryResponse> responses = new ArrayList<>();
                    rows.forEach(row -> {
                        BillingRecoveryResponse response = mapRowToBillingRecoveryResponse(row, type);
                        responses.add(response);
                    });
                    return responses;
                });
    }


    @Override
    public Uni<BillingRecoveryResponse> searchBillById(Long id) {
        String sql = "SELECT * FROM bms_payment.fuel_billing_recovery_level3 WHERE id = $1";

        return client.preparedQuery(sql)
                .execute(Tuple.of(id))
                .onItem().transform(rowSet -> {
                    if (rowSet.rowCount() == 0) {
                        return null;
                    }
                    return mapRowToBillingRecoveryResponse(rowSet.iterator().next(),1);
                });
    }

    @Override
    public Uni<FuelBillingRecoveryLevel3DTO> searchBillBySynthesisPeriod(String synthesisPeriod) {
        String sql = "SELECT * FROM bms_payment.fuel_billing_recovery_level3 WHERE synthesis_period = $1 AND is_active = true";

        return client.preparedQuery(sql)
                .mapping(DataMapping.map(FuelBillingRecoveryLevel3DTO.class))
                .execute(Tuple.of(synthesisPeriod))
                .onItem().transform(rowSet ->
                        rowSet.iterator().hasNext() ? rowSet.iterator().next() : null
                );
    }

    @Override
    public Uni<String> showNewestMonthBillingRecovery() {
        String sql = "SELECT MAX(synthesis_period) FROM bms_payment.fuel_billing_recovery_level3";

        return client.query(sql)
                .execute()
                .onItem().transform(rowSet -> {
                    if (rowSet.size() > 0) {
                        Row row = rowSet.iterator().next();
                        return row.getString("max");
                    } else {
                        return null;
                    }
                });
    }

    @Override
    public Mono<List<String>> showSynthesisPeriodsByStatus(List<Integer> status) {
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < status.size(); i++) {
            placeholders.append("$").append(i + 1);
            if (i < status.size() - 1) {
                placeholders.append(",");
            }
        }
        String sql = "SELECT synthesis_period FROM bms_payment.fuel_billing_recovery_level3" +
                " WHERE excess_status IN (" + placeholders + ") AND is_active = true";
        Object[] params = status.toArray();
        return Mono.create(sink ->
                client.preparedQuery(sql)
                        .execute(Tuple.from(params))
                        .onItem().transform(rowSet -> {
                                    List<String> synthesisPeriods = new ArrayList<>();
                                    rowSet.forEach(row -> {
                                        synthesisPeriods.add(row.getString("synthesis_period"));
                                    });
                                    return synthesisPeriods;
                        }).onFailure().recoverWithItem(List.of())
                        .subscribe()
                        .with(
                                sink::success,
                                sink::error
                        ));
    }

    @Override
    public Mono<Integer> getReductionStatusByPeriod(String period) {
        String sql = "SELECT DISTINCT reduction_status FROM bms_payment.fuel_billing_recovery_level3" +
                " WHERE synthesis_period = $1 AND is_active = true";

        return client.preparedQuery(sql)
                .execute(Tuple.of(period))
                .onItem()
                .transform(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        Row row = rowSet.iterator().next();
                        return row.getInteger("reduction_status");
                    } else {
                        return null;
                    }
                })
                .convert()
                .with(UniReactorConverters.toMono())
                .flatMap(Mono::justOrEmpty);
    }

    @Override
    public Uni<Long> countBills(String receiptNumber, String synthesisPeriod, List<Integer> status, int type) {
        String sqlTemplate = """
           SELECT COUNT(*) FROM bms_payment.fuel_billing_recovery_level3
           WHERE is_active = true
           %s %s %s %s
    """;
        List<Object> params = new ArrayList<>();

        String receiptNumberCondition = "";
        String synthesisPeriodCondition = "";
        String statusCondition = "";
        String budgetCondition = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                " AND total_budget_excess > 0" : " AND budget_reduction > 0";

        if (receiptNumber != null && !receiptNumber.isEmpty()) {
            receiptNumber = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                    " AND receipt_number_excess like $1" :
                    " AND receipt_number_reduction like $1";
            params.add("%" + receiptNumber.toUpperCase().trim() + "%");
        }

        if (synthesisPeriod != null && !synthesisPeriod.isEmpty()) {
            synthesisPeriodCondition = "AND synthesis_period = $" + (params.size() + 1);
            params.add(synthesisPeriod);
        }

        if (status != null && !status.isEmpty()) {
            StringBuilder statusBuilder = new StringBuilder(
                    (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                            "AND excess_status IN (" :
                            "AND reduction_status IN (");
            for (int i = 0; i < status.size(); i++) {
                if (i > 0) {
                    statusBuilder.append(", ");
                }
                statusBuilder.append("$").append(params.size() + 1);
                params.add(status.get(i));
            }
            statusBuilder.append(")");
            statusCondition = statusBuilder.toString();
        }

        String finalSql = String.format(sqlTemplate, budgetCondition, receiptNumberCondition,
                synthesisPeriodCondition, statusCondition);
        return client.preparedQuery(finalSql)
                .execute(Tuple.from(params))
                .onItem().transform(rows -> rows.iterator().next().getLong(0));
    }


    @Override
    public Uni<Boolean> saveFuelBillingRecoveryDetail(Long receiptId, Long userId,
            BigDecimal amount, String note, String carLicensePlate, Long carId, String userCodeBp, Integer status) {
        String sql =
                "INSERT INTO bms_payment.fuel_billing_recovery_level3_detail (receipt_id, user_id, amount, note, car_license_plate, car_id, user_code_bp, status) "
                        +
                        "VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";
        List<Object> params = new ArrayList<>();
        params.add(receiptId);
        params.add(userId);
        params.add(amount);
        params.add(note);
        params.add(carLicensePlate);
        params.add(carId);
        params.add(userCodeBp);
        params.add(status);

        return client.preparedQuery(sql)
                .execute(Tuple.from(params))
                .onItem().transform(pgRowSet -> pgRowSet.rowCount() == 1)
                .onFailure().invoke(th -> log.error(
                        "Error inserting data into fuel_billing_recovery_level3_detail", th));
    }

    @Override
    public Uni<Boolean> updateApprovedBillStatus(Long id, Integer status) {
        String sql = "UPDATE bms_payment.fuel_billing_recovery_level3 SET excess_status = $1 WHERE id = $2";

        return client.preparedQuery(sql)
                .execute(Tuple.of(status, id))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0);
    }

    @Override
    public Uni<Boolean> updateRefusedBillStatus(Long id, Integer status, String refuseReason, int type) {
        String sql = (Objects.equals(type, BillingType.TRUY_THU.getCode())) ?
                "UPDATE bms_payment.fuel_billing_recovery_level3" +
                " SET excess_status = $1, cause_reason_excess = $2 WHERE id = $3" :
                " UPDATE bms_payment.fuel_billing_recovery_level3" +
                " SET reduction_status = $1, cause_reason_reduction = $2 WHERE id = $3";

        return client.preparedQuery(sql)
                .execute(Tuple.of(status, refuseReason, id))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0);
    }

    @Override
    public Mono<Boolean> updateApprover(String approverId, List<String> synthesisPeriods, int type) {
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < synthesisPeriods.size(); i++) {
            placeholders.append("$").append(i + 2);
            if (i < synthesisPeriods.size() - 1) {
                placeholders.append(",");
            }
        }

        String sql = (Objects.equals(type, BillingType.TRUY_THU.getCode()))
                ? "UPDATE bms_payment.fuel_billing_recovery_level3 SET excess_approved = $1" +
                " WHERE excess_status IN (4,5,7) AND is_active = true AND synthesis_period IN (" + placeholders + ")"
                : "UPDATE bms_payment.fuel_billing_recovery_level3 SET reduction_approved = $1" +
                " WHERE reduction_status IN (4,5,7) AND is_active = true AND synthesis_period IN (" + placeholders + ")";

        List<Object> params = new ArrayList<>();
        params.add(approverId);
        params.addAll(synthesisPeriods);

        return client.preparedQuery(sql)
                .execute(Tuple.from(params))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0)
                .onFailure().recoverWithItem(false)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Boolean> updateNewApprover(String approverId) {
        String sql = "UPDATE bms_payment.fuel_billing_recovery_level3 " +
                    "SET " +
                    "excess_approved = CASE WHEN excess_approved IS NULL THEN $1 ELSE excess_approved END, " +
                    "reduction_approved = CASE WHEN reduction_approved IS NULL THEN $1 ELSE reduction_approved END " +
                    "WHERE (excess_status IN (4, 5, 7) OR reduction_status IN (4, 5, 7)) " +
                    "AND is_active = true";
        return client.preparedQuery(sql)
                .execute(Tuple.of(approverId))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0)
                .onFailure().recoverWithItem(false)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Mono<Void> updateFuelBillingRecoveryStatus(String synthesisPeriod, BillingStatus status,
            SqlConnection connection, String statusName) {
        return updateStatusForTable("bms_payment.fuel_billing_recovery", synthesisPeriod, status, connection, statusName)
                .then(updateStatusForTable("bms_payment.fuel_billing_recovery_level2", synthesisPeriod, status,
                        connection, statusName))
                .then(updateStatusForTable("bms_payment.fuel_billing_recovery_level3", synthesisPeriod, status,
                        connection, statusName))
                .doOnError(ex -> log.error("Error updating status for synthesisPeriod {}: {}",
                        synthesisPeriod, ex.getMessage()));
    }
    @Override
    public Mono<List<ApproverDTO>> getApprover(
            String maNhanVien, Connection connection, int page, int limit, String search, List<Long> userId, String unit) {

        int startRow = (page - 1) * limit + 1;
        int endRow = page * limit;
        List<Object> params = new ArrayList<>();

        StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM (")
                .append("    SELECT u.userid, u.manhanvien, u.telephone, u.fullname, ")
                .append("           ROW_NUMBER() OVER (ORDER BY u.manhanvien) AS rn ")
                .append("    FROM (")
                .append("        SELECT ma_buucuc, userid, manhanvien, telephone, ")
                .append("               firstname || ' ' || lastname AS fullname, ")
                .append("               ROW_NUMBER() OVER (PARTITION BY manhanvien ORDER BY manhanvien) AS row_num ")
                .append("        FROM Susers WHERE 1=1 ");

        if (maNhanVien != null && !maNhanVien.isEmpty()) {
            String[] maNhanVienArr = maNhanVien.split(",");
            sqlBuilder.append(" AND manhanvien IN (")
                    .append(String.join(", ", Collections.nCopies(maNhanVienArr.length, "?")))
                    .append(") ");
            Collections.addAll(params, (Object[]) maNhanVienArr);
        }

        if (search != null && !search.isEmpty()) {
            sqlBuilder.append(" AND (LOWER(fullname) LIKE ? OR u.telephone LIKE ?) ");
            String searchPattern = "%" + search.toLowerCase() + "%";
            params.add(searchPattern);
            params.add(searchPattern);
        }

        if (userId != null && !userId.isEmpty()) {
            sqlBuilder.append(" AND userid IN (")
                    .append(userId.stream().map(id -> "?").collect(Collectors.joining(", ")))
                    .append(") ");
            params.addAll(userId);
        }

        if (unit != null && !unit.isEmpty()) {
            sqlBuilder.append(" AND ma_buucuc = ? ");
            params.add(unit);
        }

        sqlBuilder.append("    ) u WHERE u.row_num = 1 ")
                .append(") sub WHERE sub.rn BETWEEN ? AND ? ");

        params.add(startRow);
        params.add(endRow);

        String sql = sqlBuilder.toString();
        log.info("Executing secure query: {}", sql);

        return Mono.defer(() -> {
            Statement statement = connection.createStatement(sql);

            for (int i = 0; i < params.size(); i++) {
                statement.bind(i, params.get(i));
            }

            return Mono.from(statement.execute())
                    .flatMapMany(result -> result.map((row, metadata) -> mapRowToApproverDTO(row)))
                    .collectList();
        });
    }

    @Override
    public Mono<ApproverDTO> getApproverByUserId(String maNhanVien, Connection connection) {
        String sql =
                "SELECT distinct manhanvien, telephone, concat(firstname,concat(' ',lastname)) as fullname "
                        +
                        "FROM VTP.SUSERS " +
                        "WHERE manhanvien = :maNhanVien";

        log.info("Executing query: {} with parameters: userId = {}", sql, maNhanVien);

        return Mono.from(connection
                        .createStatement(sql)
                        .bind("maNhanVien", Parameters.in(R2dbcType.VARCHAR, maNhanVien))
                        .execute())
                .flatMapMany(result -> result.map((row, metadata) -> mapRowToApprover(row)))
                .singleOrEmpty()
                .doOnSuccess(dto -> log.info("[DB] Successfully found approver by userId: {}",
                        maNhanVien))
                .doOnError(ex -> log.error("[DB] Error finding approver by userId: {}", maNhanVien,
                        ex));
    }

    @Override
    public Uni<List<FuelBillingRecoveryLevel3DetailResponse.Result>> getExcessDetail(
            String receiptNumberLv3, String synthesisPeriod, String unit, String carLicensePlate, int pageNo, int pageSize) {
        StringBuilder sql = new StringBuilder("""
            SELECT d.*, cms.unit, f3.receipt_number_excess, f3.synthesis_period
            FROM bms_payment.fuel_billing_recovery_level3_detail d
            LEFT JOIN bms_payment.fuel_billing_recovery_level3 f3 ON d.receipt_id = f3.id AND f3.is_active = true
            LEFT JOIN bms_payment.car_management_setting cms ON d.car_id = cms.id AND cms.is_active = true
            WHERE 1 = 1
        """);

        List<Object> params = new ArrayList<>();

        if (receiptNumberLv3 != null) {
            sql.append(" AND LOWER(f3.receipt_number_excess) LIKE $1");
            params.add("%" + receiptNumberLv3.toLowerCase() + "%");
        }
        if (synthesisPeriod != null) {
            sql.append(" AND f3.synthesis_period = $").append(params.size() + 1);
            params.add(synthesisPeriod);
        }
        if (unit != null) {
            sql.append(" AND cms.unit = $").append(params.size() + 1);
            params.add(unit);
        }
        if (carLicensePlate != null) {
            sql.append(" AND d.car_license_plate = $").append(params.size() + 1);
            params.add(carLicensePlate);
        }
        sql.append(" LIMIT $").append(params.size()+1);
        params.add(pageSize);
        sql.append(" OFFSET $").append(params.size()+1);
        params.add((pageNo - 1) * pageSize);

        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<FuelBillingRecoveryLevel3DetailResponse.Result> responses = new ArrayList<>();
                    rows.forEach(row -> {
                        FuelBillingRecoveryLevel3DetailResponse.Result response = mapRowToLevel3DetailResponse(row);
                        responses.add(response);
                    });
                    return responses;
                });
    }

    @Override
    public Uni<Long> countExcessDetail(String receiptNumberLv3, String synthesisPeriod, String unit, String carLicensePlate) {
        StringBuilder sql = new StringBuilder("""
        SELECT COUNT(*)
        FROM bms_payment.fuel_billing_recovery_level3_detail d
        LEFT JOIN bms_payment.fuel_billing_recovery_level3 f3 ON d.receipt_id = f3.id AND f3.is_active = true
                    LEFT JOIN bms_payment.car_management_setting cms ON d.car_id = cms.id AND cms.is_active = true
        WHERE 1 = 1
    """);

        List<Object> params = new ArrayList<>();

        if (receiptNumberLv3 != null) {
            sql.append(" AND LOWER(f3.receipt_number_excess) LIKE $1");
            params.add("%" + receiptNumberLv3.toLowerCase() + "%");
        }
        if (synthesisPeriod != null) {
            sql.append(" AND f3.synthesis_period = $").append(params.size() + 1);
            params.add(synthesisPeriod);
        }
        if (unit != null) {
            sql.append(" AND cms.unit = $").append(params.size() + 1);
            params.add(unit);
        }
        if (carLicensePlate != null) {
            sql.append(" AND d.car_license_plate = $").append(params.size() + 1);
            params.add(carLicensePlate);
        }

        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rowSet -> rowSet.iterator().hasNext() ? rowSet.iterator().next().getLong(0) : 0L);
    }

    private FuelBillingRecoveryLevel3DetailResponse.Result mapRowToLevel3DetailResponse(Row row) {
        return FuelBillingRecoveryLevel3DetailResponse.Result.builder()
                .id(row.getLong("id"))
                .receiptId(row.getLong("receipt_id"))
                .userId(row.getLong("user_id"))
                .amount(row.getBigDecimal("amount"))
                .createdAt(row.getLocalDateTime("created_at"))
                .note(row.getString("note"))
                .carId(row.getLong("car_id"))
                .carLicensePlate(row.getString("car_license_plate"))
                .userCodeBp(row.getString("user_code_bp"))
                .status(row.getInteger("status"))
                .unit(row.getString("unit"))
                .receiptNumberLv3(row.getString("receipt_number_excess"))
                .synthesisPeriod(row.getString("synthesis_period"))
                .messSap(row.getString("mess_sap"))
                .build();
    }

    private ApproverDTO mapRowToApprover(io.r2dbc.spi.Row row) {
        return ApproverDTO.builder()
                .userId(null)
                .maNhanVien(row.get("manhanvien", String.class))
                .telephone(row.get("telephone", String.class))
                .fullName(row.get("fullname", String.class))
                .build();
    }

    @Override
    public Mono<Void> sendNotificationToApprover(ApproverDTO approver, String message,
            Connection connection) {
        String sql =
                "INSERT INTO VTP.SMS_MSG2SEND (SMS_MSG_ID, CONTENT, MOBIFONE, TYPE, STATUS, CREATEBY, CREATEDATE,SENDDATE, ISSMSVIETNAM) "
                        +
                        "VALUES (VTP.SMS_MSG_ID_SEQ.NEXTVAL, :content, :mobifone, :type, :status, :createBy, SYSDATE, SYSDATE, :isSmsVietnam)";

        log.info("Executing query: {}. Inserting SMS notification for approver: {}", sql,
                approver.getMaNhanVien());

        return Mono.from(connection
                        .createStatement(sql)
                        .bind("content", Parameters.in(R2dbcType.NVARCHAR, message))
                        .bind("mobifone", Parameters.in(R2dbcType.VARCHAR, approver.getTelephone()))
                        .bind("type", Parameters.in(R2dbcType.VARCHAR, "DL2"))
                        .bind("status", Parameters.in(R2dbcType.NUMERIC, 0))
                        .bind("createBy", Parameters.in(R2dbcType.NUMERIC, 312))
                        .bind("isSmsVietnam", Parameters.in(R2dbcType.NUMERIC, 0))
                        .execute())
                .then()
                .doOnSuccess(v -> log.info("[DB] Successfully sent notification to approver: {}",
                        approver.getMaNhanVien()))
                .doOnError(ex -> log.error("[DB] Error sending notification to approver: {}",
                        approver.getMaNhanVien(), ex));
    }

    @Override
    public Mono<FuelBillingRecoveryLevel3DTO> findFuelBillingRecoveryLevel3BySynthesisPeriod(
            String synthesisPeriod, SqlConnection connection) {
        String query = "SELECT * FROM bms_payment.fuel_billing_recovery_level3 WHERE synthesis_period = $1 and is_active = true";

        return connection.preparedQuery(query)
                .execute(Tuple.of(synthesisPeriod))
                .convert().with(UniReactorConverters.toMono())
                .flatMap(rowSet -> {
                    if (!rowSet.iterator().hasNext()) {
                        return Mono.empty();
                    }
                    Row row = rowSet.iterator().next();
                    FuelBillingRecoveryLevel3DTO level3DTO = mapRowToFuelBillingRecoveryLevel3DTO(
                            row);
                    return Mono.just(level3DTO);
                })
                .doOnSuccess(dto -> log.info(
                        "[DB] Successfully found fuel billing recovery level3 by synthesisPeriod: {}",
                        synthesisPeriod))
                .doOnError(ex -> log.error(
                        "[DB] Error finding fuel billing recovery level3 by synthesisPeriod: {}",
                        synthesisPeriod, ex));
    }

    private Mono<Void> updateStatusForTable(String tableName, String synthesisPeriod,
            BillingStatus status, SqlConnection connection, String statusName) {
        String query = "UPDATE " + tableName + " SET " + statusName + " = $1 WHERE synthesis_period = $2";

        return connection.preparedQuery(query)
                .execute(Tuple.of(status.getCode(), synthesisPeriod))
                .convert().with(UniReactorConverters.toMono())
                .doOnNext(
                        rows -> log.info("Updated status to {} for synthesisPeriod {} in table {}",
                                status, synthesisPeriod, tableName))
                .doOnError(ex -> log.error(
                        "Error updating status for synthesisPeriod {} in table {}: {}",
                        synthesisPeriod, tableName, ex.getMessage()))
                .then();
    }

    private BillingRecoveryResponse mapRowToBillingRecoveryResponse(Row row, int type) {
        return BillingRecoveryResponse.builder()
                .id(row.getLong("id"))
                .receiptNumber(
                        ((Objects.equals(type, BillingType.TRUY_THU.getCode())) ||
                        (Objects.equals(type, BillingType.DUYET_TRUY_THU.getCode()))) ?
                            row.getString("receipt_number_excess") :
                            row.getString("receipt_number_reduction")
                )
                .synthesisPeriod(row.getString("synthesis_period"))
                .budgetExcess(row.getBigDecimal("total_budget_excess")
                        .setScale(0, RoundingMode.HALF_UP))
                .budgetReduction(row.getBigDecimal("budget_reduction")
                        .setScale(0, RoundingMode.HALF_UP))
                .approved(
                        ((Objects.equals(type, BillingType.TRUY_THU.getCode())) ||
                        (Objects.equals(type, BillingType.DUYET_TRUY_THU.getCode())))  ?
                                row.getString("excess_approved") :
                                row.getString("reduction_approved")
                )
                .status(
                        ((Objects.equals(type, BillingType.TRUY_THU.getCode())) ||
                        (Objects.equals(type, BillingType.DUYET_TRUY_THU.getCode())))  ?
                                row.getInteger("excess_status") :
                                row.getInteger("reduction_status")
                )
                .causeReason(
                        ((Objects.equals(type, BillingType.TRUY_THU.getCode())) ||
                        (Objects.equals(type, BillingType.DUYET_TRUY_THU.getCode()))) ?
                                row.getString("cause_reason_excess") :
                                row.getString("cause_reason_reduction")
                )
                .build();
    }

    private ApproverDTO mapRowToApproverDTO(io.r2dbc.spi.Row row) {
        return ApproverDTO.builder()
                .userId(row.get("userid", Long.class))
                .maNhanVien(row.get("manhanvien", String.class))
                .telephone(row.get("telephone", String.class))
                .fullName(row.get("fullname", String.class))
                .build();
    }

    private FuelBillingRecoveryLevel3DTO mapRowToFuelBillingRecoveryLevel3DTO(Row row) {
        return FuelBillingRecoveryLevel3DTO.builder()
                .id(row.getLong("id"))
                .reductionNumber(row.getString("receipt_number_reduction"))
                .excessNumber(row.getString("receipt_number_excess"))
                .synthesisPeriod(row.getString("synthesis_period"))
                .totalExcessAmount(row.getBigDecimal("total_excess_amount"))
                .totalExcessBudget(row.getBigDecimal("total_budget_excess"))
                .budgetReduction(row.getBigDecimal("budget_reduction"))
                .approved(row.getString("reduction_approved"))
                .reductionStatus(row.getInteger("reduction_status"))
                .createdAt(row.getLocalDateTime("created_at"))
                .approvedAt(row.getLocalDateTime("approved_at"))
                .excessStatus(row.getInteger("excess_status"))
                .excessApproved(row.getString("excess_approved"))
                .build();
    }
}
