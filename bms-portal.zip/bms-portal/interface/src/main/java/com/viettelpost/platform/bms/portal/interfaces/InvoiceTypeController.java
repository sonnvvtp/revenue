package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.service.handler.InvoiceTypeService;
import com.viettelpost.platform.model.request.Invoice.InvoiceTypeReq;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/accounting-cf")
@Tag(name = "API config accounting SAP Common")
@RequiredArgsConstructor
@ApplicationScoped
public class InvoiceTypeController {
    private final InvoiceTypeService invoiceTypeService;

    @Inject
    AuthenticationContext authCtx;

    /**
     * CONFIG
     * */

    @POST
    @Path("/create-invoice-type")
    @Operation(summary = "Thêm mới cấu hình mã loại hóa đơn")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> createInvoiceTypeConfig(@RequestBody @Valid InvoiceTypeReq req) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceTypeService.createInvoiceType(req, infoUser);
    }

    @GET
    @Path("/list-invoice-type")
    @Operation(summary = "Danh sách cấu hình hình mã loại hóa đơn")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> getListInvoiceType(@QueryParam("companyCod") String companyCod, @QueryParam("typeCode") String typeCode) {
        return invoiceTypeService.getInvoiceType(companyCod, typeCode);
    }

    @POST
    @Path("/update-invoice-type-config")
    @Operation(summary = "Thêm mới cấu hình mã loại hóa đơn")
    @APIResponse(responseCode = "200", description = "OK")
    public Uni<Response> updateInvoiceTypeConfig(@RequestBody @Valid InvoiceTypeReq req) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invoiceTypeService.updateInvoiceType(req, infoUser);
    }
}
