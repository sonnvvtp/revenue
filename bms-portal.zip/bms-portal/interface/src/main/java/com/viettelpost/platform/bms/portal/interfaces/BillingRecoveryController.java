package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.portal.model.response.FuelBillingRecoveryLevel3DetailResponse;
import com.viettelpost.platform.bms.portal.model.request.FuelBillingRecoveryLevel3DetailRequest;
import com.viettelpost.platform.bms.portal.model.request.FuelBillingRecoveryLevel3RefuseRequest;
import com.viettelpost.platform.bms.portal.model.response.BillingRecoveryResponse;
import com.viettelpost.platform.bms.portal.model.response.sap.BudgetCancellationResponse;
import com.viettelpost.platform.bms.portal.model.response.sap.DetailsBudgetDocumentResponse;
import com.viettelpost.platform.bms.portal.service.handler.BillingRecoveryService;
import com.viettelpost.platform.bms.portal.service.handler.FuelBillingRecoveryService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/billing-recovery")
@Tag(name = "Billing Recovery")
@RequiredArgsConstructor
public class BillingRecoveryController {

    private final BillingRecoveryService billingRecoveryService;

    private final FuelBillingRecoveryService fuelBillingRecoveryService;

    @GET
    @Operation(summary = "Search Bill")
    @APIResponse(responseCode = "200", description = "Returns a list of nationwide bill")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Map<String, Object>> searchBills(
            @QueryParam("receiptNumber") String receiptNumber,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("status") String status,
            @QueryParam("pageNo") @DefaultValue("1") int pageNo,
            @QueryParam("pageSize") @DefaultValue("10") int pageSize,
            @QueryParam("type") int type) {
        return billingRecoveryService.searchBills(receiptNumber, synthesisPeriod, status, pageNo,
                pageSize, type);
    }

    @GET
    @Operation(summary = "Bill Detail")
    @Path("/{id}")
    @APIResponse(responseCode = "200", description = "Returns nationwide bill detail")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<BillingRecoveryResponse> getBillingDetail(
            @PathParam("id") Long id) {
        return billingRecoveryService.getBillDetail(id);
    }

    @GET
    @Path("/export-to-excel")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON})
    @Operation(summary = "Export Fuel Billing Recovery Lv3 to Excel")
    @APIResponse(responseCode = "200", description = "Returns an Excel file containing Fuel Billing Recovery Lv3")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> exportToExcel(
            @QueryParam("receiptNumber") String receiptNumber,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("status") String status,
            @QueryParam("type") int type
    ) {
        return billingRecoveryService.exportToExcel(receiptNumber, synthesisPeriod, status, type)
                .onItem().transform(excelData -> {
                    String fileName = billingRecoveryService.generateFileName(
                            "Fuel_Billing_Recovery_Lv3.xlsx");
                    return Response.ok(new ByteArrayInputStream(excelData))
                            .header("Content-Disposition",
                                    "attachment; filename=\"" + fileName + "\"")
                            .build();
                })
                .onFailure().recoverWithItem(throwable ->
                        Response.serverError().entity("Failed to generate Excel file").build()
                );
    }

    @POST
    @Path("/{id}/approve")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Approve Bill")
    @APIResponse(responseCode = "200", description = "Approved Bill")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> approveBill(
            @PathParam("id") Long id,
            List<FuelBillingRecoveryLevel3DetailRequest> request) {
        return billingRecoveryService.approveBill(id, request);
    }

    @POST
    @Path("/{id}/refuse")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Refuse Bill")
    @APIResponse(responseCode = "200", description = "Refused Bill")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> refuseBill(
            @PathParam("id") Long id,
            FuelBillingRecoveryLevel3RefuseRequest request) {
        return billingRecoveryService.refuseBill(id, request);
    }

    @POST
    @Operation(summary = "Resubmit For Approval")
    @Path("/resubmit-approval")
    @APIResponse(responseCode = "200", description = "No return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Void> resubmitForApproval(
            @QueryParam("synthesisPeriod") String synthesisPeriod, @QueryParam("type") Integer type) {
        return ReactiveConverter.toUni(billingRecoveryService.resubmitForApproval(synthesisPeriod, type));
    }

    @GET
    @Path("/export-to-pdf")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response billingRecoveryPdf(
            @QueryParam("receiptNumber") String receiptNumber,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("status") String status,
            @QueryParam("type") int type
    ) {
        try {
            byte[] pdfData = billingRecoveryService.billingRecoveryToPDF(receiptNumber,
                    synthesisPeriod, status, type);
            return Response.ok(pdfData)
                    .header("Content-Disposition",
                            "attachment; filename=\"billing_recovery_report.pdf\"")
                    .build();
        } catch (Exception e) {
            log.error("Failed to generate PDF", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to generate PDF: " + e.getMessage())
                    .build();
        }
    }

    @GET
    @Path("/accounting")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getSuccessMessage() {
        String message = "success";
        return Response.ok(message).build();
    }

    @PUT
    @Path("/reduction")
    public Uni<DetailsBudgetDocumentResponse> budgetReduction(
            @QueryParam("synthesisPeriod") String synthesisPeriod) {
        return ReactiveConverter.toUni(
                fuelBillingRecoveryService.budgetReduction(synthesisPeriod)
        );
    }

    @POST
    @Path("/budget-reduction-retrieve")
    public Uni<BudgetCancellationResponse> budgetReductionRetrieve(
            @QueryParam("synthesisPeriod") String synthesisPeriod) {
        return ReactiveConverter.toUni(
                fuelBillingRecoveryService.budgetReductionRetrieve(synthesisPeriod)
        );
    }

    @GET
    @Path("/excess-detail")
    public Uni<FuelBillingRecoveryLevel3DetailResponse> excessBudgetDetail(
            @QueryParam("receiptNumberLv3") String receiptNumberLv3,
            @QueryParam("synthesisPeriod") String synthesisPeriod,
            @QueryParam("unit") String unit,
            @QueryParam("carLicensePlate") String carLicensePlate,
            @QueryParam("pageNo") @DefaultValue("1") int pageNo,
            @QueryParam("pageSize") @DefaultValue("10") int pageSize
    ) {
        return billingRecoveryService.getExcessDetail(
                receiptNumberLv3, synthesisPeriod, unit, carLicensePlate, pageNo, pageSize);
    }
}
