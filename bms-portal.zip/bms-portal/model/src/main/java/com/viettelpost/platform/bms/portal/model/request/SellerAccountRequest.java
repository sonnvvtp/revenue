package com.viettelpost.platform.bms.portal.model.request;

import lombok.Data;

@Data
public class SellerAccountRequest {
    private String username;
    private String password;
}
