package com.viettelpost.platform.bms.portal.model.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddPaymentPeriodCusRequest {
    @JsonAlias({"cus_id","CUS_ID"})
    private Long cusId;

    @JsonAlias({"full_name","DISPLAYNAME"})
    private String fullName;

    @JsonAlias({"phone","PHONE"})
    private String phone;

    @JsonAlias({"email","EMAIL"})
    private String email;

    @JsonAlias({"payment_period","PAYMENT_PERIOD"})
    private String paymentPeriod;


    @JsonAlias("created_by")
    private Long userId;

    @JsonAlias("TYPE_CONFIG")
    private Integer typeConfig;

    private String reason;
}
