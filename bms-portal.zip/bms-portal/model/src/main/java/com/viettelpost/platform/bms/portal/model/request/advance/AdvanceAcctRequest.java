package com.viettelpost.platform.bms.portal.model.request.advance;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class AdvanceAcctRequest {

    private String advancedFilter;

    private Integer status;

    @NotNull(message = "Vui lòng cung cấp loại bảng kê")
    private Integer docType;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate fromDate;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate toDate;

    private Integer page;

    private Integer size;
}
