package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.portal.model.dto.PostCodeDTO;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;

public interface FicoPostCodeRepository {

    Uni<PostCodeDTO> getPostCodeFromCode(String postcodes, Connection connection);
}
