package com.viettelpost.platform.bms.portal.model.response.epacket;
import lombok.*;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class EpacketExportListResponse {
    private List<ITEMS> items;
    private String fromDate;
    private String toDate;
    private Long cusId;
    private Long startingBalance;
    private Long endingBalance;

    @Data
    @Accessors(chain = true)
    public static class ITEMS {
        private String statusText;
        private String transactionCode;
        private Integer transactionType;
        private String reqPaymentCode;
        private Integer walletType;
        private String transactionCodeGori;
        private Long cusId;
        private String cusName;
        private String email;
        private String phone;
        private BigDecimal amount;
        private Integer reconStatus;
        private Integer accountingStatus;
        private String createDate;
        private String updateDate;
    }
}
