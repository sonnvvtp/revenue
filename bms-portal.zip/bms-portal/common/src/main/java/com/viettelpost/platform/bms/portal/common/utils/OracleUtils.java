package com.viettelpost.platform.bms.portal.common.utils;

import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.spi.Connection;
import reactor.core.publisher.Mono;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class OracleUtils {

    public static String genConditionInBigSize(Integer size) {
        return IntStream.range(0, size)
                .mapToObj(i -> "(?, 0)")
                .collect(Collectors.joining(", "));
    }

    public static <R> Mono<R> withTransaction(ConnectionPool oracleClient, Function<Connection, Mono<R>> function) {
        // Note: Action connection.setAutoCommit(true) to prevent ORA-01453 when using R2dbc transactional and non-transactional on a database connection pool
        // See https://github.com/spring-projects/spring-framework/issues/31268 for more information
        return Mono.usingWhen(
                oracleClient.create(),
                connection -> Mono.from(connection.beginTransaction())
                        .then(Mono.defer(() -> function.apply(connection))),
                // Complete signal
                connection -> Mono.from(connection.commitTransaction())
                        // Prevent error: ORA-01453
                        .then(Mono.defer(() -> Mono.from(connection.setAutoCommit(true))))
                        .then(Mono.defer(() -> Mono.from(connection.close()))),
                // Failure signal
                (connection, throwable) -> Mono.from(connection.rollbackTransaction())
                        // Prevent error: ORA-01453
                        .then(Mono.defer(() -> Mono.from(connection.setAutoCommit(true))))
                        .then(Mono.defer(() -> Mono.from(connection.close()))),
                // Cancel signal
                connection -> Mono.from(connection.rollbackTransaction())
                        // Prevent error: ORA-01453
                        .then(Mono.defer(() -> Mono.from(connection.setAutoCommit(true))))
                        .then(Mono.defer(() -> Mono.from(connection.close())))
        );
    }
}