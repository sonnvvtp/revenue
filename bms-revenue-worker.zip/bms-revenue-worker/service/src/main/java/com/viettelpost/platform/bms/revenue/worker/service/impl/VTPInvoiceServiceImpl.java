package com.viettelpost.platform.bms.revenue.worker.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.viettelpost.platform.bms.revenue.worker.common.enums.InvoiceOrderStatus;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupCustomeCodeDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.GroupRevenueInvoiceDTO;
import com.viettelpost.platform.bms.revenue.worker.model.dto.InvoiceRecordDto;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceDoctypeEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceRecordEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceRecordLineEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceSymbolEntity;
import com.viettelpost.platform.bms.revenue.worker.model.dto.entity.eInvoice.InvoiceTypeEntity;
import com.viettelpost.platform.bms.revenue.worker.repository.CalculationRevenueRepository;
import com.viettelpost.platform.bms.revenue.worker.repository.VtpInvoiceRepository;
import com.viettelpost.platform.bms.revenue.worker.service.VTPInvoiceService;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class VTPInvoiceServiceImpl implements VTPInvoiceService {

    private final CalculationRevenueRepository calculationRevenueRepository;

    private final PgPool pool;

    private final VtpInvoiceRepository vtpInvoiceRepository;

    @ConfigProperty(name = "config.batch.create", defaultValue = "100")
    Integer maxChunkSize;

    @ConfigProperty(name = "config.revenue.domain.type", defaultValue = "REVENUE_VTP")
    String revenueDomainType;

    @ConfigProperty(name = "config.concurrency.process.create.invoice", defaultValue = "5")
    Integer concurrencyProcess;

    @ConfigProperty(name = "config.batch.handle.size", defaultValue = "100")
    Integer batchBillHandleSize;

    @ConfigProperty(name = "config.revenue.company", defaultValue = "1000")
    String configRevenueCompany;

    @ConfigProperty(name = "config.revenue.doctype.id", defaultValue = "9")
    Long configDoctypeId;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMM");

    private final ObjectMapper objectMapper;

    @Override
    public Uni<Void> processInvoiceRecordEveryMonth() {
        long currentTime = System.currentTimeMillis();
        // Lấy ngày hiện tại
        LocalDate today = LocalDate.now().minusMonths(2);

        // Lấy ngày bắt đầu của tháng hiện tại (ngày 1)
        LocalDate startOfMonth = today.with(TemporalAdjusters.firstDayOfMonth());

        // Lấy ngày kết thúc của tháng hiện tại
        LocalDate endOfMonth = today.with(TemporalAdjusters.lastDayOfMonth());

        AtomicReference<BigDecimal> periodIdFinal = new AtomicReference<>();

        Uni<BigDecimal> periodUni = calculationRevenueRepository.findPeriodIdBy(startOfMonth);

        return periodUni
            .flatMap(periodId -> {
              Uni<Integer> countUni = vtpInvoiceRepository.findCustomerCodeToInvoiceCount(periodId, revenueDomainType);
              return countUni
                  .flatMap(totalItems -> {
                    log.info("findCustomerCodeToInvoice_size: {}, periodId: {}",  totalItems, periodId);
                    int maxPage = (int) Math.ceil((double) totalItems / batchBillHandleSize);
                    List<Multi<GroupCustomeCodeDTO>> multiList = new ArrayList<>();

                    for (int i = 0; i < maxPage; i++) {
                      multiList.add(vtpInvoiceRepository.findCustomerCodeToInvoice(periodId, revenueDomainType, i, batchBillHandleSize));
                    }

                    Uni<Void> uniChainProcess = Uni.createFrom().voidItem();

                    for (Multi<GroupCustomeCodeDTO> multi : multiList) {
                      uniChainProcess = uniChainProcess.chain(() ->
                              multi.collect().asList()
                                  .flatMap(listCustomerCode -> pushBatchCustomerCode(listCustomerCode, periodId)))
                          .onFailure()
                          .recoverWithUni((throwable) -> {
                            log.error("saveBatch_fail: {}", throwable.getMessage(), throwable);
                            return Uni.createFrom().voidItem();
                          });
                    }
                    return uniChainProcess;
                  })
                  .onFailure()
                  .recoverWithUni(throwable -> {
                    log.info("findCustomerCodeToInvoice_executed_successfully: {} ms", System.currentTimeMillis() - currentTime);
                    return Uni.createFrom().voidItem();
                  });
            });

    }

    private Uni<Void> pushBatchCustomerCode(List<GroupCustomeCodeDTO> customeCodeDTOList, BigDecimal periodId) {

      log.info("customeCodeDTOList_size: {}", customeCodeDTOList.size());
      if(CollectionUtils.isEmpty(customeCodeDTOList)) {
        return Uni.createFrom().voidItem();
      }

      int size = customeCodeDTOList.size();
      int numChunks = (size + maxChunkSize - 1) / maxChunkSize; // Tính số chunk (làm tròn lên)

      List<List<GroupCustomeCodeDTO>> chunks = IntStream.range(0, numChunks)
          .mapToObj(i -> customeCodeDTOList.subList(i * maxChunkSize, Math.min((i + 1) * maxChunkSize, size)))
          .toList();

      List<Uni<Boolean>> uniList = new ArrayList<>();
      for (List<GroupCustomeCodeDTO> chunk : chunks) {
        uniList.add(processCreateVtpInvoiceRecord(periodId, chunk));
      }
      return Uni.join().all(uniList).usingConcurrencyOf(concurrencyProcess).andCollectFailures()
          .onFailure()
          .recoverWithItem(throwable -> {
            log.error("pushBatchCustomeCode_error_pre: {}", throwable.getMessage(), throwable);
            return new ArrayList<>();
          })
          .replaceWithVoid();
  }

  private Uni<Boolean> processCreateVtpInvoiceRecord(BigDecimal periodId, List<GroupCustomeCodeDTO> customeCodeDTOList) {
    long currentTime = System.currentTimeMillis();
    Uni<InvoiceDoctypeEntity> doctypeEntityUni = vtpInvoiceRepository.finErpDoctypeBy(configDoctypeId, null);
    Uni<InvoiceTypeEntity> invoiceTypeEntityUni = vtpInvoiceRepository.findInvoiceTypeBy(configRevenueCompany, null);
    Uni<InvoiceSymbolEntity> invoiceSymbolEntityUni = vtpInvoiceRepository.findInvoiceSymbolBy(configRevenueCompany, null);
    Multi<GroupRevenueInvoiceDTO> groupByRevenueInvoiceMulti = vtpInvoiceRepository.findGroupByRevenueRecord(revenueDomainType, periodId, customeCodeDTOList);

    return Uni.combine().all().unis(doctypeEntityUni, invoiceTypeEntityUni, invoiceSymbolEntityUni, groupByRevenueInvoiceMulti.collect().asList())
        .withUni((doctype, invoiceType, invoiceSymbol, groupByRevenueRecords) -> {
          return pool.withTransaction(sqlConnection -> {
            log.info("groupByRevenueRecords_size: {}, periodId: {}", groupByRevenueRecords, periodId);
            List<InvoiceRecordEntity> originEntities = toInvoiceRecordEntities(periodId, groupByRevenueRecords, doctype, invoiceType, invoiceSymbol);
                return vtpInvoiceRepository.saveBatchInvoiceRecord(originEntities, sqlConnection)
                    .collect().asList()
                    .flatMap(destEntities -> {
                      log.info("saveBatchInvoiceRecord_success_size: {}, periodId: {}", destEntities.size(), periodId);
                      return vtpInvoiceRepository.saveBatchInvoiceRecordLine(toInvoiceRecordLineEntities(originEntities, destEntities), sqlConnection)
                          .collect().asList()
                          .flatMap(recordLineEntityList -> {
                            log.info("saveBatchInvoiceRecordLine_success_size: {}, periodId: {}", recordLineEntityList.size(), periodId);
                            List<BigDecimal> ids = recordLineEntityList.stream()
                                .map(InvoiceRecordLineEntity::getOrderId)
                                .collect(Collectors.toList());
                            return vtpInvoiceRepository.updateInvoiceStatusBy(revenueDomainType, ids, InvoiceOrderStatus.DA_GOM_BANG_KE.getCode(), sqlConnection)
                                .flatMap(unused -> {
                                      log.info("updateInvoiceStatusBy_success_size: {}, periodId: {}", ids.size(), periodId);
                                      return Uni.createFrom().voidItem();
                                })
                                .onFailure()
                                .invoke(throwable -> {
                                  log.error("updateInvoiceStatusBy_fail: {}", throwable.getMessage(), throwable);
                                });
                          })
                          .onFailure()
                          .invoke(throwable -> {
                            log.error("saveBatchInvoiceRecordLine_fail: {}", throwable.getMessage(), throwable);
                          });
                    })
                    .onFailure()
                    .invoke(throwable -> {
                      log.error("saveBatchRevenueStatement_fail: {}", throwable.getMessage(),
                          throwable);
                    });
              }
          );
        }).map(rs -> true);
  }

  private List<InvoiceRecordEntity> toInvoiceRecordEntities(BigDecimal invoiceRecordId, List<GroupRevenueInvoiceDTO> groupRevenueRecordList,
      InvoiceDoctypeEntity invoiceDoctypeEntity, InvoiceTypeEntity invoiceTypeEntity, InvoiceSymbolEntity invoiceSymbolEntity) {
    if (CollectionUtils.isEmpty(groupRevenueRecordList)) {
        return new ArrayList<>();
    }

    String paymentMethod = "TM/CK";

    List<InvoiceRecordEntity> entities = new ArrayList<>();
    for (GroupRevenueInvoiceDTO revenueRecord : groupRevenueRecordList) {
      List<InvoiceRecordDto> records = new ArrayList<>();
      if (Objects.nonNull(revenueRecord.getRecords())) {
        if (revenueRecord.getRecords().isArray()) {
          records = objectMapper.convertValue(
              revenueRecord.getRecords(),
              objectMapper.getTypeFactory().constructCollectionType(List.class, InvoiceRecordDto.class)
          );
        }
      }

      entities.add(
          InvoiceRecordEntity.builder()
              .tenantId(1)
              .createdBy(-1L)
              .recordStatus(1)
              .recordNo(String.format("XHĐTD-%s-%s", LocalDate.now().format(formatter), revenueRecord.getBuyerCode()))
              .unitLevel1Id(String.valueOf(revenueRecord.getUnitLevel1Id()))
              .unitLevel2Id(String.valueOf(revenueRecord.getUnitLevel2Id()))
              .buyerId(null)
              .buyerCode(revenueRecord.getBuyerCode())
              .accountingDate(LocalDateTime.now())
              .invoiceSerial(Objects.nonNull(invoiceSymbolEntity) ? invoiceSymbolEntity.getSymbolCode() : "")
              .invoiceForm(Objects.nonNull(invoiceTypeEntity) ? invoiceTypeEntity.getTemplateCode() : "")
              .accountantId(null)
              .paymentMethod(paymentMethod)
              .taxPercent(null)
              .email(CollectionUtils.isNotEmpty(records) ? records.getFirst().getBuyerEmail() : "")
              .phone(CollectionUtils.isNotEmpty(records) ? records.getFirst().getBuyerPhone() : "")
              .taxCode(CollectionUtils.isNotEmpty(records) ? records.getFirst().getBuyerTaxCode() : "")
              .accountNo("")
              .customerName(CollectionUtils.isNotEmpty(records) ? records.getFirst().getBuyerName()  : "Người mua không lấy hóa đơn")
              .address(CollectionUtils.isNotEmpty(records) ? records.getFirst().getBuyerAddress() : "")
              .recordTypeId(Objects.nonNull(invoiceDoctypeEntity) ? invoiceDoctypeEntity.getId() : null)
              .amountBeforeTax(revenueRecord.getAmountBeforeTax())
              .amountTax(revenueRecord.getTaxAmount())
              .amountTotal(revenueRecord.getAmountAfterTax())
              .companyCode(configRevenueCompany)
              .recordType(1) // tao thu cong
              .recordSource(revenueDomainType)
              .unitName("")
//              .fromDate(Objects.nonNull(request.getFromDate()) ? LocalDateTime.of(request.getFromDate(), LocalTime.MIN) : null)
//              .toDate(Objects.nonNull(request.getToDate()) ? LocalDateTime.of(request.getToDate(), LocalTime.MAX) : null)
              .fromDate(LocalDateTime.now())
              .toDate(LocalDateTime.now())
              .records(records)
              .build()
      );
    }
    return entities;
  }

  private List<InvoiceRecordLineEntity> toInvoiceRecordLineEntities(List<InvoiceRecordEntity> statementOrginList, List<InvoiceRecordEntity> statementSavedList) {

    if (CollectionUtils.isEmpty(statementSavedList)) {
      return new ArrayList<>();
    }
    List<InvoiceRecordLineEntity> entities = new ArrayList<>();
    for (InvoiceRecordEntity statementSaved : statementSavedList) {

      // Find the matching GeneralOrderEntity
      statementOrginList.stream()
          .filter(order ->
              statementSaved.getRecordNo() != null &&
                  statementSaved.getRecordNo().equals(order.getRecordNo()) &&
                  statementSaved.getBuyerCode() != null &&
                  statementSaved.getBuyerCode().equals(order.getBuyerCode()))
          .findFirst().ifPresent(matchingOrder -> {
            if (!CollectionUtils.isEmpty(matchingOrder.getRecords())) {
              for (InvoiceRecordDto record : matchingOrder.getRecords()) {
                entities.add(InvoiceRecordLineEntity.builder()
                    .tenantId(1)
                    .createdBy(-1L)
                    .recordId(statementSaved.getId())
                    .orderId(record.getId())
                    .orderCode(record.getCode())
                    .amount(record.getAmount())
                    .build());
              }
            }
          });
    }
    return entities;
  }
}
