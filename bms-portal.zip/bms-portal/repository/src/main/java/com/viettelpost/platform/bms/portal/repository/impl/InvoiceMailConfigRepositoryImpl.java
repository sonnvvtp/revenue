package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.dto.InvoiceMailConfigDTO;
import com.viettelpost.platform.bms.portal.repository.InvoiceMailConfigRepository;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@ApplicationScoped
public class InvoiceMailConfigRepositoryImpl implements InvoiceMailConfigRepository {
    @Inject
    PgPool client;

    @Override
    public Flux<InvoiceMailConfigDTO> listAll() {
        String sql = "SELECT * FROM bms_payment.invoice_mail_config ORDER BY id DESC";
        return Flux.create(sink -> {
            client.query(sql)
                    .execute()
                    .subscribe().with(rows -> {
                        for (Row row : rows) {
                            sink.next(mapRowToDTO(row));
                        }
                        sink.complete();
                    }, sink::error);
        });
    }

    @Override
    public Mono<InvoiceMailConfigDTO> insert(CustomUser user, InvoiceMailConfigDTO dto) {
        if (Boolean.FALSE.equals(dto.getIsActive())) {
            return Mono.error(new RuntimeException("Cấu hình mail phải có trạng thái active"));
        }

        String checkSql = "SELECT 1 FROM bms_payment.invoice_mail_config WHERE company_code = $1 and is_active=true LIMIT 1";
        Tuple checkParams = Tuple.tuple()
                .addValue(dto.getCompanyCode());
        return Mono.fromCompletionStage(
                client.preparedQuery(checkSql)
                        .execute(checkParams)
                        .subscribeAsCompletionStage()
        ).flatMap(rows -> {
            if (rows.iterator().hasNext()) {
                return Mono.error(new RuntimeException("Cấu hình mail đã được khai báo cho mã công ty này"));
            }
            
            String sql = "INSERT INTO bms_payment.invoice_mail_config " +
                    "(send_name, content, is_active, company_code, created_by, update_by, title, start_date) " +
                    "VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP) RETURNING *";
            Tuple params = Tuple.tuple()
                    .addValue(dto.getSendName())
                    .addValue(dto.getContent())
                    .addValue(dto.getIsActive())
                    .addValue(dto.getCompanyCode())
                    .addValue(user.getName())
                    .addValue(user.getName())
                    .addValue(dto.getTitle());
            return Mono.fromCompletionStage(
                    client.preparedQuery(sql)
                            .execute(params)
                            .subscribeAsCompletionStage()
            ).map(insertRows -> {
                Row row = insertRows.iterator().hasNext() ? insertRows.iterator().next() : null;
                if (row == null) return null;
                return mapRowToDTO(row);
            });
        });
    }

    @Override
    public Mono<InvoiceMailConfigDTO> update(CustomUser user, InvoiceMailConfigDTO dto) {
        String getCurrentSql = "SELECT is_active FROM bms_payment.invoice_mail_config WHERE id = $1";
        Tuple getCurrentParams = Tuple.tuple().addValue(dto.getId());

        return Mono.fromCompletionStage(
                client.preparedQuery(getCurrentSql)
                        .execute(getCurrentParams)
                        .subscribeAsCompletionStage()
        ).flatMap(currentRows -> {
            if (!currentRows.iterator().hasNext()) {
                return Mono.error(new RuntimeException("Không tìm thấy cấu hình mail với ID đã cho"));
            }

            boolean currentIsActive = currentRows.iterator().next().getBoolean("is_active");
            boolean newIsActive = Boolean.TRUE.equals(dto.getIsActive());

            String checkSql = "SELECT 1 FROM bms_payment.invoice_mail_config " +
                              "WHERE company_code = $1 AND id <> $2 AND is_active = true LIMIT 1";
            Tuple checkParams = Tuple.tuple()
                    .addValue(dto.getCompanyCode())
                    .addValue(dto.getId());

            return Mono.fromCompletionStage(
                    client.preparedQuery(checkSql)
                            .execute(checkParams)
                            .subscribeAsCompletionStage()
            ).flatMap(rows -> {
                if (rows.iterator().hasNext()) {
                    return Mono.error(new RuntimeException("Cấu hình mail đã được khai báo cho mã công ty này"));
                }

                StringBuilder sqlBuilder = new StringBuilder(
                        "UPDATE bms_payment.invoice_mail_config SET " +
                        "send_name=$1, content=$2, is_active=$3, company_code=$4, update_by=$5, update_at=now(), title=$6"
                );

                if (!currentIsActive && newIsActive) {
                    sqlBuilder.append(", start_date = now()");
                }

                sqlBuilder.append(" WHERE id=$7 RETURNING *");

                Tuple params = Tuple.tuple()
                        .addValue(dto.getSendName())
                        .addValue(dto.getContent())
                        .addValue(dto.getIsActive())
                        .addValue(dto.getCompanyCode())
                        .addValue(user.getName())
                        .addValue(dto.getTitle())
                        .addValue(dto.getId());

                return Mono.fromCompletionStage(
                        client.preparedQuery(sqlBuilder.toString())
                                .execute(params)
                                .subscribeAsCompletionStage()
                ).map(updateRows -> {
                    Row row = updateRows.iterator().hasNext() ? updateRows.iterator().next() : null;
                    if (row == null) return null;
                    return mapRowToDTO(row);
                });
            });
        });
    }

    private InvoiceMailConfigDTO mapRowToDTO(Row row) {
        InvoiceMailConfigDTO dto = new InvoiceMailConfigDTO();
        dto.setId(row.getLong("id"));
        dto.setSendName(row.getString("send_name"));
        dto.setContent(row.getString("content"));
        dto.setIsActive(row.getBoolean("is_active"));
        dto.setCompanyCode(row.getString("company_code"));
        dto.setCreatedAt(row.getLocalDateTime("created_at"));
        dto.setCreatedBy(row.getString("created_by"));
        dto.setUpdateAt(row.getLocalDateTime("update_at"));
        dto.setUpdateBy(row.getString("update_by"));
        dto.setStartDate(row.getLocalDateTime("start_date"));
        dto.setTitle(row.getString("title"));
        return dto;
    }

    @Override
    public Mono<InvoiceMailConfigDTO> updateStartDate(CustomUser user, String companyCode, LocalDateTime startDate) {
        String sql = "UPDATE bms_payment.invoice_mail_config SET " +
                "start_date=$1, update_by=$2, update_at=now() " +
                "WHERE company_code=$3 RETURNING *";
        Tuple params = Tuple.tuple()
                .addValue(startDate)
                .addValue(user.getName())
                .addValue(companyCode);

        return Mono.fromCompletionStage(
                client.preparedQuery(sql)
                        .execute(params)
                        .subscribeAsCompletionStage()
        ).map(updateRows -> {
            Row row = updateRows.iterator().hasNext() ? updateRows.iterator().next() : null;
            if (row == null) return null;
            return mapRowToDTO(row);
        });
    }
}