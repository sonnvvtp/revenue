package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class ReportRevenueDTO {

    @JsonAlias("RN")
    private Long rn;

    @JsonAlias("PERIOD_NAME")
    private String periodName;

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("ORG_CODE")
    private String orgCode;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("POST_CODE")
    private String postCode;

    @JsonAlias("POST_NAME")
    private String postName;

    @JsonAlias("SERVICE_CODE")
    private String serviceCode;

    @JsonAlias("SERVICE_NAME")
    private String serviceName;

    @JsonAlias("CUSTOMER_CODE")
    private String customerCode;

    @JsonAlias("CUSTOMER_NAME")
    private String customerName;

    @JsonAlias("QUANTITY")
    private Long quantity;

    @JsonAlias("AMOUNT_BEFORE_TAX")
    private BigDecimal amountBeforeTax;     // Cước phí

    @JsonAlias("AMOUNT_TAX")
    private BigDecimal amountTax;  // vat

    @JsonAlias("AMOUNT_AFTER_TAX")
    private BigDecimal amountAfterTax;  // Tiền sau thuế

    @JsonAlias("AMOUNT_DEDUCT")
    private BigDecimal amountDeduct;  // Giảm giá

    @JsonAlias("AMOUNT_AFTER_DEDUCT")
    private BigDecimal amountAfterDeduct;  // Doanh thu sau giảm giá
}
