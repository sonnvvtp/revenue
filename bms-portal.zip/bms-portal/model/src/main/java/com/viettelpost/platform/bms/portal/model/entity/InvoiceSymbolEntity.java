package com.viettelpost.platform.bms.portal.model.entity;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceSymbolEntity {

  @JsonAlias("symbol_id")
  private BigDecimal id;

  @JsonAlias("symbol_code")
  private String symbolCode;

  @JsonAlias("invoice_type")
  private Integer invoiceType;

  @JsonAlias("current_number")
  private Integer currentNumber = 0;

  @JsonAlias("max_threshold")
  private Long maxThreshold = 1000000L;

  @JsonAlias("is_active")
  private Boolean isActive = true;

  @JsonAlias("company_code")
  private String companyCode;

  @JsonAlias("issue_date_type")
  private String issueDateType;

  @JsonAlias("created_at")
  private LocalDateTime createdAt = LocalDateTime.now();

  @JsonAlias("created_by")
  private String createdBy;

  @JsonAlias("update_at")
  private LocalDateTime updateAt = LocalDateTime.now();

  @JsonAlias("update_by")
  private String updateBy;

  @JsonAlias("tenant_id")
  private Integer tenantId = 1;
}
