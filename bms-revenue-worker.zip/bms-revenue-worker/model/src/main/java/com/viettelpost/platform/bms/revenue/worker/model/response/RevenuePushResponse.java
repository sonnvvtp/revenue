package com.viettelpost.platform.bms.revenue.worker.model.response;

import java.util.List;
import lombok.Data;

@Data
public class RevenuePushResponse {
    private Boolean error;
    private String errorCode;
    private String message;
    private Object data;
}
