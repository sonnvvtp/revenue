package com.viettelpost.platform.bms.revenue.worker.main.controller;

import com.viettelpost.platform.bms.revenue.worker.service.CalculationRevenueService;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/test")
@Tag(name = "API đẩy đơn xuất hóa đơn")
@RequiredArgsConstructor
public class TestRevenueController {

//    private final GloExpRevenueService gloExpRevenueService;
//    private final GloExpRevenuePGService gloExpRevenuePGService;
    private final CalculationRevenueService calculationRevenueService;

    @GET
    @Path("/push")
    @Operation(summary = "API tra cứu thông tin hoá đơn")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> queryInvoiceOrder() {
//        return gloExpRevenueService.pusAllBillToRevenue().map(unused ->  Response.ok().build());
//        return gloExpRevenuePGService.processRevenueEveryMonth().map(unused ->  Response.ok().build());
        return calculationRevenueService.calculationAllBillToRevenue().map(unused ->  Response.ok().build());
    }
}
