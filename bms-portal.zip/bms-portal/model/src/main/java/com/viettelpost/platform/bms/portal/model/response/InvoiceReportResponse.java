package com.viettelpost.platform.bms.portal.model.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.sql.Timestamp;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class InvoiceReportResponse {
    private List<InvoiceReportItem> data;
    private long totalRecords;
    private int totalPage;
    private int currentPage;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class InvoiceReportItem {
        @JsonInclude
        private Long stt;
        private String orderCode;
        private String invoiceDate;
        private String invoiceNo;
        private String paymentMethod;
        private String customerCode;
        private String customerName;
        private String unitName;
        private String address;
        private String productName;
        private String taxCode;
        private Double price;
        private Double amount;
        private Double preTaxAmount;
        private Double taxAmount;
        private String taxRate;
        private String createdBy;
        private String status;
        private String companyCode;
        private String note="Có";
    }
} 