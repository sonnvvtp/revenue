package com.viettelpost.platform.bms.portal.repository.impl.einvoice;

import com.viettelpost.platform.bms.portal.model.entity.BmsRequestApiLogEntity;
import com.viettelpost.platform.bms.portal.model.entity.GeneralOrderEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.ItemOrderEntity;
import com.viettelpost.platform.bms.portal.model.request.eInvoice.FindInvoiceOrderRequest;
import com.viettelpost.platform.bms.portal.model.response.einvoice.FindInvoiceOrderResponse;
import com.viettelpost.platform.bms.portal.model.response.einvoice.QueryInvoiceOrderResponse;
import com.viettelpost.platform.bms.portal.repository.InvoiceOrderRepository;
import io.quarkus.cache.CacheResult;
import io.r2dbc.pool.ConnectionPool;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.SqlConnection;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class InvoiceOrderRepositoryImpl implements InvoiceOrderRepository {

    private final PgPool client;

    private final ConnectionPool oraclePool;

    @Override
    public Uni<Boolean> checkExistedInvoiceOrder(String domainType, String orderCode, String source) {
        List<Object> params = new ArrayList<>();
        String tableName;
        String sql;
        if (Objects.nonNull(domainType)) {
            tableName = "bms_payment." + domainType + "_record";
             sql = "select 1 as existed from " + tableName + " where record_code = $1 and record_source = $2";
        } else {
            tableName = "bms_payment.general_order";
             sql = "select 1 as existed from " + tableName + " where order_code = $1 and order_source = $2";
        }
        params.add(orderCode);
        params.add(source);
        return executeAndGetValue(client, sql, Tuple.from(params), "existed", Integer.class)
                .map(Objects::nonNull);
    }

    @Override
    public Uni<GeneralOrderEntity> save(String domainType, GeneralOrderEntity entity, SqlConnection sqlConnection) {
        List<Object> params = new ArrayList<>();
        String tableName;
        String sql = null;
        if (Objects.nonNull(domainType)) {
            tableName = "bms_payment." + domainType + "_record";
            sql = "insert into " + tableName + "(tenant_id"
                    + ",created_by"
                    + ",created_at"
                    + ",updated_by"
                    + ",updated_at"
                    + ",record_id"
                    + ",record_code"
                    + ",record_reference"
                    + ",cashflow_type"
                    + ",service_code"
                    + ",record_created_at"
                    + ",record_delivered_at"
                    + ",unit_level1_id"
                    + ",unit_level2_id"
                    + ",unit_info"
                    + ",company_code"
                    + ",seller_id"
                    + ",seller_code"
                    + ",seller_info"
                    + ",buyer_id"
                    + ",buyer_code"
                    + ",buyer_info"
                    + ",consignee_id"
                    + ",consignee"
                    + ",record_total_quantity"
                    + ",record_amount_before_tax"
                    + ",record_tax_amount"
                    + ",record_amount_after_tax"
                    + ",total_amount"
                    + ",payment_status"
                    + ",payment_info"
                    + ",payment_method"
                    + ",payment_term_id"
                    + ",revenue_sync_status"
                    + ",invoice_status"
                    + ",invoice_partner"
                    + ",currency"
                    + ",record_source" +
                    ",record_type" +
                    ",pic_type" +
                    ",pic_info" +
                    ",pic_id)"
                    + " values ($1"
                    + ",$2"
                    + ",current_timestamp"
                    + ",$3"
                    + ",current_timestamp"
                    + ",$4"
                    + ",$5"
                    + ",$6"
                    + ",$7"
                    + ",$8"
                    + ",$9"
                    + ",$10"
                    + ",$11"
                    + ",$12"
                    + ",$13"
                    + ",$14"
                    + ",$15"
                    + ",$16"
                    + ",$17"
                    + ",$18"
                    + ",$19"
                    + ",$20"
                    + ",$21"
                    + ",$22"
                    + ",$23"
                    + ",$24"
                    + ",$25"
                    + ",$26"
                    + ",$27"
                    + ",$28"
                    + ",$29"
                    + ",$30"
                    + ",$31"
                    + ",$32"
                    + ",$33"
                    + ",$34"
                    + ",$35"
                    + ",$36"
                    + ",$37"
                    + ",$38" +
                    ",$39" +
                    ",$40"
                    + ") returning *";
        } else {
            tableName = "bms_payment.general_order";
            sql = "insert into " + tableName + "(tenant_id"
                    + ",created_by"
                    + ",created_at"
                    + ",updated_by"
                    + ",updated_at"
                    + ",order_id"
                    + ",order_code"
                    + ",order_reference"
                    + ",cashflow_type"
                    + ",service_code"
                    + ",order_created_at"
                    + ",order_delivered_at"
                    + ",unit_level1_id"
                    + ",unit_level2_id"
                    + ",unit_info"
                    + ",company_code"
                    + ",seller_id"
                    + ",seller_code"
                    + ",seller_info"
                    + ",buyer_id"
                    + ",buyer_code"
                    + ",buyer_info"
                    + ",consignee_id"
                    + ",consignee"
                    + ",order_total_quantity"
                    + ",order_amount_before_tax"
                    + ",order_tax_amount"
                    + ",order_amount_after_tax"
                    + ",total_amount"
                    + ",payment_status"
                    + ",payment_info"
                    + ",payment_method"
                    + ",payment_term_id"
                    + ",revenue_sync_status"
                    + ",invoice_status"
                    + ",invoice_partner"
                    + ",currency"
                    + ",order_source" +
                    ",record_type" +
                    ",pic_type" +
                    ",pic_info" +
                    ",pic_id)"
                    + " values ($1"
                    + ",$2"
                    + ",current_timestamp"
                    + ",$3"
                    + ",current_timestamp"
                    + ",$4"
                    + ",$5"
                    + ",$6"
                    + ",$7"
                    + ",$8"
                    + ",$9"
                    + ",$10"
                    + ",$11"
                    + ",$12"
                    + ",$13"
                    + ",$14"
                    + ",$15"
                    + ",$16"
                    + ",$17"
                    + ",$18"
                    + ",$19"
                    + ",$20"
                    + ",$21"
                    + ",$22"
                    + ",$23"
                    + ",$24"
                    + ",$25"
                    + ",$26"
                    + ",$27"
                    + ",$28"
                    + ",$29"
                    + ",$30"
                    + ",$31"
                    + ",$32"
                    + ",$33"
                    + ",$34"
                    + ",$35"
                    + ",$36"
                    + ",$37"
                    + ",$38" +
                    ",$39" +
                    ",$40" 
                    + ") returning *";
        }


        params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), GeneralOrderEntity.class);
        }

        return execute(client, sql, Tuple.from(params), GeneralOrderEntity.class);
    }

    @Override
    public Uni<InvoiceInfoEntity> save(InvoiceInfoEntity entity, SqlConnection sqlConnection) {

        if (entity == null) {
            return Uni.createFrom().item(new InvoiceInfoEntity());
        }

        List<Object> params = new ArrayList<>();

        String sql = """
                insert into bms_payment.invoice_info(tenant_id
                                                        ,created_by
                                                        ,created_at
                                                        ,updated_by
                                                        ,updated_at
                                                        ,general_order_id
                                                        ,order_id
                                                        ,buyer_id
                                                        ,buyer_type
                                                        ,buyer_name
                                                        ,partner_name
                                                        ,buyer_phone
                                                        ,buyer_email
                                                        ,buyer_tax_code
                                                        ,buyer_address
                                                        ,buyer_bank_account
                                                        ,buyer_bank_name)
                values ($1
                      ,$2
                      ,current_timestamp
                      ,$3
                      ,current_timestamp
                      ,$4
                      ,$5
                      ,$6
                      ,$7
                      ,$8
                      ,$9
                      ,$10
                      ,$11
                      ,$12
                      ,$13
                      ,$14
                      ,$15
                )
                returning *
                """;
        params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));

        if (Objects.nonNull(sqlConnection)) {
            return execute(sqlConnection, sql, Tuple.from(params), InvoiceInfoEntity.class);
        }

        return execute(client, sql, Tuple.from(params), InvoiceInfoEntity.class);
    }

    @Override
    public Multi<ItemOrderEntity> saveBatch(String domainType, List<ItemOrderEntity> entities,
                                            SqlConnection sqlConnection) {
        int maxBatchSize = 500;
        List<Multi<ItemOrderEntity>> bulkInsert = new ArrayList<>();
        String tableName;
        if (Objects.nonNull(domainType)) {
            tableName = "bms_payment." + domainType + "_item_record";
        } else {
            tableName = "bms_payment.item_order";
        }
        for (int i = 0; i < entities.size(); i += maxBatchSize) {
            int end = Math.min(i + maxBatchSize, entities.size());
            List<ItemOrderEntity> chunk = entities.subList(i, end);

            String INSERT_STATEMENT = "insert into " + tableName + " ("
                    + "tenant_id"
                    + ",created_by"
                    + ",created_at"
                    + ",updated_by"
                    + ",updated_at"
                    + ",general_order_id"
                    + ",departure_location"
                    + ",arrival_location"
                    + ",vehicle_plateNumber"
                    + ",warehouse_code"
                    + ",item_selection"
                    + ",item_code"
                    + ",item_name"
                    + ",item_note"
                    + ",item_unit"
                    + ",item_quantity"
                    + ",item_price"
                    + ",item_weight"
                    + ",item_amount_before_tax"
                    + ",item_tax_type"
                    + ",item_tax_percent"
                    + ",item_tax_amount"
                    + ",item_amount_after_tax"
                    + ",attribute1"
                    + ",attribute2"
                    + ",attribute3"
                    + ") values ";

            int counter = 1;
            StringBuilder insertValues = new StringBuilder();
            List<Object> params = new ArrayList<>();
            for (ItemOrderEntity entity : chunk) {
                insertValues.append(String.format(" ($%d, $%d, current_timestamp, $%d, current_timestamp, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d, $%d),\n",
                        counter++, counter++, counter++, counter++,
                        counter++, counter++, counter++, counter++,
                        counter++, counter++, counter++, counter++,
                        counter++, counter++, counter++, counter++,
                        counter++, counter++, counter++, counter++,
                        counter++, counter++, counter++, counter++
                ));
                params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "id", "createdAt", "updatedAt"));
            }

            insertValues = new StringBuilder(StringUtils.removeEnd(insertValues.toString(), ",\n"));

            INSERT_STATEMENT += insertValues;
            INSERT_STATEMENT += " returning * ";

            Multi<ItemOrderEntity> insert;
            if (Objects.nonNull(sqlConnection)) {
                insert = executeMulti(sqlConnection, INSERT_STATEMENT, Tuple.from(params), ItemOrderEntity.class);
            } else {
                insert = executeMulti(client, INSERT_STATEMENT, Tuple.from(params), ItemOrderEntity.class);
            }

            bulkInsert.add(insert);
        }

        return Multi.createBy().concatenating().streams(bulkInsert);
    }

    @Override
    public Uni<QueryInvoiceOrderResponse> queryInvoiceOrder(String orderCode, String companyCode, String source) {
        String sql = """
                select ir.id record_id,
                  go2.order_code,
                	go2.invoice_status,
                	ir.accounting_date,
                	ir.invoice_form,
                	concat(ir.invoice_serial, ir.invoice_number) invoice_number,
                	ir.invoice_export_date,
                	ir.invoice_url,
                	ir.created_at,
                	ir.updated_at
                from bms_payment.general_order go2
                left join bms_payment.invoice_record_line irl on irl.order_id  = go2.id
                left join bms_payment.invoice_record ir on ir.id = irl.record_id
                where go2.order_code = $1 and go2.company_code = $2 limit 1
            """;
        return execute(client, sql, Tuple.of(orderCode, companyCode), QueryInvoiceOrderResponse.class);
    }

    @Override
    public Uni<Integer> findInvoiceOrderCount(FindInvoiceOrderRequest findInvoiceOrderRequest, List<String> companyCodes) {
        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        List<Integer> status = findInvoiceOrderRequest.getStatus();
        LocalDate fromDate = findInvoiceOrderRequest.getFromDate();
        LocalDate toDate = findInvoiceOrderRequest.getToDate();
        String sql = "select count(1) as total from bms_payment.general_order where 1 = 1";

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and order_code = $%d ", counter++);
            params.add(advancedFilter.trim());
        }

        if (!CollectionUtils.isEmpty(companyCodes)) {
            sql += String.format(" and company_code = any($%d) ", counter++);
            params.add(companyCodes.toArray());
        }

        if (Objects.nonNull(status) && !status.isEmpty()) {
            sql += String.format(" and invoice_status = any($%d) ", counter++);
            params.add(status.toArray());
        }

        if (StringUtils.isNotEmpty(findInvoiceOrderRequest.getSource())) {
            sql += String.format(" and order_source = $%d ", counter++);
            params.add(findInvoiceOrderRequest.getSource());
        }

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and created_at between $%d and $%d ", counter++, counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and created_at >= $%d ", counter);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and created_at <= $%d ", counter);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }

        return executeAndGetValue(client, sql, Tuple.from(params), "total", Integer.class);
    }

    @Override
    public Multi<FindInvoiceOrderResponse> findInvoiceOrder(
            FindInvoiceOrderRequest findInvoiceOrderRequest, List<String> companyCodes) {
        String advancedFilter = findInvoiceOrderRequest.getAdvancedFilter();
        List<Integer> status = findInvoiceOrderRequest.getStatus();

        String sql = """
                    select io.*,
                     	ii.buyer_type,
                     	ii.buyer_name,
                     	ii.partner_name,
                     	ii.buyer_phone ,
                     	ii.buyer_email,
                     	ii.buyer_tax_code,
                     	ii.buyer_address,
                     	ii.buyer_bank_account,
                     	ii.buyer_bank_name,
                     	ii.doctype_id,
                     	ii.group_order_id
                     from bms_payment.general_order io
                     left join bms_payment.invoice_info ii on ii.general_order_id = io.id and ii.domain_type='FMCG'
                     where 1 = 1 
                """;

        int page = Objects.nonNull(findInvoiceOrderRequest.getPage()) ? findInvoiceOrderRequest.getPage() : 1;
        int size = Objects.nonNull(findInvoiceOrderRequest.getSize()) ? findInvoiceOrderRequest.getSize() : 10;
        LocalDate fromDate = findInvoiceOrderRequest.getFromDate();
        LocalDate toDate = findInvoiceOrderRequest.getToDate();

        List<Object> params = new ArrayList<>();
        int counter = 1;

        if (Objects.nonNull(advancedFilter) && !advancedFilter.isEmpty()) {
            sql += String.format(" and io.order_code = $%d ", counter++);
            params.add(advancedFilter.trim());
        }

        if (!CollectionUtils.isEmpty(companyCodes)) {
            sql += String.format(" and company_code = any($%d) ", counter++);
            params.add(companyCodes.toArray());
        }

        if (Objects.nonNull(status) && !status.isEmpty()) {
            sql += String.format(" and io.invoice_status = any($%d) ", counter++);
            params.add(status.toArray());
        }

        if (Objects.nonNull(fromDate) && Objects.nonNull(toDate)) {
            sql += String.format(" and io.created_at >= $%d and io.created_at <= $%d ", counter++, counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        } else if (Objects.nonNull(fromDate)) {
            sql += String.format(" and io.created_at >= $%d ", counter++);
            params.add(LocalDateTime.of(fromDate, LocalTime.MIN));
        } else if (Objects.nonNull(toDate)) {
            sql += String.format(" and io.created_at <= $%d ", counter++);
            params.add(LocalDateTime.of(toDate, LocalTime.MAX));
        }

        if (StringUtils.isNotEmpty(findInvoiceOrderRequest.getSource())) {
            sql += String.format(" and io.order_source = $%d ", counter++);
            params.add(findInvoiceOrderRequest.getSource());
        }

        sql += String.format(" order by io.created_at desc limit $%d offset $%d ", counter++, counter);
        params.add(size);
        params.add(size * (page - 1));

        return executeMulti(client, sql, Tuple.from(params), FindInvoiceOrderResponse.class);
    }

    @Override
    public Uni<BmsRequestApiLogEntity> save(BmsRequestApiLogEntity entity) {
        if (entity == null) {
            return Uni.createFrom().item(new BmsRequestApiLogEntity());
        }

        List<Object> params = new ArrayList<>();

        String sql = """
                insert into bms_payment.bms_request_api_log(request_id
                                                            ,parrent_id
                                                            ,request_value
                                                            ,response_value
                                                            ,request_key
                                                            ,request_source
                                                            ,request_at
                                                            ,request_by
                                                            ,tenant_id)
                values ($1
                      ,$2
                      ,$3
                      ,$4
                      ,$5
                      ,$6
                      ,current_timestamp
                      ,$7
                      ,$8
                )
                returning *
                """;
        params.addAll(com.viettelpost.platform.bms.portal.common.utils.DataMappingUtils.getAllPropertyValuesExcept(entity, "requestLogId", "requestAt"));
        return execute(client, sql, Tuple.from(params), BmsRequestApiLogEntity.class);
    }

    @Override
    @CacheResult(cacheName = "partner-cache")
    public Uni<Boolean> checkPartnerExists(String partnerCode) {
        log.debug("Checking partner existence in database for code: {}", partnerCode);
        String sql = "SELECT EXISTS(SELECT 1 FROM bms_payment.partner_integration_config WHERE partner_code = $1 AND status = true)";
        return client.preparedQuery(sql)
                .execute(Tuple.of(partnerCode))
                .map(rowSet -> {
                    Row row = rowSet.iterator().next();
                    boolean exists = row.getBoolean(0);
                    log.debug("Partner with code {} exists: {}", partnerCode, exists);
                    return exists;
                })
                .onFailure().invoke(e -> {
                    log.error("Error checking partner existence for code: {}", partnerCode, e);
                });
    }

    @Override
    public Uni<QueryInvoiceOrderResponse> queryLogRequest(BigDecimal recordId) {
        String sql = """
                select *\s
               from bms_payment.invoice_log_request\s
               where invoice_record_id  = $1\s
               order by request_at desc\s
               limit 1
            """;
        return execute(client, sql, Tuple.of(recordId), QueryInvoiceOrderResponse.class);
    }

    @Override
    public Multi<String> getCompanyCodeBy(String postCode) {
        String sql = """
                SELECT COMPANY_CODE
                  FROM ERP_AC.FICO_SAP_POST_CODE_CENTER
                 WHERE POST_ID IN (SELECT POST_ID
                                     FROM ERP_AC.HR_POSTCODE
                                    WHERE POSTCODE = :postCode)
                """;
        return executeMultiAndGetValue(oraclePool, sql, Map.of("postCode", postCode), "COMPANY_CODE", String.class);
    }
}
