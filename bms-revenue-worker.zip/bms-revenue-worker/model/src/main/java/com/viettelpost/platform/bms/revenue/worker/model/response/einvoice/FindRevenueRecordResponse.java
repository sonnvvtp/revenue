package com.viettelpost.platform.bms.revenue.worker.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FindRevenueRecordResponse {
    // Thông tin chính từ glo_exp_record
    @JsonAlias("id")
    public BigDecimal id;
    
    @JsonAlias("record_code")
    public String recordCode;
    
    @JsonAlias("invoice_status")
    public Integer invoiceStatus;
    
    @JsonAlias("record_created_at")
    public LocalDate recordCreatedAt;
    
    @JsonAlias("buyer_id")
    public Long buyerId;
    
    @JsonAlias("buyer_code")
    public String buyerCode;
    
    @JsonAlias("company_code")
    public String companyCode;
    
    @JsonAlias("unit_level1_id")
    public Long unitLevel1Id;
    
    @JsonAlias("unit_level2_id")
    public Long unitLevel2Id;
    
    @JsonAlias("payment_method")
    public Integer paymentMethod;
    
    @JsonAlias("record_source")
    public String recordSource;
    
    @JsonAlias("order_amount_before_tax")
    public BigDecimal orderAmountBeforeTax;
    
    @JsonAlias("order_tax_amount")
    public BigDecimal orderTaxAmount;
    
    @JsonAlias("order_amount_after_tax")
    public BigDecimal orderAmountAfterTax;
    
    @JsonAlias("order_delivered_at")
    public LocalDateTime orderDeliveredAt;
    
    // Thông tin người mua từ invoice_info (nếu có)
    @JsonAlias("invoice_buyer_id")
    public Long invoiceBuyerId;
    
    @JsonAlias("buyer_type")
    public String buyerType;
    
    @JsonAlias("buyer_name")
    public String buyerName;
    
    @JsonAlias("partner_name")
    public String partnerName;
    
    @JsonAlias("buyer_phone")
    public String buyerPhone;
    
    @JsonAlias("buyer_email")
    public String buyerEmail;
    
    @JsonAlias("buyer_tax_code")
    public String buyerTaxCode;
    
    @JsonAlias("buyer_address")
    public String buyerAddress;
    
    @JsonAlias("buyer_bank_account")
    public String buyerBankAccount;
    
    @JsonAlias("buyer_bank_name")
    public String buyerBankName;
    
    @JsonAlias("doctype_id")
    public Long doctypeId;
    
    @JsonAlias("group_order_id")
    public Long groupOrderId;
}

