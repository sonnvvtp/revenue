package com.viettelpost.platform.bms.portal.model.request.partnerConfig;

import com.viettelpost.platform.bms.portal.model.enums.ConfigStatus;
import lombok.Builder;
import lombok.Data;

@Data
public class PartnerInternalStatusReq {
    private Long partnerInternalLineId;
    private ConfigStatus configStatus;
}
