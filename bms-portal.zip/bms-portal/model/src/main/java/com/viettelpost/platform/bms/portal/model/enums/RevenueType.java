package com.viettelpost.platform.bms.portal.model.enums;

import lombok.Getter;

@Getter
public enum RevenueType {
    TOTAL(1, "Doanh thu tổng"),
    COMPLETED(2, "Doanh thu hoàn thành"),
    TEMPORARY(3, "Doanh thu tạm tính");

    private final int code;
    private final String description;

    RevenueType(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static RevenueType fromCode(int code) {
        for (RevenueType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Loại báo cáo doanh thu không hợp lệ");
    }
}
