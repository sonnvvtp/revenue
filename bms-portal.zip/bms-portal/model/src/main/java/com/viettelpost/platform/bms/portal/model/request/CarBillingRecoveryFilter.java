package com.viettelpost.platform.bms.portal.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CarBillingRecoveryFilter {
    String carLicensePlate;
    String synthesisPeriod;
    String receiptNumberLv3;
    String unit;
    @Builder.Default
    int pageNo = 1;
    @Builder.Default
    int pageSize = 10;
    int type;
    List<Integer> status;
}
