package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum InvoiceCustomerStatus {
    DONG_BO_TU_DONG(1, "Đồng bộ tự động"),
    CAP_NHAT_THONG_TIN(2, "Cập nhật thông tin"),
    CHO_DUYET(3, "Chờ duyệt"),
    TU_CHOI_DUYET(4, "Từ chối duyệt"),
    DA_DUYET(5, "Đã duyệt");

    private final Integer code;
    private final String description;

}
