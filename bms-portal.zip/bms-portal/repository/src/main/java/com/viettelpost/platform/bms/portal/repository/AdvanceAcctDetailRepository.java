package com.viettelpost.platform.bms.portal.repository;

import com.viettelpost.platform.bms.common.repository.BaseRepository;
import com.viettelpost.platform.bms.portal.model.dto.advance.AdvanceAcctDetailEntity;
import io.r2dbc.spi.Connection;
import io.smallrye.mutiny.Uni;

import java.util.List;

public interface AdvanceAcctDetailRepository extends BaseRepository {

    Uni<Void> saveBatch(List<AdvanceAcctDetailEntity> entities, Connection connection);

    Uni<Boolean> deleteByListAdvAcctId(List<Long> ids, Connection connection);
}
