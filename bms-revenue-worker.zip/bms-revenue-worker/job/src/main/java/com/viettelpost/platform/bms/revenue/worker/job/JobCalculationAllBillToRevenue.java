package com.viettelpost.platform.bms.revenue.worker.job;

import com.viettelpost.platform.bms.revenue.worker.service.CalculationRevenueService;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import com.viettelpost.platform.root.common.quarkus.job.JobAbs;
import io.quarkus.scheduler.Scheduled;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import reactor.core.publisher.Mono;

@ApplicationScoped
@Slf4j
@Named("JobCalculationAllBillToRevenue")
public class JobCalculationAllBillToRevenue extends JobAbs<Void> {

  @ConfigProperty(name = "config.cron.calculation.bill.revenue", defaultValue = "")
  String cronCalculationBillRevenue;

  @Inject
  CalculationRevenueService calculationRevenueService;

  @Scheduled(cron = "${config.cron.calculation.bill.revenue}")
  public Uni<Void> calculationAllBillToRevenue() {
    log.info("=====calculationAllBillToRevenue=====");
    return ReactiveConverter.toUni(super.executeTask("calculationAllBillToRevenue", cronCalculationBillRevenue));
  }

  @Override
  protected Mono<Void> taskAction() {
    log.debug("=====start_JobCalculationAllBillToRevenue======");
    return ReactiveConverter.toMono(calculationRevenueService.calculationAllBillToRevenue());
  }
}
