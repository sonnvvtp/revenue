package com.viettelpost.platform.bms.portal.common.utils;

import io.r2dbc.spi.ColumnMetadata;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import io.vertx.core.json.JsonObject;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.*;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class DataMappingUtils {

    public static List<Object> getAllPropertyValues(Object obj) {
        return getAllPropertyValuesExcept(obj);
    }

    /**
     * Get all property value from object except list property name input
     * @param obj Object
     * @param propertyNames name of properties to remove in result
     * @return list value of all properties in object
     */
    public static List<Object> getAllPropertyValuesExcept(Object obj, String... propertyNames) {
        List<Object> values = new ArrayList<>();

        try {
            // Convert object to JSON Map
            Map<String, Object> map = parameters(obj);


            if (Objects.isNull(propertyNames)) {
                // Add all values to the list, keeping their original types
                values.addAll(map.values());
            } else {
                // Add all values to the list, except the input list property name
                List<String> exceptProperties = List.of(propertyNames);
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (!exceptProperties.contains(entry.getKey())) {
                        Object value = entry.getValue();
                        if (value instanceof Timestamp timestamp) {
                            value = timestamp.toLocalDateTime();
                        }
                        if (value instanceof LinkedHashMap linkedHashMap) {
                            value = linkedHashMap != null ? new JsonObject(linkedHashMap) : new JsonObject();
                        }
                        values.add(value);
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return values;
    }

    public static Object getPropertyValue(Object obj, String propertyName) {
        // Convert object to JSON Map
        Map<String, Object> map = parameters(obj);
        return map.get(propertyName);
    }

    public static <T> BiFunction<Row, RowMetadata, T> map(Class<T> pojoType) {
        return (row, metadata) -> {
            try {
                // Convert io.r2dbc.spi.Row to io.vertx.mutiny.sqlclient.Row
                Map<String, Object> rowMap = new HashMap<>();
                for (ColumnMetadata columnName : metadata.getColumnMetadatas()) {
                    rowMap.put(columnName.getName(), row.get(columnName.getName(), Object.class));
                }

                // Create a JsonObject from the map
                JsonObject jsonObject = new JsonObject(rowMap);

                // Map JsonObject to POJO
                return jsonObject.mapTo(pojoType);
            } catch (Exception e) {
                return null;
            }
        };
    }

    public static String convertPlaceholder(String query) {
        StringBuffer result = new StringBuffer();
        Pattern pattern = Pattern.compile("\\?");
        Matcher matcher = pattern.matcher(query);

        int placeholderIndex = 1;

        while (matcher.find()) {
            matcher.appendReplacement(result, "\\$" + placeholderIndex++);
        }
        matcher.appendTail(result);

        return result.toString();
    }

    public static Map<String, Object> parameters(Object obj) {
        Map<String, Object> map = new LinkedHashMap<>();
        if (obj instanceof Map) {
            return (Map<String, Object>) obj;
        }
        for (Field field : obj.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            try {
                map.put(field.getName(), field.get(obj));
            } catch (Exception ignore) {
            }
        }

        return map;
    }
}
