package com.viettelpost.platform.bms.portal.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.*;

import java.math.BigDecimal;

@Data
public class BillRevenueDTO {
    @JsonAlias("BILL_REVENUE_ID")
    private Long billRevenueId;

    @JsonAlias("BILL")
    private String bill;

    @JsonAlias("PARTNER_EVTP")
    private String partnerEvtp;

    @JsonAlias("M_PRODUCT")
    private String mProduct;

    @JsonAlias("DATE_BILL")
    private String dateBill;

    @JsonAlias("DATE_INSERT")
    private String dateInsert;

    @JsonAlias("TYPE")
    private Long type;

    @JsonAlias("BILL_REVENUE_TYPE")
    private Long billRevenueType;

    @JsonAlias("CITY_FROM")
    private String cityFrom;

    @JsonAlias("CITY_TO")
    private String cityTo;

    @JsonAlias("CITY_FROM_NAME")
    private String cityFromName;

    @JsonAlias("CITY_TO_NAME")
    private String cityToName;

    @JsonAlias("BILL_STATUS")
    private Long billStatus;

    @JsonAlias("WEIGHT")
    private Long weight;

    @JsonAlias("AMT")
    private BigDecimal amt;     // doanh thu

    @JsonAlias("AMT_DEDUCT")
    private BigDecimal amtDeduct;  // chiet khau

    @JsonAlias("AMT_VAT")
    private BigDecimal amtVat;  // vat

    @JsonAlias("AMOUNT")
    private BigDecimal amount;  // tong tien

    @JsonAlias("ORG_ID")
    private Long orgId;

    @JsonAlias("POST_ID")
    private Long postId;

    @JsonAlias("CREATED_DATE")
    private String createdDate;

}
