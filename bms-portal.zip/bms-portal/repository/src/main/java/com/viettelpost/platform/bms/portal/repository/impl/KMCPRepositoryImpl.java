package com.viettelpost.platform.bms.portal.repository.impl;


import com.viettelpost.platform.bms.portal.model.dto.KMCPDTO;
import com.viettelpost.platform.bms.portal.model.model.KMCPModel;
import com.viettelpost.platform.bms.portal.repository.KMCPRepository;
import com.viettelpost.platform.root.common.quarkus.tracing.KeepTracedContext;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.Statement;
import jakarta.inject.Singleton;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Singleton
@RequiredArgsConstructor
@KeepTracedContext
public class KMCPRepositoryImpl implements KMCPRepository {

    @Override
    public Mono<List<KMCPModel>> getKMCPByIds(Connection connection, List<String> ids) {
        String placeholders = String.join(",", ids.stream().map(id -> "?").toArray(String[]::new));
        String query = "SELECT ID, NAME, DEBIT_ACC FROM ERP_AC.KMCP WHERE ID in (" + placeholders + ")";
        Statement statement = connection.createStatement(query);
        for (int i = 0; i < ids.size(); i++) {
            statement.bind(i, ids.get(i));
        }
        return Mono.from(statement.execute())
                .flatMapMany(result ->
                        result.map((row, rowMetaData) ->
                                new KMCPModel(row.get("ID", String.class),
                                        row.get("NAME", String.class),
                                        row.get("DEBIT_ACC", String.class))))
                .collectList()
                .switchIfEmpty(Mono.empty());
    }

    @Override
    public Mono<KMCPDTO> getKMCPById(Connection connection, String id) {
        var query = "SELECT ID, NAME, DEBIT_ACC, TYPE_PAY, LICENSE_PLATE_REQUIRE FROM ERP_AC.KMCP WHERE ID = :id";
        return Mono.from(connection.createStatement(query)
                        .bind("id", id).execute())
                .flatMapMany(result ->
                        result.map((row, rowMetaData) ->
                                new KMCPDTO(id, row.get("NAME", String.class),
                                        row.get("DEBIT_ACC", String.class),
                                        row.get("TYPE_PAY", Integer.class),
                                        row.get("LICENSE_PLATE_REQUIRE", Integer.class))))
                .collectList()
                .flatMap(list -> {
                    if (list.isEmpty()) {
                        return Mono.just(new KMCPDTO());
                    } else {
                        return Mono.just(list.get(0));
                    }
                })
                .doOnSuccess(
                        kmcpModel -> log.warn("Get KMCP success: {}",  kmcpModel))
                .onErrorResume(throwable -> {
                    log.warn(" Get KMCP error", throwable);
                    return Mono.just(new KMCPDTO());
                });
    }
}