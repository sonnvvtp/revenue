package com.viettelpost.platform.bms.portal.interfaces;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import com.viettelpost.platform.bms.portal.common.config.AuthenticationContext;
import com.viettelpost.platform.bms.portal.common.config.CustomUser;
import com.viettelpost.platform.bms.portal.model.request.ConfirmRecordRequest;
import com.viettelpost.platform.bms.portal.model.request.InvRecordUpdateRequest;
import com.viettelpost.platform.bms.portal.service.handler.InvRecordService;
import io.smallrye.mutiny.Uni;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;

@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/inv-record")
@Tag(name = "Api invoice_record")
@RequiredArgsConstructor
public class InvRecordController {

    private final InvRecordService invRecordService;

    private final AuthenticationContext authCtx;

    @POST
    @Path("/{id}")
    @Operation(summary = "Thêm hóa đơn vào bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> addOrdersToInvoice(@PathParam("id") Long id, @RequestBody List<Long> orderIds) {
        return invRecordService.addOrdersToInvoice(id, orderIds)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @POST
    @Path("/reject")
    @Operation(summary = "Gỡ chốt bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> rejectInvoiceRecord(@Valid @RequestBody ConfirmRecordRequest request) {
        CustomUser infoUser = authCtx.getCurrentUser();
        return invRecordService.rejectInvoiceRecord(request, infoUser);
    }

    @DELETE
    @Path("/{id}")
    @Operation(summary = "Xóa bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> deleteInvoiceRecord(@PathParam("id") Long recordId) {
        return invRecordService.deleteInvoiceRecord(recordId)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @PUT
    @Path("/{id}")
    @Operation(summary = "Cập nhật bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> updateInvoiceRecordInfo(@PathParam("id") Long recordId, @RequestBody InvRecordUpdateRequest request) {
        return invRecordService.updateInvoiceRecordInfo(recordId, request)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

    @GET
    @Path("/{id}")
    @Operation(summary = "In Chi tiết đơn hàng bảng kê")
    @APIResponse(responseCode = "200", description = "return data")
    @APIResponse(responseCode = "400", description = "Bad request")
    public Uni<Response> getInvoiceRecordInfo(@PathParam("id") Long id) {
        return invRecordService.getInvoiceRecordInfo(id)
                .map(response -> BaseResponse.successApi(response, "OK"));
    }

}
