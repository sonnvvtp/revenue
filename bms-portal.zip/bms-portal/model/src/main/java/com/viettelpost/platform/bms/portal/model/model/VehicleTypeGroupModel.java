package com.viettelpost.platform.bms.portal.model.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class VehicleTypeGroupModel {

    private Long id;
    private String name;
    @JsonAlias("vehicle_types")
    private String vehicleType;
    private List<String> vehicleTypes;
    @JsonAlias("is_sync_invoice")
    private boolean isSyncInvoice;
}
