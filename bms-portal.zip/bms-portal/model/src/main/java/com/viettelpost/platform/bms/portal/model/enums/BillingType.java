package com.viettelpost.platform.bms.portal.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

@Getter
@AllArgsConstructor
public enum BillingType {
    TRUY_THU(1, "Chứng từ truy thu"),
    GHI_GIAM(2, "Chứng từ ghi giảm"),
    DUYET_TRUY_THU(3, "Duyêt chứng từ ghi giảm"),
    DUYET_GHI_GIAM(4, "Duyêt chứng từ ghi giảm"),

    NA(0, "N/A");

    private final Integer code;
    private final String description;

    public static BillingType fromCode(Integer code) {
        for (BillingType type : BillingType.values()) {
            if (Objects.equals(type.getCode(), code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Invalid type code: " + code);
    }

    public static Integer fromStatus(BillingType status) {
        return status.getCode();
    }
}
