package com.viettelpost.platform.bms.portal.repository.impl;

import com.viettelpost.platform.bms.portal.model.dto.VehicleTypeGroupDTO;
import com.viettelpost.platform.bms.portal.model.request.VehicleTypeGroupFilter;
import com.viettelpost.platform.bms.portal.model.response.CarLicensePlateRecoverResponse;
import com.viettelpost.platform.bms.portal.model.response.CarLicensePlateResponse;
import com.viettelpost.platform.bms.portal.model.response.VehicleTypeGroupResponse;
import com.viettelpost.platform.bms.portal.model.response.VehicleTypeResponse;
import com.viettelpost.platform.bms.portal.repository.CarManagementRepository;
import com.viettelpost.platform.root.common.quarkus.helper.ReactiveConverter;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.converters.uni.UniReactorConverters;
import io.vertx.mutiny.pgclient.PgPool;
import io.vertx.mutiny.sqlclient.Row;
import io.vertx.mutiny.sqlclient.Tuple;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class CarManagementRepositoryImpl implements CarManagementRepository {

    @Inject
    PgPool client;

    private static final int MAX_CONDITION = 1000;

    @Override
    public Uni<List<String>> findAllCarUnits(String search, int page, int size) {
        int offset = (page - 1) * size;
        StringBuilder sql = new StringBuilder(
                "SELECT DISTINCT unit FROM bms_payment.car_management_setting WHERE is_active = true");
        List<Object> params = new ArrayList<>();
        if (search != null && !search.isEmpty()) {
            sql.append(" AND LOWER(unit) like $1");
            params.add("%" + search.toLowerCase() + "%");
        }
        sql.append(" LIMIT $").append(params.size() + 1);
        params.add(size);
        sql.append(" OFFSET $").append(params.size() + 1);
        params.add(offset);
        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<String> units = new ArrayList<>();
                    rows.forEach(row -> {
                        String unit = row.getString("unit");
                        units.add(unit);
                    });
                    return units;
                });
    }

    @Override
    public Uni<List<String>> findAllCarLicensePlatesByUnit(String unit, String search, Integer page,
            Integer size) {
        int offset = 0;
        int limit = Integer.MAX_VALUE;

        if ((page != null && page > 0) && (size != null && size > 0)) {
            offset = (page - 1) * size;
            limit = size;
        }
        StringBuilder sql = new StringBuilder("SELECT * FROM bms_payment.car_management_setting WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (unit != null && !unit.isEmpty()) {
            sql.append(" AND unit = $").append(1);
            params.add(unit);
        }

        if (search != null && !search.isEmpty()) {
            sql.append(" AND car_license_plate like $").append(params.size() + 1);
            params.add("%" + search + "%");
        }

        sql.append(" LIMIT $").append(params.size() + 1);
        params.add(limit);
        sql.append(" OFFSET $").append(params.size() + 1);
        params.add(offset);

        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> {
                    List<String> carPlates = new ArrayList<>();
                    rows.forEach(row -> {
                        String carLicensePlate = row.getString("car_license_plate");
                        carPlates.add(carLicensePlate);
                    });
                    return carPlates;
                });
    }

    @Override
    public Uni<List<CarLicensePlateResponse>> findAllCarLicensePlatesInWaitingApprove(
            Long receiptId) {
        String sql = """
                SELECT f1.car_license_plate, f1.total_budget_excess, f1.car_id, cms.recover_id, cms.unit FROM bms_payment.fuel_billing_recovery f1
                LEFT JOIN bms_payment.fuel_billing_recovery_level3 f3
                    ON f1.synthesis_period = f3.synthesis_period and f3.is_active = true
                LEFT JOIN bms_payment.car_management_setting cms ON cms.id = f1.car_id and cms.is_active = true
                WHERE f3.id = $1 and f1.total_budget_excess > 0 and f1.is_active = true;
                """;
        return client.preparedQuery(sql)
                .execute(Tuple.of(receiptId))
                .onItem().transform(rowSet -> {
                    Map<String, CarLicensePlateResponse> responseMap = new HashMap<>();

                    rowSet.forEach(row -> {
                        String carLicensePlate = row.getString("car_license_plate");
                        Long carId = row.getLong("car_id");
                        BigDecimal budgetExcess = row.getBigDecimal("total_budget_excess");
                        String recoverId = row.getString("recover_id");
                        String unit = row.getString("unit");

                        responseMap.computeIfAbsent(carLicensePlate, k -> {
                            CarLicensePlateResponse response = new CarLicensePlateResponse();
                            response.setCarLicensePlate(carLicensePlate);
                            response.setCarId(carId);
                            response.setTotalBudgetExcess(BigDecimal.ZERO);
                            response.setRecovers(new ArrayList<>());
                            response.setUnit(unit);
                            return response;
                        });

                        CarLicensePlateResponse response = responseMap.get(carLicensePlate);
                        response.setTotalBudgetExcess(
                                response.getTotalBudgetExcess().add(budgetExcess));

                        CarLicensePlateRecoverResponse recoverResponse = new CarLicensePlateRecoverResponse();
                        recoverResponse.setId(UUID.randomUUID());
                        recoverResponse.setBudgetExcess(budgetExcess);
                        recoverResponse.setRecoverId(recoverId);
                        recoverResponse.setNote(null);
                        response.getRecovers().add(recoverResponse);

                        response.getRecovers().add(recoverResponse);
                    });

                    return new ArrayList<>(responseMap.values());
                });
    }

    @Override
    public Uni<List<String>> getCarLicensePlateByReceiptId(Long receiptId) {
        String sql = "SELECT distinct car_license_plate FROM bms_payment.fuel_billing_recovery_level3_detail WHERE receipt_id = $1";

        return client.preparedQuery(sql)
                .execute(Tuple.of(receiptId))
                .onItem().transform(rows -> {
                    List<String> carPlates = new ArrayList<>();
                    rows.forEach(row -> {
                        String carLicensePlate = row.getString("car_license_plate");
                        carPlates.add(carLicensePlate);
                    });
                    return carPlates;
                });
    }

    @Override
    public Uni<Integer> countBillDetailLv3ByReceiptId(Long receiptId) {
        String sql = "SELECT count(*) FROM bms_payment.fuel_billing_recovery_level3_detail WHERE receipt_id = $1";

        return client.preparedQuery(sql)
                .execute(Tuple.of(receiptId))
                .onItem().transform(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        return rowSet.iterator().next().getInteger(0);
                    } else {
                        return 0;
                    }
                });
    }

    @Override
    public Uni<List<CarLicensePlateResponse>> getListBillDetailLv3ByCarLicensePlate(
            List<String> carLicensePlates) {
        String sql = """
                SELECT f.car_license_plate, f.car_id, f.amount AS budget_excess, f.note, f.user_id, f.user_code_bp, c.unit
                FROM bms_payment.fuel_billing_recovery_level3_detail f
                LEFT JOIN bms_payment.car_management_setting c ON f.car_id = c.id
                WHERE f.car_license_plate = ANY($1)
                ORDER BY f.car_license_plate;
                """;

        return client.preparedQuery(sql)
                .execute(Tuple.of(carLicensePlates.toArray()))
                .onItem().transform(rowSet -> {
                    Map<String, CarLicensePlateResponse> responseMap = new HashMap<>();

                    rowSet.forEach(row -> {
                        String carLicensePlate = row.getString("car_license_plate");
                        Long carId = row.getLong("car_id");
                        BigDecimal budgetExcess = row.getBigDecimal("budget_excess");
                        String note = row.getString("note");
                        String unit = row.getString("unit");
                        String recoverCodeBp = row.getString("user_code_bp");

                        responseMap.computeIfAbsent(carLicensePlate, k -> {
                            CarLicensePlateResponse response = new CarLicensePlateResponse();
                            response.setCarLicensePlate(carLicensePlate);
                            response.setCarId(carId);
                            response.setTotalBudgetExcess(BigDecimal.ZERO);
                            response.setRecovers(new ArrayList<>());
                            response.setUnit(unit);
                            return response;
                        });

                        CarLicensePlateResponse response = responseMap.get(carLicensePlate);
                        response.setTotalBudgetExcess(
                                response.getTotalBudgetExcess().add(budgetExcess));

                        CarLicensePlateRecoverResponse recoverResponse = new CarLicensePlateRecoverResponse();
                        recoverResponse.setId(UUID.randomUUID());
                        recoverResponse.setBudgetExcess(budgetExcess);
                        recoverResponse.setRecoverId(recoverCodeBp);
                        recoverResponse.setNote(note);
                        recoverResponse.setRecoverCodeBp(recoverCodeBp);
                        response.getRecovers().add(recoverResponse);
                    });

                    return new ArrayList<>(responseMap.values());
                });
    }

    @Override
    public Uni<List<VehicleTypeResponse>> getVehicleTypes() {
        return client.preparedQuery(
                        "select code, name from bms_payment.vehicle_type_setting where is_active = true")
                .execute()
                .onItem().transform(rows -> {
                    List<VehicleTypeResponse> responseList = new ArrayList<>();
                    rows.forEach(row -> {
                        VehicleTypeResponse response = new VehicleTypeResponse(
                                row.getString("code"),
                                row.getString("name")
                        );
                        responseList.add(response);
                    });
                    return responseList;
                });
    }

    @Override
    public Uni<List<VehicleTypeResponse>> getVehicleTypesNotInGroup() {
        String sql = """
                    SELECT code, name FROM bms_payment.vehicle_type_setting
                    WHERE is_active = true
                      AND code NOT IN (
                        SELECT unnest(string_to_array(vehicle_types, ',')) FROM bms_payment.vehicle_type_group_setting)
                """;

        return client.preparedQuery(sql)
                .execute()
                .onItem().transform(rows -> {
                    List<VehicleTypeResponse> responseList = new ArrayList<>();
                    rows.forEach(row -> {
                        String code = row.getString("code");
                        String name = row.getString("name");
                        responseList.add(new VehicleTypeResponse(code, name));
                    });
                    return responseList;
                });
    }


    @Override
    public Uni<List<VehicleTypeGroupResponse>> getVehicleTypeGroups(VehicleTypeGroupFilter filter) {
        List<Long> groupIds = filter.getGroupId();
        List<String> typeCodes = filter.getTypeCode();
        int page = filter.getPage();
        int size = filter.getSize();
        boolean excludeTypes = filter.isExcludeTypes();

        int offset = (page - 1) * size;
        StringBuilder sql = new StringBuilder(
                excludeTypes
                        ? "SELECT id, name, is_sync_invoice FROM bms_payment.vehicle_type_group_setting WHERE 1=1"
                        : "SELECT id, name, vehicle_types, is_sync_invoice FROM bms_payment.vehicle_type_group_setting WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (groupIds != null && !groupIds.isEmpty()) {
            sql.append(" AND id = ANY($").append(1).append(")");
            params.add(groupIds.toArray());
        }

        if (filter.getIsSyncInvoice() != null) {
            sql.append(" AND is_sync_invoice = $").append(params.size() + 1);
            params.add(filter.getIsSyncInvoice());
        }

        if (typeCodes != null && !typeCodes.isEmpty()) {
            sql.append(" AND (");
            for (int i = 0; i < typeCodes.size(); i++) {
                if (i > 0) {
                    sql.append(" OR ");
                }
                sql.append("vehicle_types LIKE $").append(params.size() + 1);
                params.add("%" + typeCodes.get(i) + "%");
            }
            sql.append(")");
        }

        if (filter.getSearch() != null && !filter.getSearch().isEmpty()) {
            sql.append(" AND LOWER(name) like $").append(params.size() + 1);
            params.add("%" + filter.getSearch().toLowerCase().trim() + "%");
        }

        sql.append(" ORDER BY id desc ");
        sql.append(" LIMIT $").append(params.size() + 1);
        params.add(size);
        sql.append(" OFFSET $").append(params.size() + 1);
        params.add(offset);

        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transformToUni(rows -> {
                    if (!rows.iterator().hasNext()) {
                        return Uni.createFrom().item(Collections.emptyList());
                    }
                    List<Uni<VehicleTypeGroupResponse>> groupResponses = new ArrayList<>();

                    rows.forEach(row -> {
                        Long id = row.getLong("id");
                        String name = row.getString("name");
                        Boolean isSyncInvoice = row.getBoolean("is_sync_invoice");

                        if (excludeTypes) {
                            groupResponses.add(Uni.createFrom()
                                    .item(new VehicleTypeGroupResponse(id, name, isSyncInvoice,
                                            null)));
                        } else {
                            String vehicleTypesStr = row.getString("vehicle_types");
                            List<String> vehicleTypeCodes = Arrays.asList(
                                    vehicleTypesStr.split(","));

                            Uni<List<VehicleTypeResponse>> vehicleTypesUni = getVehicleTypes()
                                    .onItem().transform(vehicleTypes -> vehicleTypes.stream()
                                            .filter(type -> vehicleTypeCodes.contains(
                                                    type.getCode()))
                                            .collect(Collectors.toList()));

                            groupResponses.add(vehicleTypesUni.onItem().transform(vehicleTypes ->
                                    new VehicleTypeGroupResponse(id, name, isSyncInvoice,
                                            vehicleTypes)));
                        }
                    });

                    return Uni.combine().all().unis(groupResponses).combinedWith(responses ->
                            (List<VehicleTypeGroupResponse>) responses
                    );
                });
    }

    @Override
    public Uni<Long> countVehicleTypeGroups(VehicleTypeGroupFilter filter) {
        List<Long> groupIds = filter.getGroupId();
        List<String> typeCodes = filter.getTypeCode();
        StringBuilder sql = new StringBuilder("SELECT count(*) FROM bms_payment.vehicle_type_group_setting WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (groupIds != null && !groupIds.isEmpty()) {
            sql.append(" AND id = ANY($").append(1).append(")");
            params.add(groupIds.toArray());
        }

        if (filter.getIsSyncInvoice() != null) {
            sql.append(" AND is_sync_invoice = $").append(params.size() + 1);
            params.add(filter.getIsSyncInvoice());
        }

        if (typeCodes != null && !typeCodes.isEmpty()) {
            sql.append(" AND (");
            for (int i = 0; i < typeCodes.size(); i++) {
                if (i > 0) {
                    sql.append(" OR ");
                }
                sql.append("vehicle_types LIKE $").append(params.size() + 1);
                params.add("%" + typeCodes.get(i) + "%");
            }
            sql.append(")");
        }

        if (filter.getSearch() != null && !filter.getSearch().isEmpty()) {
            sql.append(" AND LOWER(name) like $").append(params.size() + 1);
            params.add("%" + filter.getSearch().toLowerCase().trim() + "%");
        }
        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rows -> rows.iterator().next().getLong(0));
    }

    @Override
    public Uni<VehicleTypeGroupDTO> findVehicleTypeGroupById(Long id) {
        if (id == null || id <= 0) {
            return Uni.createFrom().failure(new IllegalArgumentException("ID không hợp lệ."));
        }

        String query = "SELECT id, name, vehicle_types, is_sync_invoice FROM bms_payment.vehicle_type_group_setting WHERE id = $1";

        return client.preparedQuery(query)
                .execute(Tuple.of(id))
                .onItem()
                .transform(rowSet -> {
                    if (rowSet.iterator().hasNext()) {
                        Row row = rowSet.iterator().next();
                        return new VehicleTypeGroupDTO(
                                row.getLong("id"),
                                row.getString("name"),
                                row.getString("vehicle_types"),
                                row.getBoolean("is_sync_invoice")
                        );
                    }
                    return null;
                })
                .onFailure().invoke(ex -> log.error("Lỗi khi tìm VehicleTypeGroup. ID: {}, Lỗi: {}", id, ex.getMessage()))
                .onItem().ifNull().failWith(() -> new IllegalArgumentException("Nhóm loại xe không tồn tại."));
    }

    @Override
    public Uni<Long> createVehicleTypeGroup(String name, String vehicleTypeCodes, Boolean isSyncInvoice) {
        String checkQuery = "SELECT EXISTS (SELECT 1 FROM bms_payment.vehicle_type_group_setting WHERE LOWER(name) = LOWER($1))";
        String query = "INSERT INTO bms_payment.vehicle_type_group_setting (name, vehicle_types, update_date, is_sync_invoice) VALUES ($1, $2, $3, $4) RETURNING id";

        return client.preparedQuery(checkQuery)
                .execute(Tuple.of(name))
                .onItem().transformToUni(rowSet -> {
                    Boolean exists = rowSet.iterator().next().getBoolean(0);
                    if (Boolean.TRUE.equals(exists)) {
                        return Uni.createFrom().failure(
                            new IllegalArgumentException("Tên nhóm loại xe đã tồn tại"));
                    }
                    return client.preparedQuery(query)
                            .execute(Tuple.of(name, vehicleTypeCodes, LocalDateTime.now(), isSyncInvoice))
                            .onItem().transform(insertRowSet -> {
                                if (insertRowSet.iterator().hasNext()) {
                                    return insertRowSet.iterator().next().getLong("id");
                                }
                                throw new IllegalStateException("Không thể lấy ID của nhóm loại xe vừa tạo");
                            });
                })
                .onFailure(IllegalArgumentException.class).invoke(ex -> log.warn("Lỗi logic: {}", ex.getMessage()))
                .onFailure().invoke(ex -> log.error("Lỗi hệ thống khi lưu nhóm loại xe: {}", ex.getMessage()));
    }


    @Override
    public Uni<Boolean> updateVehicleTypeGroup(Long id, String name, String vehicleTypeCodes,
            Boolean isSyncInvoice) {
        String query = "UPDATE bms_payment.vehicle_type_group_setting SET name = $1, vehicle_types = $2, update_date = $3, is_sync_invoice = $4 WHERE id = $5";

        return client.preparedQuery(query)
                .execute(Tuple.of(name, vehicleTypeCodes, LocalDateTime.now(), isSyncInvoice, id))
                .onItem().transform(pgRowSet -> pgRowSet.rowCount() > 0);
    }

    @Override
    public Uni<Boolean> deleteVehicleTypeGroup(Long id) {
        String query = "DELETE FROM bms_payment.vehicle_type_group_setting WHERE id = $1";

        return client.preparedQuery(query)
                .execute(Tuple.of(id))
                .onItem().transform(rowSet -> rowSet.rowCount() > 0)
                .onFailure()
                .invoke(ex -> log.error("Lỗi khi xóa nhóm loại xe: {}", ex.getMessage()))
                .onFailure().recoverWithItem(false);
    }

    @Override
    public Mono<Map<String, String>> getKmcpIdByCarLicensePlates(List<String> carLicensePlates) {
        var platesSet = new HashSet<>(carLicensePlates);
        return Flux.fromIterable(chunk(platesSet.iterator(), MAX_CONDITION))
                .flatMap(chunk -> {
                    String query = "SELECT c.car_license_plate, v.kmcp_id " +
                            "FROM bms_payment.vehicle_type_group_kmcp_config v " +
                            "JOIN bms_payment.car_management_setting c " +
                            "ON v.org_type = c.org_type " +
                            "WHERE c.car_license_plate = ANY($1) " +
                            "AND v.vehicle_type_group_id = c.type_group_id";

                    Tuple tuple = Tuple.of((Object) chunk.toArray(new String[0]));

                    return ReactiveConverter.toFlux(client.preparedQuery(query)
                            .mapping(row -> Map.entry(row.getString("car_license_plate"), row.getString("kmcp_id")))
                            .execute(tuple)
                            .toMulti()
                            .flatMap(rows -> Multi.createFrom().iterable(rows)));
                })
                .timeout(Duration.ofSeconds(30), Mono.error(new Throwable("Timeout")))
                .collectMap(Map.Entry::getKey, Map.Entry::getValue);
    }

    @Override
    public Mono<List<String>> getVehicleTypesForSyncInvoice() {
        String query = "SELECT v.vehicle_types FROM bms_payment.vehicle_type_group_setting v WHERE v.is_sync_invoice = true";

        log.debug("Executing query: {}", query);

        return client.preparedQuery(query)
                .execute()
                .onItem()
                .transform(rowSet -> {
                    List<String> vehicleTypesList = new ArrayList<>();
                    rowSet.forEach(row -> {
                        String vehicleTypes = row.getString("vehicle_types");
                        log.debug("Fetched vehicle_types: {}", vehicleTypes);
                        if (vehicleTypes != null && !vehicleTypes.isEmpty()) {
                            String[] typesArray = vehicleTypes.split(",");
                            vehicleTypesList.addAll(Arrays.asList(typesArray));
                        }
                    });
                    return vehicleTypesList;
                })
                .convert()
                .with(UniReactorConverters.toMono())
                .doOnError(error -> log.error("Error executing query for vehicle types", error));
    }


    @Override
    public Mono<List<String>> getValidCarLicensePlatesInTypes(List<String> types) {
        String sql = "SELECT car_license_plate FROM bms_payment.car_management_setting " +
                "WHERE type_id = ANY($1::varchar[]) AND is_active = true";

        log.debug("Executing query: {} with types: {}", sql, types);

        // Convert the types list to an array
        String[] typesArray = types.toArray(new String[0]);

        return client.preparedQuery(sql)
                .execute(Tuple.of((Object) typesArray))
                .onItem()
                .transform(resultSet -> {
                    List<String> carLicensePlates = new ArrayList<>();
                    resultSet.forEach(row -> {
                        String plate = row.getString("car_license_plate");
                        if (plate != null) {
                            carLicensePlates.add(plate.trim());
                        }
                    });
                    return carLicensePlates;
                })
                .convert()
                .with(UniReactorConverters.toMono())
                .doOnSuccess(plates -> log.info("[DB] Successfully retrieved and trimmed active car license plates: {}", plates))
                .doOnError(ex -> log.error("[DB] Error retrieving active car license plates", ex));
    }

    @Override
    public Mono<String> getKMCPId(String carLicensePlate) {
        String query = """
        SELECT v.kmcp_id
        FROM bms_payment.vehicle_type_group_kmcp_config v
        JOIN bms_payment.car_management_setting c
          ON v.vehicle_type_group_id = c.type_group_id
         AND v.org_type = c.org_type
        WHERE c.car_license_plate = $1 and c.is_active = true
    """;

        return client.preparedQuery(query)
                .execute(Tuple.of(carLicensePlate))
                .onItem()
                .transform(rowSet -> rowSet.iterator().hasNext()
                        ? rowSet.iterator().next().getString("kmcp_id")
                        : null)
                .convert()
                .with(UniReactorConverters.toMono());
    }

    @Override
    public Uni<Boolean> updateTypeGroupByType(List<String> vehicleTypes, Long vehicleTypeGroupId) {
        StringBuilder sql = new StringBuilder("""
            UPDATE bms_payment.car_management_setting
            SET type_group_id = $1
            WHERE is_active = true
            """);
        List<Object> params = new ArrayList<>();
        params.add(vehicleTypeGroupId);

        if (vehicleTypes != null && !vehicleTypes.isEmpty()) {
            sql.append(" AND type_id = ANY($").append(2).append(")");
            params.add(vehicleTypes.toArray());
        }

        return client.preparedQuery(sql.toString())
                .execute(Tuple.from(params))
                .onItem().transform(rowSet -> {
                    int updatedRows = rowSet.rowCount();
                    if (updatedRows == 0) {
                        log.info("Không có bản ghi nào bị thay đổi.");
                    } else {
                        log.info("Đã cập nhật {} bản ghi.", updatedRows);
                    }
                    return true;
                });
    }

    public static <T> List<List<T>> chunk(Iterator<T> iterator, int chunkSize) {
        List<List<T>> chunks = new ArrayList<>();

        while (iterator.hasNext()) {
            List<T> chunk = new ArrayList<>(chunkSize);
            for (int i = 0; i < chunkSize && iterator.hasNext(); i++) {
                chunk.add(iterator.next());
            }
            chunks.add(chunk);
        }

        return chunks;
    }
}
