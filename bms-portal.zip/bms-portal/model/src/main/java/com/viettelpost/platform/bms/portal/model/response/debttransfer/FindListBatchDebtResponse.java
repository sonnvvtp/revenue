package com.viettelpost.platform.bms.portal.model.response.debttransfer;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FindListBatchDebtResponse {

    @JsonAlias("DOCSTATUS_ID")
    private Integer docStatusId;

    @JsonAlias("DOCSTATUS")
    private String docStatusName;

    @JsonAlias("DOCUMENTNO")
    private String batchNo;

    @JsonAlias("PAYMENT_DATE")
    private String paymentDate;

    @JsonAlias("ACCOUNTING_DATE")
    private String accountingDate;

    @JsonAlias("DESCRIPTION")
    private String description;

    @JsonAlias("PERSON_ID")
    private String personId;

    @JsonAlias("EMPLOYEENAME")
    private String employeeName;

    @JsonAlias("ACCOUNTANT_NAME")
    private String accountantName;

    @JsonAlias("TOTALAMT")
    private BigDecimal totalAmt;

    @JsonAlias("TOTALAMT_PAY")
    private BigDecimal totalAmtPay;

    @JsonAlias("CLEAR_BATCH_ID")
    private Long clearBatchId;
}
