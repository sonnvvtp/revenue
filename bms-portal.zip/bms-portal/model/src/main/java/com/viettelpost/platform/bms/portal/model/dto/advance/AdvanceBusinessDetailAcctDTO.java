package com.viettelpost.platform.bms.portal.model.dto.advance;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class AdvanceBusinessDetailAcctDTO {

    @JsonAlias("drcr")
    private String drcr;

    @JsonAlias("bp_code")
    private String bpCode;

    @JsonAlias("gl_account")
    private String accountNo;

    @JsonAlias("profit_ctr")
    private String pcCode;

    @JsonAlias("amount")
    private BigDecimal amount;
}
