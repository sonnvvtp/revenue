package com.viettelpost.platform.bms.revenue.worker.common.exception;

import com.viettelpost.platform.bms.common.exception.BaseResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Provider
@Slf4j
@RequiredArgsConstructor
public class ConstraintViolationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {
    @Override
    public Response toResponse(ConstraintViolationException e) {
        String errorMessage = String.join(", ", e.getConstraintViolations().stream().map(ConstraintViolation::getMessageTemplate).toList());
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setData(null);
        baseResponse.setMessage(errorMessage);
        baseResponse.setError(true);
        log.error("Return error to client with details: {}", e.getMessage());
        return Response.status(400).entity(baseResponse).build();
    }
}