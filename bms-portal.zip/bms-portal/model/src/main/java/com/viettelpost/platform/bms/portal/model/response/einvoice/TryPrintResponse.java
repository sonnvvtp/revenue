package com.viettelpost.platform.bms.portal.model.response.einvoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceInfoEntity;
import com.viettelpost.platform.bms.portal.model.entity.InvoiceSellerInfoEntity;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TryPrintResponse {

    InvoiceSellerInfoEntity sellerInfo;

    InvoiceInfoEntity buyerInfo;

    @Schema(description = "Total items")
    @JsonAlias("count")
    Integer count;

    @Schema(description = "Total items")
    @JsonAlias("order_amount_before_tax")
    BigDecimal totalAmountBeforeTax = BigDecimal.ZERO;

    @Schema(description = "Total items")
    @JsonAlias("order_tax_amount")
    BigDecimal totalTaxAmount = BigDecimal.ZERO;

    @Schema(description = "Total items")
    @JsonAlias("order_amount_after_tax")
    BigDecimal totalAmountAfterTax = BigDecimal.ZERO;

    List<ItemRecordResponse> items;
}
