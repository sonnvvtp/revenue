package com.viettelpost.platform.bms.portal.model.response.sap;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
public class MSTSapResponse implements Serializable {

    @JsonProperty("BP_LISTS")
    List<BP_LISTS> BP_LISTS;

    @Data
    @Accessors(chain = true)
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BP_LISTS {

        @JsonProperty("SEQ")
        private String SEQ;

        @JsonProperty("VAT_REGISTRATION_NO")
        private String VAT_REGISTRATION_NO;

        @JsonProperty("EV_ERROR")
        private String EV_ERROR;

        @JsonProperty("PARTNER_NUMBER")
        private String PARTNER_NUMBER;

        @JsonProperty("NAME")
        private String NAME;

        @JsonProperty("ADDRESS")
        private String ADDRESS;

        @JsonProperty("E_MAIL")
        private String E_MAIL;

        @JsonProperty("TELEPHONE")
        private String TELEPHONE;

        @JsonProperty("VENDOR_ROLE")
        private String VENDOR_ROLE;
    }
}
